-- cake
ENT.Type = "anim"
if (WireLib) then
    DEFINE_BASECLASS("base_wire_entity")
else
    DEFINE_BASECLASS("base_gmodentity")
end
ENT.PrintName = "Money Pot"
ENT.Author = "Lexi"
ENT.Spawnable = true
ENT.AdminSpawnable = false
