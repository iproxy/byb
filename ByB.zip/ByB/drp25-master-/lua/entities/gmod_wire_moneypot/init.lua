AddCSLuaFile("shared.lua")
include("shared.lua")

local BaseClass;
if (WireLib) then
    BaseClass = "base_wire_entity"
else
    BaseClass = "base_gmodentity"
end
DEFINE_BASECLASS(BaseClass);

ENT.IsMoneyPot = true;

function ENT:SpawnFunction( ply, tr )
	if not tr.Hit then return end
	local ent = ents.Create(self.ClassName or ClassName)
	ent:SetPos( tr.HitPos + tr.HitNormal * 52)
	ent:Spawn()
	ent:Activate()
	return ent
end 
	
function ENT:Initialize()
	self:SetModel("models/props_lab/powerbox02b.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
	self:UpdateOverlay()
    if (WireLib) then
        WireLib.CreateSpecialInputs(self, {
            "SpawnAll",
            "SpawnAmount"
        });
        WireLib.CreateSpecialOutputs(self, {
            "StoredAmount",
            "LastAmount",
            "Updated"
        });
    end
	local phys = self:GetPhysicsObject()
    if (not phys:IsValid()) then
        local mdl = self:GetModel()
        self:Remove();
        error("Entity of type " .. self.ClassName .. " created without a physobj! (Model: " .. mdl .. ")");
    end
    phys:Wake()
end

local function timr(self, amt)
	if (self:IsValid()) then
		self:SpawnAmount(amt);
		self.sparking = false;
	end
end

function ENT:Use(activator)
    self:DelayedSpawn(self:GetDTInt(0));
end

function ENT:UpdateWireOutputs(amount)
    if (not Wire_TriggerOutput) then return; end
    Wire_TriggerOutput(self, "StoredAmount", self:GetDTInt(0));
    Wire_TriggerOutput(self, "LastAmount", amount);
    Wire_TriggerOutput(self, "Updated", 1);
    Wire_TriggerOutput(self, "Updated", 0);
end

function ENT:StartTouch(ent)
	if ( ent:GetClass() == "spawned_money" or (ent:GetClass() == "darkrp_cheque" and IsValid(self.FPPOwner) and ent:Getrecipient() == self.FPPOwner) and (ent.MoneyPotPause or 0) < CurTime()) then
        ent.MoneyPotPause = CurTime() + 100 -- Fix a stupid glitch
		if ent.USED or ent.hasMerged then
			return
		else 
			ent.USED = true
			ent.hasMerged = true
		end -- sigh
		ent:Remove();
		local amount = 0		
		if ent:GetClass() == "spawned_money" then
		amount = ent.dt.amount or 0
		end
		
		if ent:GetClass() == "darkrp_cheque" then
		amount = ent:Getamount() or 0
		end
		
		self:SetDTInt(0, self:GetDTInt(0) + amount);
		self:UpdateOverlay();
        self:UpdateWireOutputs(amount);
	end
end

local spos = Vector(0, 0, 17);
function ENT:SpawnAmount(amount)
	amount = math.Clamp(amount, 0, self:GetDTInt(0));
	if (amount == 0) then return; end
    -- Prevent people spawning too many
    if (#ents.FindByClass("spawned_money") >= 50) then return; end
	
	local cash = ents.Create("spawned_money");
	cash:SetPos(self:LocalToWorld(spos));
	cash.dt.amount = amount;
	cash:Spawn();
	cash:Activate();
	cash.MoneyPotPause = CurTime() + 5;
	self:SetDTInt(0, self:GetDTInt(0) - amount);
    self:UpdateWireOutputs(-amount);
	self:UpdateOverlay()
end

-- For calling from lua (ie so /givemoney can give direct to it)
function ENT:AddMoney(amount)
    self:SetDTInt(0, self:GetDTInt(0) + amount);
    self:UpdateOverlay();
    self:UpdateWireOutputs(amount);
end

function ENT:UpdateOverlay()
	self:SetOverlayText("- Money Pot -\nAmount: $" .. self:GetDTInt(0));
end

function ENT:DelayedSpawn(amount)
	amount = math.Clamp(amount, 0, self:GetDTInt(0));
	if (amount == 0) then return; end
    if (self.DoSpawn) then
        self.DoSpawn = self.DoSpawn + amount;
    else
        self.DoSpawn = amount;
    end
    self.SpawnTime = CurTime() + 1;
end

-- From Moneyprinter
ENT.DoSpawn = false;
ENT.SpawnTime = 0;
function ENT:Think()
	BaseClass.Think(self);
    if (not self.DoSpawn) then
        return;
    end
    local ctime = CurTime();
    if (self.SpawnTime < ctime) then
        self:SpawnAmount(self.DoSpawn);
        self.DoSpawn = false;
        return;
    end

	local effectdata = EffectData();
	effectdata:SetOrigin(self:GetPos());
	effectdata:SetMagnitude(1);
	effectdata:SetScale(1);
	effectdata:SetRadius(2);
	util.Effect("Sparks", effectdata);
end

function ENT:OnRemove()
	self:SpawnAmount(self:GetDTInt(0))
	BaseClass.OnRemove(self);
end

function ENT:TriggerInput(key, value)
	if (key == "SpawnAll" and value ~= 0) then
		self:Use();
	elseif (key == "SpawnAmount"  and value ~= 0) then
        self:DelayedSpawn(value);
	end
end