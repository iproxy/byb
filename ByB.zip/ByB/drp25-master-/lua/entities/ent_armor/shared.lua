ENT.Type = "anim"
ENT.PrintName = "Armor"
ENT.Author = "Pantho"
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	--self:NetworkVar("Int",0,"price")
	--self:NetworkVar("Entity",1,"owning_ent")
end