---------------------------------
---------------------------------
---- Made By Greyfox -----
---------------------------------
---------------------------------

--clientside lua is BELOW THIS GOES IN lua/autorun/client folder 
-- you need to copy this code and then name the file cl_deathmessages.lua 

TimeToWait = 5 -- The time needed until the player can spawn again

function DrawDeathMessage() 
  

-- give me credit! 
local DeathMessages = { 
"You have died, you forget everything that happened in the past. Wait 5 sec to respawn.",  
} 
  
local LDFrame = vgui.Create( "DFrame" )  
LDFrame:SetPos( ScrW() / 2 - 250,ScrH() / 2 )  
LDFrame:SetSize( 512, 128 )  
LDFrame:SetTitle( "New Life Rule - NLR" )  
LDFrame:SetVisible( true )  
LDFrame:SetDraggable( true )  
LDFrame:ShowCloseButton( false ) 
LDFrame:SetBackgroundBlur( true )  
LDFrame:MakePopup() 
  
local PaintPanel = vgui.Create( "DPanel", LDFrame )  
  
PaintPanel:SetPos( 5, 25 )  
PaintPanel:SetSize( 490, 90 )  
PaintPanel.Paint = function()      
surface.SetDrawColor( 50, 50, 50, 255 )      
surface.DrawRect( 0, 0, PaintPanel:GetWide(), PaintPanel:GetTall() ) 
--PaintPanel:SetCursor("hand"); 
end 
  
local Dlabel = vgui.Create("DLabel", PaintPanel); 
    Dlabel:SetText(DeathMessages[math.random(1,#DeathMessages)]); 
    Dlabel:SetSize(490, 30); 
    Dlabel:SetPos(10, 20); 
  
  
local OKButton = vgui.Create("DButton", PaintPanel); 
    OKButton:SetText("Start a new life"); 
    OKButton:SetSize(100, 30); 
    OKButton:SetPos(10, 50); 
	OKButton:SetDisabled( true );
    OKButton.DoClick = function() 
        LDFrame:Close() 
        RunConsoleCommand("dmspawn") 
    end 
	
	timer.Simple( TimeToWait, function()
			OKButton:SetDisabled( false )
	end )
end 
concommand.Add("DrawDeathMsg", DrawDeathMessage)