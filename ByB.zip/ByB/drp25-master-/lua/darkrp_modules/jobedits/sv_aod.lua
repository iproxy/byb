hook.Add("PlayerSpawn", "AODModifiers", function(ply)
	timer.Simple(1, function()
		if IsValid(ply) and ply:Team() == TEAM_AOD then
			ply:SetRunSpeed(500)
			ply:GodEnable()
		end
	end)
end)