hook.Add("OnPlayerChangedTeam", "ProfMobModifiers", function(ply, prev, new)
	if IsValid(ply) and new == TEAM_PMOB then
		ply:SetArmor(100)
	end
end)