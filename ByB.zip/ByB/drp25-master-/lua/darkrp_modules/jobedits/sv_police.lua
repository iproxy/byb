--function plyMeta:isSwat()
--	if not IsValid(self) then return false end
--	local Team = self:Team()
--	return GAMEMODE.Swats and GAMEMODE.Swats[Team]
--end

hook.Add("PlayerSpawn", "PoliceModifiers", function(ply)
	timer.Simple(1, function()
		if IsValid(ply) and ply:isCP() then
			if GAMEMODE.Swats[ply:Team()] then
				ply:SetArmor(250)
				ply:SetHealth(100)
				ply:SetRunSpeed(240)
			else
				ply:SetArmor(100)
				ply:SetHealth(100)
				ply:SetRunSpeed(300)
			end			
		end
	end)
end)