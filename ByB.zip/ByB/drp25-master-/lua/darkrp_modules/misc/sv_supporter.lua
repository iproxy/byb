hook.Add("PlayerSpawn", "AODModifiers", function(ply)
	timer.Simple(1, function()
		if IsValid(ply) then
			ply:Give[[weapon_fists]]
		end
	end)
end)