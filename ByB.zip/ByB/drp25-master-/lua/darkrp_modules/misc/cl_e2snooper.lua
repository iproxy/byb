local Chips = {};
function DrawE2Menu()
	if not Chips then
		chat.Addtext(Color(255,0,0,255),"Sorry but no chip data has been received by server.");
		return
	end
	local Ply;
	local Menu = vgui.Create("DFrame");
	local Frame = vgui.Create("DPanel",Menu);
	local List = vgui.Create("DListView",Frame);
	local name = "<Nameless>";
	Menu:SetSize(750,550);
	Menu:Center();
	Menu:SetTitle("E2 Snooper");
	Menu:SetSizable(false);
	Menu:MakePopup();
	Frame:SetSize(Menu:GetWide()-25,Menu:GetTall()-40);
	Frame.Paint = function()
		surface.SetDrawColor( 135,175,175,255 )
		surface.DrawRect( 0, 0, Frame:GetWide(), Frame:GetTall() )
	end
	Frame:SetPos(10,30)
	List:SetSize(Frame:GetWide()-10,Frame:GetTall()-10);
	List:AddColumn("EntIndex");
	List:AddColumn("Owner");
	List:AddColumn("E2Name");
	List:AddColumn("Average");
	List:AddColumn("CurrentOps");
	List:AddColumn("CPU Time");
	List:SetPos(5,5)
	for k,v in pairs(Chips) do
		if IsValid(Entity(k)) then
			if IsValid(Entity(v[1])) and Entity(v[1]):IsPlayer() then 
				ply = Entity(v[1]);
				name = ply:Name();
			end
			List:AddLine(tostring(k),name,v[2],v[3],v[4],v[5])
		end
	end
	function List.OnRowSelected(panel,line)
		local int = List:GetLine(line):GetValue(1)
		net.Start("E2snopperfetch")
		net.WriteInt(int,32)
		net.SendToServer()
	end
end

function DrawE2TextBox(code)
	local Frame = vgui.Create("DFrame");
	local Box = vgui.Create("DPanel",Frame);
	local TextBoxHolder = vgui.Create("DPanelList",Box);
	local TextBox = vgui.Create("RichText",TextBoxHolder);
	--local LabelTest = vgui.Create("DLabel",TextBoxHolder)
	local Exit = vgui.Create("DButton",Box)
	code = code or "No code sent? - please inform fluffy overlords: ;Bug @ DrawE2TextBox func!";
	Frame:SetSize(ScrW()-80,ScrH()-50);
	Frame:Center();
	Box:SetSize(Frame:GetWide(),Frame:GetTall());
	Box:SetPos(5,20);
	Box:MakePopup();
	TextBoxHolder:SetSize(Box:GetWide()-10,Box:GetTall()-10);
	TextBoxHolder:SetPos(5,5);
	TextBoxHolder:EnableVerticalScrollbar(true)
	local n=0
	for i in code:gmatch("\n") do n=n+1 end
	n = n * 15
	if n > 1000 then n = n - 900 end
	TextBox:SetSize(TextBoxHolder:GetWide()-20,TextBoxHolder:GetTall()-20);
	TextBox:SetPos(2,2);
	TextBox:SetText("")
	TextBox.Paint = function()
		surface.SetDrawColor( 25,25,25,255 )
		surface.DrawRect( 0, 0, TextBox:GetWide(), TextBox:GetTall() )
	end
	local i =0
	while i<string.len(code) do
		TextBox:AppendText(string.sub(code,i,i+100))
		i = i + 101
	end
	TextBoxHolder:AddItem(TextBox);
	Box.Paint = function()
		surface.SetDrawColor( 145,115,115,255 )
		surface.DrawRect( 0, 0, Box:GetWide(), Box:GetTall() )
	end
	Exit:SetPos(5,Frame:GetTall()-25);
	Exit:SetText("Exit!");
	Exit:SetSize(Box:GetWide()-10,20);
	Exit.DoClick = function()
		Exit:GetParent():GetParent():Close();
	end
	Frame.Paint = function()
		surface.SetDrawColor( 0,0,0,0 );
	end
end


net.Receive("e2chipsnooper", function()
	Chips = net.ReadTable();
	DrawE2Menu();
end)

net.Receive("E2SnooperfileSend", function()
	local code = net.ReadString();
	DrawE2TextBox(code);
end)