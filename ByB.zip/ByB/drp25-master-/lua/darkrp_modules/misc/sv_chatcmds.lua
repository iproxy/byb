
util.AddNetworkString("911calls")
local function CombineRequest(ply, args)
	if args:gsub("%s", "") == "" then return end
	local t = ply:Team()
	local Coppers = {}
	for k, v in pairs(player.GetAll()) do
		if (v:isCP()) or v == ply then
			DarkRP.talkToPerson(v, team.GetColor(ply:Team()), "(Police) "..ply:Nick(), Color(255,0,0,255), args, ply)
			table.insert(Coppers,v)
		end
	end
	DarkRP.talkToRange(ply, ply:Nick() .. " called 911", "", 250)
	for k,v in pairs(Coppers) do
		if IsValid(v) and v:IsPlayer() then
			net.Start("911calls")
			net.WriteVector(ply:GetPos())
			net.Send(v)
		end
	end
	return ""
end
DarkRP.defineChatCommand("911", CombineRequest)

local function AdminMsg(ply, args)
	if args:gsub("%s", "") == "" then return end
	
	if (not ply:IsAdmin()) then
			--if (not ply:IsRoot()) then
				--GAMEMODE:Notify(ply, 1, 5, string.format(LANGUAGE.need_admin, "/a"))
				return ""
			--end
	end
	
	local audience = {}
	
	for k, v in pairs(player.GetAll()) do
		if v:IsAdmin() or v == ply or v.SAD then table.insert(audience, v) end
	end
	for k, v in pairs(audience) do
		DarkRP.talkToPerson(v, team.GetColor(ply:Team()), "(AdminChat) " ..ply:Nick(), Color(255,0,255,255), args, ply)
	end
	return ""		
end
timer.Simple(5,function()
DarkRP.removeChatCommand("a")
DarkRP.defineChatCommand("a", AdminMsg)
end)
--DarkRP.removeChatReceiver("/a")
