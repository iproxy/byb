-- Moo & Weasels hud material.
resource.AddFile("materials/hud_moomoo.png") 
-- M9k workshop files:
-- SCREW YOU GARRY! :(
-- if I add them via here I seem to have issues editing clientside lua, which sucks.
--resource.AddWorkshop(128093075) -- small arms pack
--resource.AddWorkshop(128089118) -- assault rifles pack
--resource.AddWorkshop(128091208)	-- heavy weapons pack
-- rp_bangclaw
--resource.AddWorkshop(111863064)
-- rp_downtown_v4_v2c
resource.AddWorkshop(110286060)

