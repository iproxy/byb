//  A list of hooks and timers that we want to modify, without altering the DarkRP code directly. //
// A lot of pointless copy & pasting to change 1 number at times, but at least darkrp isn't edited. //
// With love, //
// Fluffy Guy. //

-- just incase some of the code can't be ran until the server has loaded.
-- shouldn't matter, but might so we'll throw it inside here...
hook.Add("InitPostEntity", "HookTimerRedesign", function()
 
hook.Remove("PlayerNoClip", "FAdmin_noclip")
hook.Add("PlayerNoClip", "AdminNoclip", function(ply) 
    if (ply:isArrested()) then
        ply:ChatPrint("Can't noclip while arrested")
        return false
    end
	return ply:GetMoveType() == MOVETYPE_NOCLIP or ply:IsAdmin()
end)

local threed = GAMEMODE.Config.voice3D
local vrad = GAMEMODE.Config.voiceradius
local dynv = GAMEMODE.Config.dynamicvoice
-- Making it check less often, as we're mean.
hook.Remove("PlayerInitialSpawn", "DarkRPCanHearVoice")
local function calcPlyCanHearPlayerVoice(listener)
	if not IsValid(listener) then return end
	listener.DrpCanHear = listener.DrpCanHear or {}
	for _, talker in pairs(player.GetAll()) do
		listener.DrpCanHear[talker] = not vrad or -- Voiceradius is off, everyone can hear everyone
			(listener:GetShootPos():Distance(talker:GetShootPos()) < 550 and -- voiceradius is on and the two are within hearing distance
				(not dynv or IsInRoom(listener, talker))) -- Dynamic voice is on and players are in the same room
	end
end
hook.Add("PlayerInitialSpawn", "DarkRPCanHearVoice", function(ply)
	timer.Create(ply:UserID() .. "DarkRPCanHearPlayersVoice", 2, 0, fn.Curry(calcPlyCanHearPlayerVoice, 2)(ply))
end)
		
hook.Add("PlayerGiveSWEP", "StoppingNubsSWEPGIVE", function(ply, class)
	if IsValid(ply) and not ply:IsSuperAdmin() then 
		DarkRP.notify(ply, 1, 2, DarkRP.getPhrase("need_admin", "GAMEMODE_spawnsent"))
		return false
	end
end)
hook.Add("PlayerSpawnSENT", "StoppingNubsSENT", function(ply, class)
	if IsValid(ply) and not ply:IsSuperAdmin() then 
		DarkRP.notify(ply, 1, 2, DarkRP.getPhrase("need_admin", "GAMEMODE_spawnsent"))
		return false
	end
end)
hook.Add("PlayerSpawnSWEP", "StoppingNubsSWEP", function(ply, class)
	if IsValid(ply) and not ply:IsSuperAdmin() then
		DarkRP.notify(ply, 1, 2, DarkRP.getPhrase("need_admin", "GAMEMODE_spawnsent"))
		return false
	end
end)
hook.Add("PlayerSpawnEffect", "StoppingNubsEffect", function(ply, class)
	if IsValid(ply) and not ply:IsSuperAdmin() then
		DarkRP.notify(ply, 1, 2, DarkRP.getPhrase("need_admin", "GAMEMODE_spawnsent"))
		return false
	end
end)
hook.Add("PlayerSpawnRagdoll", "StoppingNubsRagdoll", function(ply, class)
	if IsValid(ply) and not ply:IsSuperAdmin() then
		DarkRP.notify(ply, 1, 2, DarkRP.getPhrase("need_admin", "GAMEMODE_spawnsent"))
		return false
	end
end)
hook.Add("PlayerSpawnVehicle", "StoppingNubsVeh", function(ply, class)
	if IsValid(ply) and not ply:IsSuperAdmin() then
		DarkRP.notify(ply, 1, 2, DarkRP.getPhrase("need_admin", "GAMEMODE_spawnsent"))
		return false
	end
end)

hook.Add("PlayerUse","playeruselogging", function(ply,ent)
	if IsValid(ent) and IsValid(ply) then 
		DarkRP.log(tostring(ply) .. " Has used entitiy "..tostring(ent))
	end
end)
hook.Add("OnPlayerHitGround", "Goomba", function(ply, in_water, on_floater, speed)
  if in_water or speed < 450 or not IsValid(ply) then return end

   -- Everything over a threshold hurts you, rising exponentially with speed
   local damage = math.pow(0.05 * (speed - 420), 1.75)

   -- I don't know exactly when on_floater is true, but it's probably when
   -- landing on something that is in water.
   if on_floater then damage = damage / 2 end

   -- if we fell on a dude, that hurts (him)
   local ground = ply:GetGroundEntity()
   if IsValid(ground) and ground:IsPlayer() then
      if math.floor(damage) > 0 then
         local att = ply

         -- if the faller was pushed, that person should get attrib
         local push = ply.was_pushed
         if push then
            -- TODO: move push time checking stuff into fn?
            if math.max(push.t or 0, push.hurt or 0) > CurTime() - 4 then
               att = push.att
            end
         end

         local dmg = DamageInfo()

         if att == ply then
            -- hijack physgun damage as a marker of this type of kill
            dmg:SetDamageType(DMG_CRUSH + DMG_PHYSGUN)
         else
            -- if attributing to pusher, show more generic crush msg for now
            dmg:SetDamageType(DMG_CRUSH)
         end

         dmg:SetAttacker(att)
         dmg:SetInflictor(att)
         dmg:SetDamageForce(Vector(0,0,-1))
         dmg:SetDamage(damage)

         ground:TakeDamageInfo(dmg)
      end

      -- our own falling damage is cushioned
      damage = damage / 3
   end

   if math.floor(damage) > 0 then
      local dmg = DamageInfo()
      dmg:SetDamageType(DMG_FALL)
      dmg:SetAttacker(game.GetWorld())
      dmg:SetInflictor(game.GetWorld())
      dmg:SetDamageForce(Vector(0,0,1))
      dmg:SetDamage(damage)

     ply:TakeDamageInfo(dmg)

      -- play CS:S fall sound if we got somewhat significant damage
      if damage > 5 then
         sound.Play(table.Random(fallsounds), ply:GetShootPos(), 55 + math.Clamp(damage, 0, 50), 100)
      end
   end
end)

function GAMEMODE:PlayerSpawnSENT(ply, class)
	if IsValid(ply) and ply:IsRoot() then
		return true
	end
	return false
end

function GAMEMODE:PlayerSpawnedSENT(ply, ent)
	if IsValid(ply) and ply:IsSuperAdmin() then
		return true
	end
	return false
end

local function canSpawnWeapon(ply)
	if IsValid(ply) and ply:IsRoot() then
		return true
	end
	return false
end

function GAMEMODE:PlayerSpawnSWEP(ply, class, info)
	if IsValid(ply) and ply:IsSuperAdmin() then
		return true
	end
	return false
end

function GAMEMODE:PlayerGiveSWEP(ply, class, info)
	if IsValid(ply) and ply:IsSuperAdmin() then
		return true
	end
	return false
end

function GAMEMODE:PlayerSpawnEffect(ply, model)
	if IsValid(ply) and ply:IsSuperAdmin() then
		return true
	end
	return false
end

function GAMEMODE:PlayerSpawnVehicle(ply, model, class, info)
	if IsValid(ply) and ply:IsSuperAdmin() then
		return true
	end
	return false
end

function GAMEMODE:PlayerSpawnedVehicle(ply, ent)
	if IsValid(ply) and ply:IsSuperAdmin() then
		return true
	end
	return false
end

function GAMEMODE:PlayerSpawnNPC(ply, type, weapon)
	if IsValid(ply) and ply:IsSuperAdmin() then
		return true
	end
	return false
end

function GAMEMODE:PlayerSpawnedNPC(ply, ent)
	if IsValid(ply) and ply:IsSuperAdmin() then
		return true
	end
	return false
end

function GAMEMODE:PlayerSpawnRagdoll(ply, model)
	if IsValid(ply) and ply:IsSuperAdmin() then
		return true
	end
	return false
end

function GAMEMODE:PlayerSpawnedRagdoll(ply, model, ent)
	if IsValid(ply) and ply:IsSuperAdmin() then
		return true
	end
	return false
end

concommand.Add( "gmod_admin_cleanup",function() end)

end)