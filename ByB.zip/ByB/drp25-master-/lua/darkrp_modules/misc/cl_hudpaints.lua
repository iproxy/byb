local function RootToggle() 
   if (LocalPlayer().RootMode)
      then LocalPlayer().RootMode = false
   else
      LocalPlayer().RootMode = true
   end
end
usermessage.Hook("ToggleRoot", RootToggle)

concommand.Add("HaxToggle", function(ply,_,_)
	if ply.HaxOn == true then
		ply.HaxOn = false
		ply:ChatPrint("Hax are now off darling!")
	elseif ply.RootMode then 
		ply.HaxOn = true 
		ply:ChatPrint("Hax enabled Mr Root Slut!")
	elseif ply:Team() == 22 then
		ply.HaxOn = true
		ply:ChatPrint("Hax on babeh!")
	else
		ply.HaxOn = false
		ply:ChatPrint("You don't appear to be allowed to use this command.")
	end
end)

-- The simple ent and player tracking for super admin on duty
hook.Add("HUDPaint", "EntTracker", function() 
	if not LocalPlayer().HaxOn then
		LocalPlayer().TrackEnt = ""
		return
	end
	for k,v in pairs ( player.GetAll() ) do 		
		local TeamCol = team.GetColor( v:Team()  )
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen() 
		draw.SimpleText( v:Name(), "Default", Position.x, Position.y, TeamCol )
	end 
	local ent = LocalPlayer():GetEyeTrace().Entity;
	if IsValid(ent) then
		draw.SimpleText( "Ent ClassName: " .. ent:GetClass(), "Default", 5, 1,  color_white )
		draw.SimpleText( "Ent Model: " ..     ent:GetModel(), "Default", 5, 30, color_white )
		draw.SimpleText( "Ent ID: " ..        ent:EntIndex(), "Default", 5, 60, color_white )
	end
	if not LocalPlayer().TrackEnt or LocalPlayer().TrackEnt == "" then
		return
	end
	
	local TrackEnt = string.Explode(";", LocalPlayer().TrackEnt)
		
	local colours = {
	Color(255,255,255,255), 	-- white
	Color(255,0,0,255),			-- red
	Color(0,255,0,255),			-- green
	Color(0,0,255,255),			-- blue
	Color(158,61,255,255),		-- purple
	Color(127,255,0,255),		-- chartreuse (happy ride?)
	}
	
	local ccount = 1
	
	for k,v in pairs(TrackEnt) do
	
		for k,v in pairs ( ents.FindByClass(v) ) do
			local Position = ( v:GetPos() + Vector( 0,0,0 ) ):ToScreen() 
			draw.SimpleText( v:GetClass(), "Default", Position.x, Position.y, colours[ccount] )
		end
	
		if ccount >= table.getn(colours) then ccount = 1 else ccount = ccount + 1 end
	
	end
	
end)

concommand.Add("TrackEnt", function(ply,_,args)

	if not LocalPlayer().HaxOn then
		ply:ChatPrint("You don't appear to be allowed to use this command.")
		return
	end

	if next(args) == nil then
		ply:ChatPrint("Tracking cleared.")
		LocalPlayer().TrackEnt = ""
	else
	
		local ttext = ""

		for k,v in pairs(args) do
			ttext = ttext .. " " .. v
		end
	
		ply:ChatPrint("Tracking:" .. ttext)
	
		LocalPlayer().TrackEnt = tostring(table.concat(args, ";"))
	
	end
end)


local copcalls = copcalls or {}
local cin = (math.sin(CurTime()) + 1) / 2
local col = Color(cin * 255, 0, 255 - (cin * 255), 255)
local pos
local ct = CurTime()
surface.CreateFont( "CopFont", {
 font = "coolvetica",
 size = 23,
 weight = 500,
 antialias = true,
 shadow = true,
} )
net.Receive("911calls", function ()
	if CurTime() < ct then return end
	if not LocalPlayer():isCP() then return end
    local callpos = net.ReadVector()
	table.insert(copcalls,callpos)
	timer.Simple(15, function() ct = CurTime() + 15 copcalls = {} end)
end)
hook.Add("HUDPaint", "911callsforhud", function()
	if not IsValid(LocalPlayer()) then return end
	cin = (math.sin(CurTime()) + 1) / 2
	for k,v in pairs(copcalls) do 
		pos = (v + Vector(0,0,50)):ToScreen()
		dist = v:Distance(LocalPlayer():GetPos())
		draw.SimpleText("911 Call @ " .. math.floor(dist,1), "CopFont",pos.x ,pos.y , Color(cin * 255, 0, 255 - (cin * 255), 255))
	end
end)

hook.Add("DrawDeathNotice", thetype, function(x,y)
	if LocalPlayer():IsAdmin() then
		self.BaseClass:DrawDeathNotice(x, y)
	end
end)


net.Receive("911calls", function ()
	if CurTime() < ct then return end
    local callpos = net.ReadVector()
	table.insert(copcalls,callpos)
	timer.Simple(15, function() ct = CurTime() + 15 copcalls = {} end)
end)
hook.Add("HUDPaint", "911callsforhud", function()
	if not IsValid(LocalPlayer()) then return end
	cin = (math.sin(CurTime()) + 1) / 2
	for k,v in pairs(copcalls) do 
		pos = (v + Vector(0,0,50)):ToScreen()
		dist = v:Distance(LocalPlayer():GetPos())
		draw.SimpleText("911 Call @ " .. math.floor(dist,1), "CopFont",pos.x ,pos.y , Color(cin * 255, 0, 255 - (cin * 255), 255))
	end
end)