local limit_mul = {
	supporter = {
		props = 2,
	},
	adminsupporter = {
		props = 2,
	},
}

local limit_mod = {
	supporter = {
	},
	adminsupporter = {
	},
}

-- ---------------------------------------------------------
--   Name: UnoLimits
--   Author: Garry 99% - Megiddo .75% - JamminR .25% - A "Team" Ulysses idea
--   Desc: Allows SuperAdmins and Admins to spawn past the sbox_max limits.
--   v1 release to Ulysses - v1.1 - Fixed sents (evil garry)
-- ---------------------------------------------------------
local function LimitReachedProcess( ply, str )
	// Always allow in single player
	--if (SinglePlayer()) then return true end
	if ply:IsRoot() then return true end	

	local c = GetConVarNumber( "sbox_max"..str, 0 )
	local usergroup = ply:IsSupporter() and (ply:IsAdmin() and "adminsupporter" or "supporter")
	
	if limit_mod[usergroup] and limit_mod[usergroup][str] then
		c = limit_mod[usergroup][str]
		--	PrintMessage( HUD_PRINTTALK, " 1 debug"  )
	end
	if limit_mul[usergroup] and limit_mul[usergroup][str] then
		c = math.floor(c * limit_mul[usergroup][str])
	end
	
	if ( ply:GetCount( str ) < c || c < 0 ) then return true end

	ply:LimitHit( str )
	return false
end


local function init()

function CCSpawn( player, command, arguments )
	if arguments[1] == nil then return end
	if player:isArrested() then return false end
	--if RPArrestedPlayers[player:SteamID()] then return end
	local model = arguments[1]:gsub("\\", "/"):lower()
	for k, v in pairs(BannedProps) do
		if string.lower(v) == model then 
			DarkRP.notify(player, 1, 4, "You can't spawn this prop as it is banned. "..model) 
			DB.Log(player:SteamName().." ("..player:SteamID()..") tried to spawn banned prop "..model)
			return 
		end
	end
	if !gamemode.Call( "PlayerSpawnObject", player ) then return end
	if !util.IsValidModel( arguments[1] ) then return end
	
	local iSkin = arguments[2] or 0

	if util.IsValidProp( arguments[1] ) then 
		GMODSpawnProp( player, arguments[1], iSkin )
		return
	end
	
	if util.IsValidRagdoll( arguments[1] ) then 
		GMODSpawnRagdoll( player, arguments[1], iSkin )
		return
	end

	// Not a ragdoll or prop.. must be an 'effect' - spawn it as one
	GMODSpawnEffect( player, arguments[1], iSkin )
end
concommand.Add( "gm_spawn", CCSpawn, nil, "Spawns props/ragdolls" )

-- ---------------------------------------------------------
--   Name: gamemode:PlayerSpawnRagdoll( ply, model )
--   Desc: Return true if it's allowed
-- ---------------------------------------------------------
function GAMEMODE:PlayerSpawnRagdoll( ply, model )

	return LimitReachedProcess( ply, "ragdolls" )

end

-- ---------------------------------------------------------
--   Name: gamemode:PlayerSpawnProp( ply, model )
--   Desc: Return true if it's allowed
-- ---------------------------------------------------------
function GAMEMODE:PlayerSpawnProp( ply, model )
	--if RPArrestedPlayers[ply:SteamID()] then return false end
	model = string.gsub(model, "\\", "/")

	if string.find(model,  "//") then DarkRP.notify(ply, 1, 4, "You can't spawn this prop as it contains an invalid path. " ..model) 
		DB.Log(ply:SteamName().." ("..ply:SteamID()..") tried to spawn prop with an invalid path "..model)
		return false
	end

	return LimitReachedProcess( ply, "props" )
end


-- ---------------------------------------------------------
--   Name: gamemode:PlayerSpawnEffect( ply, model )
--   Desc: Return true if it's allowed
-- ---------------------------------------------------------
function GAMEMODE:PlayerSpawnEffect( ply, model )

	return LimitReachedProcess( ply, "effects" )

end

-- ---------------------------------------------------------
--   Name: gamemode:PlayerSpawnVehicle( ply )
--   Desc: Return true if it's allowed
-- ---------------------------------------------------------
function GAMEMODE:PlayerSpawnVehicle( ply )

	return LimitReachedProcess( ply, "vehicles" )

end

-- ---------------------------------------------------------
--   Name: gamemode:PlayerSpawnSENT( ply, name )
--   Desc: Return true if player is allowed to spawn the SENT
-- ---------------------------------------------------------
-- Commented out since Garry's now just always returns true. This may change some day...year...etc
function GAMEMODE:PlayerSpawnSENT( ply, name )

 	return LimitReachedProcess( ply, "sents" )
end
function GAMEMODE:PlayerSpawnSWEP( ply, name )

 	return LimitReachedProcess( ply, "sweps" )
end
--
-- ---------------------------------------------------------
--   Name: gamemode:PlayerSpawnNPC( ply, npc_type )   GM:PlayerSpawnSWEP
--   Desc: Return true if player is allowed to spawn the NPC
-- ---------------------------------------------------------
function GAMEMODE:PlayerSpawnNPC( ply, npc_type, equipment )

	--return LimitReachedProcess( ply, "npcs" )
	return false

end

local meta = FindMetaTable( "Player" )
// Return if there's nothing to add on to
if (!meta) then return end

function meta:CheckLimit( str )
	return LimitReachedProcess(self, str)

end

end

hook.Add( "InitPostEntity", "LimitInitilize", init )

