
-- just incase some of the code can't be ran until the server has loaded.
-- shouldn't matter, but might so we'll throw it inside here...
hook.Add("InitPostEntity", "Customproprot", function()

local dupeblacklist = {"money_black_printer","money_coal_printer","money_coolant_cell","money_diamond_printer","money_emerald_printer","money_pearl_printer","money_sapphire_printer","money_white_printer","money_normal_printer","money_printer","weapon_crowbar", "weapon_physgun", "weapon_physcannon", "weapon_pistol", "weapon_stunstick", "weapon_357", "weapon_smg1",
	"weapon_ar2", "weapon_shotgun", "weapon_crossbow", "weapon_frag", "weapon_rpg", "gmod_tool", "weapon_bugbait","ammo_machine","m9k_thrown_harpoon"} --for advanced duplicator, you can't use any IsWeapon...
ToolTable = {"Global","Supporter Only","Entities","EntCreation"}
TestTable = {}
ToolTable["Global"] = {}
ToolTable["Supporter Only"] = {}
ToolTable["Entities"] = {}
ToolTable["EntCreation"] = {}

timer.Simple(10, function()	
	for k,v in pairs(weapons.GetList()) do
		if v.ClassName then table.insert(dupeblacklist, v.ClassName) end -- Not sure why this has to go in a timer, it gets a bit bitchy at being ran on server load even inside a the initpost hook.
	end
	MySQLite.query("SELECT list FROM darkrp.tooltable_global;", function(data) -- globally blacklisted tools
		if data then
		   for k,v in pairs(data) do
			ToolTable["Global"][k] = data[k].list
		   end	   
		end
	end)
	MySQLite.query("SELECT list FROM darkrp.tooltable_supporter;", function(data) -- Tools only supporters can use
		if data then 
		   for k,v in pairs(data) do
			ToolTable["Supporter Only"][k] = data[k].list
		   end
		end
	end)
	MySQLite.query("SELECT list FROM darkrp.tooltable_entities;", function(data) -- Entities nobody can use toolgun on
		   for k,v in pairs(data) do
			ToolTable["Entities"][k] = data[k].list
            table.insert(dupeblacklist, data[k].list)
		   end
	end)
	MySQLite.query("SELECT list FROM darkrp.tooltable_entitycreate;", function(data) -- Entities we always want to delete, no matter how they are spawned
		if data then
			for k,v in pairs(data) do
			ToolTable["EntCreation"][k] = data[k].list
            table.insert(dupeblacklist, data[k].list)
		   end
		end
	end)
end)

-- The bases of my toolgun restriction
-- I've split this into multiple hooks while I'm developing it. Then if one dies the rest doesn't.
local Owner
local matblacklist = {
	"models/props_c17/fence01a.mdl",
	"models/props_c17/fence01a.mdl",
	"models/props_c17/fence01b.mdl",
	"models/props_c17/fence01b.mdl",
	"models/props_c17/fence02a.mdl",
	"models/props_c17/fence02a.mdl",
	"models/props_c17/fence02b.mdl",
	"models/props_c17/fence02b.mdl",
	"models/props_c17/fence03a.mdl",
	"models/props_c17/fence03a.mdl",
	"models/props_c17/fence04a.mdl",
	"models/props_c17/fence04a.mdl",
	"models/props_c17/gate_door02a.mdl",
	"models/props_c17/gate_door02a.mdl",
	"models/props_c17/gate_door01a.mdl",
	"models/props_c17/gate_door01a.mdl"
}

hook.Add( "CanTool", "ToolRestrict", function( ply, tr, tool )
	if ply.RootMode then 		
		DarkRP.log(ply:Name() .. " : ("..ply:SteamID()..") Has used tool" ..tool)
		return true 
	end
	if IsValid(tr.Entity.FPPOwner) then
		Owner = "("..tr.Entity.FPPOwner:SteamID() ..") "tr.Entity.FPPOwner:Name()
	elseif IsValid(tr.Entity.Owner) then		
		Owner = "("..tr.Entity.Owner:SteamID() ..") "tr.Entity.Owner:Name()
	else
		Owner = "-Invalid-"
	end
	DarkRP.log(ply:Name() .. " : ("..ply:SteamID()..") Has used tool " ..tool.." On prop owned by " .. Owner )
	
	for k,v in pairs(ToolTable["Entities"]) do  
		if IsValid(tr.Entity) and string.match( string.lower(tr.Entity:GetClass()),v) then
			ply:ChatPrint("You may not use tools on roleplay entities.")
			return false
		end
	end
	for k,v in pairs(ToolTable["Global"]) do
		if tool == v then
			ply:ChatPrint("This tool is global blacklisted from either abuse or crash exploits!")
			return false
		end
	end
	for k,v in pairs(ToolTable["Supporter Only"]) do
		if not ply:IsSupporter() then
			if tool == v then
				ply:ChatPrint("This tool has been restricted to our VIP/Supporter rank. Info @ www.bybservers.co.uk")
				return false
			end
		end
	end
	if IsValid(tr.Entity) and tool == "material" or tool == "colmatter" then
		local m = tr.Entity:GetModel() or ""
		for k,v in pairs(matblacklist) do
			if string.lower(m) == string.lower(v) then return false end
		end
	end
end)
-- Backup ent creation removal and removes blocked models from entities.
hook.Add( "OnEntityCreated", "Blacklisted ent removal", function(ent)
	for _,v in pairs(ToolTable["EntCreation"]) do
		if IsValid(ent) and string.match( string.lower(ent:GetClass()),v) then
         ent:Remove()
			return false
        end
        timer.Simple(0.1, function()
            if IsValid(ent) then
                local entmod = ent:GetModel() or ""
				BannedProps = BannedProps or {}
                for _,d in pairs(BannedProps) do
                    if string.lower(entmod) == string.lower(d) then
                    	local x = string.lower(ent:GetClass())
                    	for o,p in pairs(dupeblacklist) do
                    		if string.lower(p) == x then return end
                    	end
                        --if ent:GetClass() == "money_printer" or ent:GetClass() == "letter" or ent:GetClass() == "becki_box" or ent:GetClass() == "spawned_shipment" or ent:GetClass() == "ammo_machine" then
                        --    return
                        --end
                    	ent:Remove()
                    	return
                    end
                end
            end
        end)
	end
end)


-- Basic prop kill protection
local function GravPunter(ply, ent)
    if not IsValid(ply) then return end
    if ply.RootMode then return true end
    return false
end
hook.Add("GravGunPunt", "Dontyapuntyme", GravPunter)

function AntiPropDamage( target, inflictor )
	if IsValid(target) and target:IsNPC() then return false end
	if not IsValid(inflictor) then return end
	if inflictor:IsVehicle() then return end
	if target:InVehicle() and inflcitor ~= target then return false end
    if inflictor:IsPlayer() and (IsValid(inflictor:GetActiveWeapon())) and inflictor:GetActiveWeapon():GetClass() == "weapon_physcannon" then return false end
	if inflictor.IsMoneyPrinter then return end
	if not inflictor:IsPlayer() then return false end
end
hook.Add("PlayerShouldTakeDamage", "Anti PropDamage", AntiPropDamage)
local function AntiPropKill( ply, ent )
    if not IsValid(ent) then return end 
    ent:SetPos(ent:GetPos())--That trick resets velocity
end
hook.Add("PhysgunDrop", "Anti PropKill", AntiPropKill)
-- crushing is always 200, so here.
local function PropCrushingOff(target, dmginfo)
	if (dmginfo:GetAttacker() == game.GetWorld( ) and dmginfo:GetDamage() == 200) then
		dmginfo:SetDamage(0)
	end
end
hook.Add("EntityTakeDamage", "PropCrushingOff", PropCrushingOff)


local function MassWeld(ply)
	ply.MassWeldCD = ply.MassWeldCD or 0
	if not ply:IsSupporter() then return end
	local base = ply:GetEyeTrace().Entity
	if not IsValid(base) then ply:ChatPrint("You must be looking at a prop to be the base prop") return end
	if not IsValid(base.FPPOwner) and not ply == base.FPPOwner then return end
	DarkRP.log("Mass Weld is happening, if this crash blame: "..ply:SteamID())
	if ply.MassWeldCD > CurTime() then ply:ChatPrint("cmd can only be ran every 3 minutes") return end
	for k,ent in pairs(ents.GetAll()) do
		if (IsValid(ent.FPPOwner) and ent.FPPOwner == ply)then 
			if ent:GetClass() == "money_printer" or ent:GetClass() == "spawned_money" or ent:GetClass() == "prop_vehicle_jeep" or FPP.Blocked.Spawning1[string.lower(ent:GetClass())]then 
			else
				constraint.Weld(base,ent,0,0,0,true)
			end
		end
	end
	ply.MassWeldCD = CurTime() + 180
	ply:ChatPrint("Oly run this when needed. On 100 props it might be a bit evil")
end
concommand.Add("pleaseweldthisstuff", MassWeld )
concommand.Add("weldall", MassWeld )

local function DelayPlayerUnfreezeObject( pl, ent, object )

if not (ent.Owner == pl) or not (ent.FPPOwner == pl) then return 0 end

-- Not frozen!
if ( object:IsMoveable() ) then return 0 end

-- Unfreezable means it can't be frozen or unfrozen.
-- This prevents the player unfreezing the gmod_anchor entity.
if ( ent:GetUnFreezable() ) then return 0 end



-- NOTE: IF YOU'RE MAKING SOME KIND OF PROP PROTECTOR THEN HOOK "CanPlayerUnfreeze"
if ( !gamemode.Call( "CanPlayerUnfreeze", pl, ent, object ) ) then return 0 end

object:EnableMotion( true )
object:Wake()

gamemode.Call( "PlayerUnfrozeObject", pl, ent, object )

return 1

end

-- Stolen from [SFX]Fox's addon - http://steamcommunity.com/sharedfiles/filedetails/?id=120262616
function DelayUnFreezePhysProp(_, ply)

    if !ply.lastfreezedelay or ply.lastfreezedelay + .5 < CurTime() then
    
        local unfreezeable = 0
    
        local tr = ply:GetEyeTrace()
        if ( tr.HitNonWorld && tr.Entity:IsValid() ) then
        
        local Ents = constraint.GetAllConstrainedEntities( tr.Entity )
    
            
                for k, ent in pairs( Ents ) do
            
                    local objects = ent:GetPhysicsObjectCount()
                   
                    for i=1, objects do
            
                        local physobject = ent:GetPhysicsObjectNum( i-1 )
                        
                        if !physobject:IsMoveable() and !ent:GetUnFreezable() then
                        
                            gamemode.Call( "PlayerUnfrozeObject", ply, ent, physobject )
                            gamemode.Call( "PlayerFrozeObject", ply, ent, physobject )
                            unfreezeable = 1
                        end
                    end
              end

              if unfreezeable == 1 then
					ply:SendLua("LocalPlayer():EmitSound('buttons/blip1.wav')") 
                    ply:SendLua("GAMEMODE:AddNotify(\"Keep holding to unfreeze.\", NOTIFY_GENERIC, 1.5)")     
              end
        
    
            timer.Create( "unfreezedelay", 1, 1, function()
                if ply:KeyDown( IN_RELOAD ) then
				 
					-- send two blips when unfrozen
					ply:SendLua([[ LocalPlayer():EmitSound('buttons/blip1.wav') timer.Simple(.2, function() LocalPlayer():EmitSound('buttons/blip1.wav') end) ]]) 
                    local Ents = constraint.GetAllConstrainedEntities( tr.Entity )
                    local UnfrozenObjects = 0
					
                    for k, ent in pairs( Ents ) do
                
                        local objects = ent:GetPhysicsObjectCount()
                       
                        for i=1, objects do
                
                            local physobject = ent:GetPhysicsObjectNum( i-1 )
        
                            UnfrozenObjects = UnfrozenObjects + DelayPlayerUnfreezeObject( ply, ent, physobject )
                        end
                    end 
                    
                    if ( UnfrozenObjects > 0 ) then
                        local unfreezemessage = 'GAMEMODE:AddNotify(\"Unfroze " .. ' ..UnfrozenObjects.. ' .. " Objects\", NOTIFY_GENERIC, 3)'
                        ply:SendLua( unfreezemessage )
                    end
                    ply:SuppressHint( "PhysgunReload" )
                    
                else
                
                    for k, ent in pairs( Ents ) do
            
                        local objects = ent:GetPhysicsObjectCount()
                   
                        for i=1, objects do
            
                            local physobject = ent:GetPhysicsObjectNum( i-1 )
                        
                            if  !physobject:IsMoveable() and !ent:GetUnFreezable() then
                                gamemode.Call( "PlayerFrozeObject", ply, ent, physobject )
                            end
                            
                       end
                    
                    end 
            
                end
        
            end)
        end
        
    ply.lastfreezedelay = CurTime()
    
    end    

    return false
end
hook.Add("OnPhysgunReload", "StopUnFreezePhysProp", DelayUnFreezePhysProp)   
end)