local function pdclose()
    for _, ent in pairs(ents.FindByClass'prop_door_rotating') do
        if (ent.DoorData and ent.DoorData.GroupOwn == "Authorised Personnel Only") then
            ent:Fire("close");
            ent:Fire("lock");
        end
    end
    for k,v in pairs(ents.FindByClass[[sent_keypad]]) do if v:GetPos() == Vector(0,0,0) then v:Remove() end end -- Small fix for keypad exploits, figured I'd add it here instead of making another timer. It's only temp anyway - pantho.
end
--timer.Create("pdclose", 360, 0, pdclose);
bybhl2ents = bybhl2ents or {}
local function RechangeEnts()
    for k,v in pairs(bybhl2ents) do
        if IsValid(v) then
            v:Fire("Recharge")
        end
    end
end
timer.Create("rechargeents",180,0, RechangeEnts)

function ChatPrint(msg)
    PrintMessage(HUD_PRINTTALK, msg);
end

hook.Add("PlayerAuthed", "Root Admin Shenanigans", function(ply, steamid)
    print("PlayerAuth hook")
	-- Makes jump height more like GM12
	ply:SetJumpPower(200)
	GAMEMODE.RootAdmins = GAMEMODE.RootAdmins or {}
    local name = GAMEMODE.RootAdmins[steamid];
    if (not name) then return; end
    -- Assign the admin to a variable with their name.
    _G[name] = ply;
    ply.IsRootAdmin = true;
end)

-- Just in case :B
game.ReallyCleanUpMap = game.CleanUpMap;
function game.CleanUpMap()
return false
end

concommand.Add("spawn",function(ply, _, args)
    if (not ply:IsRoot()) then
        return;
    end
    local trace = ply:GetEyeTrace();
    if not trace.Hit then return end
    local ent = {}
    for var=1, args[2] or 1 do
        ent[var] = ents.Create(args[1]);
        ent[var]:SetPos(trace.HitPos);
        ent[var].FPPOwner = ply;
        ent[var]:Spawn();
    end
end)

concommand.Add("print_owner",function(ply,cmd,args)
    if not (ply:IsAdmin()) then return end
    local ent = ply:GetEyeTrace().Entity;
    if ent.STID then
        ply:ChatPrint("Owner ID: " .. ent.STID .. " | Ent ID: " .. ent:EntIndex() .. " | Location: " .. tostring(ent:GetPos()));
    else
        ply:ChatPrint("Unknown");
    end
end)


do
    local tell = FindMetaTable'Player'.ChatPrint;
    local tellall = ChatPrint;
    local function killall(ent)
        if (ent == "spawned_shipment" or ent == "empty_shipment") then
            local empty = ent == "empty_shipment";
            ent = "spawned_shipment";
            for _, ent in pairs(ents.FindByClass(ent)) do
                if ((empty and not ent.ShipmentInfo) or (not empty and ent.ShipmentInfo)) then
                    ent:Remove()
                end
            end
        else
            for _, ent in pairs(ents.FindByClass(ent)) do
                ent:Remove();
            end
        end
    end
    local function getcount(ent)
        if (ent == "spawned_shipment" or ent == "empty_shipment") then
            local count = 0;
            local empty = ent == "empty_shipment";
            ent = "spawned_shipment";
            for _, ent in pairs(ents.FindByClass(ent)) do
                if ((empty and not ent.ShipmentInfo) or (not empty and ent.ShipmentInfo)) then
                    count = count + 1;
                end
            end
            return count;
        else
            return #ents.FindByClass(ent);
        end
    end

    local physpurgable = {
        phys_constraintsystems  = 100;
        phys_constraint         = 200;
        logic_collision_pairs   = 200;
    };
    local enablemotionfor = {
        spawned_shipment          = true;
        money_printer             = true;
        prop_vehicle_jeep         = true;
        prop_vehicle_prisoner_pod = true; -- should fix it, mebbie not.
		};
    local function physpurge()
        local phys;
        for _, ent in pairs (ents.GetAll()) do
            phys = ent:GetPhysicsObject()
            -- Enable motion for things that shouldn't be frozen
            if (enablemotionfor[ent:GetClass()]) then
				if ent.MapSeat then
					phys:EnableMotion(false);
				else
					phys:EnableMotion(true);
				end
            -- Freeze everything else
            elseif (phys:IsValid()) then
                phys:EnableMotion(false);
            end
            -- Wipe any constraints attached to this entitiy
            constraint.RemoveAll(ent)
        end
    end

    local tocount = {
        spawned_money    = "bits of cash";
        sent_keypad      = "keypads";
        spawned_weapon   = "loose weapons";
        empty_shipment   = "empty shipments";
        spawned_shipment = "shipments";
        money_printer    = "money printers";
		gmod_wire_expression2 = "E2 Chips";
    };
    local antilags = {
        empty_shipment = {
            num = 10;
            msg = "Too many empty boxes on the server! Don't spawn 'em until you need 'em!";
        };
        spawned_money = {
            num = 20;
            msg = "Too many bits of loose cash on the server! Pick your money up faster next time!";
        };
        spawned_weapon = {
            num = 30;
            msg = "Too many loose weapons on the server! Try storing your guns in empty boxes next time?";
        };
    };

    local function cclagcheck(ply, _, args)
        if (IsValid(ply) and not ply:IsTrustedAdmin()) then
            return;
        end
        -- Informative spam
        local blame = IsValid(ply) and ply:Name() or "Console";
        local counts = {};
        for class, desc in pairs(tocount) do
            table.insert(counts, string.format("%d %s,", getcount(class), desc));
        end
        for _, ply in pairs(player.GetAll()) do
            if (not ply:IsAdmin()) then continue; end
            tell(ply, "Entity count, courtesy of " .. blame .. ":");
            tell(ply, "There are currently:");
            for _, words in pairs(counts) do
                tell(ply, words);
            end
            tell(ply, "On the map right now.");
        end

        if (args[1]) then
            return;
        end

        -- Anti-lag shenanigans
        for class, tab in pairs(antilags) do
            if (getcount(class) > tab.num) then
                tellall(tab.msg);
                killall(class);
            end
        end

        -- Damn you physics
        for class, maxcount in pairs(physpurgable) do
            if (getcount(class) > maxcount) then
                tellall("Over " .. maxcount .. " " .. class .. " entities on the server! Removing all constraints . . .");
                physpurge();
                break;
            end
        end
		ply:ChatPrint("New command e2checker via console will check status of E2 chips for abuse")

    end
    local function cclagcheckdisabled(ply)
        if (IsValid(ply)) then
            if (not ply:IsTrustedAdmin()) then
                return;
            end
            ply:ChatPrint("Use `lagcheck disabled` next time.");
        end
        cclagcheck(ply, _, {"disabled"});
    end
    local function ccpurgephys(ply)
        if (ply:IsSuperAdmin()) then
            physpurge();
        end
    end
    local function cckillall(ply, _, args)
        if (ply:IsSuperAdmin() and args[1]) then
            killall(args[1]);
        end
    end
    local function cccleanarrows(ply)
        if (ply:IsAdmin()) then
            killall("ent_mad_arrow");
        end
    end
    local function cccleankeypads(ply)
        if (ply:IsAdmin()) then
            for k,v in pairs(ents.FindByClass[[sent_keypad]]) do if v:GetPos() == Vector(0,0,0) then v:Remove() end end
        end
    end
    concommand.Add("lagcheck", cclagcheck);
    concommand.Add("lagcheckdisabled", cclagcheckdisabled);
    concommand.Add("worldender", ccpurgephys);
    concommand.Add("entremove", cckillall);
    concommand.Add("cleanarrows", cccleanarrows);
    concommand.Add("cleankeypads", cccleankeypads);
	local function cce2check(ply, _, args)
		if (IsValid(ply) and not ply:IsAdmin()) then
			return;
		end
		local count = 0
		for k,ent in pairs(ents.FindByClass[[gmod_wire_expression2]]) do
			if ent.context and ent.context.prfbench then -- how does an e2 not have a .context ... 
				local ops = math.Round(ent.context.prfbench,0) or "Error?"
				local owner = (IsValid(ent.FPPOwner) and ent.FPPOwner:Nick()) or "Unknown"
				local ownerid = (IsValid(ent.FPPOwner) and ent.FPPOwner:SteamID()) or "--"
				ply:ChatPrint("E2 Chip: " .. ent.name .. "(Ent " .. ent:EntIndex() .. ") Owner: " .. owner .. "(" .. ownerid ..") @ OPS: " .. ops)
				count = count+1
			end
		end
		if count == 0 then
			ply:ChatPrint([[No E2 chips found.]])
		end		
	end
	concommand.Add("e2checker",cce2check)
end

concommand.Add("heal",function(ply, _, args)
    if (not ply:IsSuperAdmin()) then
        return;
    end
    local pl = ply;
    if (args[1]) then
        pl = FindPlayer(args[1]);
        if (not IsValid(pl)) then
            ply:ChatPrint("who?");
            return;
        end
    end
    pl:SetHealth(100)
    local max = 100 --ply:GetClassArmor();
    if (max < 100) then
        max = 100;
    end
    ply:SetArmor(max);
	DB.Log(ply:Name().."("..ply:SteamID()..") healed "..ply:Name().."("..ply:SteamID()..")")
end);

concommand.Add("cleardecals", function(ply)
    if (ply:IsAdmin()) then
        for _, ply in pairs(player.GetAll()) do
            ply:ConCommand[[r_cleardecals]]
        end
    end     
end);

hook.Add( "CanTool", "BlockCameraSpam", function( ply, tool, tr ) 
    if tool == "rtcamera" and ( ply:GetInfoNum( "rtcamera_key" ) > 20 or ply:GetInfoNum( "rtcamera_key" ) < -5 ) then
        return false
    end
    if tool == "camera" and ( ply:GetInfoNum( "camera_key" ) > 20 or ply:GetInfoNum( "camera_key" ) < - 5 ) then
        return false
    end
end)

concommand.Add("rootmode", function(ply,_,_)
	if (ply.RootMode) then
		ply:ChatPrint("RootMode disabled.")
      umsg.Start("ToggleRoot", ply)
      umsg.End()
      ply.RootMode = false
	elseif ply:IsRoot() then 
		ply:ChatPrint("RootMode Activated.")
      umsg.Start("ToggleRoot", ply)
      umsg.End()
      ply.RootMode = true
	end
end)

--Why old darkrp remove, me like this:
function FindPlayer(info)
	if not info then return nil end
	local pls = player.GetAll()

	-- Find by Index Number (status in console)
	for k = 1, #pls do -- Proven to be faster than pairs loop.
		local v = pls[k]
		if tonumber(info) == v:UserID() then
			return v
		end

		if info == v:SteamID() then
			return v
		end
	
		if string.find(string.lower(v:SteamName()), string.lower(tostring(info)), 1, true) ~= nil then
			return v
		end
	
		if string.find(string.lower(v:Name()), string.lower(tostring(info)), 1, true) ~= nil then
			return v
		end
	end
	return nil
end

hook.Add("InitPostEntity", "RemoveMapProps", function()  
	for k, v in pairs(ents.FindByClass[[prop_physics]]) do v:Remove()  end 
	for k, v in pairs(ents.FindByClass[[prop_physics_multiplayer]]) do v:Remove()  end 
	if game.GetMap() == "rp_downtown_v2" then
        local dieents = {
            2209; -- furniture shop button of doom;
            2224; -- gunshop glock button
            2225; -- gunshop fiveseven button
            2226; -- gunshop ammo button
            -- Admin room buttons
            2250;
            2251;
            2252;
            2253;
        };
        for _, mid in pairs(dieents) do
            --print(mid)
            ents.GetMapCreatedEntity(mid):Remove()
        end
	end
	-- Just moving the jail window a tad, stops stupid arresting through the wall.
	if game.GetMap() == "rp_bangclaw" then
		if IsValid(Entity(335)) and Entity(335):GetClass() == "func_wall" then
			Entity(335):SetPos(Entity(335):GetPos()+Vector(0,9,0))
		end
	end
	if RP3 then
		Entity(540):Remove() -- Bridge barrier
		Entity(513):Remove() -- Bridge barrier
		Entity(514):Remove() -- Bridge barrier
		Entity(515):Remove() -- Bridge barrier
		Entity(516):Remove() -- Bridge barrier
		Entity(520):Remove() -- Bridge
		Entity(205):Remove() -- Bridge Controls
		Entity(1189):Remove() -- Bridge Controls
		Entity(1190):Remove() -- Bridge Controls
		Entity(1191):Remove() -- Bridge Controls
	end
	for k,v in pairs(ents.FindByClass[[env_soundscape]]) do
		if IsValid(v) then v:Remove() end
	end	
end)
concommand.Add("rootmode", function(ply,_,_)
	if (ply.RootMode) then
		ply:ChatPrint("RootMode disabled.")
      umsg.Start("ToggleRoot", ply)
      umsg.End()
      ply.RootMode = false
	elseif ply:IsRoot() then 
		ply:ChatPrint("RootMode Activated.")
      umsg.Start("ToggleRoot", ply)
      umsg.End()
      ply.RootMode = true
	end
end)

concommand.Add("restartme",function(ply)
	if ply:IsRoot() or ply:EntIndex() == 0 then 
		game.ConsoleCommand("changelevel " .. game.GetMap() .. "\n");
	end
end)