if true then return end -- Sigh, ULX is over writting ma stuffs, I'll have to modify it directly at a later date.
local Badmin = {}
function Badmin.isValidSteamID( steamid )
	return steamid:match( "^STEAM_%d:%d:%d+$" ) ~= nil
end
function Badmin.Ban(ply,vicsid,len,reason)
	if not ply:IsAdmin() then return end
	local reason = reason or "Something went wrong, no reason was found in arguments?"
	local len = tonumber(len) or 1440
	if len == 0 then len = 1440 elseif len > 1440 then  ply:ChatPrint("ingame bans are limtied to 24hours") len = 1440 end
	local victim = FindPlayer(vicsid)
	local name = "BannedID"
	if IsValid(victim) then
		name = victim:Name()
	end
	local bandata = sql.SQLStr(ply:Name()) .. "," .. sql.SQLStr(ply:SteamID()) .. "," .. sql.SQLStr(name) .. "," .. sql.SQLStr(vicsid) .. "," .. sql.SQLStr(reason) .. "," .. os.time() ..",".. len..",".. sql.SQLStr(ServID)
	MySQLite.query("INSERT INTO byb_tempbans (adminname,adminid,plyname,plyid,reason,bantime,banlen,server) VALUES("..bandata..");");
	local msg = name.."("..vicsid..") was banned by " .. ply:Name().."("..ply:SteamID()..") for "..len.." minutes for the reason "..reason
	local tar = FindPlayer(vicsid)
	if IsValid(tar) then tar:Kick(msg) end
	DB.Log(msg)
	Badmin.Announce(msg)
	AdminLog(ply,victim, " Has banned ", " ".. len .. " minute(s) for " ..reason)
end	

function Badmin.BanCheck(ply,vicsid,len,reason)
	 MySQLite.query("SELECT * FROM byb_tempbans WHERE plyid=" .. sql.SQLStr(vicsid) .." AND server=".. sql.SQLStr(ServID) .." AND unban=0 order by `id` desc limit 1;",function(data)
		local bandata = data or {}
		if bandata[1] then
			if bandata[1].unban == "0" then 
				local expired = bandata[1].bantime + (bandata[1].banlen*60)
				if not bandata[1].server == ServID then return end
				if expired > os.time() then 
					ply:ChatPrint("The guys already banned you fool")
					return true
				end
			end
		end		
		Badmin.Ban(ply,vicsid,len,reason)
	end)
end
function Badmin.PlayerConnect(ply,vicsid)
	--Extremely simple flag to stop join spammers from flooding mysql queries
	if Badmin.LastBanCheck == vicsid then
		ply:Kick("Bans are cached for a few minutes, if you where recently unbanned try again in 5 minutes")
		timer.Create("LastBan",360,1, function() Badmin.LastBanCheck = "" end)
		return
	end
	 MySQLite.query("SELECT * FROM byb_tempbans WHERE plyid=" .. sql.SQLStr(vicsid) .."  AND unban=0 order by `id` desc limit 1;",function(data)
		bandata = data or {}
		if bandata[1] then
			--print(bandata[1].server)
			if tostring(bandata[1].server) == tostring(ServID) then
				local expired = bandata[1].bantime + (bandata[1].banlen*60)
				if expired > os.time() then 
					ply:Kick("BANNED: Expires in : " ..math.floor(((expired-os.time())/60)) .."minutes. REASON : \""..bandata[1].reason.."\"")
					Badmin.LastBanCheck = vicsid
				end
			end
		end		
	end)
end
concommand.Add("byb_banid", function(ply,_,args)
	local sid = args[1]
	if not Badmin.isValidSteamID(sid) then ply:ChatPrint("Invalid SteamID") return end
	local reason = ""
	local len = args[2]
	if type(len) == "number" then ply:ChatPrint("Wrong ban layout, you should use !ban name time reason. Or just use the menu !amenu") return end
	for k,v in pairs(args) do
		if v == args[1] or v == args[2] then
		else			
			reason = reason .. " " .. v
		end
	end
	Badmin.BanCheck(ply,sid,len,reason)
end)

local function ChatBan(ply,args)
	local reason = " "
	args = string.Explode(" ", args)
	local tar = FindPlayer(args[1])
	local reason = ""
	local len = args[2]
	for k,v in pairs(args) do
		if v == args[1] or v == args[2] then
		else
			reason = reason .. " " .. v
		end
	end
	if IsValid(tar) then
		Badmin.BanCheck(ply,tar:SteamID(),len,reason)
	end
	return ""
end
DarkRP.defineChatCommand("!ban", CombineRequest)
