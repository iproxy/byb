local matemp = CurTime()
concommand.Add("moneyauth", function(ply,cmd,args)
        local month = 2629743
        local etime = os.time()
        local expires
        local codeservid
        local admingroup = ""
        -- Once again, I cba playing with timers so im doing el stupido method.
        if ply.UsedCode1 == "1" then ply.UsedCode1 = "2" return end
        if ply.UsedCode1 == "2" then ply.UsedCode1 = "0" return end
        ply.UsedCode1 = "1"
        if matemp > CurTime() then ply:ChatPrint("Please try again in 60 seconds") return end
        matemp= CurTime() + 10;
        MySQLite.query("SELECT license,active,fuid,value,sid FROM darkrp.moneyauth WHERE license= "..sql.SQLStr(args[1])..";", function(data)
                codedetails = data or {}
                if codedetails and codedetails[1] then
                        local license = codedetails[1].license
                        local active = codedetails[1].drp25
                        local value = tonumber(codedetails[1].value)
                        if active == 0 then
                                ply:ChatPrint("I'm afraid this code has already been activated, if you believe this to be an error then contact Pantho on the forums @ www.bybservers.co.uk")
                                return
                        end
                        MySQLite.query("UPDATE darkrp.moneyauth SET drp25='0',sid="..sql.SQLStr(ply:SteamID()).." WHERE license="  .. sql.SQLStr(args[1]) ..";")
                        DarkRP.log(ply:Name() .. " : ("..ply:SteamID()..") Has used code " ..args[1])
                        if value <= 4 then
                                value = value * 50000
                        else
                                value = (value - 3) * 200000
                        end
                        ply:addMoney(value)
                        ply:ChatPrint("You have received $"..value..". Thank you for your purchase. Any issues contact Pantho @ bybservers.co.uk")
                end
        end)
end)