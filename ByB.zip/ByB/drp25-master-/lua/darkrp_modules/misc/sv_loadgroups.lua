hook.Add("PlayerAuthed", "AdminSupporterLoading", function(ply, steamid)
	ply:SetJumpPower(200)
    local name = GAMEMODE.RootAdmins[steamid];
    if (name) then
	    -- Assign the admin to a variable with their name.
	    _G[name] = ply;
	    ply.IsRootAdmin = true;
	 end
	local steamID = sql.SQLStr(ply:SteamID())
	--timer.Simple(10, function() 
		MySQLite.query("SELECT steamID,demote_blacklist FROM darkrp.supporters WHERE steamID = " ..steamID..";",	function(cb)
			if (cb) then
				--timer.Simple(1, function()
					if not IsValid(ply) then return end
					ply:setDarkRPVar("supporter", true)
					sup = true
					ply.CanDemote = 1
					blklist = cb or {}
					if blklist[1] and blklist[1].demote_blacklist == 1 then
						ply.CanDemote = 0
					end			
				--end)
			else
				MySQLite.query("SELECT steamID,demote_blacklist FROM darkrp.supporters2 WHERE steamID = " ..steamID..";",	function(cb)
					if (cb) then
						--timer.Simple(1, function()							
							if not IsValid(ply) then return end
							ply:setDarkRPVar("supporter", true)
							ply.CanDemote = 1
							blklist = cb or {}
							if blklist[1].demote_blacklist == 1 then
								ply.CanDemote = 0
							end					
						--end)
					else
						--timer.Simple(1, function()
							if not IsValid(ply) then return end
							ply:SetDarkRPVar("supporter", false)
						--end)
					end
				end)
			end
		end)
	--end)
    local sbasgroups = {}
    local sbadmins = {}
    -- Setting to global server incase no sbans.cfg is present
    servid = servid or 0
	--timer.Simple(5, function()
	    if servid == 0 then    
			MySQLite.query("SELECT aid,srv_group FROM sbans.sb_admins WHERE authid = "..steamID..";", function(data)
			sbadmins = data or {}
				if sbadmins and sbadmins[1] then
					local adminid = sbadmins[1].aid
					local admingroup = sbadmins[1].srv_group
					if admingroup == "superadmin" then
						game.ConsoleCommand("ulx adduserid "..steamid.." serveradmin\n")
							print("-------------------------------------------------------------------------------------------------------------------")
							print("ulx adduserid "..steamid.." "..admingroup)
							return
					end
					MySQLite.query("SELECT server_id,expires FROM sbans.sb_admins_servers_groups WHERE admin_id = ".. adminid .." AND DATEDIFF(expires, CURDATE()) > 0;", function(data)
						if (data) then
							game.ConsoleCommand("ulx adduserid "..steamid.." "..admingroup.."\n")
							return
						end
					end)
				end
		    end)
	    else
		    MySQLite.query("SELECT aid,srv_group FROM sbans.sb_admins WHERE authid = "..steamID..";", function(data)
			sbadmins = data or {}
				if sbadmins and sbadmins[1] then
					local adminid = sbadmins[1].aid
					local admingroup = sbadmins[1].srv_group
					if admingroup == "superadmin" then
						ply.SAD = true
						game.ConsoleCommand("ulx adduserid "..steamid.." serveradmin\n")
						ply:SetUserGroup("serveradmin")
						return
					elseif admingroup == "trusted_admin" then
						MySQLite.query("SELECT server_id,expires FROM sbans.sb_admins_servers_groups WHERE DATEDIFF(expires, CURDATE()) > 0 AND admin_id = "..adminid..";", function(data)
							if (data) then
								game.ConsoleCommand("ulx adduserid "..steamid.." "..admingroup.."\n")
							ply:SetUserGroup(admingroup)
								return
							end
						end)					
					else
						MySQLite.query("SELECT server_id,expires FROM sbans.sb_admins_servers_groups WHERE (server_id = ".. servid .." OR server_id = 0) AND DATEDIFF(expires, CURDATE()) > 0 AND admin_id = "..adminid..";", function(data)
							if (data) then
								game.ConsoleCommand("ulx adduserid "..steamid.." "..admingroup.."\n")
								return
							end
						end)
					end
				end
		    end)
	    end
	--end)
end)