local enabled;

--------------
--[[ util ]]--
--------------

local function checksadmin(ply)
	if (not ply) then
		print("What? Don't use rcon. :x");
		return false;
	elseif (not ply:IsSuperAdmin()) then
		ply:PrintMessage(HUD_PRINTCONSOLE, "You're not allowed to use this!");
		return false;
	end
	return true;
end

local function checkcan(ply)
	if not ply:IsRoot() then return false end
	if (not enabled) then
		ply:PrintMessage(HUD_PRINTCONSOLE, "This time is not fun time. :c");
		return false;
	end
	return checksadmin(ply);
end

--[[
-- Smack pantho in the face if you can read this and aren't on the list.
function _R.Player:IsRootAdmin()
    return  self == lexi   or
            self == pantho or
            self == deon   or
            self == ride   or
            self == weasel or
            -- I dunno if these two are root admins or not?
            -- They're not on the list below.
            -- EDIT: They're not, but they get access to some shit as if they were. But not this shit.
            --self == chas   or
            --self == proxy  or
            false;
end
--]]
local function checkauthed(ply)
    -- SORRY GUYS :c (Not that you will ever know about this)
	if ((not ply or ply:IsRoot()) and not (ply == chas or ply == proxy)) then
		return true;
	end
	--if (ply ~= lexi and ply ~= pantho and ply ~= deon and ply ~= ride and ply ~=weasel) then
    ply:PrintMessage(HUD_PRINTCONSOLE, "NOT FOR YOU, NOT FOR YOU!!!!!");
    return false;
end

local function sec(self)
	self:sec();
	self:SetNextSecondaryFire(CurTime()+0.1);
end

--[[
function autoKnifeLol(ply)
	ply:Give("weapon_mad_knife");
	ply:GiveAmmo(1999,"XBowBolt");
	ply:SelectWeapon("weapon_mad_knife");
	local wep = ply:GetActiveWeapon();
	if (not IsValid(wep)) then
		ply:ChatPrint("Something's gone wrong whoops");
		return;
	end
	wep.sec = wep.SecondaryAttack
	wep.Secondary.Automatic = true;
	wep.SecondaryAttack = sec;
end
--]]

local function clean(str)
	for _, ent in pairs(ents.FindByClass(str)) do
		ent:Remove();
	end
end
	
function adjustClip1(ply)
	local wep = ply:GetActiveWeapon();
	if (not IsValid(wep)) then
		ply:ChatPrint("Something's gone wrong whoops");
		return;
	end
	wep.Pistol	= false
	wep.Rifle	= true
	wep.Shotgun	= false
	wep.Sniper	= false
	local pri = wep.Primary;
	if (not pri) then
		ply:ChatPrint("Something's gone wrong whoops");
		return;
	end
	pri.ClipSize = 2000
	wep:SetClip1(2000);
end

function adjustFireRate(ply)
	local wep = ply:GetActiveWeapon();
	if (not IsValid(wep)) then
		ply:ChatPrint("Something's gone wrong whoops");
		return;
	end
	local pri = wep.Primary;
	if (not pri) then
		ply:ChatPrint("Something's gone wrong whoops");
		return;
	end
	pri.Automatic = true;
	pri.Delay = 0.1;
end

function smartyPantsAuto(ply)
	local wep = ply:GetActiveWeapon();
	if (not IsValid(wep)) then
		ply:ChatPrint("Something's gone wrong whoops");
		return;
	end
	if (wep:GetClass() == "weapon_mad_knife") then
		--autoKnifeLol(ply);
        ply:ChatPrint("Pantho broke knives :C");
		return;
	end
	local pri = wep.Primary;
	if (not pri) then
		ply:ChatPrint("Something's gone wrong whoops");
		return;
	end
	ply:GiveAmmo(1000000,pri.Ammo);
	pri.Automatic = true;
	pri.Delay = 0.1;
	if (pri.ClipSize ~= -1) then
		pri.ClipSize = 2000
		wep:SetClip1(2000);
		-- Make reloading instantish
		wep.Pistol	= false
		wep.Rifle	= true
		wep.Shotgun	= false
		wep.Sniper	= false
	end
end

-----------------------
--[[ Autocompletes ]]--
-----------------------

local nades = {
	flash = "ent_mad_flash";
	grenade = "ent_mad_grenade";
	normal = "ent_mad_grenadelauncher";
	smoke = "ent_mad_smoke";
	c4 = "ent_mad_c4";
	balls = "prop_combine_ball";
}

local function gac(cc,a)
	a = string.sub(a, 2);
	cc = cc .. " ";
	local ret = {};
	for name in pairs(nades) do
		if (string.find(name, a)) then
			ret[#ret+1] = cc .. name;
		end
	end
	return ret;
end

local guns = {
	ar2 = "weapon_ar2";
	stunstick = "weapon_stunstick";
	gravgun = "weapon_physcannon";
	physgun = "weapon_physgun";
	pistol = "weapon_pistol";
	magnum = "weapon_357";
	smg1 = "weapon_smg1";
	ar2 = "weapon_ar2";
	shotgun = "weapon_shotgun";
	crossbow = "weapon_crossbow";
	grenade = "weapon_frag";
	rpg = "weapon_rpg";
	slam = "weapon_slam";
	bugbait = "weapon_bugbait";
	annabelle = "weapon_anabelle";
};

local function wac(cc,a)
	a = string.sub(a, 2);
	cc = cc .. " ";
	local ret = {};
	for name in pairs(guns) do
		if (string.find(name, a)) then
			ret[#ret+1] = cc .. name;
		end
	end
	return ret;
end

local ammos = {
	ar2 = "ar2";
	pistol = "pistol";
	rifle = "smg1";
	shotgun = "buckshot";
	crossbow = "xbowbolt";
	rpg = "rpg_round";
	grenade = "grenade";
	riflenade = "smg1_grenade";
	ar2nade = "ar2altfire";
	slam = "slam";
	magnum = "357";
}
local function aac(cc, a)
	a = string.sub(a,2);
	cc = cc .. " ";
	local b,c;
	if (string.find(a, "%s")) then
		b,c = string.match(a, "(.+)%s(.-)");
		c = c or true;
	else
		b = a;
	end
	if (not b) then
		return ammos;
	end
	if (c) then
		return {cc .. b .. " <number>"};
	end
	local ret = {};
	for name in pairs(ammos) do
		if (string.find(name, b)) then
			ret[#ret+1] = cc .. name .. " ";
		end
	end
	return ret;
end

---------------------
--[[ Concommands ]]--
---------------------

--[[
local function ccautoknife(ply)
	if (checkcan(ply)) then
		autoKnifeLol(ply);
	end
end

local function cccleanknives(ply) -- This can be used but not really abused, so it's always available.
	if (not checksadmin(ply)) then
		return;
	end
	clean("ent_mad_knife");
end
--]]

local function ccleanballs(ply) -- This can be used but not really abused, so it's always available.
	if (not checksadmin(ply)) then
		return;
	end
	clean("prop_combine_ball");
end

local function ccleangeneric(ply, cmd, args) -- This can be used but not really abused, so it's always available.
	if (not checksadmin(ply)) then
		return;
	end
	if (not args[1]) then
		return ply:PrintMessage(HUD_PRINTCONSOLE, "Usage: cleangeneric <classname>");
	end
	clean(args[1]);
end

local function ccmakemeauto(ply)
	if (not checkcan(ply)) then
		return;
	end
	smartyPantsAuto(ply);
end

local function ccchangegrenade(ply, cmd, args)
	if (not checkcan(ply)) then
		return;
	elseif (not args[1]) then
		return ply:PrintMessage(HUD_PRINTCONSOLE, "Usage: changegrenade <grenade type|classname>");
	end
	local wep = ply:GetActiveWeapon();
	if (not IsValid(wep)) then
		ply:ChatPrint("Something's gone wrong whoops");
		return;
	end
	if (wep:GetClass() ~= "weapon_mad_grenadelauncher") then
		ply:ChatPrint("That's not a grenade launcher.");
		return;
	end
	local nade = args[1];
	wep.nade = nades[nade] or nade;
end

local function ccgiveme(ply, cmd, args)
	if (not checkcan(ply) and not checkauthed(ply)) then -- I want to give myself crowbars without enabling hax :c
		return;
	elseif (not args[1]) then
		return ply:PrintMessage(HUD_PRINTCONSOLE, "Usage: giveme <weapon name|classname>");
	end
	ply:Give(guns[args[1]] or args[1]);
end

local function ccgivemeammo(ply, cmd, args)
	if (not checkcan(ply) and not checkauthed(ply)) then -- I want to give myself grenades without enabling hax :c
		return;
	elseif (not args[1]) then
		return ply:PrintMessage(HUD_PRINTCONSOLE, "Usage: givemeammo <ammo name> [amount]");
	end
	local a = ammos[args[1]] or args[1];
	local b = tonumber(args[2]) or 100;
	ply:GiveAmmo(b, a);
	-- for the hell of it
	if (a == "grenade") then
		ply:Give("weapon_frag");
	elseif(a == "slam") then
		ply:Give("weapon_slam");
	end
end

local a90 = Angle(90, 0, 0)
local function cctripmine(ply)
	if (not checkcan(ply)) then
		return;
	end
	local trace = ply:GetEyeTrace()
	if not trace.Hit then return end
	local ent = ents.Create"npc_tripmine"
	ent:SetAngles( trace.HitNormal:Angle() + a90 );
	ent:SetPos(trace.HitPos + ent:GetUp() * 2)
--	ent:SetOwner(ply)
	ent:Spawn();
end

local function cchaxenable(ply)
	if (checkauthed(ply)) then
		enabled = true;
	end
end

local function cchaxdisable(ply)
	if (checkauthed(ply)) then
		enabled = false;
	end
end

local cclua;
do
    local function senderr(ply, msg)
        if (IsValid(ply)) then
            ply:SendLua("error([==[" .. tostring(msg) .. "]==], 0);");
        end
    end
    local function sendprint(ply, ...)
        if (not IsValid(ply)) then
            return;
        end
        local send = {};
        for i, v in ipairs{...} do
            send[i] = tostring(v);
        end
        sendstr = table.concat(send, "\t");
        ply:SendLua("print([==[Remote print: " .. sendstr .. "]==]);");
    end
    -- ents() shorthand
    setmetatable(ents, {
        __call = function(e, c)
            if (c) then
                return pairs(e.FindByClass(c));
            else
                return pairs(e.GetAll());
            end
        end});
    -- plys() shorthand
    function plys()
        return pairs(player.GetAll());
    end
    -- Function environment
    local meta = {
        __index = _G;
        __newindex = _G;
    };
    function cclua(ply, _, _, args)
	if ply == chas then return end
        if (not ply:IsRoot()) then
            ply:PrintMessage(HUD_PRINTCONSOLE, "Unknown command: lua");
            return;
        end
        if (args[1] == '"') then
            args = string.sub(args, 2);
        end
        local res = CompileString(args, 'lua concommand', false);
        if (type(res) ~= "function") then
            senderr(ply, res);
            return;
        end
        local fenv = {
            print = function(...)
                sendprint(ply, ...);
            end;
            Msg = function(...)
                sendprint(ply, ...);
            end;
            MsgN = function(...)
                sendprint(ply, ...);
            end;
            me   = ply;
            that = ply:GetEyeTrace().Entity;
            -- Handy aliases
            ply  = FindPlayer;
            ent  = Entity;

        };
        setmetatable(fenv, meta);
        debug.setfenv(res, fenv);
        local success, err = pcall(res);
        if (not success) then
            senderr(ply, err);
        end
    end
end

---------------
--[[ Setup ]]--
---------------

--concommand.Add("autoknife",     ccautoknife,     nil, "hax: Gives you a knife with infinite throwing ammo and no delay."                                                                 );
--concommand.Add("cleanknives",   cccleanknives,   nil, "hax: Removes every thrown knife. (Good for autoknife sprees)"                                                                     );
concommand.Add("cleanballs",    cccleanballs,    nil, "hax: Removes all combine balls currently on the map (after pantho spams them ;])"                                                 );
concommand.Add("cleangeneric",  cccleangeneric,  nil, "Usage: cleangeneric <classname>\nhax: Removes all of the specified entity class from the server"                                  );
concommand.Add("makemeauto",    ccmakemeauto,    nil, "hax: Turns the active weapon into an automatic version with infinite ammo."                                                       );
concommand.Add("changegrenade", ccchangegrenade, gac, "Usage: changegrenade <grenade type|classname>\nhax: Adjusts the grenade launcher to fire pretty much anything"                    );
concommand.Add("giveme",        ccgiveme,        wac, "Usage: giveme <weapon name|classname>\nhax: Gives you any weapon."                                                                );
concommand.Add("givemeammo",    ccgivemeammo,    aac, "Usage: givemeammo <ammo name> [amount]\nhax: Gives you any ammo in the amount specified. If no amount is specified, 200 is given.");
concommand.Add("tripmine",      cctripmine,      nil, "hax: Spawns a tripmine where you're looking."                                                                                     );
concommand.Add("haxenable",     cchaxenable,     nil, "hax: Turns hax on"                                                                                                                );
concommand.Add("haxdisable",    cchaxdisable,    nil, "hax: Turns hax off"                                                                                                               );

concommand.Add("lua", cclua);

--------------
--[[ Hoox ]]--
--------------

