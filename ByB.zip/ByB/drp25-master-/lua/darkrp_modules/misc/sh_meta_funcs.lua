AddCSLuaFile()

-- THESE NAMES DO NOT HAVE SPACES IN THEM. DO NOT PUT SPACES IN NEW ENTRIES
GAMEMODE.RootAdmins = {
    ["STEAM_0:1:16678762"] = "lexi";
    ["STEAM_0:0:12921574"] = "pantho";
    ["STEAM_0:1:25946072"] = "proxy";
    ["STEAM_0:1:11392510"] = "deon";
	["STEAM_0:0:30280339"] = "ride";
	["STEAM_0:0:20235793"] = "chas";
    ["STEAM_0:1:24400282"] = "weasel";
	["STEAM_0:0:27609078"] = "shikari";
	["STEAM_0:1:22575020"] = "adol";
};

local plymeta = FindMetaTable'Player';
function plymeta:IsSupporter()
	if self:GetNWString("usergroup") == "serveradmin" or self:getDarkRPVar("supporter") then return true else return false end
--	return self:getDarkRPVar("supporter")
end

function plymeta:IsRoot()	
    return self.IsRootAdmin or GAMEMODE.RootAdmins[self:SteamID()];
end


function plymeta:IsTrustedAdmin()
	if  self:GetNWString("usergroup") == "trusted_admin" or self:GetNWString("usergroup") == "serveradmin" or self:GetNWString("usergroup") == "superadmin" then
		return true
	end
	return false
end

--Why old darkrp remove, me like this:
function FindPlayer(info)
	if not info then return nil end
	local pls = player.GetAll()

	-- Find by Index Number (status in console)
	for k = 1, #pls do -- Proven to be faster than pairs loop.
		local v = pls[k]
		if tonumber(info) == v:UserID() then
			return v
		end

		if info == v:SteamID() then
			return v
		end
	
		if string.find(string.lower(v:SteamName()), string.lower(tostring(info)), 1, true) ~= nil then
			return v
		end
	
		if string.find(string.lower(v:Name()), string.lower(tostring(info)), 1, true) ~= nil then
			return v
		end
	end
	return nil
end