/*---------------------------------------------------------------------------
F4 menu tab modification module.
---------------------------------------------------------------------------*/

--if true then return end -- REMOVE THIS LINE TO ENABLE THIS MODULE
-- Purchases page
--local function createF4MenuTab()
	// DarkRP.switchTabOrder(2, 3) -- Remove the "//" in this line if you want to move the third tab to the left of the second tab!
	// DarkRP.removeF4MenuTab("Ammo") -- Remove the "//" in this line if you want to remove the Ammo tab!

	--local webPage = vgui.Create("DHTML")
	--webPage:SetAllowLua( true );
	--webPage:OpenURL("http://www.bybservers.co.uk/index.php?topic=13.msg46#msg46")
	--DarkRP.addF4MenuTab("Supporter/Admin", webPage)
--end
--hook.Add("F4MenuTabs", "PurchaseF4MenuTab", createF4MenuTab)
-- Code page
--local function createF4MenuTab()
	--local webPage = vgui.Create("DHTML")
	--webPage:SetAllowLua( true );
	--webPage:OpenURL("http://www.bybservers.co.uk/index.php?page=panthofailsholding")
	--DarkRP.addF4MenuTab("Gift Codes", webPage)
--end
--hook.Add("F4MenuTabs", "CodesF4MenuTab", createF4MenuTab)

-- Rules page
--local function createF4MenuTab()
	--local webPage = vgui.Create("DHTML")
	--webPage:SetAllowLua( true );
	--webPage:OpenURL("http://www.bybservers.co.uk/index.php?page=Rulesrp5#ServerRules")
	--DarkRP.addF4MenuTab("Rules", webPage)
--end
--hook.Add("F4MenuTabs", "RulesF4MenuTab", createF4MenuTab)


