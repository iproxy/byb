SWEP.PrintName = "Super Keypad Cracker"
DEFINE_BASECLASS("weapon_keypad_cracker")
SWEP.Author = "Lexi / Chief Tiger / iRIDEsisters"
SWEP.CrackTime = 10
