SWEP.PrintName = "SWAT Keypad Cracker"
DEFINE_BASECLASS("weapon_keypad_cracker")
SWEP.Author = "Lexi / Chief Tiger / iRIDEsisters"
SWEP.CrackTime = 5
