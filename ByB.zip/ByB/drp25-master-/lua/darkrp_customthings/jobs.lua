/*---------------------------------------------------------------------------
/*---------------------------------------------------------------------------
DarkRP custom jobs
---------------------------------------------------------------------------

This file contains your custom jobs.
This file should also contain jobs from DarkRP that you edited.

Note: If you want to edit a default DarkRP job, first disable it in darkrp_config/disabled_defaults.lua
	Once youve done that, copy and paste the job to this file and edit it.

The default jobs can be found here:
<TODO: INSERT URL HERE>

For examples and explanation please visit this wiki page:
http://wiki.darkrp.com/index.php/DarkRP:CustomJobFields


Add jobs under the following line:
---------------------------------------------------------------------------*/

TEAM_BGUARD = DarkRP.createJob("Bodyguard", {
        color = Color(187, 25, 0, 255),
        model = {
                "models/player/guerilla.mdl"
                },
				
				
        description = [[You must be hired to defend, you may not be rogue.]],
        weapons = {"weapon_p2282"},
        command = "bodyguard",
        max = 5,
        salary = 45,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "Follow the rules of the job who has hired you, gundealer/police/any professional may hire you.",
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_AOD = DarkRP.createJob("Admin On Duty", {
        color = Color(255, 255, 0, 255),
        model = {
			"models/player/Combine_Super_Soldier.mdl"
               },				
        description = [[Admin away!
			BOOOOOOO!
			Admin warning - Please keep sheep away from JamieH, we have recently learned he abodes in wales.
			Apologies if this offends, but we care deeply for the sheep.]],
        weapons = {"lockpick_byb","weapon_keypadchecker"},
        command = "aod",
        max = 2,
        salary = 0,
        admin = 1,
        vote = false,
        hasLicense = false,
        help = "Could we try not being as harsh/mean/cruel or as useless as Deon please?",
		--RequiresVote = function(ply, job) return not ply:IsSupporter() end,
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_THIEF = DarkRP.createJob("Thief", {
        color = Color(128, 20, 128, 255),
        model = {
			"models/player/arctic.mdl"
               },				
        description = [[HELP HELP SOMEONE STOLE MY SHOE! You get the idea, steal stuff...
			Go forth, steal things...
			The end...]],
        weapons = {"lockpick_byb","weapon_keypad_cracker"},
        command = "thief",
        max = 3,
        salary = 25,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "Just go around stealing suff and being the bane of that poor guys life.",
		--RequiresVote = function(ply, job) return not ply:IsSupporter() end,
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_DOC = DarkRP.createJob("Doctor", {
        color = Color(100, 15, 50, 255),
        model = {
			"models/player/kleiner.mdl"
               },				
        description = [[Setup a shop or heal on the go - but you must be a public doctor, not a gangs personal slave.
			Heal the sick... and make money if you wish ;).
			You must not base with gangs.
			You must offer your services, either for money or on a moral contract etc.
			If you only want to heal 'good' people such as police then you may.]],
        weapons = {"med_kit"},
        command = "doctor",
        max = 2,
        salary = 25,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "Setup a shop or heal on the go - but you must be a public doctor, not a gangs personal slave.",
		--RequiresVote = function(ply, job) return not ply:IsSupporter() end,
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_GUN = DarkRP.createJob("Gun Dealer", {
        color = Color(255, 140, 25, 255),
        model = {
			"models/player/mossman.mdl",
			"models/player/monk.mdl"
               },				
        description = [[Setup a shop, or deliver by hand - but you MUST sell - not base with gangs.
			You must sell weapons, you cannot simply base and self supply.
			You cannot be part of a gang / only supply specific gangs.
			Your goal is to make money, scripted rp, sell guns etc.]],
        weapons = {"m9k_glock"},
        command = "gundealer",
        max = 2,
        salary = 25,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "Setup a shop, or deliver by hand - but you MUST sell - not base with gangs.",
		--RequiresVote = function(ply, job) return not ply:IsSupporter() end,
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})
TEAM_AGANGM = DarkRP.createJob("Affiliated Doctor", {
        color = Color(50, 50, 50, 255),
        model = {
			"models/player/group03m/female_01.mdl",
			"models/player/group03m/female_02.mdl",
			"models/player/group03m/female_03.mdl",
			"models/player/group03m/female_04.mdl",
			"models/player/group03m/female_05.mdl",
			"models/player/group03m/female_06.mdl",
			"models/player/group03m/male_01.mdl",
			"models/player/group03m/male_02.mdl",
			"models/player/group03m/male_03.mdl",
			"models/player/group03m/male_04.mdl",
			"models/player/group03m/male_05.mdl",
			"models/player/group03m/male_06.mdl",
			"models/player/group03m/male_07.mdl",
			"models/player/group03m/male_08.mdl",
			"models/player/group03m/male_09.mdl"
               },				
        description = [[You used to be a vet, until you lost your license for helping illegal horse racing. So you've joined a gang and are putting your healing skills to use on new animals...
		
			You MUST be part of the Affiliated gang.
			This is the only main rule, you're a normal gangster with medic training. Heal allies, enemies, turtles or whatever.]],
        weapons = {"gang_med_kit"},
        command = "agangmedic",
        max = 1,
        salary = 25,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "Setup a shop, or deliver by hand - but you MUST sell - not base with gangs.",
		--RequiresVote = function(ply, job) return not ply:IsSupporter() end,
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_ROGUE = DarkRP.createJob("Rogue Trader", {
        color = Color(10, 40, 10, 255),
        model = {
			"models/player/mossman.mdl",
			"models/player/monk.mdl"
               },				
        description = [[Rogue Traders are innocent civilians, who just so happen to have a secret job...
			You cannot have an obvious shop.
			You may have hidden counters within apartments or disguised shops.
			You may sell on the streets or in deliveries.]],
        weapons = {"m9k_glock"},
        command = "roguetrader",
        max = 2,
        salary = 25,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "You must sell in secret, as your items are highly illegal.",
		--RequiresVote = function(ply, job) return not ply:IsSupporter() end,
        customCheck = function(ply) return ply:IsSupporter() end,
        CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_HIT = DarkRP.createJob("Hitman", {
        color = Color(170, 25, 25, 255),
        model = {
			"models/player/phoenix.mdl",
			"models/player/Group03/Female_06.mdl",
			"models/player/group03/male_01.mdl",
			"models/player/Group01/Female_04.mdl",
			"models/player/Group01/Female_06.mdl",
			"models/player/group01/male_01.mdl"
               },				
        description = [[You're a hitman, read the rules or DONT BE A HITMAN!
			You must take money for hits.
			You must have an RP reason for hits.
			You must not take hits against the same person repeatedly.
			If you believe the HIT violates NLR then you should not pursue it.]],
        weapons = {"m9k_contender","weapon_mad_knife","lockpick_byb","weapon_keypad_cracker","m9k_mp9"},
        command = "hitman",
        max = 1,
        salary = 25,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "You must take hits in an RP fashion.",
		--RequiresVote = function(ply, job) return not ply:IsSupporter() end,
        customCheck = function(ply) return ply:IsSupporter() end,
        CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_MOB = DarkRP.createJob("Affiliated Mob Boss", {
        color = Color(30, 30, 30, 255),
        model = {
			"models/player/Group03/Female_01.mdl",
			"models/player/Group03/Female_02.mdl",
			"models/player/Group03/Female_03.mdl",
			"models/player/Group03/Female_04.mdl",
			"models/player/Group03/Female_06.mdl",
			"models/player/group03/male_01.mdl",
			"models/player/Group03/Male_02.mdl",
			"models/player/Group03/male_03.mdl",
			"models/player/Group03/Male_04.mdl",
			"models/player/Group03/Male_05.mdl",
			"models/player/Group03/Male_06.mdl",
			"models/player/Group03/Male_07.mdl",
			"models/player/Group03/Male_08.mdl",
			"models/player/Group03/Male_09.mdl"
               },
				
				
        description = [[King of the affiliated gangsters.
			You must lead the gang.
			Anyone who is an 'affiliated gangster' will share group chat with you and MUST be part of your gang.
			You're criminals, go forth and make money.]],
        weapons = {"unarrest_stick","lockpick_byb","m9k_model627"},
        command = "mobboss",
        max = 1,
        salary = 65,
        admin = 0,
       -- vote = true,
        hasLicense = false,
        help = "You MUST gang with the mob boss.",
        RequiresVote = function(ply, job) if ply:IsSupporter() then return false else return true end end,
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_GANG = DarkRP.createJob("Gangster", {
        color = Color(75, 75, 75, 255),
        model = {
			"models/player/Group03/Female_01.mdl",
			"models/player/Group03/Female_02.mdl",
			"models/player/Group03/Female_03.mdl",
			"models/player/Group03/Female_04.mdl",
			"models/player/Group03/Female_06.mdl",
			"models/player/group03/male_01.mdl",
			"models/player/Group03/Male_02.mdl",
			"models/player/Group03/male_03.mdl",
			"models/player/Group03/Male_04.mdl",
			"models/player/Group03/Male_05.mdl",
			"models/player/Group03/Male_06.mdl",
			"models/player/Group03/Male_07.mdl",
			"models/player/Group03/Male_08.mdl",
			"models/player/Group03/Male_09.mdl"
               },
				
				
        description = [[This Gangster is NOT part of the Mob Boss' gang.
			This means you cannot see there group chat.
			It also means you are NOT supposed to base with them.]],
        weapons = {"lockpick_byb","weapon_keypad_cracker"},
        command = "gangster",
        max = 5,
        salary = 45,
        admin = 0,
       -- vote = false,
        hasLicense = false,
        help = "IF you wish to base with the mob boss, please become an Affliated Gangster.",
		--RequiresVote = function(ply, job) return not ply:IsSupporter() end,
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_AGANG = DarkRP.createJob("Affiliated Gangster", {
        color = Color(50, 50, 50, 255),
        model = {
			"models/player/Group03/Female_01.mdl",
			"models/player/Group03/Female_02.mdl",
			"models/player/Group03/Female_03.mdl",
			"models/player/Group03/Female_04.mdl",
			"models/player/Group03/Female_06.mdl",
			"models/player/group03/male_01.mdl",
			"models/player/Group03/Male_02.mdl",
			"models/player/Group03/male_03.mdl",
			"models/player/Group03/Male_04.mdl",
			"models/player/Group03/Male_05.mdl",
			"models/player/Group03/Male_06.mdl",
			"models/player/Group03/Male_07.mdl",
			"models/player/Group03/Male_08.mdl",
			"models/player/Group03/Male_09.mdl"
               },
				
				
        description = [[If you're are in this job, you must be part of the Mob Boss gang.]],
        weapons = {"lockpick_byb","weapon_keypad_cracker"},
        command = "agangster",
        max = 5,
        salary = 45,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "You MUST gang with the mob boss.",
		--RequiresVote = function(ply, job) return not ply:IsSupporter() end,
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_CP = DarkRP.createJob("Police Officer", {
        color = Color(10, 10, 190, 255),
        model = {
                "models/player/police.mdl",
				"models/player/police_fem.mdl"
                },
				
				
        description = [[You are an arm of the law, behave thyself and defend the people.]],
        weapons = {"arrest_stick", "unarrest_stick","m9k_hk45","stunstick", "door_ram", "lockpick_byb","weapon_keypad_cracker"},
        command = "police",
        max = 5,
        salary = 45,
        admin = 0,
        --vote = false,
        hasLicense = false,
        help = "Be kind, but harsh. You must defend the citizens of Downtown.",
		RequiresVote = function(ply, job) if ply:IsSupporter() then return false else return true end end,
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_CHIEF = DarkRP.createJob("Police Chief", {
        color = Color(10, 10, 240, 255),
        model = {
                "models/player/combine_soldier_prisonguard.mdl",
                },				
        description = [[The big guy, boss of the cops.]],
        weapons = {"arrest_stick", "unarrest_stick", "m9k_model500", "stunstick", "door_ram", "lockpick_byb","weapon_keypad_cracker"},
        command = "chief",
        max = 1,
        salary = 60,
        admin = 0,
       -- vote = true,
        hasLicense = false,
        help = "You are in charge of all police and swat units - you are under the mayors civil order.",
        RequiresVote = function(ply, job) if ply:IsSupporter() then return false else return true end end,
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_MAYOR = DarkRP.createJob("Mayor", {
        color = Color(124, 10, 240, 255),
        model = {
                "models/player/breen.mdl"
                },				
        description = [[The lawmaker, be kind with your laws or the plebs shall rebell.]],
        weapons = {"unarrest_stick","m9k_mp5sd","stunstick", "door_ram"},
        command = "mayor",
        max = 1,
        salary = 80,
        admin = 0,
        --vote = true,
        hasLicense = false,
        help = "You may rule the goverment, but the people rule you.",
        RequiresVote = function(ply, job) if ply:IsSupporter() then return false else return true end end,
		mayor = true
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})



TEAM_PMOB = DarkRP.createJob("Profesional Mobster", {
        color = Color(175, 120, 255, 255),
        model = {
                "models/player/Group03/Female_01.mdl",
                "models/player/Group03/Female_02.mdl"
                },
				
				
        description = [[Gangsters, with style. May RP as gangster or as seperate entitiy.]],
        weapons = {"m9k_m29satan","weapon_crossbow","lockpick_byb","weapon_keypad_cracker"},
        command = "pmob",
        max = 5,
        salary = 45,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "A better armed thief/gangster. Same rules apply.",
        customCheck = function(ply) return ply:IsSupporter() end,
        CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

TEAM_SWAT = DarkRP.createJob("SWAT", {
        color = Color(20, 20, 190, 255),
        model = {
                "models/player/gasmask.mdl",
				"models/player/swat.mdl",
				"models/player/urban.mdl",
				"models/player/riot.mdl"
                },				
        description = [[VIP Only - Heavily armored cops.]],
        weapons = {"arrest_stick", "unarrest_stick","m9k_mp7", "stunstick", "door_ram", "swat_keypad_cracker","lockpick_byb","weapon_frag"},
        command = "swat",
        max = 5,
        salary = 45,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "Same rules & rank or the regular police, but more combat ready.",
        customCheck = function(ply) return ply:IsSupporter() end,
        CustomCheckFailMsg = "This job is VIP/Supporter only.",
})
TEAM_HOBO = DarkRP.createJob("Hobo", {
        color = Color(80, 45, 0, 255),
        model = {
                "models/player/corpse1.mdl"
                },
				
				
        description = [[GET BACK TO YOUR GUTTER YOU WORTHLESS TRASH!
		
		You've hit rock bottom, you must choose wisely.
		Do you give up on life and live in the gutters? 
		Do you try and make a home for yourself with some random boxes and crates? 
		Do you give up all wealth and live as a busking hobo dancing for coins? 
		
		Maybe you try to fight back? Become something better than a hobo, become something better than a worthless, useless and pointless member of society? 
		Do you really want to struggle and take that VERY short step from what you are, to becoming Nightmare...]],
        weapons = {"weapon_fists","m9k_harpoon"},
        command = "hobo",
        max = 5,
        salary = 0,
        admin = 0,
        vote = false,
        hasLicense = false,
        help = "Follow the rules of the job who has hired you, gundealer/police/any professional may hire you.",
        --customCheck = function(ply) return ply:IsSupporter() end,
        --CustomCheckFailMsg = "This job is VIP/Supporter only.",
})

/*---------------------------------------------------------------------------
Define which team joining players spawn into and what team you change to if demoted
---------------------------------------------------------------------------*/
GAMEMODE.DefaultTeam = TEAM_CITIZEN


/*---------------------------------------------------------------------------
Define which teams belong to civil protection
Civil protection can set warrants, make people wanted and do some other police related things
---------------------------------------------------------------------------*/
GAMEMODE.CivilProtection = {
	[TEAM_CP] = true,
	[TEAM_CHIEF] = true,
	[TEAM_MAYOR] = true,
	[TEAM_SWAT] = true,
	[TEAM_AOD] = true,
}
GAMEMODE.Swats = {
	[TEAM_SWAT] = true,
}

/*---------------------------------------------------------------------------
Jobs that are hitmen (enables the hitman menu)
---------------------------------------------------------------------------*/
DarkRP.addHitmanTeam(TEAM_HIT)


-- Demote groups, anyone demoted from one is demoted for all for the duration.
DarkRP.createDemoteGroup("CP", {TEAM_CP, TEAM_CHIEF, TEAM_MAYOR, TEAM_SWAT})
DarkRP.createDemoteGroup("Gundealers", {TEAM_GUN, TEAM_ROGUE})
