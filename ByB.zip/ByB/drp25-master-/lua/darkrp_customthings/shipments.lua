/*---------------------------------------------------------------------------
/*---------------------------------------------------------------------------
DarkRP custom shipments and guns
---------------------------------------------------------------------------

This file contains your custom shipments and guns.
This file should also contain shipments and guns from DarkRP that you edited.

Note: If you want to edit a default DarkRP shipment, first disable it in darkrp_config/disabled_defaults.lua
	Once youve done that, copy and paste the shipment to this file and edit it.

The default shipments and guns can be found here:
<TODO: INSERT URL HERE>

For examples and explanation please visit this wiki page:
http://wiki.darkrp.com/index.php/DarkRP:CustomShipmentFields


Add shipments and guns under the following line: 
---------------------------------------------------------------------------*/
// PISTOLS //
AddCustomShipment("Python", {
        model = "models/weapons/w_colt_python.mdl", -- The model of the item that hovers above the shipment
        entity = "m9k_coltpython", -- the entity that comes out of the shipment
        price = 2500, -- the price of one shipment
        amount = 10, -- how many of the item go in one purchased shipment
        separate = true, -- whether the item is sold separately (usually used for guns)
        pricesep = 500, -- the price of a separately sold item
        allowed = {TEAM_GUN}, -- OPTIONAL, which teams are allowed to buy this shipment/separate gun
        shipmodel = "models/items/item_item_crate.mdl", -- OPTIONAL, the model of the shipment (this crate is the default)
        --customCheck = function(ply) return ply:Frags() < 10 end, -- OPTIONAL, extra conditions before people can purchase the shipment or separate item
       -- weight = 15, -- OPTIONAL, the weight of the shipment. The default is the weight of the shipment 
        buttonColor = Color(255, 255, 255, 255), -- Optional: The color of the button in the F4 menu,
        --label = "Super pistol", -- Optional: the text on the button in the F4 menu

        -- Advanced, optional
        shipmentClass = "spawned_shipment", -- The classname of the shipment entity. Use this if you have made a different shipment entity
       -- onBought = function(ply, shipment, ent) end, -- function that is called when the shipment is bought
       -- getPrice = function(ply, price) return ply:GetNWString("usergroup") == "donator" and price * 0.9 or price end, -- function to decide what the price is based on the player
})
AddCustomShipment("Colt 1911", {
        model = "models/weapons/s_dmgf_co1911.mdl",
        entity = "m9k_colt1911",
        price = 1500,
        amount = 10,
        separate = true,
        pricesep = 300,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(20, 20, 170, 255),
})
AddCustomShipment("Baretta", {
        model = "models/weapons/w_beretta_m92.mdl",
        entity = "m9k_m92beretta",
        price = 2000,
        amount = 10,
        separate = true,
        pricesep = 300,
        allowed = {TEAM_GUN},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(20, 20, 170, 255),
})
// Assault Rifles & SMGS //
AddCustomShipment("Acre", {
        model = "models/weapons/w_masada_acr.mdl",
        entity = "m9k_acr",
        price = 5000,
        amount = 10,
        separate = true,
        pricesep = 600,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(20, 170, 20, 255),
})
AddCustomShipment("FN FAL", {
        model = "models/weapons/w_fn_fal.mdl",
        entity = "m9k_fal",
        price = 5000,
        amount = 10,
        separate = true,
        pricesep = 600,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(20, 170, 20, 255),
})
AddCustomShipment("M14", {
        model = "models/weapons/w_snip_m14sp.mdl",
        entity = "m9k_m14sp",
        price = 6000,
        amount = 10,
        separate = true,
        pricesep = 700,
        allowed = {TEAM_GUN},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(20, 170, 20, 255),
})
AddCustomShipment("M16 Scoped", {
        model = "models/weapons/w_dmg_m16ag.mdl",
        entity = "m9k_m16a4_acog",
        price = 6500,
        amount = 10,
        separate = true,
        pricesep = 800,
        allowed = {TEAM_GUN},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(20, 170, 20, 255),
})
AddCustomShipment("Val", {
        model = "models/weapons/w_dmg_vally.mdl",
        entity = "m9k_val",
        price = 5500,
        amount = 10,
        separate = true,
        pricesep = 600,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(20, 170, 20, 255),
})
AddCustomShipment("Winchester 73", {
        model = "models/weapons/w_winchester_1873.mdl",
        entity = "m9k_winchester73",
        price = 3500,
        amount = 10,
        separate = true,
        pricesep = 500,
        allowed = {TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(20, 170, 20, 255),
})
AddCustomShipment("SR-3M Vikhr", {
        model = "models/weapons/w_dmg_vikhr.mdl",
        entity = "m9k_vikhr",
        price = 4500,
        amount = 10,
        separate = true,
        pricesep = 600,
        allowed = {TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(20, 170, 20, 255),
})
// SHOTGUNS //
AddCustomShipment("1887 Winchester", {
        model = "models/weapons/w_winchester_1887.mdl",
        entity = "m9k_1887winchester",
        price = 4500,
        amount = 10,
        separate = true,
        pricesep = 550,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(170, 20, 20, 255),
})
AddCustomShipment("1887 Winchester", {
        model = "models/weapons/w_winchester_1887.mdl",
        entity = "m9k_1887winchester",
        price = 4500,
        amount = 10,
        separate = true,
        pricesep = 550,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(170, 20, 20, 255),
})
AddCustomShipment("Benelli M3", {
        model = "models/weapons/w_benelli_m3.mdl",
        entity = "m9k_m3",
        price = 4500,
        amount = 10,
        separate = true,
        pricesep = 550,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(170, 20, 20, 255),
})
AddCustomShipment("Double Barrel", {
        model = "models/weapons/w_double_barrel_shotgun.mdl",
        entity = "m9k_dbarrel",
        price = 3500,
        amount = 10,
        separate = true,
        pricesep = 450,
        allowed = {TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(170, 20, 20, 255),
})
AddCustomShipment("Jack Hammer", {
        model = "models/weapons/w_pancor_jackhammer.mdl",
        entity = "m9k_jackhammer",
        price = 3000,
        amount = 10,
        separate = true,
        pricesep = 350,
        allowed = {TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(170, 20, 20, 255),
})
AddCustomShipment("1897 Winchester", {
        model = "models/weapons/w_winchester_1897_trench.mdl",
        entity = "m9k_1897winchester",
        price = 3500,
        amount = 10,
        separate = true,
        pricesep = 350,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(170, 20, 20, 255),
})
// SNIPERS //
AddCustomShipment("Barret M82 Winchester", {
        model = "models/weapons/w_barret_m82.mdl",
        entity = "m9k_barret_m82",
        price = 5500,
        amount = 10,
        separate = true,
        pricesep = 700,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(50, 124, 140, 255),
})
AddCustomShipment("Barret M98B", {
        model = "models/weapons/w_barrett_m98b.mdl",
        entity = "m9k_m98b",
        price = 6500,
        amount = 10,
        separate = true,
        pricesep = 750,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(50, 124, 140, 255),
})
AddCustomShipment("SVT 40", {
        model = "models/weapons/w_svt_40.mdl",
        entity = "m9k_svt40",
        price = 4500,
        amount = 10,
        separate = true,
        pricesep = 550,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(50, 124, 140, 255),
})
AddCustomShipment("SVD Dragunov", {
        model = "models/weapons/w_svd_dragunov.mdl",
        entity = "m9k_dragunov",
        price = 6500,
        amount = 10,
        separate = true,
        pricesep = 750,
        allowed = {TEAM_GUN,TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(50, 124, 140, 255),
})
AddCustomShipment("AW 40", {
        model = "models/weapons/w_acc_int_aw50.mdl",
        entity = "m9k_aw50",
        price = 1000,
        amount = 10,
        separate = true,
        pricesep = 1250,
        allowed = {TEAM_ROGUE},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(50, 124, 140, 255),
})
AddCustomShipment("Armor", {
        model = "models/items/combine_rifle_ammo01.mdl",
        entity = "ent_armor",
        price = 1000,
        amount = 10,
        separate = true,
        pricesep = 1250,
        allowed = {TEAM_ROGUE,TEAM_GUN,TEAM_MAYOR},
        shipmodel = "models/items/item_item_crate.mdl",
        buttonColor = Color(78, 104, 206, 255),
})



