/*---------------------------------------------------------------------------
/*---------------------------------------------------------------------------
DarkRP custom entities
---------------------------------------------------------------------------

This file contains your custom entities.
This file should also contain entities from DarkRP that you edited.

Note: If you want to edit a default DarkRP entity, first disable it in darkrp_config/disabled_defaults.lua
	Once youve done that, copy and paste the entity to this file and edit it.

The default entities can be found here:
<TODO: INSERT URL HERE>

Add entities under the following line:
AddEntity("Money Printer", {
	ent = "money_printer",
	model = "models/props_c17/consolebox01a.mdl",
	price = 1000,
	max = 2,
	cmd = "buymoneyprinter"
	--customCheck = function(ply) return ply:IsSupporter() end, 
})
AddEntity("Iron Money Printer", {
	ent = "money_printer_iron",
	model = "models/props_c17/consolebox01a.mdl",
	price = 2000,
	max = 2,
	cmd = "buymoneyprinteriron"
	--customCheck = function(ply) return ply:IsSupporter() end, 
})
AddEntity("Silver Money Printer", {
	ent = "money_printer_silv",
	model = "models/props_c17/consolebox01a.mdl",
	price = 3000,
	max = 2,
	cmd = "buymoneyprintersilver"
	--customCheck = function(ply) return ply:IsSupporter() end, 
})
AddEntity("Golden Money Printer", {
	ent = "money_printer_gold",
	model = "models/props_c17/consolebox01a.mdl",
	price = 5000,
	max = 2,
	cmd = "buymoneyprintergold"
	--customCheck = function(ply) return ply:IsSupporter() end, 
})
AddEntity("VIP Money Printer", {
	ent = "money_printer_vip",
	model = "models/props_c17/consolebox01a.mdl",
	price = 1000,
	max = 2,
	cmd = "buymoneyprintervip"
	--customCheck = function(ply) return ply:IsSupporter() end, 
})


AddEntity("Coolant Cell", {
	ent = "money_coolant_cell",
	model = "models/Items/battery.mdl",
	price = 2000,
	max = 2,
	cmd = "coolantcell"
})

---------------------------------------------------------------------------*/
AddEntity("Printer Upgrade", {
	ent = "money_printer_upgrade",
	model = "models/props_lab/box01a.mdl",
	price = 10000,
	max = 2,
	cmd = "printerupgrade"
})
AddEntity("Printer Coolant", {
	ent = "money_coolant_cell",
	model = "models/items/battery.mdl",
	price = 10000,
	max = 2,
	cmd = "printercooler"
})
AddEntity("Normal Money Printer", {
	ent = "money_normal_printer",
	model = "models/props_lab/reciever01a.mdl",
	price = 2000,
	max = 2,
	cmd = "normalprinter"
})

AddEntity("Coal Money Printer", {
	ent = "money_coal_printer",
	model = "models/props_lab/reciever01a.mdl",
	price = 4000,
	max = 2,
	cmd = "coalprinter"
})

AddEntity("Ruby Money Printer", {
	ent = "money_ruby_printer",
	model = "models/props_lab/reciever01a.mdl",
	price = 5000,
	max = 2,
	cmd = "rubyprinter"
})

AddEntity("Sapphire Money Printer", {
	ent = "money_sapphire_printer",
	model = "models/props_lab/reciever01a.mdl",
	price = 10000,
	max = 2,
	cmd = "sapphireprinter"
})

AddEntity("Diamond Money Printer", {
	ent = "money_diamond_printer",
	model = "models/props_lab/reciever01a.mdl",
	price = 50000,
	max = 2,
	cmd = "diamondprinter"
})

AddEntity("VIP Money Printer", {
	ent = "money_black_printer",
	model = "models/props_lab/reciever01a.mdl",
	price = 50000,
	max = 2,
	cmd = "blackprinter",
	customCheck = function(ply) return ply:IsSupporter() end
})
