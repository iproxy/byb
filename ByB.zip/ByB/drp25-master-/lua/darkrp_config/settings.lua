/*---------------------------------------------------------------------------
/*---------------------------------------------------------------------------
DarkRP config settings
---------------------------------------------------------------------------

This is the settings file of DarkRP. Every DarkRP setting is listed here.

Warning:
If this file is missing settings (because of e.g. an update), DarkRP will assume default values for these settings.
You need not worry about updating this file. If a new setting is added you can manually add them to this file.
---------------------------------------------------------------------------*/


/*
Toggle settings
Set to true or false
*/

-- voice3D - Enable/disable 3DVoice is enabled
GM.Config.voice3D						= false
-- adminnpcs - Whether or not NPCs should be admin only.
GM.Config.adminnpcs 					= true
-- AdminsCopWeapons - Enable/disable admins spawning with cop weapons
GM.Config.AdminsCopWeapons 				= false
-- adminsents - Whether or not SENTs should be admin only.
GM.Config.adminsents 					= true
-- adminvehicles - Whether or not Vehicles should be admin only.
GM.Config.adminvehicles 				= true
-- allow people getting their own custom jobs
GM.Config.allowjobswitch 				= true
-- allowrpnames - Allow Players to Set their RP names using the /rpname command.
GM.Config.allowrpnames 					= true
-- allowsprays - Enable/disable the use of sprays on the server.
GM.Config.allowsprays 					= true
-- allowvehicleowning - Enable/disable whether people can own vehicles.
GM.Config.allowvehicleowning 			= true
-- allowvnocollide - Enable/disable the ability to no-collide a vehicle (for security).
GM.Config.allowvnocollide 				= false
-- alltalk - Enable for global chat, disable for local chat.
GM.Config.alltalk 						= false
-- autovehiclelock - Enable/Disable automatic locking of a vehicle when a player exits it.
GM.Config.autovehiclelock 				= false
-- babygod - people spawn godded (prevent spawn killing)
GM.Config.babygod 						= false
-- canforcedooropen - whether players can force an unownable door open with lockpick or battering ram or w/e
GM.Config.canforcedooropen				= true
-- chatsounds - sounds are played when some things are said in chat
GM.Config.chatsounds					= true
-- chiefjailpos - Allow the Chief to set the jail positions.
GM.Config.chiefjailpos 					= true
-- cit_propertytax - Enable/disable property tax that is exclusive only for citizens.
GM.Config.cit_propertytax 				= false
-- copscanunfreeze - Enable/disable the ability of cops to unfreeze other people's props
GM.Config.copscanunfreeze 				= false
-- copscanunweld - Enable/disable the ability of cops to unweld other people's props
GM.Config.copscanunweld 				= false
-- cpcanarrestcp - Allow/Disallow CPs to arrest other CPs.
GM.Config.cpcanarrestcp 				= false
-- customjobs - Enable/disable the /job command (personalized job names).
GM.Config.customjobs 					= true
-- customspawns - Enable/disable whether custom spawns should be used.
GM.Config.customspawns 					= true
-- deathblack - Whether or not a player sees black on death.
GM.Config.deathblack 					= true
-- showdeaths - Display kill information in the upper right corner of everyone's screen.
GM.Config.showdeaths 					= false
-- deathpov - Enable/disable whether people see their death in first person view
GM.Config.deathpov 						= true
-- decalcleaner - Enable/Disable clearing ever players decals.
GM.Config.decalcleaner 					= true
-- disallowClientsideScripts - Clientside scripts can be very useful for customizing the HUD or to aid in building. This option bans those scripts.
GM.Config.disallowClientsideScripts		= true
-- doorwarrants - Enable/disable Warrant requirement to enter property.
GM.Config.doorwarrants 					= false
-- dropmoneyondeath - Enable/disable whether people drop money on death.
GM.Config.dropmoneyondeath 				= false
-- droppocketarrest - Enable/disable whether people drop the stuff in their pockets when they get arrested.
GM.Config.droppocketarrest 				= true
-- droppocketdeath - Enable/disable whether people drop the stuff in their pockets when they die.
GM.Config.droppocketdeath 				= true
-- dropweapondeath - Enable/disable whether people drop their current weapon when they die.
GM.Config.dropweapondeath 				= false
-- Whether players can drop the weapons they spawn with
GM.Config.dropspawnedweapons			= false
-- dynamicvoice - Enable/disable whether only people in the same room as you can hear your mic.
GM.Config.dynamicvoice 					= false
-- earthquakes - Enable/disable earthquakes.
GM.Config.earthquakes 					= false
-- enablebuypistol - Turn /buy on of off.
GM.Config.enablebuypistol 				= true
-- enforceplayermodel - Whether or not to force players to use their role-defined character models.
GM.Config.enforceplayermodel 			= true
-- globalshow - Whether or not to display player info above players' heads in-game.
GM.Config.globalshow 					= false
-- ironshoot - Enable/disable whether people need iron sights to shoot.
GM.Config.ironshoot 					= false
-- showjob - Whether or not to display a player's job above their head in-game.
GM.Config.showjob 						= true
-- letters - Enable/disable letter writing / typing.
GM.Config.letters 						= true
-- license - Enable/disable People need a license to be able to pick up guns
GM.Config.license 						= false
-- logging - Enable/disable logging everything that happens.
GM.Config.logging 						= true
-- lottery - Enable/disable creating lotteries for mayors
GM.Config.lottery 						= true
-- showname - Whether or not to display a player's name above their head in-game.
GM.Config.showname 						= true
-- needwantedforarrest - Enable/disable Cops can only arrest wanted people.
GM.Config.needwantedforarrest 			= false
-- noguns - Enabling this feature bans Guns and Gun Dealers.
GM.Config.noguns 						= false
-- norespawn - Enable/Disable that people don't have to respawn when they change job.
GM.Config.norespawn 					= false
-- npcarrest - Enable/disable arresting npc's
GM.Config.npcarrest 					= true
-- ooc - Whether or not OOC tags are enabled.
GM.Config.ooc 							= true
-- propertytax - Enable/disable property tax.
GM.Config.propertytax 					= false
-- proppaying - Whether or not players should pay for spawning props.
GM.Config.proppaying 					= false
-- propspawning - Enable/disable props spawning for non-admins.
GM.Config.propspawning 					= true
-- removeclassitems - Enable/disable shipments/microwaves/etc. removal when someone changes team.
GM.Config.removeclassitems 				= false
-- respawninjail - Enable/disable whether people can respawn in jail when they die
GM.Config.respawninjail 				= false
-- restrictallteams - Enable/disable Players can only be citizen until an admin allows them.
GM.Config.restrictallteams 				= false
-- restrictbuypistol - Enabling this feature makes /buy available only to Gun Dealers.
GM.Config.restrictbuypistol 			= true
-- restrictdrop - Enable/disable restricting the weapons players can drop. Setting this to true disallows weapons from shipments from being dropped
GM.Config.restrictdrop 					= false
-- strictsuicide - Whether or not players should spawn where they suicided
GM.Config.strictsuicide 				= false
-- telefromjail - Enable/disable teleporting from jail.
GM.Config.telefromjail 					= true
-- teletojail - Enable/disable teleporting to jail.
GM.Config.teletojail 					= true
-- unlockdoorsonstart - Enable/Disable unlocking all doors on map start.
GM.Config.unlockdoorsonstart 			= true
-- voiceradius - Enable/disable local voice chat.
GM.Config.voiceradius 					= true
-- tax - Whether players pay taxes on their wallets.
GM.Config.wallettax 					= false
-- wantedsuicide - Enable/Disable suiciding while you are wanted by the police.
GM.Config.wantedsuicide 				= false
-- showcrosshairs - Enable/disable crosshair visibility
GM.Config.showcrosshairs				= true
-- realisticfalldamage - Enable/Disable dynamic fall damage. Setting mp_falldamage to 1 will over-ride this.
GM.Config.realisticfalldamage			= false
-- printeroverheat - Can the default money printer overheat on its own?
GM.Config.printeroverheat				= true

/*
Value settings
*/
-- adminweapons - Who can spawn weapons: 0: admins only, 1: supadmins only, 2: no one
GM.Config.adminweapons					= 1
-- arrestspeed - Sets the max arrest speed.
GM.Config.arrestspeed					= 120
-- babygodtime - How long the babygod lasts
GM.Config.babygodtime					= 5
-- chatsoundsdelay - How long to wait before letting a player emit a sound from their chat again. Leave this on at least a few seconds to prevent 'HAXHAXHAXHAXHAXHAX'-ing. Set to 0 to disable.
GM.Config.chatsoundsdelay				= 5
-- deathfee - the amount of money someone drops when dead.
GM.Config.deathfee						= 30
-- decaltimer - Sets the time to clear clientside decals. (seconds)
GM.Config.decaltimer					= 120
-- demotetime - Number of seconds before a player can rejoin a team after demotion from that team.
GM.Config.demotetime					= 120
-- doorcost - Sets the cost of a door.
GM.Config.doorcost						= 30
-- entremovedelay - how long to wait before removing a bought entity after disconnect.
GM.Config.entremovedelay				= 0
-- jailtimer - Sets the jailtimer. (in seconds)
GM.Config.jailtimer						= 120
-- maxdoors - Sets the max amount of doors one can own.
GM.Config.maxdoors						= 10
-- maxdrugs - Sets max drugs.
GM.Config.maxdrugs						= 2
-- maxfoods - Sets the max food cartons per Microwave owner.
GM.Config.maxfoods						= 2
-- maxlawboards - The maximum number of law boards the mayor can place.
GM.Config.maxlawboards					= 2
-- maxletters - Sets max letters.
GM.Config.maxletters					= 10
-- maxlotterycost - Maximum payment the mayor can set to join a lottery.
GM.Config.maxlotterycost				= 2000
-- maxvehicles - Sets how many vehicles one can buy.
GM.Config.maxvehicles					= 5
-- microwavefoodcost - Sets the sale price of Microwave Food.
GM.Config.microwavefoodcost				= 30
-- minlotterycost - Minimum payment the mayor can set to join a lottery.
GM.Config.minlotterycost				= 30
-- Money packets will get removed if they don't get picked up after a while. Set to 0 to disable
GM.Config.moneyRemoveTime				= 600
-- mprintamount - Value of the money printed by the money printer.
GM.Config.mprintamount					= 250
-- normalsalary - Sets the starting salary for newly joined players.
GM.Config.normalsalary					= 45
-- npckillpay - Sets the money given for each NPC kill.
GM.Config.npckillpay					= 10
-- paydelay - Sets how long it takes before people get salary
GM.Config.paydelay						= 160
-- pocketitems - Sets the amount of objects the pocket can carry
GM.Config.pocketitems					= 10
-- pricecap - The maximum price of items (using /price)
GM.Config.pricecap						= 500
-- pricemin - The minimum price of items (using /price)
GM.Config.pricemin						= 50
-- propcost - How much prop spawning should cost. (prop paying must be enabled for this to have an effect)
GM.Config.propcost						= 10
-- quakechance - Chance of an earthquake happening.
GM.Config.quakechance					= 4000
-- respawntime - Minimum amount of seconds a player has to wait before respawning.
GM.Config.respawntime					= 1
-- runspeed - Sets the max running speed.
GM.Config.runspeed						= 240
-- runspeed - Sets the max running speed for CP teams
GM.Config.runspeedcp					= 255
-- searchtime - Number of seconds for which a search warrant is valid.
GM.Config.searchtime					= 30
-- ShipmentSpawnTime - Antispam time between spawning shipments.
GM.Config.ShipmentSpamTime				= 3
-- shipmenttime - The number of seconds it takes for a shipment to spawn.
GM.Config.shipmentspawntime				= 10
-- startinghealth - the health when you spawn.
GM.Config.startinghealth				= 100
-- startingmoney - your wallet when you join for the first time.
GM.Config.startingmoney					= 50000
-- vehiclecost - Sets the cost of a vehicle (To own it).
GM.Config.vehiclecost					= 40
-- wallettaxmax - Maximum percentage of tax to be paid.
GM.Config.wallettaxmax					= 5
-- wallettaxmin - Minimum percentage of tax to be paid.
GM.Config.wallettaxmin					= 1
-- wallettaxtime - Time in seconds between taxing players. Requires server restart.
GM.Config.wallettaxtime					= 600
-- wantedtime - Number of seconds for which a player is wanted for.
GM.Config.wantedtime					= 120
-- walkspeed - Sets the max walking speed.
GM.Config.walkspeed						= 160
-- falldamagedamper - The damper on realistic fall damage. Default is 15. Decrease this for more damage.
GM.Config.falldamagedamper				= 15
-- falldamageamount - The base damage taken from falling for static fall damage. Default is 10
GM.Config.falldamageamount				= 10
-- printeroverheatchance - The likelyhood of a printer overheating. The higher this number, the less likely. Minimum 3. Default 22
GM.Config.printeroverheatchance			= 22

/*---------------------------------------------------------------------------
Other settings
---------------------------------------------------------------------------*/

-- The skin DarkRP uses. Set to "default" to use the GMod default derma theme
GM.Config.DarkRPSkin = "DarkRP"
GM.Config.currency = "$"
GM.Config.chatCommandPrefix = "/"
GM.Config.F1MenuHelpPage = "http://wiki.darkrp.com/index.php/Main_Page"
GM.Config.F1MenuHelpPageTitle = "Wiki page"

-- Put Steam ID's and ranks in this list, and the players will have that rank when they join.
GM.Config.DefaultPlayerGroups = {
	["STEAM_0:0:00000000"] = "superadmin",
	["STEAM_0:0:11111111"] = "admin",
}

-- Custom modules in this addon that are disabled.
GM.Config.DisabledCustomModules = {
       ["hudreplacement"] = false,
       ["extraf4tab"] = false,
}

-- The list of weapons that players are not allowed to drop. Items set to true are not allowed to be dropped
GM.Config.DisallowDrop = {
	["arrest_stick"] = true,
	["door_ram"] = true,
	["gmod_camera"] = true,
	["gmod_tool"] = true,
	["keys"] = true,
	["lockpick"] = true,
	["med_kit"] = true,
	["pocket"] = true,
	["stunstick"] = true,
	["unarrest_stick"] = true,
	["weapon_keypadchecker"] = true,
	["weapon_physcannon"] = true,
	["weapon_physgun"] = true,
	["weaponchecker"] = true
}

-- The list of weapons people spawn with
GM.Config.DefaultWeapons = {
	"keys",
	"weapon_physcannon",
	"gmod_camera",
	"gmod_tool",
	"pocket",
	"weapon_physgun"
}

-- The list of weapons admins spawn with, in addition to the normal weapons
--
GM.Config.AdminWeapons = {
--	"weapon_keypadchecker"
}

-- These are the default laws, they're unchangeable in-game.
GM.Config.DefaultLaws = {
	"Do not attack other citizens except in self-defence.",
	"Do not steal or break in to peoples homes.",
	"Money printers/drugs are illegal."
}

GM.Config.PocketBlacklist = {
	["fadmin_jail"] = true,
	["meteor"] = true,
	["door"] = true,
	["func_"] = true,
	["player"] = true,
	["beam"] = true,
	["worldspawn"] = true,
	["env_"] = true,
	["path_"] = true,
	["prop_physics"] = true,
	["money_normal_printer"] = true,
	["money_black_printer"] = true,
	["money_coal_printer"] = true,
	["money_diamond_printer"] = true,
	["money_pearl_printer"] = true,
	["money_emerald_printer"] = true,
	["money_platinum_printer"] = true,
	["money_ruby_printer"] = true,
	["money_white_printer"] = true,
	["money_sapphire_printer"] = true,
	["spawned_money"] = true,
	["spawned_money"] = true,
	["darkrp_cheque"] = true,
	["gunlab"] = true,
	["spawned_weapon"] = true,
	["m9k_thrown_weapon"] = true,
}

-- These weapons are classed as 'legal' in the weapon checker and are not stripped when confiscating weapons.
GM.Config.noStripWeapons = {
	["weapon_physgun"] = true,
	["weapon_physcannon"] = true,
	["keys"] = true,
	["gmod_camera"] = true,
	["gmod_tool"] = true,
	["weaponchecker"] = true,
	["med_kit"] = true,
	["pocket"] = true,
}

-- Properties set to true are allowed to be used. Values set to false or are missing from this list are blocked.
GM.Config.allowedProperties = {
	remover = true,
	ignite = false,
	extinguish = true,
	keepupright = false,
	gravity = false,
	collision = true,
	skin = true,
	bodygroups = true,
}

/*---------------------------------------------------------------------------
F4 menu
---------------------------------------------------------------------------*/
-- hide the items that you can't buy and the jobs you can't get (instead of graying them out)
-- this option hides items when you don't have enough money, when the maximum is reached for a job or any other reason
GM.Config.hideNonBuyable = false

-- Hide only the items that you have the wrong job for (or for which the customCheck says no)
-- When you set this option to true and hideNonBuyable to false, you WILL see e.g. items that are too expensive for you to buy
-- but you won't see gundealer shipments when you have the citizen job
GM.Config.hideTeamUnbuyable = true

/*---------------------------------------------------------------------------
AFK module
---------------------------------------------------------------------------*/
GM.Config.afkdemotetime = 900

/*---------------------------------------------------------------------------
Hitmenu module
---------------------------------------------------------------------------*/
-- The minimum price for a hit
GM.Config.minHitPrice = 200
-- The minimum distance between a hitman and his customer when they make the deal
GM.Config.minHitDistance = 150
-- The text that tells the player he can press use on the hitman to request a hit
GM.Config.hudText = "I am a hitman.\nPress E on me to request a hit!"
-- The text above a hitman when he's got a hit
GM.Config.hitmanText = "Hit\naccepted!"
-- The cooldown time for a hit target (so they aren't spam killed)
GM.Config.hitTargetCooldown = 360
-- How long a customer has to wait to be able to buy another hit (from the moment the hit is accepted)
GM.Config.hitCustomerCooldown = 240

/*---------------------------------------------------------------------------
Hungermod module
---------------------------------------------------------------------------*/
-- hungerspeed <Amount> - Set the rate at which players will become hungry (2 is the default)
GM.Config.hungerspeed = 2
-- starverate <Amount> - How much health that is taken away every second the player is starving  (3 is the default)
GM.Config.starverate = 3
