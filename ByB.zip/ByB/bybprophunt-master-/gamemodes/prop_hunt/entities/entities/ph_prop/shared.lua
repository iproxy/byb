// Entity information
ENT.Type = "anim"
ENT.Base = "base_anim"