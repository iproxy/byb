Yay ByB Prophunt <3

-- Credits --
Kow@lski for the excellent Garry's Mod Prophunt - http://xspacesoft.github.io/PropHunt/ 

-- Original Credits -- 
Credit goes for the original authors of both gamemodes and who made Prop Hunt compatible with GMOD 13. 
Originally written and released by Darkimmortal (TF2)
