//require("datastream")
SWEP.Category = "DarkRP"
SWEP.PrintName = "Pocket"
SWEP.Slot = 1
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

SWEP.Author = "FPtje and everyone who gave FPtje the idea"
SWEP.Instructions = "Left click to pick up, right click to drop, reload for menu"
SWEP.Contact = ""
SWEP.Purpose = ""

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.AnimPrefix	 = "rpg"

SWEP.Spawnable = false
SWEP.AdminSpawnable = true
SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = 0
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = ""

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = 0
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = ""

if CLIENT then
	SWEP.FrameVisible = false
end

function SWEP:Initialize()
	if SERVER then self:SetHoldType("normal") end
end

function SWEP:Deploy()
	if SERVER then
		self.Owner:DrawViewModel(false)
		self.Owner:DrawWorldModel(false)
	end
end

local whitelist = {"spawned_shipment", "spawned_weapon", "empty_shipment", "letter"}
function SWEP:PrimaryAttack()
	if CLIENT then return end

	self.Weapon:SetNextPrimaryFire(CurTime() + 0.2)
	local trace = self.Owner:GetEyeTrace()

	if not IsValid(trace.Entity) then
		return
	end
	
	if self.Owner:EyePos():Distance(trace.HitPos) > 65 then
		return
	end
	
	local phys = trace.Entity:GetPhysicsObject()
	if not phys:IsValid() then return end
	local mass = phys:GetMass()
	
	if SERVER then
		self:SetHoldType("pistol")
		timer.Simple(0.2, function() if self:IsValid() then self:SetHoldType("normal") end end)
	end
	
	self.Owner.Pocket = self.Owner.Pocket or {} 
	local pent = trace.Entity:GetClass()
	local found;
	for _, class in pairs(whitelist) do
		if (pent == class) then
			found = true;
			break;
		end
	end
	if (not found) then
		GAMEMODE:Notify(self.Owner,1,4,"I don't think that wants to go into your pocket.");
		return false;
	end

	--for k,v in pairs(blacklist) do 
	--	if string.find(string.lower(trace.Entity:GetClass()), v) then

	--	end
	--end
	
	--if mass > 100 then
	--	GAMEMODE:Notify(self.Owner, 1, 4, "This object is too heavy.")
	--	return
	--end
	local Psize = 10
	if self.Owner:IsSupporter() then Psize = 20	end
	--if not CfgVars["pocketitems"] then CfgVars["pocketitems"] = 10 end
	if #self.Owner.Pocket >= Psize then
		GAMEMODE:Notify(self.Owner, 1, 4, "Your pocket is full!")
		return
	end

	umsg.Start("Pocket_AddItem", self.Owner)
	umsg.Short(trace.Entity:EntIndex())
	umsg.End()
	
	table.insert(self.Owner.Pocket, trace.Entity)
	ent = trace.Entity
	ent:SetNoDraw()
	ent:SetPos(Vector(-1434.454712, -1910.167603,  -1868.270508))
	ent.STID = "Pocket changed ID to: ".. self.Owner:SteamID()
	--trace.Entity:SetCollisionGroup(0)
	local phys = ent:GetPhysicsObject()
	phys:EnableMotion(false)
	ent:SetMoveType(MOVETYPE_VPHYSICS)
	if phys:IsValid() then
		phys:EnableCollisions(false)
		phys:Wake()
	end


end

function SWEP:SecondaryAttack()
	if CLIENT then return end
	self.Weapon:SetNextSecondaryFire(CurTime() + 0.2)
	
	if not self.Owner.Pocket or #self.Owner.Pocket <= 0 then
		GAMEMODE:Notify(self.Owner, 1, 4, "Your pocket contains no items.")
		return
	end
	local ent = self.Owner.Pocket[#self.Owner.Pocket]
	self.Owner.Pocket[#self.Owner.Pocket] = nil
	if not IsValid(ent) then GAMEMODE:Notify(self.Owner, 1, 4, "Your pocket contains no items.") return end
	if SERVER then
		self:SetHoldType("pistol")
		timer.Simple(0.2, function() if self:IsValid() then self:SetHoldType("normal") end end)
	end
	local trace = {}
	trace.start = self.Owner:EyePos()
	trace.endpos = trace.start + self.Owner:GetAimVector() * 85
	trace.filter = self.Owner
	local tr = util.TraceLine(trace)
	ent:SetMoveType(MOVETYPE_VPHYSICS)
	ent:SetNoDraw(false)
	--ent:SetCollisionGroup(4)
	ent:SetPos(tr.HitPos)
	local phys = ent:GetPhysicsObject()
	if phys:IsValid() then
		phys:EnableCollisions(true)
		phys:EnableMotion(true)
		phys:Wake()
	end
	umsg.Start("Pocket_RemoveItem", self.Owner)
	umsg.Short(ent:EntIndex())
	umsg.End()
end

SWEP.OnceReload = 0
function SWEP:Reload()
	if CLIENT or self.OnceReload > CurTime() then return end
	self.OnceReload = CurTime() + 1;
	
	if not self.Owner.Pocket or #self.Owner.Pocket <= 0 then
		GAMEMODE:Notify(self.Owner, 1, 4, "Your pocket contains no items.")
		return
	end
	
	for k,v in pairs(self.Owner.Pocket) do 
		if not IsValid(v) then
			self.Owner.Pocket[k] = nil
			self.Owner.Pocket = table.ClearKeys(self.Owner.Pocket)
			if #self.Owner.Pocket <= 0 then -- Recheck after the entities have been validated.
				GAMEMODE:Notify(self.Owner, 1, 4, "Your pocket contains no items.") 
				return
			end
		end
	end
	
	umsg.Start("StartPocketMenu", self.Owner)
	umsg.End()
end

if CLIENT then
	local function StorePocketItem(um)
		LocalPlayer().Pocket = LocalPlayer().Pocket or {}

		local ent = Entity(um:ReadShort())
		if IsValid(ent) and not table.HasValue(LocalPlayer().Pocket, ent) then
			table.insert(LocalPlayer().Pocket, ent)
		end
	end
	usermessage.Hook("Pocket_AddItem", StorePocketItem)
	
	local function RemovePocketItem(um)
		LocalPlayer().Pocket = LocalPlayer().Pocket or {}
		
		local ent = Entity(um:ReadShort())
		for k,v in pairs(LocalPlayer().Pocket) do
			if v == ent then LocalPlayer().Pocket[k] = nil end
		end
	end
	usermessage.Hook("Pocket_RemoveItem", RemovePocketItem)
	
	local frame
	local function PocketMenu()
		if frame and frame:IsValid() and frame:IsVisible() then return end
		if LocalPlayer():GetActiveWeapon():GetClass() ~= "pocket" then return end
		if not LocalPlayer().Pocket then LocalPlayer().Pocket = {} return end
		for k,v in pairs(LocalPlayer().Pocket) do if not IsValid(v) then table.remove(LocalPlayer().Pocket, k) end end
		if #LocalPlayer().Pocket <= 0 then return end
		LocalPlayer().Pocket = table.ClearKeys(LocalPlayer().Pocket)
		frame = vgui.Create( "DFrame" )
		frame:SetTitle( "Drop item" )
		frame:SetVisible( true )
		frame:MakePopup( )
		
		local items = LocalPlayer().Pocket
		local function Reload()
			frame:SetSize( #items * 64, 90 ) 
			frame:Center()
			for k,v in pairs(items) do
				if not IsValid(v) then 
					items[k] = nil
					for a,b in pairs(LocalPlayer().Pocket) do
						if b == v or not IsValid(b) then
							LocalPlayer().Pocket[a] = nil
						end
					end
					items = table.ClearKeys(items)
					frame:Close()
					PocketMenu()
					break
				end
				local icon = vgui.Create("SpawnIcon", frame)
				icon:SetPos((k-1) * 64, 25)
				icon:SetModel(v:GetModel())
				icon:SetSize(64, 64)
				icon:SetToolTip()
				icon.DoClick = function()
					icon:SetToolTip()
					RunConsoleCommand("_RPSpawnPocketItem", v:EntIndex())
					items[k] = nil
					for a,b in pairs(LocalPlayer().Pocket) do
						if b == v then
							LocalPlayer().Pocket[a] = nil
						end
					end
					if #items == 0 then
						frame:Close()
						return
					end
					items = table.ClearKeys(items)
					Reload()
				end
			end
		end
		Reload()
		frame:SetSkin("DarkRP")
	end
	usermessage.Hook("StartPocketMenu", PocketMenu)
elseif SERVER then
	local function Spawn(ply, cmd, args)
		if ply:GetActiveWeapon():GetClass() ~= "pocket" then
			return
		end
		if ply.Pocket and IsValid(Entity(tonumber(args[1]))) then
			local ent = Entity(tonumber(args[1]))
			if not table.HasValue(ply.Pocket, ent) then return end
			
			for k,v in pairs(ply.Pocket) do 
				if v == ent then
					ply.Pocket[k] = nil
				end
			end
			ply.Pocket = table.ClearKeys(ply.Pocket)
			
			if SERVER then
                local wep = ply:GetActiveWeapon();
				wep:SetHoldType("pistol")
				timer.Simple(0.2, function() if wep:IsValid() then wep:SetHoldType("normal") end end)
			end
			
			local trace = {}
			trace.start = ply:EyePos()
			trace.endpos = trace.start + ply:GetAimVector() * 85
			trace.filter = ply
			local tr = util.TraceLine(trace)
			ent:SetMoveType(MOVETYPE_VPHYSICS)
			ent:SetNoDraw(false)
			ent:SetCollisionGroup(4)
			ent:SetPos(tr.HitPos)
			local phys = ent:GetPhysicsObject()
			if phys:IsValid() then
	if phys:IsValid() then
		phys:EnableCollisions(true)
		phys:EnableMotion(true)
		phys:Wake()
	end
			end
		end
	end
	concommand.Add("_RPSpawnPocketItem", Spawn)

	hook.Add("PlayerDeath", "DropPocketItems", function(ply)if ply.Pocket then 
			for k, v in pairs(ply.Pocket) do
				if IsValid(v) then
					v:SetMoveType(MOVETYPE_VPHYSICS)
					v:SetNoDraw(false)
					v:SetCollisionGroup(4)
					v:SetPos(ply:GetPos() + Vector(0,0,10))
					local phys = v:GetPhysicsObject()
					if phys:IsValid() then
						phys:EnableCollisions(true)
						phys:EnableMotion(true)
						phys:Wake()
					end
				end
			end
		end
		ply.Pocket = nil
	end)
end
