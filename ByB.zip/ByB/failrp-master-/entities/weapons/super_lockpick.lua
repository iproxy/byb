SWEP.Category = "DarkRP"
SWEP.PrintName = "Master Lock Pick"
DEFINE_BASECLASS("lockpick")
SWEP.Author = "Rickster / iRIDEsisters / Lexi"
SWEP.CrackTime = 6
