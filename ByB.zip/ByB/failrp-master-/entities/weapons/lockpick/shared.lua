SWEP.Category = "DarkRP"
SWEP.PrintName = "Lock Pick"
SWEP.Slot = 5
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

DEFINE_BASECLASS("base_cracker")

-- Variables that are used on both client and server

SWEP.Author = "Rickster"
SWEP.Instructions = "Left click to pick a lock"
SWEP.Contact = ""
SWEP.Purpose = ""

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false
SWEP.ViewModel = Model("models/weapons/v_crowbar.mdl")
SWEP.WorldModel = Model("models/weapons/w_crowbar.mdl")

SWEP.AdminSpawnable = true
SWEP.CrackTime = 10

function SWEP:IsTargetEntity(ent)
		return ent:IsDoor() or ent:IsVehicle()
end

local snd = {1,3,4}
function SWEP:DoNoise()
    self:EmitSound("weapons/357/357_reload".. tostring(snd[math.random(1, #snd)]) ..".wav", 70, 100)
end

function SWEP:OnFailure()
    -- . . .
end

function SWEP:OnSuccess()
    if (CLIENT) then return; end
    local ent = self.CrackTarget;
    ent:Fire("unlock", "", .5)
    ent:Fire("open", "", .6)
    ent:Fire("setanimation","open",.6)
end