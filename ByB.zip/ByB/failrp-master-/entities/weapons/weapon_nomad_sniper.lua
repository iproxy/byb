--DEFINE_BASECLASS("weapon_mad_base")
SWEP.Category               = "Arcadium Software";
SWEP.PrintName              = "Nomad Sniper";
SWEP.Author                 = "Arcadium Software (Tobba edit)";
SWEP.Contact                = "cdbarrett@gmail.com";
SWEP.Purpose                = "Destroy your enemy!";
SWEP.Instructions           = "Left click to fire a pulse of energy.";

SWEP.ViewModel              = "models/weapons/v_snip_scout.mdl"
SWEP.WorldModel             = "models/weapons/w_snip_scout.mdl"
SWEP.ViewModelFOV           = 52;
SWEP.ViewModelFlip          = true

SWEP.Slot                   = 2;
SWEP.SlotPos                = 1;
SWEP.Weight                 = 5;
SWEP.AutoSwitchTo           = true;
SWEP.AutoSwitchFrom         = false;

SWEP.SwayScale              = 2.0;
SWEP.BobScale               = 2.0;

SWEP.Primary.ClipSize       = -1;
SWEP.Primary.DefaultClip    = -1;
SWEP.Primary.Automatic      = true;
SWEP.Primary.Ammo           = "none";

SWEP.Secondary.ClipSize     = -1;
SWEP.Secondary.DefaultClip  = -1;
SWEP.Secondary.Automatic    = false;
SWEP.Secondary.Ammo         = "none";

SWEP.Spawnable              = true;
SWEP.AdminSpawnable         = false;

SWEP.IronSightsPos          = Vector (4.9906, -9.5434, 2.5078)
SWEP.IronSightsAng          = Vector (0, 0, 0)
SWEP.RunArmOffset           = Vector (-2.6657, 0, 3.5)
SWEP.RunArmAngle            = Vector (-20.0824, -20.5693, 0)


local EmptySound            = Sound( "buttons/combine_button1.wav" );
local ShootSound            = Sound( "npc/combine_gunship/attack_start2.wav" );

local KillIconInitialized   = false;
local ScopeLevel = 0

--[[------------------------------------
    Initialize()
--------------------------------------]]
function SWEP:Initialize()

    self:SetHoldType( "ar2" );

    -- networked variables
    self:InstallDataTable();
    self:DTVar( "Int", 0, "Energy" );
    self:DTVar( "Bool", 0, "IronSights" );

    if( CLIENT ) then

        self.LastIronSights = false;
        self.IronSightsTime = 0;

        -- initialize the kill icon for toybox entities
        if( !KillIconInitialized ) then

            KillIconInitialized = true;
            killicon.AddFont( self:GetClass(), "HL2MPTypeDeath", "/", Color( 128, 128, 255, 128 ) );

        end

    end

    if( SERVER ) then

        -- setup some npc attributes
        self:SetNPCMinBurst( 1 );
        self:SetNPCMaxBurst( 1 );
        self:SetNPCFireRate( 0.001 );

        self.dt.Energy = 200;
        self.dt.IronSights = false;

        self.NextAmmoRegeneration = CurTime();
        self.NextIdleTime = CurTime();

    end

end


--[[------------------------------------
    DoImpactEffect()
--------------------------------------]]
function SWEP:DoImpactEffect( tr, dmgtype )

    -- having the impact effect on the sky looks strange, ditch it
    if( tr.Hit && !tr.HitSky ) then

        local effect = EffectData();
            effect:SetOrigin( tr.HitPos );
            effect:SetNormal( tr.HitNormal );
        util.Effect( "Nomad3Impact", effect );

    end

    return true;

end


--[[------------------------------------
    CanPrimaryAttack()
--------------------------------------]]
function SWEP:CanPrimaryAttack()

    -- npcs have unlimited ammo
    if( self.Owner:IsNPC() ) then
        return true;
    end

    -- have enough energy to fire?
    if( self.dt.Energy >= 1 ) then
        return true;
    end

    return false;

end


--[[------------------------------------
    PrimaryAttack()
--------------------------------------]]
function SWEP:PrimaryAttack()

    -- bail if we can't fire
    if( !self:CanPrimaryAttack() ) then

        self:EmitSound( EmptySound );

        self:SetNextPrimaryFire( CurTime() + 0.4 );

        if( SERVER ) then

            -- delay ammo regeneration so we don't have
            -- infinite ammo while shooting
            self.NextAmmoRegeneration = CurTime() + 1.25;

        end

        return;

    end

    if( SERVER ) then

        self:TakePrimaryAmmo( 1 );

        -- delay ammo regeneration so we don't have
        -- infinite ammo while shooting
        self.NextAmmoRegeneration = CurTime() + 1.25;

        -- idle
        self.IdleTime = CurTime() + 0.4;

    end

    -- fire the bullet
    local bullet = {
        Num            = 1,
        Src            = self.Owner:GetShootPos(),
        Dir            = self.Owner:GetAimVector(),
        Spread        = Vector( 0.00, 0.00, 0 ),
        Tracer        = 1,
        Force        = 7,
        Damage        = 200,
        AmmoType    = "Pistol",
        TracerName    = "Nomad3Tracer",
        Attacker    = self.Owner,
        Inflictor    = self,
    };
    self.Weapon:FireBullets( bullet );

    -- sound & animation
    self:EmitSound( ShootSound, 100, math.random( 200, 250 ) );
    self:SendWeaponAnim( ACT_VM_PRIMARYATTACK );
    self.Owner:SetAnimation( PLAYER_ATTACK1 );

    -- handle weapon idle times
    if( SERVER ) then

        self.NextIdleTime = CurTime() + self:SequenceDuration();

    end

    -- some view punching to make it not so static.
    if( self.Owner:IsPlayer() ) then

        self.Owner:ViewPunch( Angle( math.Rand( -0.5, 0.5 ), math.Rand( -0.5, 0.5 ), math.Rand( -0.5, 0.5 ) ) );

    end

    local effect = EffectData();
        effect:SetOrigin( self.Owner:GetShootPos() );
        effect:SetEntity( self.Weapon );
        effect:SetAttachment( 1 );
    util.Effect( "Nomad3Muzzle", effect );

    -- we're an automatic weapon
    -- have a decent fire rate
    self:SetNextPrimaryFire( CurTime() + 0.08 );
    --SWEP.BoltActionSniper     = true
end


--[[------------------------------------
    CanSecondaryAttack()
--------------------------------------]]
function SWEP:CanSecondaryAttack()

    return true;

end


--[[------------------------------------
    SecondaryAttack()
--------------------------------------]]
function SWEP:SecondaryAttack()
    --The variable "ScopeLevel" tells how far the scope has zoomed.
    --This SWEP has 2 zoom levels.
    if(ScopeLevel == 0) then

        if(SERVER) then
            self.Owner:SetFOV( 45, 0 )
            --SetFOV changes the field of view, or zoom. First argument is the
            --number of degrees in the player's view (lower numbers zoom farther,)
            --and the second is the duration it takes in seconds.
        end

        ScopeLevel = 2
        --This is zoom level 1.

    else if(ScopeLevel == 1) then

        if(SERVER) then
            self.Owner:SetFOV( 25, 0 )
        end

        ScopeLevel = 2
        --This is zoom level 2.

    else
        --If the user is zoomed in all the way, reset their view.
        if(SERVER) then
            self.Owner:SetFOV( 0, 0 )
            --Setting the FOV to zero resets the player's view, AFAIK
        end

        ScopeLevel = 0
        --There is no zoom.

    end
    end

end


--[[------------------------------------
    Reload()
--------------------------------------]]
function SWEP:Reload()
end


--[[------------------------------------
    Think()
--------------------------------------]]
function SWEP:Think()

    if( SERVER ) then

        -- do idle
        if( self.NextIdleTime <= CurTime() ) then

            self:SendWeaponAnim( ACT_VM_IDLE );
            self.NextIdleTime = CurTime() + self:SequenceDuration();

        end

        -- regenerate energy
        if( self.NextAmmoRegeneration <= CurTime() ) then

            self.dt.Energy = math.min( 1000, self.dt.Energy + 1 );
            self.NextAmmoRegeneration = CurTime() + 0.01;

        end

    end

end


--[[------------------------------------
    Deploy()
--------------------------------------]]
function SWEP:Deploy()

    if( SERVER ) then

        self.dt.IronSights = false;

    end

end


--[[------------------------------------
    Holster()
--------------------------------------]]
function SWEP:Holster()

    if( SERVER ) then

        self.Owner:CrosshairEnable();

    end

    return true;

end


if( CLIENT ) then

    local AmmoDisplay = {};

    --[[------------------------------------
        CustomAmmoDisplay()
    --------------------------------------]]
    function SWEP:CustomAmmoDisplay()

        AmmoDisplay.Draw            = true;
        AmmoDisplay.PrimaryClip        = self.dt.Energy;
        AmmoDisplay.PrimaryAmmo        = -1;
        AmmoDisplay.SecondaryClip    = -1;
        AmmoDisplay.SecondaryAmmo    = -1;

        return AmmoDisplay;

    end


    --[[------------------------------------
        GetTracerOrigin()
    --------------------------------------]]
    function SWEP:GetTracerOrigin()

        local pos, ang = GetMuzzlePosition( self );
        return pos;

    end


    --[[------------------------------------
        GetViewModelPosition()
    --------------------------------------]]
    function SWEP:GetViewModelPosition( pos, ang )

        local ironsights = self.dt.IronSights;

        -- just changed
        if( self.LastIronSights != ironsights ) then

            self.LastIronSights = ironsights;
            self.IronSightsTime = CurTime();

            -- modify sway/bob scales
            if( ironsights ) then

                self.SwayScale = 0.1;
                self.BobScale = 0.15;

            else

                self.SwayScale = 2;
                self.BobScale = 2;

            end

        end

        local ironTime = self.IronSightsTime;
        local time = CurTime() - 0.25;

        -- not in ironsights, return default position
        if( !ironsights && ironTime < time ) then

            return pos, ang;

        end

        -- figure out the fraction for transitioning
        local frac = 1;
        if( ironTime > time ) then

            frac = math.Clamp( ( CurTime() - ironTime ) / 0.25, 0, 1 );

            if( !ironsights ) then
                frac = 1 - frac;
            end

        end

        local offset = self.IronSightsPos;

        if( self.IronSightsAng ) then

            ang = ang * 1;
            ang:RotateAroundAxis( ang:Right(), self.IronSightsAng.x * frac );
            ang:RotateAroundAxis( ang:Up(), self.IronSightsAng.y * frac );
            ang:RotateAroundAxis( ang:Forward(), self.IronSightsAng.z * frac );

        end

        pos = pos + offset.x * ang:Right() * frac;
        pos = pos + offset.y * ang:Forward() * frac;
        pos = pos + offset.z * ang:Up() * frac;

        return pos, ang

    end

end


if( SERVER ) then

    --[[------------------------------------
        ToggleIronSights()
    --------------------------------------]]
    function SWEP:ToggleIronSights()

        self.dt.IronSights = !self.dt.IronSights;

        -- enable/disable crosshair
        if( self.dt.IronSights ) then
            self.Owner:CrosshairDisable();
        else
            self.Owner:CrosshairEnable();
        end

    end

    --[[------------------------------------
        TakePrimaryAmmo()
    --------------------------------------]]
    function SWEP:TakePrimaryAmmo( amt )

        self.dt.Energy = math.max( 0, self.dt.Energy - amt );

    end


    --[[------------------------------------
        GetCapabilities()
    --------------------------------------]]
    function SWEP:GetCapabilities()

        return CAP_WEAPON_RANGE_ATTACK1 + CAP_INNATE_RANGE_ATTACK1;

    end


    --[[------------------------------------
        NPCShoot_Secondary()
    --------------------------------------]]
    function SWEP:NPCShoot_Secondary( ShootPos, ShootDir )

        if( IsValid( self.Owner ) ) then
            self:SecondaryAttack();
        end

    end


    --[[------------------------------------
        NPCShoot_Primary()
    --------------------------------------]]
    function SWEP:NPCShoot_Primary( ShootPos, ShootDir )

        if( IsValid( self.Owner ) ) then
            self:PrimaryAttack();
        end

    end

end


AccessorFunc( SWEP, "fNPCMinBurst", "NPCMinBurst" );
AccessorFunc( SWEP, "fNPCMaxBurst", "NPCMaxBurst" );
AccessorFunc( SWEP, "fNPCFireRate", "NPCFireRate" );
AccessorFunc( SWEP, "fNPCMinRestTime", "NPCMinRest" );
AccessorFunc( SWEP, "fNPCMaxRestTime", "NPCMaxRest" );


--[[------------------------------------
    GetMuzzlePosition()
--------------------------------------]]
local function GetMuzzlePosition( weapon, attachment )

    if( !IsValid( weapon ) ) then
        return vector_origin, vector_up;
    end

    local origin = weapon:GetPos();
    local angle = weapon:GetAngles();

    -- if we're not in a camera and we're being carried by the local player
    -- use their view model instead.
    if( weapon:IsWeapon() && weapon:IsCarriedByLocalPlayer() ) then

        local owner = weapon:GetOwner();
        if( IsValid( owner ) && GetViewEntity() == owner ) then

            local viewmodel = owner:GetViewModel();
            if( IsValid( viewmodel ) ) then
                weapon = viewmodel;
            end

        end

    end

    -- get the attachment
    local attachment = weapon:GetAttachment( attachment or 1 );
    if( !attachment ) then
        return origin, angle;
    end

    return attachment.Pos, attachment.Ang;

end


if( CLIENT ) then

    local GlowMaterial = CreateMaterial( "arcadiumsoft/glow", "UnlitGeneric", {
        [ "$basetexture" ]    = "sprites/light_glow01",
        [ "$additive" ]        = "1",
        [ "$vertexcolor" ]    = "1",
        [ "$vertexalpha" ]    = "1",
    } );

    local EFFECT = {};


    --[[------------------------------------
        Init()
    --------------------------------------]]
    function EFFECT:Init( data )

        self.Weapon = data:GetEntity();

        self:SetRenderBounds( Vector( -16, -16, -16 ), Vector( 16, 16, 16 ) );
        self:SetParent( self.Weapon );

        self.LifeTime = math.Rand( 0.05, 0.15 );
        self.DieTime = CurTime() + self.LifeTime;
        self.Size = math.Rand( 16, 24 );

        local pos, ang = GetMuzzlePosition( self.Weapon );

        -- emit a burst of light
        local light = DynamicLight( self.Weapon:EntIndex() );
            light.Pos            = pos;
            light.Size            = 200;
            light.Decay            = 400;
            light.R                = 255;
            light.G                = 185;
            light.B                = 15;
            light.Brightness    = 2;
            light.DieTime        = CurTime() + 0.35;

    end


    --[[------------------------------------
        Think()
    --------------------------------------]]
    function EFFECT:Think()

        return IsValid( self.Weapon ) && self.DieTime >= CurTime();

    end


    --[[------------------------------------
        Render()
    --------------------------------------]]
    function EFFECT:Render()

        -- how'd this happen?
        if( !IsValid( self.Weapon ) ) then
            return;
        end

        local pos, ang = GetMuzzlePosition( self.Weapon );

        local percent = math.Clamp( ( self.DieTime - CurTime() ) / self.LifeTime, 0, 1 );
        local alpha = 255 * percent;

        render.SetMaterial( GlowMaterial );

        -- draw it twice to double the brightness D:
        for i = 1, 2 do
            render.DrawSprite( pos, self.Size, self.Size, Color( 255, 185, 15, alpha ) );
            render.StartBeam( 2 );
                render.AddBeam( pos - ang:Forward() * 48, 16, 0, Color( 255, 185, 15, alpha ) );
                render.AddBeam( pos + ang:Forward() * 64, 16, 1, Color( 255, 185, 15, 0 ) );
            render.EndBeam();
        end

    end

    effects.Register( EFFECT, "Nomad3Muzzle" );

end


if( CLIENT ) then

    local GlowMaterial = CreateMaterial( "arcadiumsoft/glow", "UnlitGeneric", {
        [ "$basetexture" ]    = "sprites/light_glow01",
        [ "$additive" ]        = "1",
        [ "$vertexcolor" ]    = "1",
        [ "$vertexalpha" ]    = "1",
    } );

    local EFFECT = {};


    --[[------------------------------------
        Init()
    --------------------------------------]]
    function EFFECT:Init( data )

        local pos = data:GetOrigin();
        local normal = data:GetNormal();

        self.Position = pos;
        self.Normal = normal;

        self.LifeTime = math.Rand( 0.25, 0.35 );    -- 0.25, 0.35
        self.DieTime = CurTime() + self.LifeTime;
        self.Size = math.Rand( 32, 48 );

        -- impact particles
        local emitter = ParticleEmitter( pos );
        for i = 1, 32 do

            local particle = emitter:Add( "sprites/glow04_noz", pos + normal * 2 );
            particle:SetVelocity( ( normal + VectorRand() * 0.75 ):GetNormal() * math.Rand( 75, 125 ) );
            particle:SetDieTime( math.Rand( 0.5, 1.25 ) );
            particle:SetStartAlpha( 255 );
            particle:SetEndAlpha( 0 );
            particle:SetStartSize( math.Rand( 1, 2 ) );
            particle:SetEndSize( 0 );
            particle:SetRoll( 0 );
            particle:SetColor( 255, 185, 15 );
            particle:SetGravity( Vector( 0, 0, -250 ) );
            particle:SetCollide( true );
            particle:SetBounce( 0.3 );
            particle:SetAirResistance( 5 );

        end
        emitter:Finish();

        -- emit a burst of light
        local light = DynamicLight( 0 );
            light.Pos            = pos;
            light.Size            = 64;
            light.Decay            = 256;
            light.R                = 185;
            light.G                = 15;
            light.B                = 255;
            light.Brightness    = 2;
            light.DieTime        = CurTime() + 0.35;

    end


    --[[------------------------------------
        Think()
    --------------------------------------]]
    function EFFECT:Think()

        return self.DieTime >= CurTime();

    end


    --[[------------------------------------
        Render()
    --------------------------------------]]
    function EFFECT:Render()

        local pos, normal = self.Position, self.Normal;

        local percent = math.Clamp( ( self.DieTime - CurTime() ) / self.LifeTime, 0, 1 );
        local alpha = 255 * percent;

        -- draw the muzzle flash as a series of sprites
        render.SetMaterial( GlowMaterial );
        render.DrawQuadEasy( pos + normal, normal, self.Size, self.Size, Color( 255, 185, 18, alpha ) );

    end

    effects.Register( EFFECT, "Nomad3Impact" );

end


if( CLIENT ) then

    local SparkMaterial = CreateMaterial( "arcadiumsoft/spark", "UnlitGeneric", {
        [ "$basetexture" ]    = "effects/spark",
        [ "$brightness" ]    = "effects/spark_brightness",
        [ "$additive" ]        = "1",
        [ "$vertexcolor" ]    = "1",
        [ "$vertexalpha" ]    = "1",
    } );

    local EFFECT = {};


    --[[------------------------------------
        Init()
    --------------------------------------]]
    function EFFECT:Init( data )

        local weapon = data:GetEntity();
        local attachment = data:GetAttachment();

        local startPos = GetMuzzlePosition( weapon, attachment );
        local endPos = data:GetOrigin();
        local distance = ( startPos - endPos ):Length();

        self.StartPos = startPos;
        self.EndPos = endPos;
        self.Normal = ( endPos - startPos ):GetNormal();
        self.Length = math.random( 1000, 2000 );
        self.StartTime = CurTime();
        self.DieTime = CurTime() + ( distance + self.Length ) / 5000;

    end


    --[[------------------------------------
        Think()
    --------------------------------------]]
    function EFFECT:Think()

        return self.DieTime >= CurTime();

    end


    --[[------------------------------------
        Render()
    --------------------------------------]]
    function EFFECT:Render()

        local time = CurTime() - self.StartTime;

        local endDistance = 5000 * time;
        local startDistance = endDistance - self.Length;

        -- clamp the start distance so we don't extend behind the weapon
        startDistance = math.max( 0, startDistance );

        local startPos = self.StartPos + self.Normal * startDistance;
        local endPos = self.StartPos + self.Normal * endDistance;

        -- draw the beam
        render.SetMaterial( SparkMaterial );
        render.DrawBeam( startPos, endPos, 8, 0, 1, Color( 255, 185, 15, 255 ) );

    end

    effects.Register( EFFECT, "Nomad3Tracer" );

end
