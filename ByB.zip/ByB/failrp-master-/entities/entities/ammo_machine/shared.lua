ENT.Type            = "anim";
DEFINE_BASECLASS("money_printer");
ENT.PrintName       = "Ammo Constructor";
ENT.Author          = "Lexi";
ENT.Spawnable       = false;
ENT.AdminSpawnable  = false;
ENT.DisableDuplicator = true

AddCSLuaFile("shared.lua")

-- TODO: Is this actaully necessary
function ENT:SetupDataTables()
    BaseClass.SetupDataTables(self);
end

-- Briliant hack - It's just a money printer with some custom info 8-)
ENT.IsMoneyPrinter = false;
ENT.HP = 500;
ENT.PrinterInfo = {
    Prefix = "";
    Price = 5000;
    Colour = Color(255, 255, 255);
    PrintMin = 0;
    PrintMax = 1;
    CanExplode = false;
};

function ENT:GetPrinterName()
    return self.PrintName;
end

function ENT:GiveMoney(ply, amt)
    ply:GiveAmmo(amt, "pistol");
    GAMEMODE:Notify(ply, 1, 4, "You took " .. amt .. " ammo from the machine");
end

function ENT:DrawInfo()
	local text = self.PrintName .. "\n"
              .. tostring(self.dt.Money) .. " Bullets"
	--local pos  = self:LocalToWorld(self:OBBCenter()):ToScreen();
    local pos = self:GetPos();
    pos.z     = pos.z + 8;
    pos       = pos:ToScreen();
	draw.DrawTextShadowed(text, "TargetID", pos.x, pos.y, Color(255, 255, 255, 200), 1)
end

