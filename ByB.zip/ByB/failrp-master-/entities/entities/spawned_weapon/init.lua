AddCSLuaFile("shared.lua")
include("shared.lua")

-- Make BaseClass available here
DEFINE_BASECLASS("base_rpentity")

ENT.SpawnInfo = nil;

ENT.WeaponClass = nil;
ENT.Callback = nil;

function ENT:Initialize()
    BaseClass.Initialize(self);
    if (not self.SpawnInfo) then
        self:Remove();
        error("No spawn information!", 2);
    end
    self.SpawnTime = CurTime();
end

function ENT:SetContents(tab)
    self.SpawnInfo = tab;
    self.WeaponClass = tab.Class;
    self.Callback = tab.Callback
    self:SetModel(tab.Model);
end

function ENT:Use(ply)
    if (not IsValid(ply) and ply:IsPlayer()) then
        return;
    end    
	if (ply:GetMoveType() == 6) then -- wire users now return true for IsPlayer, this is a quick fix - pantho.
		self:Remove()
		return;
	end
    if (self.Callback) then
        if (self.Callback(ply, self.SpawnInfo, self) == false) then
            return;
        end
    else
        local ent = ents.Create(self.WeaponClass);
        if (not ent:IsValid()) then
            ErrorNoHalt("spawned_weapon: Could not create a weapon of type ", self.WeaponClass, "!\n");
            Notify(ply, 1, 5, "ERROR: Couldn't create a weapon of type " .. self.WeaponClass .. "!");
            return;
        elseif (ent.SetSpawnInfo) then
            ent:SetSpawnInfo(self.SpawnInfo);
        end
        ent:SetPos(self:GetPos());
        ent:SetAngles(self:GetAngles());
        ent:Spawn();
        -- sigh
        ent.nodupe = true;
        ent.ShareGavgun = true;
        
        if self.SetAmmo then
            ent:SetClip1(self.SetAmmo)
        end
        
        -- Remove timer, no longer needs to run.
        if self.MyTimer then
            timer.Remove(self.MyTimer)
        end
        
    end
    self:Remove();
end
