ENT.Type            = "anim"
DEFINE_BASECLASS("base_rpentity")
ENT.PrintName       = "Spawned Weapon"
ENT.Author          = "Rickster, Lexi"
ENT.Spawnable       = false
ENT.AdminSpawnable  = false
ENT.ShareGravgun    = true;
ENT.nodupe          = true;
ENT.DisableDuplicator = true
