 ENT.Base = "base_ai"
 ENT.Type = "ai"
   
 ENT.PrintName = "Vehicle NPC"
 ENT.Author = "Macendo"
 ENT.Contact = "In the cold" //fill in these if you want it to be in the spawn menu
 ENT.Purpose = "To sell cars"
 ENT.Instructions = "Spawn the shit, talk, enjoy"
 ENT.Information	= ""  
 ENT.Category		= "Macendo"
  
 ENT.AutomaticFrameAdvance = true
   
 ENT.Spawnable = true
 ENT.AdminSpawnable = true
 
 
cars = {}
cars.c4 = {}
cars.c4.Name = "Citroen C4"
cars.c4.Model = "models/tdmcars/cit_c4.mdl"
cars.c4.Spawnname = "prop_vehicle_jeep"
cars.c4.Vehiclescript = "tdmcars/c4"
cars.c4.Secondseat = {}
cars.c4.Secondseat.Localpos = Vector(20, -13, 28.5)
cars.c4.Thirdseat = {}
cars.c4.Thirdseat.Localpos = Vector(-17.8, -35.4, 24)
cars.c4.Fourthseat = {}
cars.c4.Fourthseat.Localpos = Vector(17.8, -35.4, 24)
cars.c4.Price = 270000
cars.c4.TrunkSize = 5
cars.c4.BodyGroups = {}
cars.c4.BodyGroups["Count"] = {}
cars.c4.BodyGroups["Parts"] = {}
cars.c4.BodyGroups["Parts"]["RearLight"] = 8
cars.c4.BodyGroups["Count"][8] = 2
cars.c4.BodyGroups["Parts"]["HeadLight"] = 7
cars.c4.BodyGroups["Count"][7] = 2
cars.c4.BodyGroups["Parts"]["Hood"] = 5
cars.c4.BodyGroups["Count"][5] = 2
cars.c4.BodyGroups["Parts"]["Bumperr"] = 3
cars.c4.BodyGroups["Count"][3] = 2
cars.c4.BodyGroups["Parts"]["Bumperf"] = 2
cars.c4.BodyGroups["Count"][2] = 2
cars.c4.BodyGroups["Parts"]["Skirt"] = 4
cars.c4.BodyGroups["Count"][5] = 2
cars.c4.BodyGroups["Parts"]["Wheels"] = 6
cars.c4.BodyGroups["Count"][6] = 2
cars.c4.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.c4.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.chargerr8 = {}
cars.chargerr8.Name = "Dodge Charger SRT8"
cars.chargerr8.Model = "models/tdmcars/chargersrt8.mdl"
cars.chargerr8.Spawnname = "prop_vehicle_jeep"
cars.chargerr8.Vehiclescript = "tdmcars/chargersrt8"
cars.chargerr8.Secondseat = {}
cars.chargerr8.Secondseat.Localpos = Vector(20, -11, 31.5)
cars.chargerr8.Thirdseat = {}
cars.chargerr8.Thirdseat.Localpos = Vector(17, -46, 26.4)
cars.chargerr8.Fourthseat = {}
cars.chargerr8.Fourthseat.Localpos = Vector(-17, -46, 26.4)
cars.chargerr8.Price = 860000
cars.chargerr8.TrunkSize = 5
cars.chargerr8.BodyGroups = {}
cars.chargerr8.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.chargerr8.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.focus = {}
cars.focus.Name = "Ford Focus RS"
cars.focus.Model = "models/tdmcars/focusrs.mdl"
cars.focus.Spawnname = "prop_vehicle_jeep"
cars.focus.Vehiclescript = "tdmcars/focusrs"
cars.focus.Secondseat = {}
cars.focus.Secondseat.Localpos = Vector(-17.5, -2, 25)
cars.focus.Thirdseat = {}
cars.focus.Thirdseat.Localpos = Vector(17.5, -40, 25)
cars.focus.Fourthseat = {}
cars.focus.Fourthseat.Localpos = Vector(-17.5, -40, 25)
cars.focus.Price = 490000
cars.focus.TrunkSize = 5
cars.focus.BodyGroups = {}
cars.focus.BodyGroups["Count"] = {}
cars.focus.BodyGroups["Parts"] = {}
cars.focus.BodyGroups["Parts"]["FrontBumper"] = 2
cars.focus.BodyGroups["Count"][2] = 2
cars.focus.BodyGroups["Parts"]["Wing"] = 3
cars.focus.BodyGroups["Count"][3] = 2
cars.focus.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.focus.BodyGroups["Skins"] = {
["Prem1"] = 1,
["Prem2"] = 5,
["No Skin"] = 0
}

cars.auditt = {}
cars.auditt.Name = "Audi TT"
cars.auditt.Model = "models/tdmcars/auditt.mdl"
cars.auditt.Spawnname = "prop_vehicle_jeep"
cars.auditt.Vehiclescript = "tdmcars/auditt"
cars.auditt.Secondseat = {}
cars.auditt.Secondseat.Localpos = Vector(18, -14, 20.5)
cars.auditt.Price = 787000
cars.auditt.TrunkSize = 5
cars.auditt.BodyGroups = {}
cars.auditt.BodyGroups["Count"] = {}
cars.auditt.BodyGroups["Parts"] = {}
cars.auditt.BodyGroups["Parts"]["Wing"] = 3
cars.auditt.BodyGroups["Count"][3] = 2
cars.auditt.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.auditt.BodyGroups["Skins"] = {
["MLP"] = 1,
["PREM1"] = 2,
["No Skin"] = 0
}

cars.coopy = {}
cars.coopy.Name = "Mini Cooper 65"
cars.coopy.Model = "models/tdmcars/cooper65.mdl"
cars.coopy.Spawnname = "prop_vehicle_jeep"
cars.coopy.Vehiclescript = "tdmcars/cooper65"
cars.coopy.Secondseat = {}
cars.coopy.Secondseat.Localpos = Vector(-17, -11, 28.5)
cars.coopy.Price = 323000
cars.coopy.TrunkSize = 5
cars.coopy.BodyGroups = {}
cars.coopy.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.coopy.BodyGroups["Skins"] = {
["Mr Bean"] = 2,
["No Skin"] = 0
}

cars.mercsls = {}
cars.mercsls.Name = "Mercedes-Benz SLS AMG"
cars.mercsls.Model = "models/tdmcars/mer_slsamg.mdl"
cars.mercsls.Spawnname = "prop_vehicle_jeep"
cars.mercsls.Vehiclescript = "tdmcars/slsamg"
cars.mercsls.Secondseat = {}
cars.mercsls.Secondseat.Localpos = Vector(17, -33, 26.5)
cars.mercsls.Price = 1961000
cars.mercsls.TrunkSize = 5
cars.mercsls.BodyGroups = {}
cars.mercsls.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.mercsls.BodyGroups["Skins"] = {
["Prem1"] = 2,
["No Skin"] = 0
}

cars.r34skyline = {}
cars.r34skyline.Name = "Nissan GTR Skyline R34"
cars.r34skyline.Model = "models/tdmcars/skyline_r34.mdl"
cars.r34skyline.Spawnname = "prop_vehicle_jeep"
cars.r34skyline.Vehiclescript = "tdmcars/skyline_r34"
cars.r34skyline.Secondseat = {}
cars.r34skyline.Secondseat.Localpos = Vector(-17, -10, 26.5)
cars.r34skyline.Price = 917990
cars.r34skyline.TrunkSize = 5
cars.r34skyline.BodyGroups = {}
cars.r34skyline.BodyGroups["Count"] = {}
cars.r34skyline.BodyGroups["Parts"] = {}
cars.r34skyline.BodyGroups["Parts"]["Bumbper"] = 2
cars.r34skyline.BodyGroups["Count"][2] = 3
cars.r34skyline.BodyGroups["Parts"]["Bumper2"] = 3
cars.r34skyline.BodyGroups["Count"][3] = 3
cars.r34skyline.BodyGroups["Parts"]["Skirt"] = 4
cars.r34skyline.BodyGroups["Count"][4] = 3
cars.r34skyline.BodyGroups["Parts"]["Hood"] = 5
cars.r34skyline.BodyGroups["Count"][5] = 3
cars.r34skyline.BodyGroups["Parts"]["Wing"] = 6
cars.r34skyline.BodyGroups["Count"][6] = 2
cars.r34skyline.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.r34skyline.BodyGroups["Skins"] = {
["Prem1"] = 9,
["Default"] = 0
}

cars.colttdm = {}
cars.colttdm.Name = "Mitsubishi Colt"
cars.colttdm.Model = "models/tdmcars/coltralliart.mdl"
cars.colttdm.Spawnname = "prop_vehicle_jeep"
cars.colttdm.Vehiclescript = "tdmcars/colt"
cars.colttdm.Secondseat = {}
cars.colttdm.Secondseat.Localpos = Vector(-17, -10, 28.5)
cars.colttdm.Price = 695000
cars.colttdm.TrunkSize = 5
cars.colttdm.BodyGroups = {}
cars.colttdm.BodyGroups["Count"] = {}
cars.colttdm.BodyGroups["Parts"] = {}
cars.colttdm.BodyGroups["Parts"]["Bumbper"] = 2
cars.colttdm.BodyGroups["Count"][2] = 2
cars.colttdm.BodyGroups["Parts"]["Wing"] = 3
cars.colttdm.BodyGroups["Count"][3] = 2
cars.colttdm.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.colttdm.BodyGroups["Skins"] = {
["No Skin"] = 0
}

cars.gt05tdm = {}
cars.gt05tdm.Name = "Ford GT 05"
cars.gt05tdm.Model = "models/tdmcars/gt05.mdl"
cars.gt05tdm.Spawnname = "prop_vehicle_jeep"
cars.gt05tdm.Vehiclescript = "tdmcars/gt05"
cars.gt05tdm.Secondseat = {}
cars.gt05tdm.Secondseat.Localpos = Vector(17, -5, 18.5)
cars.gt05tdm.Price = 802850
cars.gt05tdm.TrunkSize = 5
cars.gt05tdm.BodyGroups = {}
cars.gt05tdm.BodyGroups["Count"] = {}
cars.gt05tdm.BodyGroups["Parts"] = {}
cars.gt05tdm.BodyGroups["Parts"]["Bumbper"] = 2
cars.gt05tdm.BodyGroups["Count"][2] = 2
cars.gt05tdm.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.gt05tdm.BodyGroups["Skins"] = {
["MLP"] = 3,
["Prem1"] = 5,
["Prem2"] = 6,
["Prem3"] = 2,
["No Skin"] = 0
}

cars.coupe40tdm = {}
cars.coupe40tdm.Name = "Ford Coupe 40"
cars.coupe40tdm.Model = "models/tdmcars/ford_coupe_40.mdl"
cars.coupe40tdm.Spawnname = "prop_vehicle_jeep"
cars.coupe40tdm.Vehiclescript = "tdmcars/coupe40"
cars.coupe40tdm.Secondseat = {}
cars.coupe40tdm.Secondseat.Localpos = Vector(17, 2, 35.5)
cars.coupe40tdm.Price = 162000
cars.coupe40tdm.TrunkSize = 5
cars.coupe40tdm.BodyGroups = {}
cars.coupe40tdm.BodyGroups["Count"] = {}
cars.coupe40tdm.BodyGroups["Parts"] = {}
cars.coupe40tdm.BodyGroups["Parts"]["Bumbper"] = 2
cars.coupe40tdm.BodyGroups["Count"][2] = 3
cars.coupe40tdm.BodyGroups["Parts"]["Bumbpef"] = 3
cars.coupe40tdm.BodyGroups["Count"][3] = 3
cars.coupe40tdm.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.coupe40tdm.BodyGroups["Skins"] = {
["MLP"] = 1,
["No Skin"] = 0
}

cars.supratdm = {}
cars.supratdm.Name = "Toyota Supra"
cars.supratdm.Model = "models/tdmcars/supra.mdl"
cars.supratdm.Spawnname = "prop_vehicle_jeep"
cars.supratdm.Vehiclescript = "tdmcars/supra"
cars.supratdm.Secondseat = {}
cars.supratdm.Secondseat.Localpos = Vector(-17, -15, 22.5)
cars.supratdm.Price = 826000
cars.supratdm.TrunkSize = 5
cars.supratdm.BodyGroups = {}
cars.supratdm.BodyGroups["Count"] = {}
cars.supratdm.BodyGroups["Parts"] = {}
cars.supratdm.BodyGroups["Parts"]["Bumbper"] = 2
cars.supratdm.BodyGroups["Count"][2] = 4
cars.supratdm.BodyGroups["Parts"]["Bumbpef"] = 2
cars.supratdm.BodyGroups["Count"][2] = 3
cars.supratdm.BodyGroups["Parts"]["Skirt"] = 4
cars.supratdm.BodyGroups["Count"][4] = 3
cars.supratdm.BodyGroups["Parts"]["Wing"] = 6
cars.supratdm.BodyGroups["Count"][6] = 4
cars.supratdm.BodyGroups["Parts"]["Wheel"] = 7
cars.supratdm.BodyGroups["Count"][7] = 2
cars.supratdm.BodyGroups["Parts"]["Hood"] = 5
cars.supratdm.BodyGroups["Count"][5] = 2
cars.supratdm.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.supratdm.BodyGroups["Skins"] = {
["MLP"] = 6,
["Prem1"] = 1,
["Prem2"] = 2,
["Prem3"] = 3,
["Prem4"] = 4,
["Prem5"] = 5,
["No Skin"] = 0
}

cars.mitsu_evoxtdm = {}
cars.mitsu_evoxtdm.Name = "Mitsubishi Evo"
cars.mitsu_evoxtdm.Model = "models/tdmcars/mitsu_evox.mdl"
cars.mitsu_evoxtdm.Spawnname = "prop_vehicle_jeep"
cars.mitsu_evoxtdm.Vehiclescript = "tdmcars/mitsu_evox"
cars.mitsu_evoxtdm.Secondseat = {}
cars.mitsu_evoxtdm.Secondseat.Localpos = Vector(-17, -15, 24.5)
cars.mitsu_evoxtdm.Price = 778950
cars.mitsu_evoxtdm.TrunkSize = 5
cars.mitsu_evoxtdm.BodyGroups = {}
cars.mitsu_evoxtdm.BodyGroups["Count"] = {}
cars.mitsu_evoxtdm.BodyGroups["Parts"] = {}
cars.mitsu_evoxtdm.BodyGroups["Parts"]["Bumbper"] = 2
cars.mitsu_evoxtdm.BodyGroups["Count"][2] = 3
cars.mitsu_evoxtdm.BodyGroups["Parts"]["Bumbpef"] = 3
cars.mitsu_evoxtdm.BodyGroups["Count"][3] = 2
cars.mitsu_evoxtdm.BodyGroups["Parts"]["Skirt"] = 4
cars.mitsu_evoxtdm.BodyGroups["Count"][4] = 3
cars.mitsu_evoxtdm.BodyGroups["Parts"]["Wing"] = 6
cars.mitsu_evoxtdm.BodyGroups["Count"][6] = 2
cars.mitsu_evoxtdm.BodyGroups["Parts"]["Hood"] = 5
cars.mitsu_evoxtdm.BodyGroups["Count"][5] = 3
cars.mitsu_evoxtdm.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.mitsu_evoxtdm.BodyGroups["Skins"] = {
["MLP"] = 2,
["PREM1"] = 4,
["No Skin"] = 0
}

cars.dbstdm = {}
cars.dbstdm.Name = "Austin Martin DBS"
cars.dbstdm.Model = "models/tdmcars/dbs.mdl"
cars.dbstdm.Spawnname = "prop_vehicle_jeep"
cars.dbstdm.Vehiclescript = "tdmcars/dbs"
cars.dbstdm.Secondseat = {}
cars.dbstdm.Secondseat.Localpos = Vector(17, -18, 21.5)
cars.dbstdm.Price = 2990576
cars.dbstdm.TrunkSize = 5
cars.dbstdm.BodyGroups = {}
cars.dbstdm.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.dbstdm.BodyGroups["Skins"] = {
["MLP"] = 1,
["Prem2"] = 2,
["Default"] = 0
}

cars.ferrari512trtdm = {}
cars.ferrari512trtdm.Name = "Ferrari 512"
cars.ferrari512trtdm.Model = "models/tdmcars/ferrari512tr.mdl"
cars.ferrari512trtdm.Spawnname = "prop_vehicle_jeep"
cars.ferrari512trtdm.Vehiclescript = "tdmcars/ferrari512tr"
cars.ferrari512trtdm.Secondseat = {}
cars.ferrari512trtdm.Secondseat.Localpos = Vector(17, -15, 22.5)
cars.ferrari512trtdm.Price = 750000
cars.ferrari512trtdm.TrunkSize = 5
cars.ferrari512trtdm.BodyGroups = {}
cars.ferrari512trtdm.BodyGroups["Count"] = {}
cars.ferrari512trtdm.BodyGroups["Parts"] = {}
cars.ferrari512trtdm.BodyGroups["Parts"]["Bumbper"] = 2
cars.ferrari512trtdm.BodyGroups["Count"][2] = 2
cars.ferrari512trtdm.BodyGroups["Parts"]["Bumbpef"] = 3
cars.ferrari512trtdm.BodyGroups["Count"][3] = 2
cars.ferrari512trtdm.BodyGroups["Parts"]["Wing"] = 4
cars.ferrari512trtdm.BodyGroups["Count"][4] = 2
cars.ferrari512trtdm.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.ferrari512trtdm.BodyGroups["Skins"] = {
["NO SKINS"] = 0
}

cars.golfmkii = {}
cars.golfmkii.Name = "Volkswagen Golf Mk2"
cars.golfmkii.Model = "models/tdmcars/golf_mk2.mdl"
cars.golfmkii.Spawnname = "prop_vehicle_jeep"
cars.golfmkii.Vehiclescript = "tdmcars/golfmk2"
cars.golfmkii.Secondseat = {}
cars.golfmkii.Secondseat.Localpos = Vector(17, -13, 30.5)
cars.golfmkii.Price = 334100
cars.golfmkii.TrunkSize = 5
cars.golfmkii.BodyGroups = {}
cars.golfmkii.BodyGroups["Count"] = {}
cars.golfmkii.BodyGroups["Parts"] = {}
cars.golfmkii.BodyGroups["Parts"]["Bumbper"] =3
cars.golfmkii.BodyGroups["Count"][3] = 3
cars.golfmkii.BodyGroups["Parts"]["Bumbpef"] = 2
cars.golfmkii.BodyGroups["Count"][2] = 3
cars.golfmkii.BodyGroups["Parts"]["Wing"] = 6
cars.golfmkii.BodyGroups["Count"][6] = 2
cars.golfmkii.BodyGroups["Parts"]["Wheel"] = 5
cars.golfmkii.BodyGroups["Count"][5] = 2
cars.golfmkii.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.golfmkii.BodyGroups["Skins"] = {
["MLP"] = 1,
["NO SKIN"] = 0
}

cars.Camaro = {}
cars.Camaro.Name = "Camaro ZL1"
cars.Camaro.Model = "models/tdmcars/chev_camzl1.mdl"
cars.Camaro.Spawnname = "prop_vehicle_jeep"
cars.Camaro.Vehiclescript = "tdmcars/camarozl1"
cars.Camaro.Secondseat = {}
cars.Camaro.Secondseat.Localpos = Vector(19, -14, 25.5)
cars.Camaro.Price = 943500
cars.Camaro.TrunkSize = 5
cars.Camaro.BodyGroups = {}
cars.Camaro.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.Camaro.BodyGroups["Skins"] = {
["MLP"] = 1,
["NO SKIN"] = 0
}

cars.f250 = {}
cars.f250.Name = "Ferrari 250 GT"
cars.f250.Model = "models/tdmcars/ferrari250gt.mdl"
cars.f250.Spawnname = "prop_vehicle_jeep"
cars.f250.Vehiclescript = "tdmcars/ferrari250gt"
cars.f250.Secondseat = {}
cars.f250.Secondseat.Localpos = Vector(19, -17, 27.5)
cars.f250.Price = 741000
cars.f250.TrunkSize = 5
cars.f250.BodyGroups = {}
cars.f250.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.f250.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.dodgeramtdm = {}
cars.dodgeramtdm.Name = "Dodge RAM SRT10"
cars.dodgeramtdm.Model = "models/tdmcars/dodgeram.mdl"
cars.dodgeramtdm.Spawnname = "prop_vehicle_jeep"
cars.dodgeramtdm.Vehiclescript = "tdmcars/dodgeram"
cars.dodgeramtdm.Secondseat = {}
cars.dodgeramtdm.Secondseat.Localpos = Vector(21, 0, 37.5)
cars.dodgeramtdm.Price = 640500
cars.dodgeramtdm.TrunkSize = 10
cars.dodgeramtdm.BodyGroups = {}
cars.dodgeramtdm.BodyGroups["Count"] = {}
cars.dodgeramtdm.BodyGroups["Parts"] = {}
cars.dodgeramtdm.BodyGroups["Parts"]["Bumbper"] = 3
cars.dodgeramtdm.BodyGroups["Count"][3] = 2
cars.dodgeramtdm.BodyGroups["Parts"]["Bumbpef"] = 2
cars.dodgeramtdm.BodyGroups["Count"][2] = 2
cars.dodgeramtdm.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.dodgeramtdm.BodyGroups["Skins"] = {
["PREM1"] = 2,
["PREM1"] = 5,
["NO SKIN"] = 0
}


cars.camero69 = {}
cars.camero69.Name = "Camaro 69"
cars.camero69.Model = "models/tdmcars/69camaro.mdl"
cars.camero69.Spawnname = "prop_vehicle_jeep"
cars.camero69.Vehiclescript = "tdmcars/69camaro"
cars.camero69.Secondseat = {}
cars.camero69.Secondseat.Localpos = Vector(16.5, -8, 26)
cars.camero69.Price = 541500
cars.camero69.TrunkSize = 5
cars.camero69.BodyGroups = {}
cars.camero69.BodyGroups["Count"] = {}
cars.camero69.BodyGroups["Parts"] = {}
cars.camero69.BodyGroups["Parts"]["Bumbper"] = 2
cars.camero69.BodyGroups["Count"][2] = 2
cars.camero69.BodyGroups["Parts"]["Cover"] = 3
cars.camero69.BodyGroups["Count"][3] = 2
cars.camero69.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.camero69.BodyGroups["Skins"] = {
["MLP"] = 1,
["NO SKIN"] = 0
}

cars.chevelless = {}
cars.chevelless.Name = "Chevelle SS"
cars.chevelless.Model = "models/tdmcars/chevelless.mdl"
cars.chevelless.Spawnname = "prop_vehicle_jeep"
cars.chevelless.Vehiclescript = "tdmcars/chevelless"
cars.chevelless.Secondseat = {}
cars.chevelless.Secondseat.Localpos = Vector(17, -5, 29.5)
cars.chevelless.Price = 755000
cars.chevelless.TrunkSize = 5
cars.camero69.BodyGroups = {}
cars.camero69.BodyGroups["Count"] = {}
cars.camero69.BodyGroups["Parts"] = {}
cars.camero69.BodyGroups["Parts"]["Bumbper"] = 2
cars.camero69.BodyGroups["Count"][2] = 2
cars.camero69.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.camero69.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.bugattiv = {}
cars.bugattiv.Name = "Bugatti Veyron"
cars.bugattiv.Model = "models/tdmcars/bug_veyron.mdl"
cars.bugattiv.Spawnname = "prop_vehicle_jeep"
cars.bugattiv.Vehiclescript = "tdmcars/veyron"
cars.bugattiv.Secondseat = {}
cars.bugattiv.Secondseat.Localpos = Vector(17, -6, 23.5)
cars.bugattiv.Price = 2590410
cars.bugattiv.TrunkSize = 5
cars.bugattiv.BodyGroups = {}
cars.bugattiv.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.bugattiv.BodyGroups["Skins"] = {
["PREM1"] = 1,
["NO SKIN"] = 0
}

cars.bugattivss = {}
cars.bugattivss.Name = "Bugatti SS"
cars.bugattivss.Model = "models/tdmcars/bug_veyronss.mdl"
cars.bugattivss.Spawnname = "prop_vehicle_jeep"
cars.bugattivss.Vehiclescript = "tdmcars/veyronss"
cars.bugattivss.Secondseat = {}
cars.bugattivss.Secondseat.Localpos = Vector(17, -6, 23.5)
cars.bugattivss.Price = 3290410
cars.bugattivss.TrunkSize = 5
cars.bugattivss.BodyGroups = {}
cars.bugattivss.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.bugattivss.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.bugattiveb = {}
cars.bugattiveb.Name = "Bugatti EB110"
cars.bugattiveb.Model = "models/tdmcars/bug_eb110.mdl"
cars.bugattiveb.Spawnname = "prop_vehicle_jeep"
cars.bugattiveb.Vehiclescript = "tdmcars/eb110"
cars.bugattiveb.Secondseat = {}
cars.bugattiveb.Secondseat.Localpos = Vector(17, -6, 23.5)
cars.bugattiveb.Price = 2790410
cars.bugattiveb.TrunkSize = 5
cars.bugattiveb.BodyGroups = {}
cars.bugattiveb.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.bugattiveb.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.bmw1 = {}
cars.bmw1.Name = "BMW M1"
cars.bmw1.Model = "models/tdmcars/bmwm1.mdl"
cars.bmw1.Spawnname = "prop_vehicle_jeep"
cars.bmw1.Vehiclescript = "tdmcars/m1"
cars.bmw1.Secondseat = {}
cars.bmw1.Secondseat.Localpos = Vector(17, -6, 23.5)
cars.bmw1.Price = 500000
cars.bmw1.TrunkSize = 5
cars.bmw1.BodyGroups = {}
cars.bmw1.BodyGroups["Count"] = {}
cars.bmw1.BodyGroups["Parts"] = {}
cars.bmw1.BodyGroups["Parts"]["HeadLight"] = 3
cars.bmw1.BodyGroups["Count"][3] = 2
cars.bmw1.BodyGroups["Parts"]["Wing"] = 2
cars.bmw1.BodyGroups["Count"][1] = 2
cars.bmw1.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.bmw1.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.msl95 = {}
cars.msl95.Name = "Mercedes SLS 65"
cars.msl95.Model = "models/tdmcars/sl65amg.mdl"
cars.msl95.Spawnname = "prop_vehicle_jeep"
cars.msl95.Vehiclescript = "tdmcars/sl65amg"
cars.msl95.Secondseat = {}
cars.msl95.Secondseat.Localpos = Vector(20, -22, 25.5)
cars.msl95.Price = 1649900
cars.msl95.TrunkSize = 5
cars.msl95.BodyGroups = {}
cars.msl95.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.msl95.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.syclone = {}
cars.syclone.Name = "GMC Syclone"
cars.syclone.Model = "models/tdmcars/gmc_syclone.mdl"
cars.syclone.Spawnname = "prop_vehicle_jeep"
cars.syclone.Vehiclescript = "tdmcars/syclone"
cars.syclone.Secondseat = {}
cars.syclone.Secondseat.Localpos = Vector(20, -0, 36.5)
cars.syclone.Price = 410550 
cars.syclone.TrunkSize = 10
cars.syclone.BodyGroups = {}
cars.syclone.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.syclone.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.hornet = {}
cars.hornet.Name = "Hudson Hornet"
cars.hornet.Model = "models/tdmcars/hud_hornet.mdl"
cars.hornet.Spawnname = "prop_vehicle_jeep"
cars.hornet.Vehiclescript = "tdmcars/hudhornet"
cars.hornet.Secondseat = {}
cars.hornet.Secondseat.Localpos = Vector(20, 1, 32.5)
cars.hornet.Price = 755020 
cars.hornet.TrunkSize = 5
cars.hornet.BodyGroups = {}
cars.hornet.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.hornet.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.gtrtdm = {}
cars.gtrtdm.Name = "Nissan GTR"
cars.gtrtdm.Model = "models/tdmcars/nissan_gtr.mdl"
cars.gtrtdm.Spawnname = "prop_vehicle_jeep"
cars.gtrtdm.Vehiclescript = "tdmcars/gtr"
cars.gtrtdm.Secondseat = {}
cars.gtrtdm.Secondseat.Localpos = Vector(-20, 0, 22.5)
cars.gtrtdm.Price = 1750999
cars.gtrtdm.TrunkSize = 5
cars.gtrtdm.BodyGroups = {}
cars.gtrtdm.BodyGroups["Count"] = {}
cars.gtrtdm.BodyGroups["Parts"] = {}
cars.gtrtdm.BodyGroups["Parts"]["Wing"] = 5
cars.gtrtdm.BodyGroups["Count"][5] = 3
cars.gtrtdm.BodyGroups["Parts"]["Skirt"] = 4
cars.gtrtdm.BodyGroups["Count"][4] = 2
cars.gtrtdm.BodyGroups["Parts"]["Bumperf"] = 2
cars.gtrtdm.BodyGroups["Count"][2] = 2
cars.gtrtdm.BodyGroups["Parts"]["Bumperr"] = 3
cars.gtrtdm.BodyGroups["Count"][3] = 2
cars.gtrtdm.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.gtrtdm.BodyGroups["Skins"] = {
["Prem1"] = 1,
["No Skin"] = 0
}

cars.gmcvan = {}
cars.gmcvan.Name = "GMC Van"
cars.gmcvan.Model = "models/tdmcars/gmcvan.mdl"
cars.gmcvan.Spawnname = "prop_vehicle_jeep"
cars.gmcvan.Vehiclescript = "tdmcars/gmcvan"
cars.gmcvan.Secondseat = {}
cars.gmcvan.Secondseat.Localpos = Vector(24, 35, 42)
cars.gmcvan.Price = 651050 
cars.gmcvan.TrunkSize = 20
cars.gmcvan.BodyGroups = {}
cars.gmcvan.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.gmcvan.BodyGroups["Skins"] = {
["MLP"] = 1,
["NO SKIN"] = 0
}

cars.murcielago = {}
cars.murcielago.Name = "Lamborghini Murcielago"
cars.murcielago.Model = "models/tdmcars/murcielago.mdl"
cars.murcielago.Spawnname = "prop_vehicle_jeep"
cars.murcielago.Vehiclescript = "tdmcars/murcielago"
cars.murcielago.Secondseat = {}
cars.murcielago.Secondseat.Localpos = Vector(24, -5, 18)
cars.murcielago.Price = 2580910 
cars.murcielago.TrunkSize = 5
cars.murcielago.BodyGroups = {}
cars.murcielago.BodyGroups["Count"] = {}
cars.murcielago.BodyGroups["Parts"] = {}
cars.murcielago.BodyGroups["Parts"]["Spoiler"] = 2
cars.murcielago.BodyGroups["Count"][2] = 2
cars.murcielago.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.murcielago.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.gt500 = {}
cars.gt500.Name = "Ford Shelby GT500"
cars.gt500.Model = "models/tdmcars/gt500.mdl"
cars.gt500.Spawnname = "prop_vehicle_jeep"
cars.gt500.Vehiclescript = "tdmcars/gt500"
cars.gt500.Secondseat = {}
cars.gt500.Secondseat.Localpos = Vector(17.8, 0, 27.3)
cars.gt500.Thirdseat = {}
cars.gt500.Thirdseat.Localpos = Vector(-17.8, -38.4, 27.3)
cars.gt500.Fourthseat = {}
cars.gt500.Fourthseat.Localpos = Vector(17.8, -38.4, 27.3)
cars.gt500.Price = 1950450 
cars.gt500.TrunkSize = 5
cars.gt500.BodyGroups = {}
cars.gt500.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.gt500.BodyGroups["Skins"] = {
["Prem1"] = 1,
["NO SKIN"] = 0
}

cars.gallardo = {}
cars.gallardo.Name = "Lamborghini Gallardo"
cars.gallardo.Model = "models/tdmcars/gallardo.mdl"
cars.gallardo.Spawnname = "prop_vehicle_jeep"
cars.gallardo.Vehiclescript = "tdmcars/gallardo"
cars.gallardo.Secondseat = {}
cars.gallardo.Secondseat.Localpos = Vector(17.8, 8, 14)
cars.gallardo.Price = 3610910
cars.gallardo.TrunkSize = 5
cars.gallardo.BodyGroups = {}
cars.gallardo.BodyGroups["Count"] = {}
cars.gallardo.BodyGroups["Parts"] = {}
cars.gallardo.BodyGroups["Parts"]["Wing"] = 2
cars.gallardo.BodyGroups["Count"][2] = 2
cars.gallardo.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.gallardo.BodyGroups["Skins"] = {
["Prem1"] = 1,
["Prem2"] = 2,
["Prem3"] = 3,
["Prem3"] = 5,
["Prem3"] = 9,
["MLP"] = 4,
["NO SKIN"] = 0
}

cars.scirocco = {}
cars.scirocco.Name = "Volkswagon Scirocco"
cars.scirocco.Model = "models/tdmcars/scirocco.mdl"
cars.scirocco.Spawnname = "prop_vehicle_jeep"
cars.scirocco.Vehiclescript = "tdmcars/scirocco"
cars.scirocco.Secondseat = {}
cars.scirocco.Secondseat.Localpos = Vector(-18, 10, 20)
cars.scirocco.Thirdseat = {}
cars.scirocco.Thirdseat.Localpos = Vector(-15, -33, 25)
cars.scirocco.Fourthseat = {}
cars.scirocco.Fourthseat.Localpos = Vector(11, -33, 25)
cars.scirocco.Price = 751940
cars.scirocco.TrunkSize = 5
cars.scirocco.BodyGroups = {}
cars.scirocco.BodyGroups["Count"] = {}
cars.scirocco.BodyGroups["Parts"] = {}
cars.scirocco.BodyGroups["Parts"]["Bumperf"] = 2
cars.scirocco.BodyGroups["Count"][2] = 3
cars.scirocco.BodyGroups["Parts"]["Bumperr"] = 3
cars.scirocco.BodyGroups["Count"][3] = 3
cars.scirocco.BodyGroups["Parts"]["Wing"] = 5
cars.scirocco.BodyGroups["Count"][5] = 2
cars.scirocco.BodyGroups["Parts"]["Skirt"] = 4
cars.scirocco.BodyGroups["Count"][4] = 2
cars.scirocco.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.scirocco.BodyGroups["Skins"] = {
["Prem1"] = 1,
["NO SKIN"] = 0
}

cars.audir8 = {}
cars.audir8.Name = "Audi R8 V10"
cars.audir8.Model = "models/tdmcars/audir8.mdl"
cars.audir8.Spawnname = "prop_vehicle_jeep"
cars.audir8.Vehiclescript = "tdmcars/audir8"
cars.audir8.Secondseat = {}
cars.audir8.Secondseat.Localpos = Vector(20, -10, 25.5)
cars.audir8.Price = 1720050
cars.audir8.TrunkSize = 5
cars.audir8.BodyGroups = {}
cars.audir8.BodyGroups["Count"] = {}
cars.audir8.BodyGroups["Parts"] = {}
cars.audir8.BodyGroups["Parts"]["Cover"] = 5
cars.audir8.BodyGroups["Count"][5] = 3
cars.audir8.BodyGroups["Parts"]["Wing"] = 4
cars.audir8.BodyGroups["Count"][4] = 2
cars.audir8.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.audir8.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.c32 = {}
cars.c32.Name = "Mercedes C32"
cars.c32.Model = "models/tdmcars/mercedes_c32.mdl"
cars.c32.Spawnname = "prop_vehicle_jeep"
cars.c32.Vehiclescript = "tdmcars/c32"
cars.c32.Secondseat = {}
cars.c32.Secondseat.Localpos = Vector(20, -10, 25.5)
cars.c32.Price = 853990
cars.c32.TrunkSize = 5
cars.c32.BodyGroups = {}
cars.c32.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.c32.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.ftransit = {}
cars.ftransit.Name = "Ford Transit"
cars.ftransit.Model = "models/tdmcars/ford_transit.mdl"
cars.ftransit.Spawnname = "prop_vehicle_jeep"
cars.ftransit.Vehiclescript = "tdmcars/transit"
cars.ftransit.Secondseat = {}
cars.ftransit.Secondseat.Localpos = Vector(-19, 36, 46.6)
cars.ftransit.Price = 645040
cars.ftransit.TrunkSize = 15
cars.ftransit.BodyGroups = {}
cars.ftransit.BodyGroups["Count"] = {}
cars.ftransit.BodyGroups["Parts"] = {}
cars.ftransit.BodyGroups["Parts"]["Bumperf"] = 2
cars.ftransit.BodyGroups["Count"][2] = 2
cars.ftransit.BodyGroups["Parts"]["Bumperr"] = 3
cars.ftransit.BodyGroups["Count"][3] = 2
cars.ftransit.BodyGroups["Parts"]["Skirt"] = 4
cars.ftransit.BodyGroups["Count"][4] = 2
cars.ftransit.BodyGroups["Parts"]["Wing"] = 5
cars.ftransit.BodyGroups["Count"][5] = 2
cars.ftransit.BodyGroups["Parts"]["Trim"] = 6
cars.ftransit.BodyGroups["Count"][6] = 2
cars.ftransit.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.ftransit.BodyGroups["Skins"] = {
["Prem1"] = 1,
["NO SKIN"] = 0
}

cars.audis5 = {}
cars.audis5.Name = "Audi S5"
cars.audis5.Model = "models/tdmcars/s5.mdl"
cars.audis5.Spawnname = "prop_vehicle_jeep"
cars.audis5.Vehiclescript = "tdmcars/s5"
cars.audis5.Secondseat = {}
cars.audis5.Secondseat.Localpos = Vector(18, -7, 22)
cars.audis5.Thirdseat = {}
cars.audis5.Thirdseat.Localpos = Vector(18, -42, 22)
cars.audis5.Fourthseat = {}
cars.audis5.Fourthseat.Localpos = Vector(-18, -42, 22)
cars.audis5.Price = 790240
cars.audis5.TrunkSize = 5
cars.audis5.BodyGroups = {}
cars.audis5.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.audis5.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.cspark = {}
cars.cspark.Name = "Chevy Spark"
cars.cspark.Model = "models/tdmcars/spark.mdl"
cars.cspark.Spawnname = "prop_vehicle_jeep"
cars.cspark.Vehiclescript = "tdmcars/spark"
cars.cspark.Secondseat = {}
cars.cspark.Secondseat.Localpos = Vector(18, -7, 22)
cars.cspark.Thirdseat = {}
cars.cspark.Thirdseat.Localpos = Vector(18, -42, 22)
cars.cspark.Fourthseat = {}
cars.cspark.Fourthseat.Localpos = Vector(-18, -42, 22)
cars.cspark.Price = 410050
cars.cspark.TrunkSize = 5
cars.cspark.BodyGroups = {}
cars.cspark.BodyGroups["Count"] = {}
cars.cspark.BodyGroups["Parts"] = {}
cars.cspark.BodyGroups["Parts"]["Bumperf"] = 2
cars.cspark.BodyGroups["Count"][2] = 3
cars.cspark.BodyGroups["Parts"]["Bumperr"] = 3
cars.cspark.BodyGroups["Count"][3] = 2
cars.cspark.BodyGroups["Parts"]["Skirt"] = 4
cars.cspark.BodyGroups["Count"][4] = 2
cars.cspark.BodyGroups["Parts"]["Wing"] = 5
cars.cspark.BodyGroups["Count"][5] = 2
cars.cspark.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.cspark.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.tprius = {}
cars.tprius.Name = "Toyota Prius"
cars.tprius.Model = "models/tdmcars/prius.mdl"
cars.tprius.Spawnname = "prop_vehicle_jeep"
cars.tprius.Vehiclescript = "tdmcars/prius"
cars.tprius.Secondseat = {}
cars.tprius.Secondseat.Localpos = Vector(16.5, 9, 27)
cars.tprius.Thirdseat = {}
cars.tprius.Thirdseat.Localpos = Vector(15, -30, 27)
cars.tprius.Fourthseat = {}
cars.tprius.Fourthseat.Localpos = Vector(-15, -30, 27)
cars.tprius.Price = 255090
cars.tprius.TrunkSize = 5
cars.tprius.BodyGroups = {}
cars.tprius.BodyGroups["Count"] = {}
cars.tprius.BodyGroups["Parts"] = {}
cars.tprius.BodyGroups["Parts"]["Bumperf"] = 2
cars.tprius.BodyGroups["Count"][2] = 3
cars.tprius.BodyGroups["Parts"]["Bumperr"] = 3
cars.tprius.BodyGroups["Count"][3] = 3
cars.tprius.BodyGroups["Parts"]["Skirt"] = 4
cars.tprius.BodyGroups["Count"][4] = 3
cars.tprius.BodyGroups["Parts"]["Wing"] = 5
cars.tprius.BodyGroups["Count"][5] = 2
cars.tprius.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.tprius.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.beetle = {}
cars.beetle.Name = "VW Beetle"
cars.beetle.Model = "models/tdmcars/beetle.mdl"
cars.beetle.Spawnname = "prop_vehicle_jeep"
cars.beetle.Vehiclescript = "tdmcars/beetle67"
cars.beetle.Secondseat = {}
cars.beetle.Secondseat.Localpos = Vector(18, 5, 24)
cars.beetle.Thirdseat = {}
cars.beetle.Thirdseat.Localpos = Vector(18, -40, 23)
cars.beetle.Fourthseat = {}
cars.beetle.Fourthseat.Localpos = Vector(-18, -40, 23)
cars.beetle.Price = 150900
cars.beetle.TrunkSize = 5
cars.beetle.BodyGroups = {}
cars.beetle.BodyGroups["Count"] = {}
cars.beetle.BodyGroups["Parts"] = {}
cars.beetle.BodyGroups["Parts"]["Bumperf"] = 5
cars.beetle.BodyGroups["Count"][5] = 3
cars.beetle.BodyGroups["Parts"]["Bumperr"] = 4
cars.beetle.BodyGroups["Count"][4] = 2
cars.beetle.BodyGroups["Parts"]["Skirt"] = 2
cars.beetle.BodyGroups["Count"][2] = 2
cars.beetle.BodyGroups["Parts"]["Wing"] = 3
cars.beetle.BodyGroups["Count"][3] = 2
cars.beetle.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.beetle.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.bmwm3 = {}
cars.bmwm3.Name = "BMW M3"
cars.bmwm3.Model = "models/tdmcars/bmwm3e92.mdl"
cars.bmwm3.Spawnname = "prop_vehicle_jeep"
cars.bmwm3.Vehiclescript = "tdmcars/bmwm3e92"
cars.bmwm3.Secondseat = {}
cars.bmwm3.Secondseat.Localpos = Vector(18, 5, 24)
cars.bmwm3.Thirdseat = {}
cars.bmwm3.Thirdseat.Localpos = Vector(18, -40, 23)
cars.bmwm3.Fourthseat = {}
cars.bmwm3.Fourthseat.Localpos = Vector(-18, -40, 23)
cars.bmwm3.Price = 1540990
cars.bmwm3.TrunkSize = 5
cars.bmwm3.BodyGroups = {}
cars.bmwm3.BodyGroups["Count"] = {}
cars.bmwm3.BodyGroups["Parts"] = {}
cars.bmwm3.BodyGroups["Parts"]["Wing"] = 4
cars.bmwm3.BodyGroups["Count"][4] = 3
cars.bmwm3.BodyGroups["Parts"]["Roof"] = 3
cars.bmwm3.BodyGroups["Count"][3] = 2
cars.bmwm3.BodyGroups["Parts"]["Wheels"] = 5
cars.bmwm3.BodyGroups["Count"][5] = 2
cars.bmwm3.BodyGroups["Parts"]["Hood"] = 2
cars.bmwm3.BodyGroups["Count"][2] = 2
cars.bmwm3.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/psiren.wav"}
cars.bmwm3.BodyGroups["Skins"] = {
["MLP"] = 1,
["PREM1"] = 3,
["NO SKIN"] = 0
}

--[[
cars.bmwm5e60tdm = {}
cars.bmwm5e60tdm.Name = "BMW M5"
cars.bmwm5e60tdm.Model = "models/tdmcars/bmwm5e60.mdl"
cars.bmwm5e60tdm.Spawnname = "prop_vehicle_jeep"
cars.bmwm5e60tdm.Vehiclescript = "tdmcars/bmwm5e60"
cars.bmwm5e60tdm.Secondseat = {}
cars.bmwm5e60tdm.Secondseat.Localpos = Vector(21, -2, 18)
cars.bmwm5e60tdm.Thirdseat = {}
cars.bmwm5e60tdm.Thirdseat.Localpos = Vector(18, -40, 16)
cars.bmwm5e60tdm.Fourthseat = {}
cars.bmwm5e60tdm.Fourthseat.Localpos = Vector(-18, -40, 16)
cars.bmwm5e60tdm.Price = 1840990
cars.bmwm5e60tdm.TrunkSize = 5
]]--
cars.cp = {}
cars.cp.Name = "PD Car(CP Only)"
cars.cp.Model = "models/sentry/crownviccvpi.mdl"
cars.cp.Spawnname = "prop_vehicle_jeep"
cars.cp.Vehiclescript = "sentry/crownvic"
cars.cp.Secondseat = {}
cars.cp.Secondseat.Localpos = Vector(18,5,25)
cars.cp.Thirdseat = {}
cars.cp.Thirdseat.Localpos = Vector(18,-34,25)
cars.cp.Fourthseat = {}
cars.cp.Fourthseat.Localpos = Vector(0,-34,25)
cars.cp.Price = 50
cars.cp.TrunkSize = 5
cars.cp.BodyGroups = {}
cars.cp.BodyGroups["Count"] = {}
cars.cp.BodyGroups["Parts"] = {}
cars.cp.BodyGroups["Parts"]["Grille"] =1
cars.cp.BodyGroups["Count"][1] = 2
cars.cp.BodyGroups["Parts"]["Pushbar"] = 3
cars.cp.BodyGroups["Count"][3] = 2
cars.cp.BodyGroups["Parts"]["backlight"] = 4
cars.cp.BodyGroups["Count"][4] = 2
cars.cp.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.cp.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

cars.cady = {}
cars.cady.Name = "Cadilac LMP"
cars.cady.Model = "models/tdmcars/cad_lmp.mdl"
cars.cady.Spawnname = "prop_vehicle_jeep"
cars.cady.Vehiclescript = "tdmcars/lmp"
cars.cady.Price = 5000000
cars.cady.TrunkSize = 1
cars.cady.BodyGroups = {}
cars.cady.BodyGroups["Horns"] = {"vehicles/bhorn.wav","vehicles/car-locked-honk-1.wav"}
cars.cady.BodyGroups["Skins"] = {
["NO SKIN"] = 0
}

table.SortByMember(cars, "Price")
for i,k in pairs(cars) do
	k.ID = i
	if(SERVER) then
		--resource.AddFile(k.Model)
		--resource.AddFile("scripts/vehicles/"..k.Vehiclescript..".txt")
		if(k.Materials) then
			for _,v in pairs(file.Find("../"..k.Materials.."*")) do
				--resource.AddFile(k.Materials..v)
			end
		end
		if(k.Sounds) then
			for _,v in pairs(file.Find("../"..k.Sounds.."*")) do
				--resource.AddFile(k.Sounds..v)
			end
		end
	end
end

function carIdToObject(id)
	for _,k in pairs(cars) do
		if(string.Trim(k.ID) == string.Trim(id)) then
			return k
		end
	end
	return false
end


--Testing property adding.
properties.Add("passengereject",
{
	MenuLabel = "#Eject Passengers",
	Order = 3,
	MenuIcon = "icon16/gun.png",
Filter = function(self,ent,ply)
		if (!IsValid(ent)) then return false end
		if ent:GetClass() != "prop_vehicle_jeep" then
			return false
		end
		if LocalPlayer():InVehicle() and LocalPlayer():GetVehicle() == ent then return true else return false end
		return true
	end,
Action = function(self,ent)
		if ent:GetClass() == "prop_vehicle_jeep" then
			print("Passengers removed")
			self:MsgStart()
				net.WriteEntity(ent)
			self:MsgEnd()
		end
	end, 
Receive = function(self,length,player)
		local ent = net.ReadEntity()
		if IsValid(ent) and ent:IsVehicle() and ent:GetDriver() == player then
			if IsValid(ent.Passenger) and IsValid(ent.Passenger:GetDriver()) then
				ent.Passenger:GetDriver():ExitVehicle()
			end
			if IsValid(ent.Passenger2) and IsValid(ent.Passenger2:GetDriver()) then
				ent.Passenger:GetDriver():ExitVehicle()
			end
			if IsValid(ent.Passenger3) and IsValid(ent.Passenger3:GetDriver()) then
				ent.Passenger3:GetDriver():ExitVehicle()
			end
		end
	end
});
properties.Add("lock",
{
	MenuLabel = "#Lock Doors",
	Order = 1,
	MenuIcon = "icon16/key_delete.png",
Filter = function(self,ent,ply)
		if (!IsValid(ent)) then return false end
		if ent:GetClass() != "prop_vehicle_jeep" then
			return false
		end
		if LocalPlayer():InVehicle() and LocalPlayer():GetVehicle() == ent then return true else return false end
		return true
	end,
Action = function(self,ent)
		if ent:GetClass() == "prop_vehicle_jeep" then
			print("Locked")
			self:MsgStart()
				net.WriteEntity(ent)
			self:MsgEnd()
		end
	end, 
Receive = function(self,length,player)
		local ent = net.ReadEntity()
		if IsValid(ent) and ent:IsVehicle() and ent:GetDriver() == player then
			ent:Fire('lock','',0)
			ent.CarLocked = true
		end
	end
});
properties.Add("unlock",
{
	MenuLabel = "#Unlock Doors",
	Order = 2,
	MenuIcon = "icon16/key_add.png",
Filter = function(self,ent,ply)
		if (!IsValid(ent)) then return false end
		if ent:GetClass() != "prop_vehicle_jeep" then
			return false
		end
		if LocalPlayer():InVehicle() and LocalPlayer():GetVehicle() == ent then return true else return false end
		return true
	end,
Action = function(self,ent)
		if ent:GetClass() == "prop_vehicle_jeep" then
			print("Unlocked")
			self:MsgStart()
				net.WriteEntity(ent)
			self:MsgEnd()
		end
	end, 
Receive = function(self,length,player)
		local ent = net.ReadEntity()
		if IsValid(ent) and ent:IsVehicle() and ent:GetDriver() == player then
			ent:Fire('unlock','',0)
			ent.CarLocked = false
		end
	end
});
if SERVER then
resource.AddFile("materials/byb/background.png")
resource.AddFile("materials/byb/button1.png")
resource.AddFile("materials/byb/close.png") 
resource.AddFile("materials/byb/button2.png")
resource.AddFile("materials/byb/button3.png")
resource.AddFile("materials/byb/button4.png") 

--horns/siren
resource.AddFile("sound/vehicles/psiren.wav") 
resource.AddFile("sound/vehicles/bhorn.wav") 
end