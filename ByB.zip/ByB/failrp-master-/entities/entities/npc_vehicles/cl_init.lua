-- Copyright Macendo 2009
include('shared.lua')
local TheListToContainAllElse
local TheWindowOfSavin
local function getTheCarWindow(car, buy)
	local plainit = ""
	local takeit = ""
	local letsDoThis = function() print("Pie!") end
	local price = car.Price
	carcolors = {}
	if LocalPlayer():IsSupporter() then price = car.Price / 2 end
	if(buy) then
		plainit = "    Yes, the "..car.Name.." is a very nice car.\n    It will cost you around $"..price
		takeit = "Buy!"
		letsDoThis = function()
			RunConsoleCommand("buyCar", car.ID)
			net.Start("ClientCarColor")
			net.WriteTable(carcolors)
			net.SendToServer()
		end
	else
		plainit = "Yes, your "..car.Name.." is in good condition, would you like it now?"
		takeit = "Put it outside"
		letsDoThis = function()
			RunConsoleCommand("putOutside", car.ID)
			net.Start("ClientCarColor")
			net.WriteTable(carcolors)
			net.SendToServer()
			TheWindowOfSavin:Close()
		end
	end
	TheWindowOfSavin:SetTitle("So you want to buy the "..car.Name)
	local ExplainIt = vgui.Create("DLabel")
	ExplainIt:SetText(plainit)
	ExplainIt:SizeToContents()
	TheListToContainAllElse:AddItem(ExplainIt)
	
	
	ShowOff = vgui.Create("DModelPanel")
	ShowOff:SetModel(car.Model)
	--ShowOff:SetColor(Color(255,0,0,255))
	ShowOff:SetSize(100,200)
	ShowOff:SetCamPos( Vector( 150, 150, 80 ) )
	ShowOff:SetLookAt( Vector( 0, 0, 0 ) )
	TheListToContainAllElse:AddItem(ShowOff)
	
	local TakeIt = vgui.Create("DButton")
	TakeIt:SetText(takeit) 
	TakeIt:SizeToContents()
	TakeIt:SetHeight(TakeIt:GetTall()+6)
	TakeIt.DoClick = letsDoThis
	TakeIt:SetSkin("DarkRP")
	TakeIt:SetTextColor(Color(255,255,255,255))
	TheListToContainAllElse:AddItem(TakeIt)
	if (buy) then
		local back = vgui.Create("DButton")
		back:SetText("Back to car selection.")
		back:SizeToContents()
		back:SetHeight(back:GetTall()+6)
		back.DoClick = function()
			ShowOff:SetVisible(false)
			TheListToContainAllElse:AlphaTo(0,0.5,0,function()
				ShowOff:SetVisible(true)
				buyACarWindow()
				TheListToContainAllElse:AlphaTo(255,0.5,0.5)
			end)
		end
		back:SetSkin("DarkRP")
		back:SetTextColor(Color(255,255,255,255))
		TheListToContainAllElse:AddItem(back)
	end
	local carcol = vgui.Create("DColorMixer")
	carcol:SetAlphaBar(false)
	carcol:SetPalette(true)
	carcol:SetSize(300,150)
	carcol.ValueChanged = function()
		carcolors = carcol:GetColor() 
		ShowOff:SetColor(Color(carcolors.r,carcolors.g,carcolors.b)) 
	end
	TheListToContainAllElse:AddItem(carcol)
end

function buyACarWindow()
	TheWindowOfSavin:SetTitle("Choose a car")
	TheListToContainAllElse:Clear()
	TheListToContainAllElse:EnableHorizontal(true)
	TheListToContainAllElse:SetSpacing(1)
	TheListToContainAllElse:EnableHorizontal(true)
	--[[
	for _,k in pairs(cars) do
		local TheCar = vgui.Create("SpawnIcon")
		TheCar:SetModel(k.Model)
		local price = k.Price
		if LocalPlayer():IsSupporter() then price = k.Price / 2 end
		if k.Name == "PD Car(CP Only)" then
			if not LocalPlayer():IsCP() then
				k.Name = "CP Job ONLY - BUY DISABLED"
			end 
		end
		TheCar:SetTooltip(k.Name.."\n"..price.."$")
		--TheCar:SetIconSize(64)
		TheCar:InvalidateLayout( true ) 
		TheCar.DoClick = function()
			TheListToContainAllElse:Clear()
			TheListToContainAllElse:SetSpacing(5)
			TheListToContainAllElse:EnableHorizontal(false)
			getTheCarWindow(k, true)
		end
		TheListToContainAllElse:AddItem(TheCar)
	end
	]]--

	for k,v in pairs(cars) do
		local panel = vgui.Create("DPanel")
		panel:SetSize(380,80)
		panel:SetSkin("DarkRP")
		panel.Paint =  function()
			surface.SetDrawColor(50,50,50,0)
			surface.DrawRect(0,0,panel:GetWide(),panel:GetTall())
		end
		local pic =  vgui.Create("SpawnIcon",panel)
		pic:SetModel(v.Model)
		pic:SetTooltip(v.Name)
		pic:InvalidateLayout( true ) 

		local lab = vgui.Create("DLabel",panel)
		local seats = "1"
		if v.Fourthseat then seats = "4" elseif v.Thirdseat then seats = "3" elseif v.Secondseat then seats = "2" end
		local price = v.Price
		if LocalPlayer():IsSupporter() then price = math.floor(v.Price / 2) end
		lab:SetText("Buy: "..v.Name.." for $" ..price .. ".\nThis car has " .. seats .." working seats.")
		lab:SetPos(75,20)
		lab:SizeToContents()

		local button = vgui.Create("DButton",panel)
		button:SetText("Click to view car details.")
		button:SetSize(280,20)
		button:SetPos(75,55)
		button:SetSkin("DarkRP")		
		button:SetTextColor(Color(255,255,255,255))
		--[[ Works well, but the button looks smoother.
		button.Paint =  function()
			surface.SetFont("Font123")
			surface.SetDrawColor(35,35,142,125)
			surface.DrawRect(0,0,button:GetWide(),button:GetTall())
		end]]--
		button.DoClick = function()
			TheListToContainAllElse:AlphaTo(0,0.5,0,function()
				TheListToContainAllElse:Clear()
				TheListToContainAllElse:SetSpacing(5)
				TheListToContainAllElse:EnableHorizontal(false)
				getTheCarWindow(v, true)
				TheListToContainAllElse:AlphaTo(255,0.5,0.2)
			end)
		end
		panel:Dock(TOP)
		TheListToContainAllElse:AddItem(panel)
	end
end
local function storeCarorTakeout()
	TheListToContainAllElse:EnableHorizontal(true)
	TheListToContainAllElse:SetSpacing(1)
end

local function SellCarMenu()
	if carsStored then
	TheListToContainAllElse:Clear()
	LocalPlayer():ChatPrint("Cars are sold as scrap, if you want to rebuy the same car you will have to buy a new one from the NPC.\nWe will not refund accidental sales, so be cautios as you do lose 25% of the car value")
		for k,getCar in pairs(carsStored) do
			for _,k in pairs(cars) do
				if(string.lower(string.Trim(k.Vehiclescript)) == string.lower(string.Trim(getCar))) then
					if type(getCar) == "table" then getCar = getCar.vehicleScript end
					local panel = vgui.Create("DPanel")
					panel:SetSize(380,80)
					panel:SetSkin("DarkRP")
					panel.Paint =  function()
						surface.SetDrawColor(50,50,50,0)
						surface.DrawRect(0,0,panel:GetWide(),panel:GetTall())
					end
					local pic =  vgui.Create("SpawnIcon",panel)
					pic:SetModel(k.Model)
					pic:SetTooltip(k.Name)
					pic:InvalidateLayout( true ) 
					local lab = vgui.Create("DLabel",panel)
					local price = (k.Price / 100) * 80
					if LocalPlayer():IsSupporter() then price = math.floor(price / 2) end
					lab:SetText("Sell back for: "..k.Name.." for $" ..price .. ".\nUsed cars are only worth 75% of there initial value.")
					lab:SetPos(75,20)
					lab:SizeToContents()
					local button = vgui.Create("DButton",panel)
					button:SetText("Click to sell - CANNOT BE UNDONE -")
					button:SetSize(280,20)
					button:SetPos(75,55)
					button:SetSkin("DarkRP")
					button:SetTextColor(Color(255,255,255,255))
					button.DoClick = function()
						TheListToContainAllElse:Clear()
						TheListToContainAllElse:SetSpacing(5)
						TheListToContainAllElse:EnableHorizontal(false)
						net.Start("SellCar")
						net.WriteString(k.Vehiclescript)
						net.SendToServer()
						TheWindowOfSavin:AlphaTo(0,0.2,0,function()
							TheWindowOfSavin:Close()
						end)
						carsStored = {}
					end
					panel:Dock(TOP)
					TheListToContainAllElse:AddItem(panel)
				end
			end
		end
	end
end
--[[
local function takeStoredCars(um)
	local hasCars = um:ReadBool()
	if(hasCars) then
		local amountOfCars = um:ReadShort()
		local carsStored = {}
		TheListToContainAllElse:Clear()
		storeCarorTakeout()
		for i=1,amountOfCars do
			local getCar = um:ReadString()
			table.insert(carsStored, getCar)
			for _,k in pairs(cars) do
				if(string.lower(string.Trim(k.Vehiclescript)) == string.lower(string.Trim(getCar))) then
					-- Now we can go rampage
					local carIcon = vgui.Create("SpawnIcon")
					carIcon:SetModel(k.Model)
					carIcon:SetTooltip(k.Name)
					carIcon:SizeToContents()
					carIcon:SetIconSize(64)
					carIcon:InvalidateLayout( true ) 
					carIcon.DoClick = function()
						TheListToContainAllElse:Clear()
						TheListToContainAllElse:EnableHorizontal(false)
						TheListToContainAllElse:SetSpacing(5)
						getTheCarWindow(k, false)
					end
					TheListToContainAllElse:AddItem(carIcon)
				end
			end
		end
	else
		TheListToContainAllElse:Clear()
		local Fagola = vgui.Create("DLabel")
		Fagola:SetText("No cars in storage or cars are loading previous saves!")
		Fagola:SizeToContents()
		TheListToContainAllElse:AddItem(Fagola)
	end
end
usermessage.Hook("takeStoredCars", takeStoredCars)
]]--
surface.CreateFont( "Font123", {
 font = "Arial",
 size = 13,
 weight = 500,
 blursize = 0,
 scanlines = 0,
 antialias = true,
 underline = false,
 italic = false,
 strikeout = false,
 symbol = false,
 rotary = false,
 shadow = false,
 additive = false,
 outline = false
} )
net.Receive("UpdateCars", function()
	carsStored = net.ReadTable()	
end)
net.Receive("SendStoredCars", function ()
	carsStored = net.ReadTable()	
	TheListToContainAllElse:Clear()
	for k,getCar in pairs(carsStored) do
		for _,k in pairs(cars) do
			if(string.lower(string.Trim(k.Vehiclescript)) == string.lower(string.Trim(getCar))) then
				local carIcon = vgui.Create("SpawnIcon")
				carIcon:SetModel(k.Model)
				carIcon:SetTooltip(k.Name)
				--carIcon:SizeToContents()
				carIcon:InvalidateLayout( true ) 
				carIcon.DoClick = function()
					TheListToContainAllElse:Clear()
					TheListToContainAllElse:EnableHorizontal(false)
					TheListToContainAllElse:SetSpacing(5)
					getTheCarWindow(k, false)
				end
				TheListToContainAllElse:AddItem(carIcon)
			end
		end
	end
	TheWindowOfSavin:SetTitle("Previously Purchased Vehicles. Max 2 spawned at any 1 time.")
	TheListToContainAllElse:EnableHorizontal(true)
	TheListToContainAllElse:SetSpacing(1)
	storeCarorTakeout()
end)
		
local function introWindow(um)
	TheWindowOfSavin = vgui.Create("DFrame")
	TheWindowOfSavin:SetSize(400,550)
	TheWindowOfSavin:SetPos(ScrW()/2-200,ScrH()/2-300)
	TheWindowOfSavin:SetTitle("Big Yellow Ball Car Co")
	TheWindowOfSavin:SetVisible(true)
	TheWindowOfSavin:SetDraggable(true)
	TheWindowOfSavin:ShowCloseButton(true)
	--TheWindowOfSavin:SetSkin("DarkRP")
	
	
	local background = vgui.Create( "DImageButton", TheWindowOfSavin )
	background:SetImage( "byb/background.png" ) -- Set your .vtf image
	background:SetSize(400,550)			
	local showcar = table.Random(cars)
	background.ShowOff = vgui.Create("DModelPanel",TheWindowOfSavin)
	background.ShowOff:SetModel(showcar.Model)
	background.ShowOff:SetColor(Color(math.random(0,255),math.random(0,255),math.random(0,255),255))
	background.ShowOff:SetSize(385,400)
	background.ShowOff:SetPos(7.5,225)
	background.ShowOff:SetCamPos( Vector( 150, 150, 80 ) )
	background.ShowOff:SetLookAt( Vector( 0, 0, 0 ) )
	background.ShowOff.DoClick = function()
		getTheCarWindow(showcar,true)
		background.button1:SetVisible(false)
		background.button2:SetVisible(false)
		background.button3:SetVisible(false)
		background.button4:SetVisible(false)
		background.ShowOff:SetVisible(false)
		background.button1:AlphaTo(0,0.5,0,function()
			background.button1:SetVisible(false)
			background.button2:SetVisible(false)
			background.button3:SetVisible(false)
			background.button4:SetVisible(false)
			background.ShowOff:SetVisible(false)
		end)
		background.button2:AlphaTo(0,0.5,0)
		background.button3:AlphaTo(0,0.5,0)
		background.button4:AlphaTo(0,0.5,0)
		TheListToContainAllElse:AlphaTo(255,0.5,0.5)
		background.ShowOff:SetVisible(false)
	end
	background.button1 = vgui.Create( "DImageButton", TheWindowOfSavin ) 
	background.button1:SetPos( 15,75 )
	background.button1:SetImage( "byb/button1.png" ) -- Set your .vtf image
	background.button1:SetSize(180,89)
	background.button1.DoClick = function()
		--TheListToContainAllElse:Clear()
		buyACarWindow()
		background.button1:AlphaTo(0,0.5,0,function()
			background.button1:SetVisible(false)
			background.button2:SetVisible(false)
			background.button3:SetVisible(false)
			background.button4:SetVisible(false)
			background.ShowOff:SetVisible(false)
		end)
		background.button2:AlphaTo(0,0.5,0)
		background.button3:AlphaTo(0,0.5,0)
		background.button4:AlphaTo(0,0.5,0)
		TheListToContainAllElse:AlphaTo(255,0.5,0.5)
			background.ShowOff:SetVisible(false)
		end	
	background.button2 = vgui.Create( "DImageButton", TheWindowOfSavin ) 
	background.button2:SetPos( 205,75 )
	background.button2:SetImage( "byb/button2.png" ) -- Set your .vtf image
	background.button2:SetSize(180,89)
	background.button2.DoClick = function()
		TheListToContainAllElse:Clear()
		SellCarMenu()
		background.button1:AlphaTo(0,0.5,0,function()
			background.button1:SetVisible(false)
			background.button2:SetVisible(false)
			background.button3:SetVisible(false)
			background.button4:SetVisible(false)
			background.ShowOff:SetVisible(false)
		end)
		background.button2:AlphaTo(0,0.5,0)
		background.button3:AlphaTo(0,0.5,0)
		background.button4:AlphaTo(0,0.5,0)
		TheListToContainAllElse:AlphaTo(255,0.5,0.5)
		background.ShowOff:SetVisible(false)
		end
	background.button3 = vgui.Create( "DImageButton", TheWindowOfSavin ) 
	background.button3:SetPos( 15,175 )
	background.button3:SetImage( "byb/button3.png" ) -- Set your .vtf image
	background.button3:SetSize(180,89)
	background.button3.DoClick = function()
		TheListToContainAllElse:Clear()
		RunConsoleCommand("storeCars")
		background.ShowOff:SetVisible(false)
		TheWindowOfSavin:AlphaTo(0,0.2,0,function()
			TheWindowOfSavin:Close()
		end)
		end
	background.button4 = vgui.Create( "DImageButton", TheWindowOfSavin ) 
	background.button4:SetPos( 205,175 )
	background.button4:SetImage( "byb/button4.png" ) -- Set your .vtf image
	background.button4:SetSize(180,89)
	background.button4.DoClick = function()
		RunConsoleCommand("getStoredCars")	
		chat.AddText(Color(255,0,0),"If you just bought a new car/or not used the npc this session then you might have to reload the storage.")
		storeCarorTakeout()
		background.button1:AlphaTo(0,0.5,0,function()
			background.button1:SetVisible(false)
			background.button2:SetVisible(false)
			background.button3:SetVisible(false)
			background.button4:SetVisible(false)
			background.ShowOff:SetVisible(false)
		end)
		background.button2:AlphaTo(0,0.5,0)
		background.button3:AlphaTo(0,0.5,0)
		background.button4:AlphaTo(0,0.5,0)
		TheListToContainAllElse:AlphaTo(255,0.5,0.5)
		background.ShowOff:SetVisible(false)
		end
	background.credits = vgui.Create("DButton",TheWindowOfSavin)
	background.credits:SetText("Graphics by Dr. Moo/LUA by Pantho @ bybservers.co.uk")
	background.credits:SizeToContents()
	background.credits:SetPos( 30,521 )
	background.credits:SetTextColor(Color(139,10,80,255))
	background.credits.Paint =  function()
			surface.SetDrawColor(0,0,0,0)
		end
	local exitbutton = vgui.Create( "DImageButton", TheWindowOfSavin ) 
	exitbutton:SetPos( 320,519 )
	exitbutton:SetImage( "byb/close.png" ) -- Set your .vtf image
	exitbutton:SetSize(68,17)
	exitbutton.DoClick = function()
		background.ShowOff:SetVisible(false)
		TheWindowOfSavin:AlphaTo(0,0.2,0,function()
			TheWindowOfSavin:Close()
		end)
	end	

	TheListToContainAllElse = vgui.Create("DPanelList", background)
	TheListToContainAllElse:SetSize(400,475)
	TheListToContainAllElse:SetPos(0,40)
	TheListToContainAllElse:SetSpacing(5)
	TheListToContainAllElse:SetPadding(5)
	TheListToContainAllElse:EnableHorizontal(false)
	TheListToContainAllElse:EnableVerticalScrollbar(false)
	TheListToContainAllElse:AlphaTo(0,0,0)
	
	--TheListToContainAllElse:SetSkin("DarkRP")
	TheWindowOfSavin:MakePopup()
	
	
	
end
usermessage.Hook("SellerIntro", introWindow)

-- probably shouldn't drop this here, but ah well
surface.CreateFont( "pm_mod", {font="lcd", size=25, weight=60,shadow=false} )
hook.Add("HUDPaint", "pm_mod_mph", function()
    local veh = LocalPlayer():GetVehicle() or {}
    local rech = 0
    local speed = 0
    
    if IsValid( veh ) and veh:GetClass() ~= "prop_vehicle_prisoner_pod" then
        local vehicleVel = veh:GetVelocity():Length()
        local vehicleConv = -1
        local terminal = 0
           
        terminal = math.Clamp(vehicleVel/2000, 0, 1)
        vehicleConv = math.Round(vehicleVel / 10)
        
        speed = math.Clamp(vehicleConv, 0, 320) //  Maximal Display KM/H = 320km/h
        
        local w, h = 500, 35
        local w2, h2 = 492/320*speed, 27
        local roundrech = 4/30*math.Clamp(speed, 0.1, 30)
        
        draw.RoundedBox( 4, (ScrW()/2) - (w/2), ScrH() - ( 25 + h ), w, h, Color( 0, 0, 0, 240 ) )
        draw.RoundedBox( roundrech, (ScrW()/2) - (w2/2), ScrH() - ( 25 + h2 + 4 ), w2, h2, Color( 200, 0, 0, 240 ) )
        
        local speedtext = speed .. " MPH"
        local font = "pm_mod"
        surface.SetFont( font )
        local len = surface.GetTextSize( speedtext )
        draw.SimpleTextOutlined( speedtext, font, (ScrW()/2) - len/2, ScrH() - 53, Color( 255, 255, 255, 200 ), false, false, 1, Color( 0, 0, 0, 200 ) )
    end
end)


local function carBought(um)
	TheListToContainAllElse:Clear()
	local CarOutside = vgui.Create("DLabel")
	CarOutside:SetText("Thank you very much, the car is located just outside!")
	CarOutside:SizeToContents()
	TheListToContainAllElse:AddItem(CarOutside)
end
usermessage.Hook("carLocation", carBought)

