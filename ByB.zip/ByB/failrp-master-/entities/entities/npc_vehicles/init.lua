AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include('shared.lua')

function ENT:Initialize()
   self:SetModel("models/Characters/Hostage_01.mdl")
   
    self:SetHullType(HULL_HUMAN)
    self:SetHullSizeNormal()
    self:SetNPCState(NPC_STATE_NONE)
    self:SetSolid(SOLID_BBOX)
    self:CapabilitiesAdd(CAP_ANIMATEDFACE, CAP_TURN_HEAD)
    self:DropToFloor()
    self:SetMaxYawSpeed(90)
  
   //Sets the entity values
  -- self:SetHealth(self.StartHealth)
   self:SetEnemy(NULL)
   self:SetSchedule(SCHED_IDLE_STAND)
   position = self:GetPos()
   self:SetUseType(SIMPLE_USE)
   
end
local UseCD = CurTime()
function ENT:AcceptInput( input, activator, caller )
	if input == "Use" && activator:IsPlayer() then
		if UseCD > CurTime() then return end
		UseCD = CurTime() + 1
		umsg.Start( "SellerIntro", activator )  
		umsg.End()  
	end
end
   
function ENT:OnTakeDamage(dmg)
	self:SetHealth(100000)
end


function ENT:Think()
end
   
function fPlayerDisconnect( ply )
	if ply.Car and IsValid(ply.Car) then
		ply.Car:Remove()
	end
end
hook.Add( "PlayerDisconnected", "playerdisconnected", fPlayerDisconnect )

local function UpdateLists(ply)
	DB.Query("SELECT * FROM " .. StoredCarsTable .. " WHERE steamid = '"..ply:SteamID().."';", function(data) 
	ply.SCars = data
	end)
	timer.Simple(3, function()
		local result = ply.SCars
		local hasCars = false
		local vehicleScripts = {}
		if (result) then
			for id,row in pairs(result) do
				hasCars = true
				table.insert(vehicleScripts, row['vehicleScript'])
			end
		end
		if(hasCars) then
			net.Start("UpdateCars")
			net.WriteTable(vehicleScripts)
			net.Send(ply)
		end
	end)
end

util.AddNetworkString('SendStoredCars');
util.AddNetworkString('ClientCarColor');
util.AddNetworkString('SellCar');
util.AddNetworkString('UpdateCars');
local function sendStoredCars(ply,cmd,args)
	DB.Query("SELECT * FROM " .. StoredCarsTable .. " WHERE steamid = '"..ply:SteamID().."';", function(data) 
		ply.SCars = data
	local result = ply.SCars
	local hasCars = false
	local vehicleScripts = {}
	if (result) then
		for id,row in pairs(result) do
			hasCars = true
			table.insert(vehicleScripts, row['vehicleScript'])
		end
	end
	if(hasCars) then
		for _,v in pairs(vehicleScripts) do
			if(ply:GetNWEntity("car") != NULL and ply:GetNWEntity("car"):IsValid()) then
				local vehicleScriptie = string.Explode(".", string.Explode("/", ply:GetNWEntity("car"):GetKeyValues().VehicleScript)[3])[1]
				if(v == vehicleScriptie) then					
					if ply.Car and IsValid(ply.Car) then
						ply.Car:Remove()
					end					
					local ent = ents.Create('prop_vehicle_jeep')
					ent:SetModel('models/buggy.mdl')
					ent:SetKeyValue('vehiclescript', 'scripts/vehicles/jeep_test.txt');
					ent:SetPos(Vector( 1042.563110,949.702026,128.031250))
					ent:SetAngles(Angle(0,90,0))
					ent:Spawn()
					ent:Activate()
					ent:Fire('lock','',0)
					ent:Own(ply)
					ply.Car = ent
					table.remove(vehicleScripts, _)
				end
			end
		end
		net.Start("SendStoredCars")
		net.WriteTable(vehicleScripts)
		net.Send(ply)
	end
	end)
end
concommand.Add("getStoredCars", sendStoredCars)

net.Receive("ClientCarColor", function (len,ply)
	ply.CarColors = net.ReadTable()
end)
local cpause = CurTime()
net.Receive("SellCar", function (len,ply)
	if cpause >= CurTime() then return end
	cpause = CurTime() + 10
	ply.carlist = ply.SCars or {}
	local tosell = net.ReadString()
	local carlist = {}
	for k,v in pairs(ply.carlist) do
		if(string.lower(string.Trim(v.vehicleScript)) == string.lower(string.Trim(tosell))) then
			DB.Query("DELETE FROM " .. StoredCarsTable .. " WHERE steamid="..sql.SQLStr(ply:SteamID()).." AND vehicleScript='"..v.vehicleScript.."' LIMIT 1;")  
			if ply:IsSupporter() then
				ply:AddMoney(((v.cost/100)*80)/2)
				GAMEMODE:Notify(ply,1,7,"You sold your car for $"..tostring(((v.cost/100)*80)/2))
				ply.SCars = {}
				ply.stats.SOLDCARS = ply.stats.SOLDCARS + ((v.cost/100)*80)/2
			else
				ply:AddMoney((v.cost/100)*80)	
				GAMEMODE:Notify(ply,1,7,"You sold your car for $"..tostring((v.cost/100)*80))
				ply.SCars = {}
				ply.stats.SOLDCARS = ply.stats.SOLDCARS + (v.cost/100)*80
			end
		end
	end 
end)

local function storeCar(car)
	--PrintTable(car:GetKeyValues())
	local cutUpScript = string.Explode(".", string.Explode("/", car:GetKeyValues().VehicleScript)[3])[1]
	--sql.Query("INSERT INTO storedCars VALUES( \""..car:GetNWEntity("car_owner"):SteamID().."\", \""..cutUpScript.."\", \""..math.random(0,99999).."\" );")
	if(car:GetNWEntity("car_owner"):GetPos():Distance(car:GetPos()) < 900) then
		local ply = car:GetNWEntity("car_owner")
		ply.CarsOut = ply.CarsOut or 1 
		ply.CarsOut = ply.CarsOut - 1
		car:GetNWEntity("car_owner"):SetNWEntity("car", NULL)
		car:Remove()
	else
		car:GetNWEntity("car_owner"):PrintMessage(HUD_PRINTTALK, "The car is way to far away")
	end
end

hook.Add("PlayerDisconnected", "CarSellerStore", function(ply)
	for _,k in pairs(ents.GetAll()) do
		if(k:IsVehicle() and k:GetNWEntity("car_owner") == ply) then
			storeCar(k)
		end
	end
end)

local function storeAllCars(ply,cmd,args)
	for _,k in pairs(ents.GetAll()) do
		if(k:IsVehicle() and k:GetNWEntity("car_owner") == ply) then
			storeCar(k)
		end
	end
end
concommand.Add("storeCars", storeAllCars)

local n = 1
local spawnlist 
mapang = Angle(0,0,0)
if RP6 then 
	spawnlist = {Vector(1037.750122,1258.116211,128),Vector(1037.750122,1019.116211,128),Vector(1037.750122,559.116211,128)} 
	mapang = Angle(0,-180,0)
--elseif RP5 then
--	spawnlist = {Vector(-1303,-6410,-139),Vector(-1543,-6409,-139),Vector(-1303,-6409,-139)}
--	mapang = Angle(0,90,0)
elseif RP3 then
	spawnlist = {Vector(1978, 4293, 50),Vector(1978, 4086, 50)}
	mapang = Angle(0,90,0)
else
	return
end
local function spawnCar(id,ply)
	local sid = ply.SID
	local horn
	local skin
	local color
	local carObject = carIdToObject(id)
	ply.SCars = ply.SCars or {}
	for k,v in pairs(ply.SCars) do
		if v.vehicleScript == carObject.Vehiclescript then
			bodygroups = v.bodygroups or ""
			horn = v.horn or ""
			skin = v.skin or 0
			color = v.color or {}
		end
	end
	local theCar = ents.Create(carObject.Spawnname)
	if(game.GetMap() == "gm_flatgrass") then
		theCar:SetPos(Vector(-1994, -1647, 63))
	else
		theCar:SetPos(spawnlist[n])
		n = n +1
		if n>3 then n = 1 end
		if not spawnlist[n] then n = 1 end
		theCar:SetAngles(mapang)
	end
	theCar:SetKeyValue("vehiclescript", "scripts/vehicles/"..carObject.Vehiclescript..".txt")
	theCar:SetModel(carObject.Model)
	--theCar:SetNWEntity("car_owner", ply)
	theCar:SetNWInt("health", 100)
	theCar:Spawn()
	theCar:SetNetworkedInt("trunksize",carObject.TrunkSize)
	theCar:Activate()
	theCar:Own(ply)
	if ply.CarColors.r then
		if carObject.Name != "PD Car(CP Only)" then
			theCar:SetColor(Color(ply.CarColors.r,ply.CarColors.g,ply.CarColors.b))
		end
	end
	--local vname = carObject.Name
	--for k,v in pairs(CustomVehicles) do
	--	if string.lower(v.name) == string.lower(vname) then found = CustomVehicles[k] break end
	--end
	local found = carObject
	theCar.VehicleName = found.Name
	theCar.SID = sid
	theCar.Horn = horn
	theCar.VehicleTable = list.Get("Vehicles")[found.Name]
	gamemode.Call("PlayerSpawnedVehicle", ply, theCar) -- VUMod compatability
	theCar:SetNWBool("has2", false)
	theCar:Fire("lock", "", 0)
	theCar.CarLocked = true
	theCar:SetHealth(100)
	--PrintTable(theCar:GetKeyValues())
	--theCar:SetNWBool("
	if(carObject.Secondseat) then
		local Seat = ents.Create("prop_vehicle_prisoner_pod")
		Seat:SetModel("models/props_phx/carseat2.mdl")
		Seat:SetKeyValue( "vehiclescript" , "scripts/vehicles/prisoner_pod.txt" )
		Seat:SetPos( theCar:LocalToWorld(carObject.Secondseat.Localpos))
		Seat:SetAngles(mapang)
		Seat:SetNoDraw(true)
		Seat:Spawn()
		Seat:Activate()
		Seat:SetParent(theCar)
		Seat:SetCollisionGroup(COLLISION_GROUP_WORLD)
		theCar:DeleteOnRemove(Seat)
		Seat.HandleAnimation = function(vehicle, player) return player:SelectWeightedSequence( ACT_HL2MP_SIT ) end
		theCar:SetNWBool("has2", true)
		theCar:SetNWEntity("seat", Seat)
		theCar.Passenger = Seat
	end
	if(carObject.Thirdseat) then
		local Seat = ents.Create("prop_vehicle_prisoner_pod")
		Seat:SetModel("models/props_phx/carseat2.mdl")
		Seat:SetKeyValue( "vehiclescript" , "scripts/vehicles/prisoner_pod.txt" )
		Seat:SetPos( theCar:LocalToWorld(carObject.Thirdseat.Localpos))
		Seat:SetAngles(mapang)
		Seat:SetNoDraw(true)
		Seat:Spawn()
		Seat:Activate()
		Seat:SetParent(theCar)
		Seat:SetCollisionGroup(COLLISION_GROUP_WORLD)
		theCar:DeleteOnRemove(Seat)
		Seat.HandleAnimation = function(vehicle, player) return player:SelectWeightedSequence( ACT_HL2MP_SIT ) end
		theCar:SetNWBool("has2", true)
		theCar:SetNWEntity("seat", Seat)
		--theCar:SetNWBool("
		theCar.Passenger2 = Seat
	end
	if(carObject.Fourthseat) then
		local Seat = ents.Create("prop_vehicle_prisoner_pod")
		Seat:SetModel("models/props_phx/carseat2.mdl")
		Seat:SetKeyValue( "vehiclescript" , "scripts/vehicles/prisoner_pod.txt" )
		Seat:SetPos( theCar:LocalToWorld(carObject.Fourthseat.Localpos))
		Seat:SetAngles(mapang)
		Seat:SetNoDraw(true)
		Seat:Spawn()
		Seat:Activate()
		Seat:SetParent(theCar)
		Seat:SetCollisionGroup(COLLISION_GROUP_WORLD)
		theCar:DeleteOnRemove(Seat)
		Seat.HandleAnimation = function(vehicle, player) return player:SelectWeightedSequence( ACT_HL2MP_SIT ) end
		theCar:SetNWBool("has2", true)
		theCar:SetNWEntity("seat", Seat)
		--theCar:SetNWBool("
		theCar.Passenger3 = Seat
	end
	local args = string.Explode("*",bodygroups or "")
	local id
	for k,v in pairs(args) do
		id = string.Explode(",",v)
		if tonumber(id[2]) then
			theCar:SetBodygroup(tonumber(id[1]),tonumber(id[2]))
		end
	end
	--theCar:SetColor(color)
	theCar:SetSkin(tonumber(skin) or 0)
	ply:EnterVehicle(theCar)
	return theCar
end

local function putOutside(ply,cmd,args)
	ply.CarSpawnCD = ply.CarSpawnCD or CurTime()
	if(args[1] and args[1] ~= "") then
		if ply.CarSpawnCD > CurTime() then return end
		ply.CarSpawnCD = CurTime() + 10
		local carObject = carIdToObject(args[1])
		if(carObject) then
			if ply.CarsOut >= 2 then ply:ChatPrint("I'm sorry but you're only allowed 2 vehicles out at a time. If you lost one to RP situations try to phone the police.") return end
	--		sql.Query("DELETE FROM storedCars WHERE steamid = \""..ply:SteamID().."\" and vehicleScript = \""..carObject.Vehiclescript.."\";")
			if(ply:GetNWEntity("car") != NULL and ply:GetNWEntity("car"):IsValid()) then
				if(ply:GetNWEntity("car"):GetPos():Distance(ply:GetPos()) > 1000) then
					ply:PrintMessage(HUD_PRINTTALK, "The car is not near enough")
					return false
				end
				ply:GetNWEntity("car"):Remove()
			end
			local theCar
			-- God this is a mess... - Pantho
			if carObject.Name == "PD Car(CP Only)" then
				if not ply:IsCP() then
					ply:ChatPrint("Please change to a CP job to buy/spawn this vehicle")
					return
				end
				theCar = spawnCar(args[1],ply)
				theCar.CopCar = true
				theCar:SetBodygroup(2,1)	
				local siren = ents.Create("prop_physics")
				siren:SetModel("models/lonewolfie/lightbarani.mdl")
				siren:SetParent(theCar)
				siren:SetCollisionGroup(COLLISION_GROUP_WORLD)
				theCar:DeleteOnRemove(siren)
				siren:SetPos(theCar:LocalToWorld(Vector(0,0,9.3)))
				if RP6 then siren:SetAngles(Angle(0,90,0)) end
				siren:Spawn()
				theCar.Siren = siren
			else
				theCar = spawnCar(args[1],ply)
			end
			theCar:Own(ply)
			theCar:SetNWEntity("car_owner", ply)
			ply:SetNWEntity("car", theCar)
			theCar.Owner = ply
			theCar:SetHealth(50)
			theCar.OwnerID = ply:SteamID()
			ply.CarsOut = ply.CarsOut + 1 or 1
		end
	end
end
concommand.Add("putOutside", putOutside)

local function buyCar(ply,cmd,args)
	ply.CarsOut = ply.CarsOut or 0
	if(args[1]) then
		--print("Arg is not null")
		local id = args[1]
		local carObject = carIdToObject(id)
		if(carObject) then
			local price = carObject.Price
			if ply:IsSupporter() then price = carObject.Price / 2 end
			if(ply:CanAfford(price)) then
				if carObject.Name == "PD Car(CP Only)" then
					if not ply:IsCP() then
						ply:ChatPrint("Please change to a CP job to buy/spawn this vehicle")
						return
					end
				end
				umsg.Start("carLocation", ply)
				umsg.End()
				for _,k in pairs(ents.GetAll()) do
					if(k:IsVehicle() and k:GetNWEntity("car_owner") == ply) then
						storeCar(k)
					end
				end
				if ply.CarsOut >= 2 then ply:ChatPrint("Sorry but the car was not spawned due to exceeding the max 2 vehicles per player limit. Please park a car first.") return end	--print("Start this")
				theCar = spawnCar(id,ply)				
				if carObject.Name == "PD Car(CP Only)" then
					theCar.CopCar = true
					theCar:SetBodygroup(2,1)	
					local siren = ents.Create("prop_physics")
					siren:SetModel("models/lonewolfie/lightbarani.mdl")
					siren:SetParent(theCar)
					siren:SetCollisionGroup(COLLISION_GROUP_WORLD)
					theCar:DeleteOnRemove(siren)
					siren:SetPos(theCar:LocalToWorld(Vector(0,0,9.3)))
					if RP6 then siren:SetAngles(Angle(0,90,0)) end
					siren:Spawn()
				end
				theCar.Siren = siren
				theCar:Own(ply)
				theCar:SetNWEntity("car_owner", ply)
				ply:SetNWEntity("car", theCar)
				ply:AddMoney(-price)
				ply:SetNWEntity("car", theCar)
				theCar.Owner = ply
				theCar.OwnerID = ply:SteamID()
				ply.CarsOut = ply.CarsOut + 1
				DB.Query("INSERT INTO " .. StoredCarsTable .. " (steamid,vehicleScript,cost,uniqueid) VALUES( \""..ply:SteamID().."\", \""..carObject.Vehiclescript.."\", " ..carObject.Price..","..ply:UniqueID().." );")
				--ply.PSPENTONCARS = ply.PSPENTONCARS + price
				GAMEMODE:Notify(ply,1,7,"You bought a car for $"..price)
				timer.Simple(2, function() UpdateLists(ply) end)
			else
				ply:PrintMessage(HUD_PRINTTALK, "You can not afford this car.")
			end
		else
			--print("Not found :(")
		end
	end
end
concommand.Add("buyCar", buyCar)

local function CarDamage(target, dmginfo)
local attacker = dmginfo:GetAttacker()
	if IsValid(target) and target:IsVehicle() then
		if target:Health() >= 1 then
			if IsValid(attacker) and attacker:IsPlayer() then
				target:SetHealth(target:Health() - (dmginfo:GetDamage()*10))
			end
			timer.Create(target:EntIndex().."CarHealing",360,1,function() target.CarDisabled = false target:SetHealth(100) end)
		elseif not target.CarDisabled then	
			local tdmginfo = DamageInfo()
			tdmginfo:SetDamage(50) --20-70 damage
			tdmginfo:SetDamageType(DMG_VEHICLE) --Bullet damage
			tdmginfo:SetAttacker(attacker) --First player found gets credit
			tdmginfo:SetInflictor(attacker)
			local effectdata = EffectData()
			effectdata:SetStart( target:GetPos() ) // not sure if we need a start and origin (endpoint) for this effect, but whatever
			effectdata:SetOrigin( target:GetPos()+Vector(0,0,100) )
			effectdata:SetScale( 1 )
			util.Effect( "Explosion", effectdata )
			target.CarDisabled = true
			target:Fire("lock", "", 0)
			target.CarLocked = true
			timer.Simple(180, function()
				target:SetHealth(50)
				target.CarDisabled = false
			end)
			if IsValid(target:GetDriver()) then	
				target:GetDriver():ExitVehicle()
				target:GetDriver():TakeDamageInfo(tdmginfo)
			end			
			if IsValid(target.Passenger) and IsValid(target.Passenger:GetDriver()) then
				target.Passenger:GetDriver():ExitVehicle()
				target.Passenger:GetDriver():TakeDamageInfo(tdmginfo)
			end
			if IsValid(target.Passenger2) and IsValid(target.Passenger2:GetDriver()) then
				target.Passenger2:GetDriver():ExitVehicle()
				target.Passenger2:GetDriver():TakeDamageInfo(tdmginfo)
			end
			if IsValid(target.Passenger3) and IsValid(target.Passenger3:GetDriver()) then
				target.Passenger3:GetDriver():ExitVehicle()
				target.Passenger3:GetDriver():TakeDamageInfo(tdmginfo)
			end	
		end
	end
end
hook.Add("EntityTakeDamage", "CarDamage", CarDamage)





