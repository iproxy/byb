ENT.Type            = "anim"
DEFINE_BASECLASS("base_rpentity")
ENT.PrintName       = "Becki's storage box"
ENT.Author          = "Becki, Lexi"
ENT.Spawnable       = false
ENT.AdminSpawnable  = false
ENT.DisableDuplicator = true

function ENT:SetupDataTables()
    self:DTVar("Int", 0, "numprinters");
end
