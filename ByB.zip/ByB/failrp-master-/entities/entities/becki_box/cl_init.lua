include("shared.lua")


function ENT:DrawInfo()
    self:DrawText("Becki's Funbox\nPrinters: " .. self.dt.numprinters);
end
