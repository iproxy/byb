--[[
	Becki's storage box
	For printer carrying after raids
	'n shit
--]]

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

--[[
Given that the previous confirmation system didn't work, no one expects it to exist.
Therefore, I haven't included it.
-Lex
ENT.Confirmed = false;
ENT.ConfirmTimer = 0;
--]]
ENT.UnboxTimer = 0;
ENT.Unboxing   = false;
ENT.HP = 50
ENT.MaxPrinters = 4;

function ENT:Initialize()
	self:SetModel("models/props_phx/oildrum001_explosive.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self.ShareGravgun = true

	local phys = self:GetPhysicsObject();
    if (not phys:IsValid()) then
        self:Remove();
        error("Invalid physics object for Becki's Box!");
    end
    phys:Wake();

    self.Printers = {};
end

function ENT:Use(ply)
    if (not (ply:IsValid() and ply:IsPlayer())) then
        return;
    elseif (self.Unboxing or #self.Printers == 0) then
        return;
    end
    self.Unboxing   = true;
    self.UnboxTimer = CurTime() + 1;
end

function ENT:Die(dmginfo)
    if #self.Printers == 0 then self:Remove() return end
    self.Unboxing   = true;
    self.UnboxTimer = CurTime() + 1;
end

function ENT:Think()
    if (not self.Unboxing) then
        return;
    end

    -- Sparx
    self:Spark();

    -- Timer
    if (self.UnboxTimer > CurTime()) then
        return;
    end

    -- Dump the printers
    local spawnpos = self:GetPos();
    local up = self:GetUp();
    local ang = self:GetAngles();
    local printers = self.Printers;

    -- Make sure we don't factor in any collisions
    self:Remove();

    spawnpos = spawnpos + up * 10;

    for _, ent in pairs(printers) do
        -- You never know, it might have been removed by something else.
        if (ent:IsValid()) then
            -- Turn it back on
            ent:Enable();

            -- Make it look like the printers were stacked in us
            ent:SetPos(spawnpos);
            ent:SetAngles(ang);

            -- Go up a bit
            spawnpos = spawnpos + up * 10;
        end
    end
end

function ENT:Touch(printer)
    if (not (printer:IsValid() and printer.IsMoneyPrinter)) then
        return;
    elseif (#self.Printers >= self.MaxPrinters) then
        return;
    elseif (printer.Burning) then
        return;
    end
    for _, ent in pairs(self.Printers) do
        if (ent == printer) then
            return;
        end
    end
    table.insert(self.Printers, printer);
    -- Turn the printer off while it's being transported
    printer:Disable();
    -- Update for the client
    self.dt.numprinters = #self.Printers
 end
