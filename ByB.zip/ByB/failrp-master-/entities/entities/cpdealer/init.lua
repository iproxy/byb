
AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

function ENT:Initialize( ) 
 
	self:SetModel( "models/Combine_Soldier.mdl" ) 
	self:SetHullType( HULL_HUMAN ) 
	self:SetHullSizeNormal( )
	self:SetNPCState( NPC_STATE_NONE )
	self:SetSolid( SOLID_BBOX ) 
	self:CapabilitiesAdd( CAP_ANIMATEDFACE )
	self:SetUseType( SIMPLE_USE )
	self:DropToFloor()
	self:Give("weapon_ar2")

	self:SetMaxYawSpeed( 90 )
 
end

function ENT:AcceptInput( Name, Activator, Caller )	
	if Name == "Use" and Caller:IsPlayer() and (Caller:IsCP() or Caller.DarkRPVars.PoliceDeputy or Caller.DarkRPVars.AssMayor) and Caller:Team() ~= TEAM_ADMIN then
		umsg.Start("CPMenu", Caller) 
		umsg.End()
	else
	Caller:SendLua("LocalPlayer():EmitSound('npc/metropolice/vo/movealong3.wav')")
	Caller:ChatPrint("Move along.")	
	end
end

function ENT:Think()
    CPDPos = self.Entity:GetPos()
end


-- IF SOME ONE FROM BYB IS LOOKING AT THIS I KNOW THERE IS ALOT OF IF'S AND I KNOW I COULD MAKE IT SMALLER BUT HAY IT WORKS AND I KNOW ITS ALL OVER THE PLAYS BUT NO PlAYER IS GOING TO LOOK HERE :D
-- And if you are asking Why is there returns there just beouce the loop the function ran more then once
-- Madness

function Buy(ply,command,args)
 if CPDPos:Distance(ply:GetPos()) < 80 then

	if ply:IsPlayer() and (ply:IsCP() or ply.DarkRPVars.PoliceDeputy or ply.DarkRPVars.AssMayor) and ply:Team() ~= TEAM_ADMIN then

	for k,v in pairs(CPDealer) do
	 		if v.Menu == 3 then
			if ply:CanAfford(v.Cost) == true then
				GAMEMODE:Notify(ply, 1, 7, "You have bought a " .. v.Name .. " for $" .. v.Cost)
				ply:AddMoney(-v.Cost)
				ply:SetHealth(100)
				local max = ply:GetClassArmor();
                if (max < 100) then
                max = 100;
                end
                ply:SetArmor(max)
			end
			return
		end
	if v.Weapon == args[1] then

	if v.Menu == 2 then
	
	if ply:CanAfford(v.Cost) == true then
	
	if IsValid(ply:GetWeapon(v.Weapon)) then


	GAMEMODE:Notify(ply, 1, 7, "You have bought a " .. v.Name .. " for $" .. v.Cost)
	
	ply:AddMoney(-v.Cost)
	ply:GiveAmmo(1000,"pistol")
	
	return
	
	else
	
	ply:Give(v.Weapon)
	ply:GiveAmmo(1000,"pistol")
	
	ply:AddMoney(-v.Cost)
	
	GAMEMODE:Notify(ply, 1, 7, "You have bought a " .. v.Name .. " for $" .. v.Cost)
	
	return
	
	end
	
	
	else
	
	GAMEMODE:Notify(ply, 1, 7, "You can't Afford this Item")
	
	return
	
	end
	
	else
	
	-- End of menu 2 
	
	if IsValid(ply:GetWeapon(v.Weapon)) then
	
	GAMEMODE:Notify(ply, 1, 7, "You already have this weapon")
    return
	
	else
	
	if ply:CanAfford(v.Cost) == true then 
	
	ply:Give(v.Weapon)
	ply:GiveAmmo(1000,"pistol")
	
	ply:AddMoney(-v.Cost)
	
	GAMEMODE:Notify(ply, 1, 7, "You have bought a " .. v.Name .. " for $" .. v.Cost)
    return
	
	else
	
	GAMEMODE:Notify(ply, 1, 7, "You can't Afford this weapon")
	
							end
						end
					end
				end
			end
		end
	end
end
concommand.Add("BCPDealer",Buy)
local pos
if (RP1) then
    pos = Vector(-1679,223,-195)
    ang = Angle(5.597975,-0.684257,0)
elseif (RP3) then
    pos = Vector(-3262,440,237)
    ang = Angle(0,0,0)
elseif (RP5) then
    pos = Vector(-1736,7,-160)
    ang = Angle(2.969968,88.452492,0)
elseif (RP4) then
    pos = Vector(-2084,212,100)
    ang = Angle(6.203965,0.965943,0)
elseif (RP6) then
	pos = Vector(3965,-439,264)
	ang = Angle(0,0,0)
else
    pos = Vector(0,0,0)
    ang = Angle(0,0,0)
end

if (not (RP7)) then
	timer.Simple(60, function()
		local cp = ents.Create("cpdealer")
		cp:SetPos(pos)
		cp:SetAngles(ang)
		cp:Spawn()
	end)
end