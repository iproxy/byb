
ENT.PrintName		= "CP Dealer"
ENT.Author			= "Madness"
ENT.Information		= "A dealer who sells to cps only!"
ENT.Category		= "Fun + Games"

ENT.Base = "base_ai" 
ENT.Type = "ai" 
ENT.AutomaticFrameAdvance = true 

ENT.Spawnable			= False
ENT.AdminSpawnable		= False
 
function ENT:SetAutomaticFrameAdvance( bUsingAnim )
	self.AutomaticFrameAdvance = bUsingAnim
end