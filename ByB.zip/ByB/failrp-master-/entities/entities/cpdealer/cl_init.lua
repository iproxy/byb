
include('shared.lua')

ENT.RenderGroup 		= RENDERGROUP_TRANSLUCENT


/*---------------------------------------------------------
   Name: Initialize
---------------------------------------------------------*/
function ENT:Initialize()

end

/*---------------------------------------------------------
   Name: DrawPre
---------------------------------------------------------*/
function ENT:Draw()

	
	
	self.Entity:DrawModel()
end


function CPDMenu()

local SheetItemTwo
local SheetItemOne
local PropertySheet
local DermaList
local DFrame1
local DButton1
local DLabel2
local DLabel1
local SpawnIcon1
local DPanel2
local DPanel1
local Weapons

local MDermaList
local MDButton1
local MDLabel2
local MDLabel1
local MSpawnIcon1
local MDPanel2
local MDPanel1
local MWeapons

--surface.CreateFont("TargetID", 30, 400, true, true, "BTargetID")
surface.CreateFont("BTargetID", {
    font   = "TargetID";
    size   = 34;
    weight = 400;
})

DFrame1 = vgui.Create('DFrame')
DFrame1:SetSize(477, 356)
DFrame1:SetPos((ScrW() / 2) - 235,(ScrH() / 2) - 200)
DFrame1:SetTitle('CP Dealer')
DFrame1:SetSizable(false)
DFrame1:SetDeleteOnClose(false)
DFrame1:SetSkin("DarkRP") -- Coletrain sucks
DFrame1:MakePopup()

PropertySheet = vgui.Create( "DPropertySheet")
PropertySheet:SetParent( DFrame1 )
PropertySheet:SetPos(4, 25)
PropertySheet:SetSize(468, 325)

 -- Start of weapons tab

Weapons = vgui.Create( "DPanel", PropertySheet )
Weapons:SetSize( PropertySheet:GetWide(), PropertySheet:GetTall() )
Weapons.Paint = function()
	surface.SetDrawColor( 0, 0, 0, 0 )
	surface.DrawRect( 0, 0, PropertySheet:GetWide(), PropertySheet:GetTall() )
end

DermaList = vgui.Create( "DPanelList", Weapons )
DermaList:SetPos( 0,1 )
DermaList:SetSize( 458, 293 )
DermaList:SetSpacing( 5 ) 
DermaList:EnableHorizontal( false )
DermaList:EnableVerticalScrollbar( true )



for k,v in pairs(CPDealer) do

if v.Menu == 1 then

DPanel1 = vgui.Create('DPanel')
DPanel1:SetSize(458, 74)
DPanel1:SetPos(0, 0)

DermaList:AddItem( DPanel1 )

DButton1 = vgui.Create('DButton',DPanel1)
DButton1:SetSize(70, 25)
DButton1:SetPos(367, 44)
DButton1:SetText('Buy')
DButton1.DoClick = function() DFrame1:Close() RunConsoleCommand("BCPDealer",v.Weapon) end

DLabel2 = vgui.Create('DLabel',DPanel1)
DLabel2:SetPos(85, 46)
DLabel2:SetText('$' .. v.Cost)
DLabel2:SetFont("TargetID")
DLabel2:SizeToContents()

DLabel1 = vgui.Create('DLabel',DPanel1)
DLabel1:SetPos(85, 9)
DLabel1:SetText(v.Name)
DLabel1:SetFont("TargetID")
DLabel1:SizeToContents()

DPanel2 = vgui.Create('DPanelList',DPanel1)
DPanel2:SetSize(67, 67)
DPanel2:SetPos(7, 4)

SpawnIcon1 = vgui.Create('SpawnIcon',DPanel1)
SpawnIcon1:SetPos(9, 6)
SpawnIcon1:SetModel(v.model)
SpawnIcon1:SetToolTip(v.Name)
	end
end
-- End of weapons


-- Start of Miscellaneous tab
Miscellaneous = vgui.Create( "DPanel", PropertySheet )
Miscellaneous:SetSize( PropertySheet:GetWide(), PropertySheet:GetTall() )
Miscellaneous.Paint = function()
	surface.SetDrawColor( 0, 0, 0, 0 )
	surface.DrawRect( 0, 0, PropertySheet:GetWide(), PropertySheet:GetTall() )
end
 
MDermaList = vgui.Create( "DPanelList", Miscellaneous )
MDermaList:SetPos( 0,1 )
MDermaList:SetSize( 458, 293 )
MDermaList:SetSpacing( 5 ) 
MDermaList:EnableHorizontal( false )
MDermaList:EnableVerticalScrollbar( true )

for k,v in pairs(CPDealer) do

if v.Menu ==  3 then

MDPanel1 = vgui.Create('DPanel')
MDPanel1:SetSize(458, 74)
MDPanel1:SetPos(0, 0)

MDermaList:AddItem( MDPanel1 )

MDButton1 = vgui.Create('DButton',MDPanel1)
MDButton1:SetSize(70, 25)
MDButton1:SetPos(367, 44)
MDButton1:SetText('Buy')
MDButton1.DoClick = function() DFrame1:Close() RunConsoleCommand("BCPDealer",v.Weapon) end

MDLabel2 = vgui.Create('DLabel',MDPanel1)
MDLabel2:SetPos(85, 46)
MDLabel2:SetText('$' .. v.Cost)
MDLabel2:SetFont("TargetID")
MDLabel2:SizeToContents()

MDLabel1 = vgui.Create('DLabel',MDPanel1)
MDLabel1:SetPos(85, 9)
MDLabel1:SetText(v.Name)
MDLabel1:SetFont("TargetID")
MDLabel1:SizeToContents()

MDPanel2 = vgui.Create('DPanelList',MDPanel1)
MDPanel2:SetSize(67, 67)
MDPanel2:SetPos(7, 4)

MSpawnIcon1 = vgui.Create('SpawnIcon',MDPanel1)
MSpawnIcon1:SetPos(9, 6)
MSpawnIcon1:SetModel(v.model)
MSpawnIcon1:SetToolTip(v.Name)

end

end
-- End of Miscellaneous tab

PropertySheet:AddSheet( "Weapons", Weapons, "gui/silkicons/shield", false, false, "Weapons" )

PropertySheet:AddSheet( "Miscellaneous", Miscellaneous, "gui/silkicons/bomb", false, false, "Miscellaneous" ) 


end
usermessage.Hook("CPMenu",CPDMenu)