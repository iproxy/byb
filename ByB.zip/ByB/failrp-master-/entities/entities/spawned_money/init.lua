AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/props/cs_assault/money.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()
	self.nodupe = true
	self.ShareGravgun = true

	phys:Wake()
end


function ENT:Use(activator,caller)
	if self.USED then return else self.USED = true end -- sigh
	self:Remove()
	local amount = self:Getamount()

	GAMEMODE:Notify(activator, 0, 4, "You have found " .. CUR .. (self:Getamount() or 0) .. "!")
	DB.Log(activator:Nick().. " (" .. activator:SteamID() .. ") picked up "..CUR .. tostring(amount) .." (Entity: " .. self:EntIndex() .. ")")
	activator.stats.PMONEYFOUND = activator.stats.PMONEYFOUND + amount
	activator:AddMoney(amount or 0)
end

function DarkRPCreateMoneyBag(pos, amount)
	local moneybag = ents.Create("spawned_money")
	moneybag:SetPos(pos)
	moneybag:Setamount(amount)
	moneybag:Spawn()
	moneybag:Activate()
	return moneybag
end

function ENT:Touch(ent)
	--if ent:GetClass( ) ~= "spawned_money" or self.hasMerged or ent.hasMerged then return end

	--ent.hasMerged = true

	--ent:Remove()
	--self:Setamount(self:Getamount() + ent:Getamount())
end