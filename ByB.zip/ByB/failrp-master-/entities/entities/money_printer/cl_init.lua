include("shared.lua")
function draw.DrawTextShadowed(text, font, x, y, colour, xalign)
	draw.DrawText(text, font, x + 1, y + 1, Color(0, 0, 0, 200), xalign);
	draw.DrawText(text, font, x,     y,     colour,              xalign);
end

function ENT:Draw()
    self:DrawModel();
end

function ENT:DrawInfo()
    local info = MoneyPrinters[self.dt.Edition] or {Prefix = "Broken"};
	local text = info.Prefix .. " Money Printer\n"
              .. "$" .. tostring(self.dt.Money)
	--local pos  = self:LocalToWorld(self:OBBCenter()):ToScreen();
    local pos = self:GetPos();
    pos.z     = pos.z + 8;
    pos       = pos:ToScreen();
	draw.DrawTextShadowed(text, "TargetID", pos.x, pos.y, Color(255, 255, 255, 200), 1)
end

