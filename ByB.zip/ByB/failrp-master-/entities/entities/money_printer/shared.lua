ENT.Type = "anim"
DEFINE_BASECLASS("base_rpentity")
ENT.PrintName = "Money Printer"
ENT.Author = "Render Case and philxyz, Tobba, Lexi"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.IsMoneyPrinter = true;
ENT.DisableDuplicator = true

function ENT:SetupDataTables()
	self:DTVar("Int", 0, "Money")
    self:DTVar("Int", 1, "Edition");
end
