-- RRPX Money Printer reworked for DarkRP by philxyz - Gnorma printer test subject purple
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

-- Serverside only health
ENT.HP = 100;

ENT.LastThink = 0;

ENT.PrintTimer = 0;
ENT.AntiGrabSpam = 0;

ENT.Burning = false;
ENT.BurnTime = 0;

ENT.PrinterInfo = nil;

ENT.Disabled = false;

ENT.ExplodeRadiusMin = 200;
ENT.ExplodeRadiusMax = 400;

--[[
    GM.MoneyPrinters = {
        {
            Prefix = "Fake"
            Price = 0;
            Colour = Color(255,255,255);
            PrintMin = 0;
            PrintMax = 0;
            CanExplode = false;
        }
    }
--]]

function ENT:Initialize()
	self:SetModel("models/props_lab/reciever01a.mdl");
	self:PhysicsInit(SOLID_VPHYSICS);
	self:SetMoveType(MOVETYPE_VPHYSICS);
	self:SetSolid(SOLID_VPHYSICS);

	local phys = self:GetPhysicsObject();
    if (not phys:IsValid()) then
        self:Remove();
        error("Invalid physics object for money printer!");
    end
    phys:Wake();

    self.LastThink = CurTime();

    -- Backup
    if (not self.PrinterInfo) then
        self:SetPrinterType(1);
    end	
end

function ENT:SetPrinterType(id)
    self.dt.Edition = id;
    self.PrinterInfo = MoneyPrinters[id];
    if (not self.PrinterInfo) then
        self:Remove();
        error("Invalid printer type '" .. tostring(id) .. "'!", 2);
    end
    self:SetColor(self.PrinterInfo.Colour);
    if self.PrinterInfo.Material then
        self:SetMaterial(self.PrinterInfo.Material)
    end	
	if self.PrinterInfo.ExplodeRadiusMin then
		self.ExplodeRadiusMin = self.PrinterInfo.ExplodeRadiusMin
	end
	if self.PrinterInfo.ExplodeRadiusMax then
		self.ExplodeRadiusMax = self.PrinterInfo.ExplodeRadiusMax
	end
end

function ENT:Think()
    if (self.Disabled) then
        return;
    end
    local ctime = CurTime();
    local dt = ctime - self.LastThink;
    self.LastThink = ctime;
    if (self.Burning) then
        return self:BurnThink(dt);
    else
        return self:PrintThink(dt);
    end
end

function ENT:BurnThink(dt)
    self.BurnTime = self.BurnTime - dt;
    if (self.BurnTime > 0) then
        return;
    end
    -- Explosion time
    --[[
    local pos = self:GetPos()
    for _, ent in pairs(ents.FindInSphere(pos, math.random(self.ExplodeRadiusMin, self.ExplodeRadiusMax))) do
        -- Kill everyone nearby
        if (ent:IsPlayer()) then
            ent:Kill();
        -- Set the base alight
        --elseif (ent:GetClass() == "prop_physics") then
        --    ent:Ignite(math.random(5, 22), 0);
        end
    end
    --]]
    -- Radius based death is now catered to by util.BlastDamage()!
	
	self:Explode(300, math.random(self.ExplodeRadiusMin, self.ExplodeRadiusMax));
end

function ENT:PrintThink(dt)
    self.PrintTimer = self.PrintTimer + dt;
    if (self.PrintTimer < 1) then
        return;
    end
    self.PrintTimer = 0;
    -- See if it's fireball time
    if (self.PrinterInfo.CanExplode and math.random(1, 7875) == 3) then
        self:BurstIntoFlames();
    end
    -- Money time
    self.dt.Money = self.dt.Money + math.random(self.PrinterInfo.PrintMin, self.PrinterInfo.PrintMax);
    -- Check if the printer has been forgotton about
    if (self.dt.Money >= 50000) then
        self:Explode();
        return;
    end
end

function ENT:GetPrinterName()
    if (self.PrinterInfo.Prefix == "") then
        return "Money Printer";
    else
        return self.PrinterInfo.Prefix .. " Money Printer";
    end
end

function ENT:CanTakeDamage(dmginfo)
    return not (self.Burning or self.Disabled or dmginfo:GetInflictor():GetClass() == self.ClassName);
end

function ENT:Die(dmginfo)
    if (self.Burning) then
        return;
    end
    local ply = dmginfo:GetAttacker();
	
	if (ply:IsValid() and ply:IsPlayer()) then
	
		local nick = ply:Nick() or ply:Name() or "(NA)"
	
		if ply:IsCP() and ply:SteamID() ~= self.STID then
			local money = math.floor(self.PrinterInfo.Price / 2)
			ply:AddMoney(money);
			GAMEMODE:Notify(ply, 0, 5, "You recieved $" .. money .. " for destroying that " .. self:GetPrinterName() .. "!")
			DB.Log(nick.. " (" .. ply:SteamID() .. ") destroyed printer EntID " .. self:EntIndex() .." as Job: " .. team.GetName(ply:Team()) .. " and recieved $" .. tostring(money))
		else
			if ply:IsCP() and ply:SteamID() == self.STID then
				GAMEMODE:Notify(ply, 1, 5, "This printer was spawned by you. Don't job abuse please.")
			end
			DB.Log(nick.. " (" .. ply:SteamID() .. ") destroyed printer EntID " .. self:EntIndex() .." as Job: " .. team.GetName(ply:Team()))
		end
    
	end
	
    local num = math.random(1, 10);
    if (num < 3) then
        self:BurstIntoFlames();
    else
        self:Explode();
    end
	
	ply.stats.PPRINTERDESTROYER = ply.stats.PPRINTERDESTROYER and (ply.stats.PPRINTERDESTROYER + 1) or 1
end

function ENT:BurstIntoFlames()
    self.Burning = true;
    self.BurnTime = math.random(8, 18);
    self:Ignite(self.BurnTime + 0.1, 0)
    self.DamageOff = true;
end

function ENT:ExtinguishFlames()
    self.Burning = false;
    self.BurnTime = 0;
    self:Extinguish();
    self.DamageOff = nil;
end

function ENT:Use(ply)
	ply.AntiGrabSpam = ply.AntiGrabSpam or 0
    if (not (ply:IsValid() and ply:IsPlayer())) then
        return;
    elseif (ply:GetMoveType() == MOVETYPE_NOCLIP) then
        ply:Kill();
        return;
    elseif (self.dt.money == 0) then
        return;
    elseif (self.Disabled) then
        return;
    end
	

    local ctime = CurTime();
    if (ply.AntiGrabSpam > ctime) then -- Changed it to be a player cooldown instead of a printer one, this is due to the mysql spam whores - Pantho
        return;
    end
    ply.AntiGrabSpam = ctime + 1;
	ply.stats.PMONEYPRINTED = ply.stats.PMONEYPRINTED + self.dt.Money
    self:GiveMoney(ply, self.dt.Money);
    self.dt.Money = 0;
end

function ENT:GiveMoney(ply, amt)
    ply:AddMoney(amt);
    GAMEMODE:Notify(ply, 1, 4, "You took $"..tostring(amt).." from the printer")
	--if ply:IsAdmin() then
		DB.Log(ply:Nick().. " (" .. ply:SteamID() .. ") took $" .. tostring(amt).. " from printer EntID " .. self:EntIndex() .." as Job: ".. team.GetName(ply:Team()))
	--end
end

local invisibubble = Color(0, 0, 0, 0);
function ENT:Disable()
    self.Disabled = true;
    self:SetColor(invisibubble);
    self:SetRenderMode(RENDERMODE_NONE);
    local phys = self:GetPhysicsObject();
    --phys:SetVelocity(Vector(0,0,0));
    --phys:Sleep();
    phys:EnableMotion(false);
    self:SetMoveType(MOVETYPE_NONE);
    self:SetSolid(SOLID_NONE);
end

function ENT:Enable()
    self.Disabled = false;
    self:SetColor(self.PrinterInfo.Colour);
    if self.PrinterInfo.Material then
        self:SetMaterial(self.PrinterInfo.Material)
    end
    self:SetRenderMode(RENDERMODE_NORMAL);
    self:SetMoveType(MOVETYPE_VPHYSICS);
	self:SetSolid(SOLID_VPHYSICS);
    local phys = self:GetPhysicsObject();
    phys:EnableMotion(true);
    phys:Wake();
end
