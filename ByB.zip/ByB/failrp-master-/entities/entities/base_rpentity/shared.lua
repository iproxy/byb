-- Basic basetype to derive all DarkRP entities from for convenience
ENT.Type            = "anim"
--DEFINE_BASECLASS("base_gmodentity")
DEFINE_BASECLASS("base_anim")
ENT.PrintName       = "DarkRP Base Entity"
ENT.Author          = "Lexi"
ENT.Spawnable       = false
ENT.AdminSpawnable  = false
-- NOTE: This does *NOT* inherit!
ENT.DisableDuplicator = true

AddCSLuaFile("shared.lua")

function ENT:GetCenter()
    return self:LocalToWorld(self:OBBCenter());
end

if (SERVER) then
    function ENT:Initialize()
        self:PhysicsInit(SOLID_VPHYSICS)
        self:SetMoveType(MOVETYPE_VPHYSICS)
        self:SetSolid(SOLID_VPHYSICS)
        self:SetUseType(SIMPLE_USE);
        local phys = self:GetPhysicsObject()
        if (not phys:IsValid()) then
            local mdl = self:GetModel()
            self:Remove();
            error("Entity of type " .. self.ClassName .. " created without a physobj! (Model: " .. mdl .. ")");
        end
        phys:Wake();
    end

    function ENT:Spark()
        -- Stop reinventing the goddamn wheel
        local effectdata = EffectData();
        effectdata:SetOrigin(self:GetCenter());
        effectdata:SetMagnitude(1);
        effectdata:SetScale(1);
        effectdata:SetRadius(2);
        util.Effect("Sparks", effectdata);
    end

    ENT.AntiGrabSpam = 0;
    function ENT:CheckGrabSpam()
        local ctime = CurTime();
        if (self.AntiGrabSpam > ctime) then
            return false;
        end
        self.AntiGrabSpam = ctime + 1;
        return true;
    end

    function ENT:OnTakeDamage(dmginfo)
        if (not self.HP or self.CanTakeDamage and not self:CanTakeDamage(dmginfo)) then
            return;
        end
        self.HP = self.HP - dmginfo:GetDamage();
        if (self.HP > 0) then
            return;
        end
        if (self.Die) then
            self:Die(dmginfo);
        else
            self:Explode();
        end
    end

    -- Everyone loves explosions!
    function ENT:Explode(damage, radius)
        local centre = self:GetCenter();
        local effectdata = EffectData();
        effectdata:SetStart(centre);
        effectdata:SetOrigin(centre);
        effectdata:SetScale(1);
        util.Effect("Explosion", effectdata);
        damage = damage or 10;
        radius = radius or 50;
        print("Exploding with " .. damage .. " damage at a radius of " .. radius .. "!");
        util.BlastDamage(self, self, centre, radius, damage);
        self:Remove();
    end
else
    function ENT:Draw()
        self:DrawModel();
    end
    function ENT:DrawText(text, pos)
        pos = pos or self:GetCenter():ToScreen();
        draw.DrawTextShadowed(text, "TargetID", pos.x, pos.y, Color(255, 255, 255, 200), 1)
    end
end
