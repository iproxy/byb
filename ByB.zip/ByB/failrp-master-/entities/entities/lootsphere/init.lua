AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( "shared.lua" )

function ENT:SpawnFunction( ply, tr )

	if ( !tr.Hit ) then return end

	local SpawnPos = tr.HitPos + tr.HitNormal * 16
	local Ent = ents.Create( "lightsphere" )
	Ent:SetPos( SpawnPos )
	Ent:Spawn()
	Ent:Activate()
	return Ent

end

function ENT:Initialize() 

	self.Entity:SetModel( "models/Combine_Helicopter/helicopter_bomb01.mdl" )
	self.Entity:PhysicsInit( SOLID_VPHYSICS )
	
	local phys = self.Entity:GetPhysicsObject()
	if ( phys:IsValid() ) then
		phys:Wake()
	end
	
	self:SetDTFloat( 0, math.Rand( 0.5, 1.3 ) )
	self:SetDTFloat( 1, math.Rand( 0.3, 1.2 ) )
	
end

function ENT:SetupDataTables()

	self:DTVar( "Float", 0, "RotationSeed1" )
	self:DTVar( "Float", 1, "RotationSeed2" )

end

function ENT:Think()
end

-- Drop chanceexplained: 
-- 1 = 99% chance to drop
-- 20 = 80%  chance to be dropped
-- etc etc, higher number increases rarity
local ItemTable = {}
ItemTable['zrpheal'] = {
Model = 'models/items/healthkit.mdl',
Name = 'Health Regeneration',
Class = 'zrp_heal',
Value = '150',
DropChance = 1,
DBName = 'zrpheal',
Type = 'consumable'
}
ItemTable['mdcdeagle'] = {
Model = 'models/weapons/w_pist_deagle.mdl',
Name = 'Mad Cow Deagle',
Class = 'weapon_mad_deagle',
Value = '800',
DropChance = 25,
DBName = 'mcdeagle',
Type = 'weapon'
}
ItemTable['mdcmac10'] = {
Model = 'models/weapons/w_smg_mac10.mdl',
Name = 'Mad cow Mac10',
Class = 'weapon_mad_mac10',
Value = '500',
DropChance = 50,
DBName = 'mdcmac10',
Type = 'weapon'
}
ItemTable['mdcawp'] = {
Model = 'models/weapons/w_snip_awp.mdl',
Name = 'Mad cow AWP',
Class = 'weapon_mad_awp',
Value = '1500',
DropChance = 90,
DBName = 'mdcawp',
Type = 'weapon'
}

local function LootLottery(ply)
	local item = ItemTable[math.random(#ItemTable)]
	for i=1,100,1 do
		if item.DropChance <= math.random(1,100) then
			table.insert(ply.ZRPInv,item)
			GAMEMODE:Notify(ply,1,7, "Item: "..item.Name.." has been added to your inventory.")
			break;
		else
			item = ItemTable[math.random(#ItemTable)]
		end
	end
end
		

function ENT:Use(ply)	
	--local weapons = {"weapon_mad_sako", "weapon_mad_m60", "weapon_mad_kriss", "weapon_mad_zak47"}	
	--local item = weapons[math.random(#weapons)]
	if #ply.ZRPInv >= 20 then
		ply:ChatPrint("Sorry but you're to many items in your inventory, try recycling some")
		return
	end
	LootLottery(ply)
	self:Remove()
end

function ENT:OnTakeDamage( dmginfo )
	self.Entity:TakePhysicsDamage( dmginfo )
end