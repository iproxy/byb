
AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")
util.AddNetworkString("LawyerMenu")
util.AddNetworkString("Letthisdudeout")
local pause = CurTime()
local detainees
local pos
local ang

function ENT:Initialize()
    self:SetModel("models/humans/group02/male_06.mdl")
    self:SetHullType(HULL_HUMAN)
    self:SetHullSizeNormal()
    self:SetNPCState(NPC_STATE_NONE)
    self:SetSolid(SOLID_BBOX)
    self:CapabilitiesAdd(CAP_ANIMATEDFACE, CAP_TURN_HEAD)
    self:DropToFloor()
    self:SetMaxYawSpeed(90)
end
function ENT:Think()
end
function ENT:AcceptInput(Name, Activator, Caller)
    if pause <= CurTime() then 
        detainees = {}
        detainees.time = {}
        detainees.ply = {}
        for k,ply in pairs(player.GetAll()) do 
            if ply:isArrested() then
                table.insert(detainees.time,ply.ArrestedTime)
                table.insert(detainees.ply,ply)
            end
        end
        if Name == "Use" and Caller:IsPlayer() then
            net.Start("LawyerMenu")
            net.WriteTable(detainees)
            net.Send(Caller)
        end
        pause = CurTime() + 1
    end
end

net.Receive("Letthisdudeout", function(len,ply)
    local criminal = net.ReadEntity()
    if not IsValid(criminal) then return end
    if criminal == ply then ply:ChatPrint("Sir, you cannot possibly bail yourself out.") return end
    if ply:GetPos():Distance(pos) > 250 then return end
    if ply:IsCP() then
			GAMEMODE:NotifyAll(0, 4, ply:Nick() .. " has talked with " .. criminal:Nick() .. "'s lawyer, and they've been released.")
			criminal:Unarrest()
			--ply.LastBailed = CurTime()
			DB.Log(ply:Nick().. " (" .. ply:SteamID() .. ") unarrested " .. criminal:Nick().. " (" .. criminal:SteamID() .. ") with the lawyer NPC.")
	else
	
		if criminal.LastBailed then
			if CurTime() - criminal.LastBailed < 1200 then
				ply:ChatPrint([[Sorry this prisoner was bailed recently, you may not be bailed too often.
If he isn't released before then he may be bailed in ]] .. math.floor(1200 - (CurTime() - criminal.LastBailed)) .. " seconds")
				return
			end
		end
		
		if ply.LastBailedAPlayer then
			if CurTime() - ply.LastBailedAPlayer < 300 then
				ply:ChatPrint("You've recently bailed a prisoner, you may not bail anyone for another " .. math.floor(300 - (CurTime() - ply.LastBailedAPlayer)) .. " seconds")
				return
			end
		end
				
		local amount = math.floor(30*(criminal.ArrestedTime-CurTime()))
		if ply:CanAfford(amount) then
			criminal:Unarrest()
			timer.Simple(2,function() 
				criminal:StripWeapons()			
				criminal:Give("keys")
				criminal:Give("weapon_physcannon")
				criminal:Give("gmod_tool")
				criminal:Give("weapon_physgun")
				criminal:Give("pocket")
				if criminal:IsSupporter() then
					criminal:Give("weapon_fists")
				end				
				-- Switch to prefered weapon if they have it
				local cl_defaultweapon = criminal:GetInfo("cl_defaultweapon")
				if criminal:HasWeapon(cl_defaultweapon) then
					criminal:SelectWeapon(cl_defaultweapon)
				end
			end)
			criminal.LastBailed = CurTime()
			ply.LastBailedAPlayer = CurTime()
			DB.Log(ply:Nick().. " (" .. ply:SteamID() .. ") paid " .. amount .. " to bail " .. criminal:Nick().. " (" .. criminal:SteamID() .. ")")
			GAMEMODE:Notify(ply,0,4,"You have paid $"..amount.." to bail some poor fool.")
			GAMEMODE:Notify(criminal,0,4,"" .. ply:Nick() .. " paid $" .. amount .. " to bail you. Be sure to thank them!")
			ply.stats.PLAWYER = ply.stats.PLAWYER + amount
			ply:AddMoney(-amount)
		end
		
	end
end)

if (RP4) then
    pos = Vector(-1841,200,100)
    ang = Angle(1.847717,-1.926564,0)
elseif (RP5) then
    pos = Vector(-1436,169,-195)
    ang = Angle(-1.649771,1.164145,0)
elseif (RP3) then
    pos = Vector(-2511,121,85)
    ang = Angle(0,90,0)
elseif (RP1) then
    pos = Vector(-1436,200,-195)
    ang = Angle(1.684008,0.504113,0)
elseif (RP6) then
	pos = Vector(3887,-915,136)
	ang = Angle(0.989,176,0)
end

if (not (RP7)) then
	timer.Simple(10, function() local law = ents.Create[[lawyer]]
		law:SetPos(pos)
		law:SetAngles(ang)
		law:Spawn()
	end)
end