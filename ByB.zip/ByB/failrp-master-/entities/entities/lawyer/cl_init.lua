include("shared.lua")
function ENT:Initialize()

end

function ENT:Draw()
    self.Entity:DrawModel()
end
    
local function LawyerMenu()
    detainees = net.ReadTable() or {}
    local LawMenu = vgui.Create("DFrame") or LawMenu
    LawMenu:SetPos(ScrW()/2-220,ScrH()/5) --(SrH()/2,ScrW/2)
    LawMenu:SetSize(325,560)
    LawMenu:SetTitle("Lawyer Bail Menu")
    LawMenu:SetVisible(true)
    LawMenu:SetDraggable(true)
    LawMenu:ShowCloseButton(true)
    LawMenu:MakePopup()
    
    local ListPanel = vgui.Create("DPanel", LawMenu)
    ListPanel:SetPos(12.5,25)
    ListPanel:SetSize(300,470)
    ListPanel.Paint = function()
        surface.SetDrawColor(50,50,50,255)
        surface.DrawRect(0,0,ListPanel:GetWide(),ListPanel:GetTall())
    end
    
    local DetaineeList = vgui.Create("DListView")
    DetaineeList:SetParent(ListPanel)
    DetaineeList:SetPos(5,5)
    DetaineeList:SetSize(290,390)
    DetaineeList:AddColumn("Name")
    DetaineeList:AddColumn("Job")
    DetaineeList:AddColumn("Bail Price")
    for k,v in pairs(detainees.ply) do        
        if IsValid(detainees.ply[k]) then
			
			
            DetaineeList:AddLine(detainees.ply[k].DarkRPVars.rpname,detainees.ply[k].DarkRPVars.job, ( LocalPlayer():IsCP() and "N/A" or math.floor(30*(detainees.time[k]-CurTime())) ) )
        end
    end
    
    local PriceLabel = vgui.Create("DLabel")
    PriceLabel:SetParent(ListPanel)
    PriceLabel:SetPos(-5,420)
	
	if LocalPlayer():IsCP() then
	
	PriceLabel:SetText[[
    As you're law enforcement, it costs you nothing to bail a
    player. Their bail limitation time is also not reset.]]
	
	else
	
    PriceLabel:SetText[[
    To bail out a criminal you will have to pay a pricey fee.
    The cost is $30 per second of remaining jail time.]]
	
	end
	
    PriceLabel:SizeToContents()
    
    local BailIt = vgui.Create("DButton")
    BailIt:SetParent(LawMenu)
    BailIt:SetPos(112.5,500)
    BailIt:SetSize(100,50)
    BailIt:SetText("Bail Selected")
    --BailIt:DoClick = function()     
    function BailIt.DoClick()
        local tar = detainees.ply[DetaineeList:GetSelectedLine()]
        if not IsValid(tar) then return end
        net.Start("Letthisdudeout")
        net.WriteEntity(tar)
        net.SendToServer()
        LawMenu:Close()
    end
end
net.Receive("LawyerMenu", LawyerMenu)
