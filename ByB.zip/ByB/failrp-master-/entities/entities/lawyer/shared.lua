ENT.PrintName = "Justice Lawyer"
ENT.Author = "Pantho"
ENT.Information = "Simple lawyer"
ENT.Category = "Fun + Games"

ENT.Base = "base_ai"
ENT.Type = "ai"
ENT.Spawnable = true
ENT.AdminSpawnable = true
