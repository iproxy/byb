-- CarShop stuff
CS = {}
local ChosenCol
--local CarShop
local backdrop
local StoredCars
BodySettings = {}
local action
local ModelBack
local Width = (ScrW() - 799) / 2

function IntroScreen()
	CS.CarShop = vgui.Create("DFrame") or CS.CarShop
	CS.ModelScreen = vgui.Create("DFrame")
	ModelDerma = CS.ModelScreen
	ModelBack = vgui.Create("DImageButton",ModelDerma)
	CarShop = CS.CarShop
	CarShop:SetSize(400,600)
	--CarShop:Center()
	CarShop:SetPos(Width+50,(ScrH()-600)/2)
	CarShop:SetTitle("If you can see this im guessing the material didn't load")
	CarShop:SetVisible(true)
	CarShop:SetDraggable(true)
	CarShop:ShowCloseButton(true)
	CarShop:MakePopup()
	backdrop = vgui.Create("DImageButton",CarShop)
	backdrop.Exit = vgui.Create("DImageButton",CarShop)
	backdrop.Finish = vgui.Create("DImageButton",CarShop)
	backdrop.CarSelect = vgui.Create("DImageButton",CarShop)
	backdrop.BuyHorns = vgui.Create("DImageButton",CarShop)
	backdrop.BuySkins = vgui.Create("DImageButton",CarShop)
	--backdrop.BuyParts = vgui.Create("DImageButton",CarShop)
	backdrop.CarModel = vgui.Create("DModelPanel",ModelBack)
	backdrop.CarModel:SetVisible(true)
	backdrop.CarModel:SetSize(280,280)
	backdrop.CarModel:Center()
	backdrop.BuyTitle = vgui.Create("DLabel",CarShop)
	backdrop.BuyTitle:SetVisible(true)
	backdrop.BuyTitle:SetText("I've decided half way through making this, that it needs remaking again.\nHowever I've no time atm so decided to release this functional version.\n\nFor now all sounds/skins/parts are available to all.\nWhen completed(end of august) it will be a functional shop.\nWhere you buy upgrades for your cars. Modifications should still save\n")
	backdrop.BuyTitle:SetPos(25,50)
	backdrop.BuyTitle:SizeToContents()
	backdrop.TransCost = vgui.Create("DLabel",CarShop)
	backdrop.TransCost:SetVisible(false)
	backdrop.SelectCar = vgui.Create("DListView",backdrop)
	backdrop.SelectCar:SetVisible(false)
	--backdrop.ItemModel = vgui.Create("DModelPanel",CS.ModelScreen)
	--backdrop.ItemModel:SetVisible(false)
	--backdrop.ItemType = vgui.Create("DListView",backdrop)
	--backdrop.ItemType:SetVisible(false)
	backdrop.ItemSpecs = vgui.Create("DListView",backdrop)
	backdrop.ItemSpecs:SetVisible(false)
	backdrop.CarSkin = vgui.Create("DListView",backdrop)
	backdrop.CarSkin:SetVisible(false)
	backdrop.Horns = vgui.Create("DListView",backdrop)
	backdrop.Horns:SetMultiSelect(false)
	backdrop.Horns:SetVisible(false)
	backdrop.CarColor = vgui.Create("DColorMixer",backdrop)
	backdrop.CarColor:SetVisible(false)
	backdrop.ItemSpecs:AddColumn("Items")
	backdrop.ItemSpecs:AddColumn("ID")
	backdrop.ItemSpecs:AddColumn("Item Number")
	backdrop.CarSkin:AddColumn("Skin")
	backdrop.CarSkin:AddColumn("ID")
	backdrop.Horns:AddColumn("Sound")
	backdrop:SetImage("byb/background.png")
	backdrop:SetSize(400,600)
	ModelDerma:SetSize(300,300)
	ModelDerma:SetPos(Width+475,(ScrH()-300)/2)
	ModelBack:SetImage("byb/background.png")
	ModelBack:SetSize(300,300)
	
	backdrop.Exit:SetImage("byb/close.png")
	backdrop.Exit:SetSize(68,18)
	backdrop.Exit:SetPos(317,557)
	backdrop.Exit.DoClick = function()
		ModelDerma:Close()
		CarShop:Close()
	end
	backdrop.Finish:SetImage("byb/transcom.png")
	backdrop.Finish:SetSize(136,21)
	backdrop.Finish:SetPos(50,557)
	backdrop.Finish.DoClick = function()
		CS:FinishEdit()
		--CarShop:Close()
	end
	backdrop.CarSelect:SetImage("byb/buttonthree.png")
	backdrop.CarSelect:SetSize(180,89)
	backdrop.CarSelect:SetPos(100,150)
	backdrop.CarSelect.DoClick = function()
		backdrop.CarSelect:SetVisible(false)
		backdrop.BuyHorns:SetVisible(false)
		backdrop.BuySkins:SetVisible(false)
		--backdrop.BuyParts:SetVisible(false)
		backdrop.SelectCar:SetVisible(true)
		action = "editcars"
		backdrop.SelectCar:Clear()
		for k,v in pairs(StoredCars) do
			backdrop.SelectCar:AddLine(v.Name, "Yes")
		end
	end
	backdrop.BuyHorns:SetImage("byb/buttonone.png")
	backdrop.BuyHorns:SetSize(180,89)
	backdrop.BuyHorns:SetPos(100,250)
	backdrop.BuyHorns.DoClick = function()
		--backdrop.CarSelect:SetVisible(false)
		--backdrop.BuyHorns:SetVisible(false)
		--backdrop.BuySkins:SetVisible(false)
		--backdrop.BuyParts:SetVisible(false)
		--backdrop.SelectCar:SetVisible(true)		
		--backdrop.BuyTitle:SetVisible(false)
		--action = "buyhorns"
		--backdrop.SelectCar:Clear()
		--for k,v in pairs(StoredCars) do
		--	if v.BodyGroups and v.BodyGroups["Horns"] then
		--		backdrop.SelectCar:AddLine(v.Name, "Yes")
		--	end
		--end
		LocalPlayer():ChatPrint("Only top button works")
	end
	backdrop.BuySkins:SetImage("byb/buttontwo.png")
	backdrop.BuySkins:SetSize(180,89)
	backdrop.BuySkins:SetPos(100,350)
	backdrop.BuySkins.DoClick = function()
		--backdrop.CarSelect:SetVisible(false)
		--backdrop.BuyHorns:SetVisible(false)
		--backdrop.BuySkins:SetVisible(false)
		--backdrop.BuyParts:SetVisible(false)
		--backdrop.SelectCar:SetVisible(true)
		--action = "buyskins"
		--backdrop.SelectCar:Clear()
		--for k,v in pairs(StoredCars) do
		--	if v.BodyGroups and v.BodyGroups["Skins"] then
		--		backdrop.SelectCar:AddLine(v.Name, "Yes")
		--	end
		--end
		LocalPlayer():ChatPrint("Only top button works")
	end
	--[[
	backdrop.BuyParts:SetImage("byb/button3.png")
	backdrop.BuyParts:SetSize(180,89)
	backdrop.BuyParts:SetPos(240,289)
	backdrop.BuyParts.DoClick = function()
		backdrop.CarSelect:SetVisible(false)
		backdrop.BuyHorns:SetVisible(false)
		backdrop.BuySkins:SetVisible(false)
		backdrop.BuyParts:SetVisible(false)
		backdrop.SelectCar:SetVisible(true)
		action = "buyparts"
		backdrop.SelectCar:Clear()
		for k,v in pairs(StoredCars) do
			if v.BodyGroups then
				backdrop.SelectCar:AddLine(v.Name, "Yes")
			end
		end
	end
	]]--
	backdrop.SelectCar:SetSize(350,450)
	backdrop.SelectCar:Center()
	backdrop.SelectCar:AddColumn("Car")
	backdrop.SelectCar:AddColumn("BodyGroups")
	backdrop.SelectCar.OnClickLine = function(parent,line)
		backdrop.SelectCar:SetVisible(false)
		if action=="editcars" then
			CS:EditCar(line:GetValue(1))
		elseif action =="buyhorns" then
			CS:BuyHorns(line:GetValue(1))
		elseif action =="buyskins" then
			CS:BuySkins(line:GetValue(1))
		--elseif action =="buyparts" then
		--	CS:BuyParts(line:GetValue(1))
		else
			-- errr da fudge? Just close the screen and cry
			LocalPlayer():ChatPrint("I broked myself, report this to pantho: backdrop.SelectCar.OnClickLine")
			CarShop:Close()
			ModelDerma:Close()
		end
	end
end
concommand.Add("carcustomisor",IntroScreen)

function CS:EditCar(car)
	backdrop.ItemSpecs:SetVisible(true)
	backdrop.ItemSpecs:SetSize(200,200) 
	backdrop.ItemSpecs:SetPos(100,55)
	backdrop.CarColor:SetVisible(true)
	backdrop.CarColor:SetAlphaBar(true)
	backdrop.CarColor:SetPalette(false)
	backdrop.CarColor:SetSize(200,80)
	backdrop.CarColor:SetPos(100,260)
	backdrop.Horns:SetVisible(true)
	backdrop.Horns:SetSize(200,100)
	backdrop.Horns:SetPos(100,345)
	backdrop.CarSkin:SetVisible(true)
	backdrop.CarSkin:Clear()
	backdrop.CarSkin:SetPos(100,450)
	backdrop.CarSkin:SetSize(200,100)
	--backdrop.ItemType:SetSize(75,385)
	--backdrop.ItemType:SetPos(50,65)
	for k,v in pairs(cars) do
		if v.Name == car then
			car = v
			break;
		end
	end
	BodySettings["Car"] = car.Vehiclescript
	--backdrop.ItemType:SetVisible(true)
	backdrop.CarModel:SetSize(280,280)
	backdrop.CarModel:Center()
	backdrop.CarModel:SetCamPos( Vector( 150, 150, 80 ) )
	backdrop.CarModel:SetLookAt( Vector( 0, 0, 0 ) )
	backdrop.CarModel:SetModel(car.Model)
	CS:DetailCar(car)
	backdrop.CarModel.DoClick = function()
		CarShop:Close()
		ModelDerma:Close()		
	end
	--[[backdrop.ItemType:AddColumn("Item Type")
	backdrop.ItemType:AddLine("Car Parts")
	backdrop.ItemType:AddLine("Car Skin")
	backdrop.ItemType:AddLine("Paint Car")
	backdrop.ItemType:AddLine("Car Horn")
	backdrop.ItemType:AlphaTo(225,0,0)
	backdrop.ItemType.OnClickLine = function(parent, line)
		CS:SecondList(car,line:GetValue(1))
	end
	]]--
	backdrop.BuyTitle:SetVisible(true)
	backdrop.BuyTitle:SetText("WARNING!\nTO STOP FLOODING\nOF THIS THERE\nIS A DEFAULT\nCHARGE OF\n$50,000 PER USE\nEACH TIME YOU\nCLICK COMPLETE\nYOU LOSE 50K!\n\n\nMoo's fluffy.\n\n\nNot all cars\nHave bodygroups.\nCredits for bodygroups\ngoto TDMCars and\nthe respective\nmodellers, mainly\nTheDanishMaster. ")
	backdrop.BuyTitle:SizeToContents()
	backdrop.BuyTitle:SetPos(5,150)
	CS:SecondList(car,"")
end

function CS:BuyParts(car)
	for k,v in pairs(cars) do
		if v.Name == car then
			car = v
			break;
		end
	end
	BodySettings["Car"] = car.Vehiclescript
	--backdrop.CarModel:SetSize(185,300)
	--backdrop.CarModel:SetPos(50,420)
	backdrop.CarModel:SetCamPos( Vector( 150, 150, 80 ) )
	backdrop.CarModel:SetLookAt( Vector( 0, 0, 0 ) )
	backdrop.CarModel:SetModel(car.Model)
	CS:DetailCar(car)
	backdrop.CarModel.DoClick = function()
		CarShop:Close()
		ModelDerma:Close()
	end
	backdrop.BuyTitle:SetVisible(true)
	backdrop.BuyTitle:SetPos(50,100)
	--backdrop.BuyTitle:SetText("You have selected the " .. car.Name .. ".\n\nOn this screen you may purchase access to this vehicles bodygroups.\nWe do not create most of these models nor do we have access to what bodygroups each car can equip.\nSome of the vehicles have a lot of parts, some have none. the available parts this car can equip\nare listed below. You may click these parts to view an example of how the car will look with these \nparts applied.\n\nPlease note all unlock purchases are final with NO refunds or chances to resell.")
	backdrop.BuyTitle:SetText("All items are currently free, enjoy.")
	backdrop.BuyTitle:SizeToContents()
	backdrop.TransCost:SetVisible(true)
	backdrop.TransCost:SetPos(50,600)
	--backdrop.TransCost:SetText("This purchase will unlock access to all custom parts this vehicle has.\nThe transaction cost is: 5 cakes, click finish transaction to complete.")
	backdrop.TransCost:SizeToContents()
	backdrop.ItemSpecs:SetVisible(true)
	backdrop.ItemSpecs:Clear()
	backdrop.Horns:Clear()
	backdrop.CarSkin:Clear()
	for k,v in pairs(car.BodyGroups["Parts"]) do 
		local I = 0
		while I < car.BodyGroups["Count"][v] do
			backdrop.ItemSpecs:AddLine(k,v,I)
			if I == 0 then BodySettings[v]=I end
			I = I + 1
		end
	end
	backdrop.ItemSpecs:AlphaTo(255,0,0)
	backdrop.ItemSpecs.OnClickLine = function(parent,line)
		backdrop.ItemSpecs:ClearSelection()
		backdrop.ItemSpecs:SelectItem(line)
		backdrop.CarModel.Entity:SetBodygroup(line:GetValue(2),line:GetValue(3))
		--BodySettings[line:GetValue(2)]=line:GetValue(3)
	end
end

function CS:BuySkins(car)
	for k,v in pairs(cars) do
		if v.Name == car then
			car = v
			break;
		end
	end
	local OwnedCar 
	for k,v in pairs(carsStored) do
		if v.vehicleScript == car.Vehiclescript then
			OwnedCar = v
		end
	end	
	BodySettings["Car"] = car.Vehiclescript
	backdrop.CarModel:SetCamPos( Vector( 150, 150, 80 ) )
	backdrop.CarModel:SetLookAt( Vector( 0, 0, 0 ) )
	backdrop.CarModel:SetModel(car.Model)
	CS:DetailCar(car)
	backdrop.CarModel.DoClick = function()
		CarShop:Close()
		ModelDerma:Close()
	end
	backdrop.BuyTitle:SetVisible(true)
	backdrop.BuyTitle:SetPos(50,100)
	--backdrop.BuyTitle:SetText("You have selected the " .. car.Name .. ".\n\nOn this screen you may purchase access to this vehicles skins.\n We have a few skins added for a few cars only.\nWe will add more nice skins as we find them. Feel free to recomend them on the forums, if you recomend a nice one we might add it and you'll get it free as a thanks.\nAll skins need apply to TDMCars/TheDanishMaster models.")
	backdrop.BuyTitle:SetText("All items are currently free, enjoy.")
	backdrop.BuyTitle:SizeToContents()
	backdrop.TransCost:SetVisible(true)
	backdrop.TransCost:SetPos(50,600)
	--backdrop.TransCost:SetText("You are purchasing the ability to use this skin for this car only in the car modification screen.\nThe transaction cost is: 5 cakes, click finish transaction to complete.")
	backdrop.TransCost:SizeToContents()
	backdrop.CarSkin:Clear()
	backdrop.CarSkin:SetVisible(true)
	backdrop.CarSkin:SetSize(200,150) 
	backdrop.CarSkin:SetPos(50,265)
	if car.BodyGroups["Skins"] then
		car.ownedskins = "3*13*14*15*16"
		local args = string.Explode("*",car.ownedskins)
		for k,v in pairs(car.BodyGroups["Skins"]) do
			for _,n in pairs(args) do
				if tonumber(n) == tonumber(v) then k = "PURCHASED" end
			end
			backdrop.CarSkin:AddLine(k,v)
		end
	else
		backdrop.CarSkin:AddLine("No Skins",1)
	end
	backdrop.CarSkin:AlphaTo(255,0,0)
	backdrop.CarSkin.OnClickLine = function(parent,line)
		backdrop.CarSkin:ClearSelection()
		backdrop.CarSkin:SelectItem(line)
		backdrop.CarModel.Entity:SetSkin(line:GetValue(2))
		--BodySettings[line:GetValue(2)]=line:GetValue(3)
	end
end

function CS:BuyHorns(car)
	for k,v in pairs(cars) do
		if v.Name == car then
			car = v
			break;
		end
	end
	BodySettings["Car"] = car.Vehiclescript
	--backdrop.CarModel:SetSize(185,300)
	--backdrop.CarModel:SetPos(50,420)
	backdrop.CarModel:SetCamPos( Vector( 150, 150, 80 ) )
	backdrop.CarModel:SetLookAt( Vector( 0, 0, 0 ) )
	backdrop.CarModel:SetModel(car.Model)
	CS:DetailCar(car)
	backdrop.CarModel.DoClick = function()
		CarShop:Close()
		ModelDerma:Close()
	end
	backdrop.BuyTitle:SetVisible(true)
	backdrop.BuyTitle:SetPos(50,100)
	--backdrop.BuyTitle:SetText("You have selected the " .. car.Name .. ".\n\nOn this screen you may purchase access to this vehicles sounds.\nNot all vehicles have custom horn sounds atm.")
	backdrop.BuyTitle:SetText("All items are currently free, enjoy.")
	backdrop.BuyTitle:SizeToContents()
	backdrop.TransCost:SetVisible(true)
	backdrop.TransCost:SetPos(50,600)
	--backdrop.TransCost:SetText("You are purchasing the ability to use this sound for this car only in the car modification screen.\nThe transaction cost is: 5 cakes, click finish transaction to complete.")
	backdrop.TransCost:SizeToContents()
	backdrop.Horns:SetVisible(true)
	backdrop.Horns:SetSize(200,150)
	backdrop.Horns:SetPos(50,265)
	backdrop.Horns.OnClickLine = function(parent,line)		
		backdrop.Horns:ClearSelection()
		backdrop.Horns:SelectItem(line)
		sound.Play( line:GetValue(1), LocalPlayer():GetPos())
	end
	for k,v in pairs(car.BodyGroups["Horns"]) do
		backdrop.Horns:AddLine(v)
	end
end

function CS:SecondList(car,item)
	backdrop.ItemSpecs:Clear()
	backdrop.Horns:Clear()
	backdrop.CarSkin:Clear()
	if car.BodyGroups and car.BodyGroups["Parts"] then
		for k,v in pairs(car.BodyGroups["Parts"]) do 
			local I = 0
			while I < car.BodyGroups["Count"][v] do
				backdrop.ItemSpecs:AddLine(k,v,I)
				if I == 0 then BodySettings[v]=I end
				I = I + 1
			end
		end
	end
	backdrop.ItemSpecs:AlphaTo(255,0,0)
	backdrop.ItemSpecs.OnClickLine = function(parent,line)
		backdrop.ItemSpecs:ClearSelection()
		backdrop.ItemSpecs:SelectItem(line)
		backdrop.CarModel.Entity:SetBodygroup(line:GetValue(2),line:GetValue(3))
		BodySettings[line:GetValue(2)]=line:GetValue(3)
	end
	backdrop.CarColor.ValueChanged = function()
		ChosenCol = backdrop.CarColor:GetColor()
		backdrop.CarModel:SetColor(Color(ChosenCol.r,ChosenCol.g,ChosenCol.b))
	end
	if car.BodyGroups and car.BodyGroups["Skins"] then
		for k,v in pairs(car.BodyGroups["Skins"]) do
			backdrop.CarSkin:AddLine(k,v)
		end
	else
		backdrop.CarSkin:AddLine("No Skins",1)
	end
	backdrop.CarSkin.OnClickLine = function(parent,line)
		backdrop.CarSkin:ClearSelection()
		backdrop.CarSkin:SelectItem(line)
		backdrop.CarModel.Entity:SetSkin(line:GetValue(2))
		BodySettings["Skin"] = line:GetValue(2)
	end
	if car.BodyGroups and car.BodyGroups["Horns"] then
		for k,v in pairs(car.BodyGroups["Horns"]) do
			backdrop.Horns:AddLine(v)
		end
	else
		backdrop.Horns:AddLine("vehicles/bhorn.wav")
	end
	backdrop.Horns.OnClickLine = function(parent,line)
		backdrop.Horns:ClearSelection()
		backdrop.Horns:SelectItem(line)
		sound.Play( line:GetValue(1), LocalPlayer():GetPos())
		BodySettings["Horn"] = line:GetValue(1)
	end
end

function CS:FinishEdit()
	BodySettings["Col"] = ChosenCol
	PrintTable(BodySettings)
	net.Start("CarShopEdit")
	net.WriteTable(BodySettings)
	net.SendToServer()
	PrintTable(BodySettings)
	ModelDerma:Close()
	CarShop:Close()
end

function CS:DetailCar(car)
	for k,v in pairs(carsStored) do
		if v.vehicleScript == car.Vehiclescript then
			local args = string.Explode("*",v.bodygroups or "")
			local id;
			for k,v in pairs(args) do
				id = string.Explode(",",v)
				if tonumber(id[2]) then
					backdrop.CarModel.Entity:SetBodygroup(tonumber(id[1]),tonumber(id[2]))
				end
			end
			--local col = util.JSONToTable(v.color)
			backdrop.CarModel.Entity:SetSkin(tonumber(v.skin) or 0)
		end
	end		
end	
net.Receive("VhcModCarList", function ()
	carsStored = net.ReadTable()	
	StoredCars = {}
	for k,getCar in pairs(carsStored) do
		for _,k in pairs(cars) do
			if(string.lower(string.Trim(k.Vehiclescript)) == string.lower(string.Trim(getCar.vehicleScript))) then
				table.insert(StoredCars,k)
			end
		end
	end
	IntroScreen()
end)
