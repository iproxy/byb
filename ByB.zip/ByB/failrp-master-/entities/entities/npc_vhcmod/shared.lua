 ENT.Base = "base_ai"
 ENT.Type = "ai"
   
 ENT.PrintName = "VHC Modification"
 ENT.Author = "Pantho"
 ENT.Contact = "bybservers.co.uk" //fill in these if you want it to be in the spawn menu
 ENT.Purpose = "car mod"
 ENT.Instructions = "eat pie"
 ENT.Information	= "k"  
 ENT.Category		= "Macendo"
  
 ENT.AutomaticFrameAdvance = true
   
 ENT.Spawnable = true
 ENT.AdminSpawnable = true
 