AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include('shared.lua')

function ENT:Initialize()
   self:SetModel("models/vortigaunt.mdl")
   
   self:SetHullType( HULL_HUMAN )
   self:SetHullSizeNormal();
   self:SetSolid( SOLID_BBOX )
   self:SetMoveType( MOVETYPE_STEP )
   self:CapabilitiesAdd(  CAP_ANIMATEDFACE )
   self:SetMaxYawSpeed( 5000 )
  
   //Sets the entity values
  -- self:SetHealth(self.StartHealth)
   self:SetEnemy(NULL)
   self:SetSchedule(SCHED_IDLE_STAND)
   position = self:GetPos()
   self:SetUseType(SIMPLE_USE)
   
end

util.AddNetworkString('VhcModCarList');
local function UpdateLists(ply)
	DB.Query("SELECT * FROM storedcars WHERE steamid = '"..ply:SteamID().."';", function(data) 
		ply.SCars = data
		if data then
			net.Start("VhcModCarList")
			net.WriteTable(data)
			net.Send(ply)
		end
	end)
	--[[
	timer.Simple(3, function()
		local result = ply.SCars
		local hasCars = false
		local vehicleScripts = {}
		if (result) then
			for id,row in pairs(result) do
				hasCars = true
				table.insert(vehicleScripts, row['vehicleScript'])
			end
		end
		if(hasCars) then
			net.Start("VhcModCarList")
			net.WriteTable(vehicleScripts)
			net.Send(ply)
		end
	end)
	]]--
end

function ENT:AcceptInput( input, activator, caller )
	activator.UseCD = activator.UseCD or CurTime()
	if input == "Use" && activator:IsPlayer() then
		if activator.UseCD > CurTime() then activator:ChatPrint("Wait 5 seconds to prevent network spam please.") return end
		activator.UseCD = CurTime() + 5
		activator:ChatPrint("Obtaining updated vehicle list, may a few seconds")
		UpdateLists(activator) 
	end
end
   
function ENT:OnTakeDamage(dmg)
	self:SetHealth(100000)
end


function ENT:Think()
end

util.AddNetworkString('CarShopEdit');
net.Receive("CarShopEdit", function (len,ply)
	if not IsValid(ply) then return end
	if not ply:CanAfford(50000) then 
		ply:ChatPrint("Sorry but your transaction was cancelled due to lack of funds")
		return
	end
	if ply:IsSupporter() then 
		ply:AddMoney(-10000)
		GAMEMODE:Notify(ply, 1,7, "You have paid $10,000 to modify your car")
	else
		ply:AddMoney(-50000)
		GAMEMODE:Notify(ply, 1,7, "You have paid $50,000 to modify your car")
	end
	local BodySettings = net.ReadTable()
	local BGroups = ""
	local CarCol
	local CarHorn
	local CarSkin
	local car = BodySettings["Car"]
	for k,v in pairs(BodySettings) do
		if type(k) == "number" then
			BGroups = BGroups .. "*"..tostring(k)..","..tostring(v)
		end
	end
	print(car)
	CarCol = BodySettings["Col"]
	CarHorn = BodySettings["Horn"]
	CarSkin = BodySettings["Skin"]
	
	local col = util.TableToJSON(CarCol)
	DB.Query("UPDATE storedcars SET bodygroups="..sql.SQLStr(BGroups)..", color="..sql.SQLStr(col).." ,horn="..sql.SQLStr(CarHorn)..", skin="..sql.SQLStr(CarSkin).." WHERE steamid="..sql.SQLStr(ply:SteamID()).." AND vehicleScript="..sql.SQLStr(car)..";")
	--ApplyBodyGroups(Entity(500),BGroups,CarCol,CarHon,CarSkin)
end)

function ApplyBodyGroups(ent,groups,col,Horn,Skin)
	local args = string.Explode("*",groups)
	local id
	for k,v in pairs(args) do
		id = string.Explode(",",v)
		if tonumber(id[2]) then
			ent:SetBodygroup(tonumber(id[1]),tonumber(id[2]))
		end
	end
	ent:SetColor(col)
end

resource.AddFile("materials/byb/buttonone.png")
resource.AddFile("materials/byb/buttontwo.png")
resource.AddFile("materials/byb/buttonthree.png")
resource.AddFile("materials/byb/transcom.png")