AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
	self:SetModel("models/items/healthkit.mdl")
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	local phys = self:GetPhysicsObject()
	phys:Wake()
end

function ENT:OnTakeDamage(dmg)
end

function ENT:Use(activator,caller)
	if not IsValid(activator) then return end
		
	timer.Create("ZRPHealTimer",1,60, function()
		if ply:Health() <= 99 then
			ply:SetHealth(ply:Health() + 1)
		end
	end)
	--Draw some health effect?
	self:Remove()
end
