include( "shared.lua" )
 
ENT.RenderGroup = RENDERGROUP_TRANSLUCENT
 
local GlowMat = Material( "sprites/light_glow02_add" )
 
local CurTime = CurTime
local DynamicLight = DynamicLight
local Angle = Angle
local SetMaterial = render.SetMaterial
local DrawSprite = render.DrawSprite
local AngleForward = FindMetaTable("Angle").Forward
 
local function Color( r, g, b, a )
    return { r = r, g = g, b = b, a = a }
end
 
local r, g, b, a, gray
local function CacheColor( ent, color )
    if (
        ent.LastColor and
        color.r == ent.LastColor.r and
        color.g == ent.LastColor.g and
        color.b == ent.LastColor.b and
        color.a == ent.LastColor.a
    ) then return end
     
    ent.LastColor = color
    ent.ColorCache = {}
    
    r, g, b, a = color.r, color.g, color.b, color.a
    r = r / 255
    g = g / 255
    b = b / 255
    a = a / 255
     
    for i = 1, 180 do
        gray = i / 150 * 255
        ent.ColorCache[i] = Color( gray * r, gray * g, gray * b, gray * a )
    end
end
 
function ENT:Initialize()
    self.Seed1 = math.Rand( 0.5, 1.3 )
    self.Seed2 = math.Rand( 0.3, 1.2 )
     
    CacheColor( self, self:GetColor() )
end
 
local Seed1, Seed2, MyPos, Index, Ang, Size, Forward, Pos
function ENT:Draw()
 
    self:DrawShadow( false )
     
    -- Only cache the color if entity's color has changed
    CacheColor( self, self:GetColor() )
     
    SetMaterial( GlowMat )
     
    Seed1 = self.Seed1
    Seed2 = self.Seed2
    MyPos = self:GetPos()
    Index = self:EntIndex()
 
    for i = 1, 180 do
        Ang = ( Index + 1337 + CurTime() ) * i //Yeah, random math makes awesome shit!
        Size = ( 155 - i ) / 6 
        Forward = AngleForward( Angle( Ang * Seed1, Ang * Seed2, 0 ) )
        Pos = MyPos + Forward * i * 0.09
         
        DrawSprite( Pos, Size, Size, self.ColorCache[i] )
    end
end
 
local R, G, B, A, DLight
function ENT:Think()
    R, G, B, A = self:GetColor().r,self:GetColor().g,self:GetColor().b,self:GetColor().a
     
    DLight = DynamicLight( self:EntIndex() )
    if ( DLight ) then
        DLight.Pos = self:GetPos()
        DLight.r = R
        DLight.g = G
        DLight.b = B
        DLight.Brightness = A / 255
        DLight.Size = 128
        DLight.Decay = 512
        DLight.DieTime = CurTime() + 1
    end
end