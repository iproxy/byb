ENT.Type 			= "anim"
ENT.Base 			= "base_anim"
ENT.PrintName		= "LightSphere"
ENT.Author			= "Dlaor"
ENT.Information		= ""

ENT.Spawnable			= true
ENT.AdminSpawnable		= true
