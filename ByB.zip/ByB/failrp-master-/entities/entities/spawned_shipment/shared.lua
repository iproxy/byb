ENT.Type            = "anim"
DEFINE_BASECLASS("base_rpentity")
ENT.PrintName       = "Shipment"
ENT.Author          = "philxyz, Lexi"
ENT.Spawnable       = false
ENT.AdminSpawnable  = false
ENT.DisableDuplicator = true

function ENT:SetupDataTables()
	self:DTVar("Int",0,"Contents");
	self:DTVar("Int",1,"Amount");
end

ENT.ShareGravgun = true
