include("shared.lua")

function ENT:DrawInfo()
    local shipid = self.dt.Contents;
    local text;
    if (shipid == 0) then
        text = "Empty Shipment";
    else
        local shipinfo = Shipments[shipid];
        if (shipinfo) then
            text = shipinfo.Name;
        else
            text = "???";
        end
    end
    local pos = self:GetCenter():ToScreen();
    local amount = self.dt.Amount;
    if (amount > 0) then
        pos.y = pos.y + 8;
        text = text .. "\n" .. amount .. " left";
    end
    self:DrawText(text, pos);
end
