-- ========================
-- =          Crate SENT by Mahalis
-- ========================

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

-- Make BaseClass available here
DEFINE_BASECLASS("base_rpentity")

ENT.HP = 100;

ENT.ShipmentInfo = nil;

ENT.SpawnOffset = Vector(0,0,35);


local pause = 0
function ENT:Initialize()
	self:SetModel("models/Items/item_item_crate.mdl")
    BaseClass.Initialize(self);
end

function ENT:Die(dmginfo)
	ActiveWepEnts = 0
    self:BreakApart(dmginfo);
	for k,v in pairs(ents.FindByClass[[spawned_weapon]]) do
		ActiveWepEnts = ActiveWepEnts + 1
	end
end

function ENT:SetContents(contents, override_amount, override_table)
    if (contents == 0) then
        -- Empty shipment
        self.dt.Contents  = 0;
        self.ShipmentInfo = nil;
        self.dt.Amount    = 0;
        return;
    end
    local ship = Shipments[contents] or override_table;
    if (not ship) then
        self:Remove();
        error("Invalid shipment contents '" .. tostring(contents) .. "'!", 2);
    end
    -- Store a read-only copy of the shipment info
    self.ShipmentInfo = setmetatable({}, {__index=ship});
    self.dt.Contents  = contents;
    self.dt.Amount    = override_amount or ship.Amount;
end

ActiveWepEnts = ActiveWepEnts or 0
function ENT:Use()
    if (not self.ShipmentInfo) then
        -- Empty shipments don't do anything!
        return
    elseif (not self:CheckGrabSpam()) then
        return;
    end
	if ActiveWepEnts > 100 then
		for k,v in pairs(ents.FindByClass[[spawned_weapons]]) do v:Remove() end
		local args = {Color(255,140,0),[[ Someone is attempting to spam spawned_weapons, server has removed all spawned_weapons to prevent crashing - apologies.]]}
		net.Start("ColorChatPrints")
		net.WriteTable(args)
		net.Broadcast()
	end
    self.Dispensing = true;
    self.DispenseTime = CurTime() + 1;
end
function ENT:CanTakeDamage(dmginfo)
	local atck = dmginfo:GetAttacker()
	if IsValid(atck) and atck:IsPlayer() then
		if ActiveWepEnts > 50 then return false end
		return self.dt.Amount <= 20;
	else
		return false
	end
end

function ENT:Think()
    if (not self.Dispensing) then
        return;
    end
    -- Visuals
    self:Spark();
    -- Timing
    if (self.DispenseTime > CurTime()) then
        return;
    end
    self.Dispensing = false;

    local ent = ents.Create("spawned_weapon");
    ent:SetPos(self:GetPos() + self.SpawnOffset);
    ent:SetContents(self.ShipmentInfo);
    ent:Spawn();
    local amt = self.dt.Amount - 1;
    if (amt <= 0) then
        self:Remove();
    end
    self.dt.Amount = amt;
end

function ENT:StartTouch(ent)
    if (not self.ShipmentInfo) then
        -- Empty shipment
        if (ent:GetClass() == "spawned_weapon") then
            self:Shipmentificate(ent);
        end
        return;
    end
    local class = ent:GetClass();
    if (class == "spawned_shipment") then
        self:MergeShipment(ent);
    elseif (class == "spawned_weapon") then
        self:AddWeapon(ent);
    elseif (class == self.ShipmentInfo.Class) then
        self:AddEntity(ent);
    end
end

function ENT:Shipmentificate(ent)
    if (self:CanTakeSpawnedWeapon(ent)) then
        self:SetContents(ent.SpawnInfo.ShipmentID, 1, ent.SpawnInfo);
        ent:Remove();
    end
end

function ENT:MergeShipment(ent)
    if (not ent.ShipmentInfo) then
        -- Don't merge with empty shipments
        return;
    elseif (self.dt.Contents ~= ent.dt.Contents) then
        -- Don't merge with shipments that aren't the same as us
        return;
    end
    -- Merge into the least-moving entity for convenience.
    local me = self:GetVelocity():LengthSqr() < ent:GetVelocity():LengthSqr();
    local one, two;
    if (me) then
        one = self;
        two = ent;
    else
        one = ent;
        two = self;
    end
    one.dt.Amount = one.dt.Amount + two.dt.Amount;
    -- Reset two to prevent anything else happening this frame.
    two.dt.Contents = 0;
    two.dt.Amount = 0;
    two.ShipmentInfo = nil;
    two:Remove();
end
function ENT:AddWeapon(ent)
    if (not self:CanTakeSpawnedWeapon(ent) or self.ShipmentInfo.ShipmentID ~= ent.SpawnInfo.ShipmentID) then
        return;
    end
    self.dt.Amount = self.dt.Amount + 1;
    -- Stop anything else happening this frame
    ent.SpawnTime = math.huge;
    ent:Remove();
end
function ENT:AddEntity(ent)
    if (ent:GetOwner() ~= NULL) then
        return;
    end
    ent:SetOwner(self);
    ent:Remove();
    self.dt.Amount = self.dt.Amount + 1;
end
function ENT:CanTakeSpawnedWeapon(ent)
    return ent.SpawnTime + 5 < CurTime();
end

function ENT:BreakApart(dmginfo)
    local amt = self.dt.Amount;
    if (amt > 0 and self.ShipmentInfo) then
        local pos = self:GetPos();
        for i = 1, amt do
            local ent = ents.Create("spawned_weapon");
            ent:SetPos(pos);
            ent:SetContents(self.ShipmentInfo);
            ent:Spawn();
            pos.z = pos.z + 5;
        end
    end
    -- Special effects
    local vec = self:GetVelocity();
    if (dmginfo) then
        vec = vec + dmginfo:GetDamageForce();
		local ply = dmginfo:GetAttacker();
		if ply:IsValid() then
			DB.Log(ply:Nick().. " (" .. ply:SteamID() .. ") destroyed shipment EntID " .. self:EntIndex());
		end
    end
    self:GibBreakClient(vec);
    self:Remove();
		
end
