ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Crossbow Ammo"
ENT.Author = "ByBServers"
DEFINE_BASECLASS("base_rpentity")
ENT.Spawnable = false
ENT.AdminSpawnable = false

function ENT:SetupDataTables()
	self:NetworkVar("Int",0,"amount")
end