AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

ENT.HP = 100;

function ENT:Initialize()
	self:SetModel("models/items/crossbowrounds.mdl")
    self:SetModelScale(2)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetMoveType(MOVETYPE_VPHYSICS)
	self:SetSolid(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)

	local phys = self:GetPhysicsObject()
    phys:SetDamping(0,1000)
	self.nodupe = true
	self.ShareGravgun = true

	phys:Wake()
    
    self:Setamount(4)
end


function ENT:Use(activator,caller)
	
    if not (IsValid(activator) or activator:IsPlayer()) then return end
    
    if activator:Team() ~= TEAM_AGENT then
        activator:ChatPrint("You are not a Secret Agent so have no need for this ammo")
        return
    end
    
    if self:GetPos():Distance(activator:GetPos()) > 200 then return end
    
    if activator:GetAmmoCount("XBowBolt") >= 4 then
        activator:ChatPrint("You crossbow is already full of rebar.")
        return
    end
    
    local amount = self:Getamount()
        
    amount = amount-1
        
    if amount < 1 then
        self:Remove()
    else
        self:Setamount(amount)
    end
    
    activator:GiveAmmo(1,"XBowBolt")
end

function ENT:StartTouch(ent)
	if ent:GetClass( ) ~= "xbow_ammo" then return end
    
    local me = self:GetVelocity():LengthSqr() < ent:GetVelocity():LengthSqr();
    local one, two;
    if (me) then
        one = self;
        two = ent;
    else
        one = ent;
        two = self;
    end
	
	one:Setamount(one:Getamount() + two:Getamount())
    two:Setamount(0)
    two:Remove()
end

function ENT:Die(dmginfo)

    self:Remove();
    
    local ply = dmginfo:GetAttacker();
    
	if (ply:IsValid() and ply:IsPlayer()) then
	
		local nick = ply:Nick() or ply:Name() or "(NA)"
	
		if ply:IsCP() and ply:SteamID() ~= self.STID then
			local money = 1000
			ply:AddMoney(money);
			GAMEMODE:Notify(ply, 0, 5, "You recieved $" .. money .. " for destroying the illegal crossbow ammo.")
			DB.Log(nick.. " (" .. ply:SteamID() .. ") destroyed xbowammo EntID " .. self:EntIndex() .." as Job: " .. team.GetName(ply:Team()) .. " and recieved $" .. tostring(money))
		else
			if ply:IsCP() and ply:SteamID() == self.STID then
				GAMEMODE:Notify(ply, 1, 5, "This crossbow ammo was spawned by you. Don't job abuse please.")
			end
			DB.Log(nick.. " (" .. ply:SteamID() .. ") destroyed xbowammo ammo EntID " .. self:EntIndex() .." as Job: " .. team.GetName(ply:Team()))
		end
    
	end
    
end