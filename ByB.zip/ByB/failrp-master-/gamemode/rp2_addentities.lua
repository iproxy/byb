Shipment "Desert eagle" {
    Model = "models/weapons/w_pist_deagle.mdl";
    Class = "weapon_mad_deagle";
    Price = 2200;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 250;
    Teams = {TEAM_GUN, TEAM_HITMAN, TEAM_BGUN};
};
Shipment "Glock" {
    Model = "models/weapons/w_pist_glock18.mdl";
    Class = "weapon_mad_glock";
    Price = 1400;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 160;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "USP" {
    Model = "models/weapons/w_pist_usp.mdl";
    Class = "weapon_mad_usp";
    Price = 1400;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 160;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "P228" {
    Model = "models/weapons/w_pist_p228.mdl";
    Class = "weapon_mad_p228";
    Price = 1500;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 170;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
--[[
Shipment "Knife" {
    Model = "models/weapons/w_knife_t.mdl";
    Class = "weapon_mad_knife";
    Price = 500;
    Amount = 5;
    AvailableSeperately = true;
    SeperatePrice = 100;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
]]--
Shipment "Elites" {
    Model = "models/weapons/w_pist_elite.mdl";
    Class = "weapon_mad_dual";
    Price = 2300;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 240;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "AK47" {
    Model = "models/weapons/w_rif_ak47.mdl";
    Class = "weapon_mad_ak47";
    Price = 3200;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 350;
    Teams = {TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "MP5" {
    Model = "models/weapons/w_smg_mp5.mdl";
    Class = "weapon_mad_mp5";
    Price = 2600;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 280;
    Teams = {TEAM_GUN, TEAM_CHIEF, TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "M4A1" {
    Model = "models/weapons/w_rif_m4a1.mdl";
    Class = "weapon_mad_m4";
    Price = 3550;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 370;
    Teams = {TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "Mac 10" {
    Model = "models/weapons/w_smg_mac10.mdl";
    Class = "weapon_mad_mac10";
    Price = 2000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 210;
    Teams = {TEAM_GUN, TEAM_BGUN};
}; 
Shipment "TMP" {
    Model = "models/weapons/w_smg_tmp.mdl";
    Class = "weapon_mad_tmp";
    Price = 2150;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 230;
    Teams = {TEAM_GUN, TEAM_BGUN};
}; 
Shipment "Spas Shotgun" {
    Model = "models/weapons/w_shot_xm1014.mdl";
    Class = "weapon_mad_spas";
    Price = 1850;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 190;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "AWP" {
    Model = "models/weapons/w_snip_awp.mdl";
    Class = "weapon_mad_awp";
    Price = 9000;
    Amount = 10;
    Teams = {TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "M3 Shotgun" {
    Model = "models/weapons/w_shot_m3super90.mdl";
    Class = "weapon_mad_m3";
    Price = 2100;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 230;
    Teams = {TEAM_GUN, TEAM_BGUN, TEAM_SWATCQB};
}; 
Shipment "Scout" {
    Model = "models/weapons/w_snip_scout.mdl";
    Class = "weapon_mad_scout";
    Price = 3900;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 400;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_SWATRECON};
}; 
Shipment "Flash grenade" {
    Model = "models/weapons/w_eq_flashbang.mdl";
    Class = "weapon_mad_flash";
    Price = 900;
    Amount = 3;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "P90" {
    Model = "models/weapons/w_smg_p90.mdl";
    Class = "weapon_mad_p90";
    Price = 2850;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 285;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
};
Shipment "Famas" {
    Model = "models/weapons/w_rif_famas.mdl";
    Class = "weapon_mad_famas";
    Price = 2950;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 295;
    Teams = {TEAM_HGUN, TEAM_BGUN};
};
Shipment "Galil" {
    Model = "models/weapons/w_rif_galil.mdl";
    Class = "weapon_mad_galil";
    Price = 3100;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 320;
    Teams = {TEAM_HGUN, TEAM_BGUN, TEAM_MERC};
};
Shipment "M249" {
    Model = "models/weapons/w_mach_m249para.mdl";
    Class = "weapon_mad_m249";
    Price = 4150;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 415;
    Teams = {TEAM_HGUN, TEAM_BGUN};
};
Shipment "UMP" {
    Model = "models/weapons/w_smg_ump45.mdl";
    Class = "weapon_mad_ump";
    Price = 2700;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 290;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
};
Shipment "SG552" {
    Model = "models/weapons/w_rif_sg552.mdl";
    Class = "weapon_mad_sg552";
    Price = 3350;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 335;
    Teams = {TEAM_HGUN, TEAM_BGUN};
};
Shipment "Alyx" {
    Model = "models/weapons/w_alyx_gun.mdl";
    Class = "weapon_mad_alyxgun";
    Price = 8000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1000;
    Teams = {TEAM_GUN, TEAM_CHIEF, TEAM_BGUN};
};
Shipment "Armor" {
    Model = "models/Items/BoxMRounds.mdl";
    Price = 1500;
    Amount = 5;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_MERC};
    function (ply)	
	if (ply:GetMoveType() == 6) then -- wire users now return true for IsPlayer, this is a quick fix - pantho.
		self:Remove()
		return false;
	end
        local max = ply:GetClassArmor();
        if (max < 100) then
            max = 100;
        end
        if (ply:Armor() >= max) then
            return false;
        end
        ply:SetArmor(max);
    end
};
Shipment ".357 Magnum" {
    Model = "models/weapons/w_357.mdl";
    Class = "weapon_mad_357";
    Price = 6000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 700;
    Teams = {TEAM_BGUN};
};
Shipment "StunStick" {
    Model = "models/weapons/W_stunbaton.mdl";
    Class = "stunstick";
    Price = 10000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1200;
    Teams = {TEAM_BGUN};
};
Shipment "Keypad Cracker" {
    Model = "models/weapons/w_c4.mdl";
    Class = "weapon_keypad_cracker";
    Price = 10000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1200;
    Teams = {TEAM_BGUN};
};
Shipment "Nomad" {
    Model = "models/weapons/w_smg1.mdl";
    Class = "weapon_nomad";
    Price = 10000;
    Amount = 10;
    Teams = {TEAM_BGUN};
};
Shipment "Nano-Flex Ammo" {
    -- TODO: Fix capitilisation in model name
    Model = "models/items/boxsrounds.mdl";
    Price = 1000;
    Amount = 10;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_CHIEF, TEAM_MOB};
    function(ply)
	if (ply:GetMoveType() == 6) then -- wire users now return true for IsPlayer, this is a quick fix - pantho.
		self:Remove()
		return;
	end
        ply:GiveAmmo(100, "pistol");
    end
};
Shipment "Lockpick" {
    Model = "models/weapons/w_crowbar.mdl";
    Class = "lockpick";
    Price = 6000;
    Amount = 5;
    Teams = {TEAM_MOB,TEAM_BGUN};
};
Shipment "Explosive Charge" {
    Model = "models/weapons/w_slam.mdl";
    Class = "weapon_mad_charge";
    Price = 1000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 150;
    Teams = {TEAM_MOB, TEAM_GUN, TEAM_CHIEF, TEAM_BGUN, TEAM_SWAT};
};
Shipment "Medkit" {
    Model = "models/items/healthkit.mdl";
    Price = 1000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 150;
    Teams = {TEAM_MEDIC, TEAM_SWATMEDIC};
    function(ply)
        if (ply:Health() >= 100) then
            return false;
        end
        ply:SetHealth(100);
        -- TODO: ply:EmitSound("medit_sound.wav");
    end
};
Shipment "Bananas" {
    Model = "models/props/cs_italy/bananna.mdl";
    Price = 10;
    Amount = 10;
    Teams = {-1};
    function() end
};

--------------------------
--                      --
--    Money Printers    --
--                      --
--------------------------

MoneyPrinter "" {
    Price       = 1000;
    PrintMin    = 1;
    PrintMax    = 2;
    MaxCanHave  = 4;
    CanExplode  = true;
};
MoneyPrinter "Golden" {
    Price       = 3000;
    Colour      = Color(255, 238, 0);
    PrintMin    = 2;
    PrintMax    = 3;
    MaxCanHave  = 2;
    CanExplode  = true;
};

MoneyPrinter "Emerald" {
    Price         = 5000;
    Colour        = Color(255, 0, 0);
    PrintMin      = 2;
    PrintMax      = 4;
    MaxCanHave    = 1;
    CanExplode    = false;
    SupporterOnly = true;
};
MoneyPrinter "Ruby" {
    Price         = 5000;
    Colour        = Color(0, 255, 0);
    PrintMin      = 2;
    PrintMax      = 4;
    MaxCanHave    = 1;
    CanExplode    = false;
    SupporterOnly = true;
}
AddEntity("Beckis Box", "becki_box", "models/props_phx/oildrum001_explosive.mdl", 50, 5, "/buybeck", {TEAM_AGENT, TEAM_BGUN, TEAM_HITMAN, TEAM_MERC})
AddEntity("Gun lab", "gunlab", "models/props_c17/TrapPropeller_Engine.mdl", 500, 1, "/buygunlab", TEAM_BGUN)
AddEntity("Ammo Machine", "ammo_machine", "models/props_lab/reciever_cart.mdl", 5000, 1, "/buyammomachine")
--AddCPDealerItem(1, "MP5 SMG n Ammo", "models/weapons/w_smg_mp5.mdl", "weapon_mad_mp5", 1000)
--AddCPDealerItem(1, "Nomad", "models/weapons/w_smg1.mdl", "weapon_nomad", 1000)
--AddCPDealerItem(1, "M3 Shotgun n Ammo", "models/weapons/w_shot_m3super90.mdl", "weapon_mad_m3", 1000)
--AddCPDealerItem(3, "Health n Armor", "models/items/healthkit.mdl", "healthyou", 1000)

-- TODO: EMPTY BOXES ARE NOW DIFEREINTENTSIDNGOSIDNG
AddEntity("Empty Box", "spawned_shipment", "models/Items/item_item_crate.mdl", 50, 5, "/buyemptyshipment")

