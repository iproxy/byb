-- This file is for any additions that will only affect the ZombieRP servers.
-- seemed to make sense having them all in here to stop the other init.lua files getting cluttered.
-- FA:S Workshop
resource.AddWorkshop(181283903) --pistols
resource.AddWorkshop(201027186) -- misc
resource.AddWorkshop(181656972) -- rifles
resource.AddWorkshop(183140076) -- shotguns
resource.AddWorkshop(183139624) -- SMGS
resource.AddWorkshop(180507408) -- base
-- Out of bounds:
--[[
local boundary
timer.Create("Boundarychecker", 180, 0, function()
    boundary = ents.FindInBox(Vector(7354,11913,0),Vector(-9252,-6660,-300))
    for _,ent in pairs(boundary) do
        if not IsValid(ent) then return end
        if ent:IsPlayer() then
            if ent.Boundary then ent.Kick("Kicked for multiple breaches of map boundaries) else            
                ent.Boundary = true
                ent:Kill()
                ent:ChatPrint("You have been slayed for going outside of the map")
            end
            if ent.IsMoneyPrinter or ent:IsMoneyBag() or ent:GetClass() == "spawned_shipment" or ent:GetClass() == "spawned_weapon" or ent:IsNPC() then 
                ent:Remove()
            end
        end
    end
end)
            
local npcspawns = {
	Vector(-1903.393799, 8380.677734, 190.874115),
	Vector(2532.322510, 10396.250000, 119.726280),
	Vector(-2501.112549, 11388.099609, 216.533905),
	Vector(5374.170410, 3707.488770, 119.882362),
	Vector(95.724945, -4484.371094, 200.125000)
}
timer.Create("AntGuardSpawn", 840, 0, function() 
    local int1 = math.random(5)     
	if IsValid(antguard) then
		if antguard:Health() < 50 then
			antguard:Remove()
		end
		return
	else
		antguard = ents.Create("npc_antlionguard")					
		antguard:SetPos(npcspawns[int1])					
		antguard:Spawn()
		--for k,v in pairs(player.GetAll()) do
		--	v:EmitSound("/byb/tank.mp3")
		--end
	end
end)
]]--

hook.Add("OnNPCKilled", "ZRP Loot Tables", function(victim,ply,weapon)
	local rare = false
	local dropchance = 50
	local items = {"item_healthvial"}
	local weapons = {"weapon_mad_sako", "weapon_mad_m60", "weapon_mad_kriss", "weapon_mad_zak47"}	
	if not IsValid(ply) or not ply:IsPlayer() then return end
	local lootpos = victim:GetPos() + Vector(0,0,20)
	local rnd = math.random(0,5)
	if rnd == 0 then return end
	ply:GiveAmmo(rnd,"pistol")
    GAMEMODE:Notify(ply,0,4,"You received " .. rnd .." Ammo for killing that ugly thing.")
	--Setting loot rate
	if victim:GetClass() == "npc_fastzombie" then
		dropchance = 30
	elseif victim:GetClass() == "npc_antlionguard" then
		dropchance = 4
	else		
		if rnd >= 5 then return end
	end
	-- Choosing what item to spawn
	if math.random(0,dropchance) == 3 then
		rare = true
		drop = weapons[math.random(#weapons)]
	else
		--drop = items[math.random(#items)]
		drop = "item_healthvial" -- We removed ammo, and the random errored with only 1 entry for some reason.
	end
	--Spawning the item
	local ent = ents.Create(drop)
	ent:SetPos(lootpos)
	ent:Spawn()
	timer.Simple(60, function() -- removes the loot after 30 seconds to stop the server from clogging up with crap
		if IsValid(ent) then
			if IsValid(ent.Owner) then return else ent:Remove() end
			if ent.Owner:IsPlayer() then return else ent:Remove() end
		end
	end)
	-- spawn um shiny orb for rare weapons
	if rare then
		ply:ChatPrint("You have found an elusive rare weapon, look towards the glowing orb for your treasure.")
		local ent = ents.Create("lightsphere")
		ent:SetColor(255,182,0,255)
		ent:SetPos(lootpos + Vector(0,0,20))
		ent:Spawn()
		phys = ent:GetPhysicsObject()
		if phys:IsValid() then			
			phys:EnableMotion(false)
			ent:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
			timer.Simple(60, function() -- removes the lightsphere along with the loot.
				if IsValid(ent) then
					ent:Remove()
				end
			end)
		end
	end
end)

hook.Add("InitPostEntity", "RemoveRP7Props", function()
-- Magnum & Ammo in the factory with a furnace (pos -3922.964844 1933.066650 112.429909)
for k, v in pairs(ents.FindByClass[[weapon_357]]) do v:Remove()  end
for k, v in pairs(ents.FindByClass[[item_ammo_357_large]]) do v:Remove()  end
-- Remove those stinky ragdolls
for k, v in pairs(ents.FindByClass[["prop_ragdoll]]) do v:Remove()  end
end)


local function HalfCarDmg(target, dmginfo)
	if IsValid(dmginfo:GetAttacker()) and dmginfo:GetAttacker():IsNPC() then
		dmginfo:SetDamage(dmginfo:GetDamage()/0.8)
	end
end
hook.Add("EntityTakeDamage", "zrpnpcdmgflag", HalfCarDmg)


hook.Add( "OnEntityCreated", "zrp_zombiemultipler", function(ent)
	if IsValid(ent) and ent:IsNPC() then
		if math.random(0,2) == 1 then
			local npc = ents.Create(ent:GetClass())
			npc:SetPos(ent:GetPos())
			npc:Spawn()
		end
	end
end)