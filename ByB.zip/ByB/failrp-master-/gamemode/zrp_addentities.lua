Shipment "12 Gauge" {
    Model = "models/weapons/w_henryrifle.mdl";
    Class = "weapon_mad_auto5";
    Price = 4000;
    Amount = 5;
    AvailableSeperately = true;
    SeperatePrice = 950;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "Hunting Knife" {
    Model = "models/weapons/w_knife_ct.mdl";
    Class = "weapon_mad_kabar";
    Price = 1500;
    Amount = 5;
    AvailableSeperately = true;
    SeperatePrice = 450;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "Deagle" {
    Model = "models/weapons/w_pist_deagle.mdl";
    Class = "weapon_mad_desert";
    Price = 2500;
    Amount = 5;
    AvailableSeperately = true;
    SeperatePrice = 650;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "P228" {
    Model = "models/weapons/w_pist_p228.mdl";
    Class = "weapon_mad_zp228";
    Price = 1750;
    Amount = 5;
    AvailableSeperately = true;
    SeperatePrice = 500;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "357 Magnum" {
    Model = "models/weapons/W_357.mdl";
    Class = "weapon_mad_magnum";
    Price = 3000;
    Amount = 5;
    AvailableSeperately = true;
    SeperatePrice = 700;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "Sako" {
    Model = "models/weapons/w_snip_sak.mdl";
    Class = "weapon_mad_sako";
    Price = 3800;
    Amount = 5;
    AvailableSeperately = true;
    SeperatePrice = 1000;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "Armor" {
    Model = "models/Items/BoxMRounds.mdl";
    Price = 1000;
    Amount = 5;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_MERC};
    function (ply)	
	if (ply:GetMoveType() == 6) then -- wire users now return true for IsPlayer, this is a quick fix - pantho.
		self:Remove()
		return false;
	end
        local max = ply:GetClassArmor();
        if (max < 100) then
            max = 100;
        end
        if (ply:Armor() >= max) then
            return false;
        end
        ply:SetArmor(max);
    end
};
Shipment "StunStick" {
    Model = "models/weapons/W_stunbaton.mdl";
    Class = "stunstick";
    Price = 10000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1200;
    Teams = {TEAM_BGUN};
};
Shipment "Keypad Cracker" {
    Model = "models/weapons/w_c4.mdl";
    Class = "weapon_keypad_cracker";
    Price = 10000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1200;
    Teams = {TEAM_BGUN};
};
Shipment "Lockpick" {
    Model = "models/weapons/w_crowbar.mdl";
    Class = "lockpick";
    Price = 6000;
    Amount = 5;
    Teams = {TEAM_MOB,TEAM_BGUN};
};
--------------------------
--                      --
--    Money Printers    --
--                      --
--------------------------

MoneyPrinter "" {
    Price       = 1000;
    PrintMin    = 1;
    PrintMax    = 2;
    MaxCanHave  = 3;
    CanExplode  = true;
};
MoneyPrinter "Golden" {
    Price       = 3000;
    Colour      = Color(255, 238, 0);
    PrintMin    = 1;
    PrintMax    = 3;
    MaxCanHave  = 2;
    CanExplode  = true;
};

MoneyPrinter "Emerald" {
    Price         = 5000;
    Colour        = Color(255, 0, 0);
    PrintMin      = 2;
    PrintMax      = 4;
    MaxCanHave    = 1;
    CanExplode    = false;
    SupporterOnly = true;
};
MoneyPrinter "Ruby" {
    Price         = 5000;
    Colour        = Color(0, 255, 0);
    PrintMin      = 2;
    PrintMax      = 4;
    MaxCanHave    = 1;
    CanExplode    = false;
    SupporterOnly = true;
};
--[[
AddEntity("Money printer", "money_printer", "models/props_c17/consolebox01a.mdl", 1000, 4, "/buymoneyprinter")
AddEntity("Golden Money printer", "golden_money_printer", "models/props_c17/consolebox01a.mdl", 3000, 2, "/buygoldenmoneyprinter")
AddEntity("Emerald Money Printer", "emerald_printer", "models/props_c17/consolebox01a.mdl", 5000, 1, "/buyemeraldmoneyprinter")
AddEntity("Ruby Printer", "ruby_printer", "models/props_c17/consolebox01a.mdl", 5000, 1, "/buyrubymoneyprinter")
--]]
--AddCustomVehicle("Chair_Office1", "models/nova/chair_office02.mdl", 5000 ,{TEAM_AGENT, TEAM_BGUN, TEAM_HITMAN, TEAM_MERC})
--AddCustomVehicle("phx_seat2", "models/props_phx/carseat2.mdl", 3500,{TEAM_AGENT, TEAM_BGUN, TEAM_HITMAN, TEAM_MERC})
AddEntity("Beckis Box", "becki_box", "models/props_phx/oildrum001_explosive.mdl", 50, 5, "/buybeck", {TEAM_AGENT, TEAM_MERC, TEAM_BGUN})
AddEntity("Gun lab", "gunlab", "models/props_c17/TrapPropeller_Engine.mdl", 500, 1, "/buygunlab", TEAM_BGUN)
AddEntity("Ammo Machine", "ammo_machine", "models/props_lab/reciever_cart.mdl", 5000, 1, "/buyammomachine")
--AddEntity("Mini Xmas Tree", "mini_tree", "models/cloud/kn_xmastree.mdl", 500, 1, "/buyxmastree")
--AddCPDealerItem(1, "MP5 SMG n Ammo", "models/weapons/w_smg_mp5.mdl", "weapon_mad_mp5", 1000)
--AddCPDealerItem(1, "Nomad", "models/weapons/w_smg1.mdl", "weapon_nomad", 1000)
--AddCPDealerItem(1, "M3 Shotgun n Ammo", "models/weapons/w_shot_m3super90.mdl", "weapon_mad_m3", 1000)
--AddCPDealerItem(3, "Health n Armor", "models/items/healthkit.mdl", "healthyou", 1000)

-- TODO: EMPTY BOXES ARE NOW DIFEREINTENTSIDNGOSIDNG
AddEntity("Empty Box", "spawned_shipment", "models/Items/item_item_crate.mdl", 50, 5, "/buyemptyshipment")
--AddEntity("Fuel Tank", "ent_fuel", "models/props_junk/gascan001a.mdl", 50, 20, "/fuel", {TEAM_MECHANIC})

--[[
AddCustomVehicle("Jeep", "models/buggy.mdl", 1000 , {TEAM_VEH})
AddCustomVehicle("Golf GTI", "models/golf/golf.mdl", 3500 , {TEAM_VEH})
AddCustomVehicle("Corvette C6", "models/corvette/corvette.mdl", 5000 , {TEAM_VEH})
AddCustomVehicle("Lotus Elise", "models/sickness/lotus_elise.mdl", 4000, {TEAM_VEH})
AddCustomVehicle("EvoCityBus", "models/sickness/evocitybus.mdl", 6000, {TEAM_VEH})
AddCustomVehicle("Ferrari F50", "models/sickness/f50.mdl", 10000, {TEAM_VEH})
AddCustomVehicle("GTA4 Stretch", "models/sickness/stretchdr.mdl", 5000, {TEAM_MOB})
AddCustomVehicle("GTA4 LCPD", "models/sickness/lcpddr.mdl", 2500, {TEAM_POLICE, TEAM_CHIEF})
AddCustomVehicle("GTA4 Landstalker", "models/sickness/landstalkerdr.mdl", 7000, {TEAM_VEH})
AddCustomVehicle("GTA4 Dilettante", "models/sickness/dilettante.mdl", 5000, {TEAM_VEH})
AddCustomVehicle("GTA4 Phantom", "models/sickness/phantomdr.mdl", 6000, {TEAM_VEH})
AddCustomVehicle("GTA4 Lokus", "models/sickness/lokusdr.mdl", 5500, {TEAM_VEH})
AddCustomVehicle("GTA4 Faction", "models/sickness/factiondr.mdl", 6500, {TEAM_VEH})
AddCustomVehicle("GTA4 Blista", "models/sickness/blistadr.mdl", 5500, {TEAM_VEH})
AddCustomVehicle("GTA4 Hakumai", "models/sickness/hakumaidr.mdl", 6000, {TEAM_VEH})
AddCustomVehicle("Diablo VT", "models/sickness/diablovt.mdl", 8000, {TEAM_VEH})
AddCustomVehicle("911 Turbo", "models/sickness/911turbo.mdl", 7500, {TEAM_VEH})
AddCustomVehicle("360 Spyder", "models/sickness/360spyder.mdl", 7000, {TEAM_VEH})
AddCustomVehicle("Murcielago", "models/sickness/murcielago.mdl", 8000, {TEAM_VEH})
AddCustomVehicle("GTA4 Oracle", "models/sickness/oracledr.mdl", 6500, {TEAM_VEH})
--]]
--[[
How to add custom vehicles:
FIRST
go ingame, type rp_getvehicles for available vehicles!
then:
AddCustomVehicle(<One of the vehicles from the rp_getvehicles list>, <Price of the vehicle>, <OPTIONAL jobs that can buy the vehicle>)
Examples:
AddCustomVehicle("Chair_Office1", "models/nova/chair_office02.mdl", 5000 )
AddCustomVehicle("phx_seat2", "models/props_phx/carseat2.mdl", 3500)
AddCustomVehicle("Airboat", "models/airboat.mdl", 5000)
--]]