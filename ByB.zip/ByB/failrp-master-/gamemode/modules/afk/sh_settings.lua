GM.Config.afkdemote = false
GM.Config.afkdemotetime = 600