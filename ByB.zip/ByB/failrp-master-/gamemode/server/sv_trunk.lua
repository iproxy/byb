util.AddNetworkString("TrunkWithdraw")
util.AddNetworkString("UpdateTrunk")
util.AddNetworkString("OpenTrunk")
util.AddNetworkString("RequestTrunk")
util.AddNetworkString("TrunkDeposit")
net.Receive("TrunkWithdraw", function(len,ply)
	local car = net.ReadEntity()
	local index = net.ReadInt(32)
	local ent = car.Trunk[index]
	if car.CarLocked then return end
	if IsValid(ent) then
		ent:Enable()
		local trace = {}
		trace.start = ply:EyePos()
		trace.endpos = trace.start + ply:GetAimVector() * 85
		trace.filter = ply
		local tr = util.TraceLine(trace)
		ent:SetPos(tr.HitPos)
		local phys = ent:GetPhysicsObject()
		if phys:IsValid() then
			phys:EnableCollisions(true)
			phys:EnableMotion(true)
			phys:Wake()
		end
		car.Trunk[index] = nil
		SendClientTrunk(car,ply)
	end
end)

function PlaceInTrunk(item,car)
	if not IsValid(car) then return end
	if car.CarLocked then return end
	car.Trunk = car.Trunk or {}
	if IsValid(item) then
		local phys = item:GetPhysicsObject()
		if phys:IsValid() then
			phys:EnableCollisions(false)
			phys:EnableMotion(false)
		end
		item:SetPos(Vector(-1434.454712, -1910.167603,  -1868.270508))
		item:Disable()
		local index = item:EntIndex()
		car.Trunk[index] = item		
	end
end

function SendClientTrunk(car,ply)
	net.Start("UpdateTrunk")
	net.WriteEntity(car)
	net.WriteTable(car.Trunk)
	net.Send(ply)
end

function OpenTheTrunk(car,ply)
	if not IsValid(car) then end
	if car.CarLocked then return end
	car.Trunk = car.Trunk or {}
	net.Start("OpenTrunk")
	net.WriteEntity(car)
	net.WriteTable(car.Trunk)
	net.Send(ply)
end

net.Receive("RequestTrunk", function(len,ply)
	local car = net.ReadEntity()
	OpenTheTrunk(car,ply)
end)

net.Receive("TrunkDeposit", function(len,ply)
	local car = net.ReadEntity()
	local trunksize = car:GetNetworkedInt("trunksize",5)
	if car.CarLocked then return end
	car.Trunk = car.Trunk or {}
	for k,v in pairs(ents.FindInSphere(ply:GetPos(),75)) do
		if IsValid(v) then
			if table.Count(car.Trunk) >= trunksize then return end
			if v:GetClass() == "money_printer" then
				PlaceInTrunk(v,car)
				ply:ChatPrint(MoneyPrinters[v.dt.Edition].Prefix .. " Money Printer has been placed into the trunk")
			end
		end
	end
end)

local function CarRemoved(ent)	
	if not IsValid(ent) then return end
	if ent:GetClass() != "prop_vehicle_jeep" then return end
	ent.Trunk = ent.Trunk or {}
	local h = 20
	for k,v in pairs(ent.Trunk) do
		v:Enable()
		v:SetPos(ent:GetPos()+Vector(0,0,h))
		local phys = v:GetPhysicsObject()
		if phys:IsValid() then
			phys:EnableCollisions(true)
			phys:EnableMotion(true)
			phys:Wake()
		end
		ent.Trunk[v:EntIndex()] = nil
		h=h+20
	end
end
hook.Add("EntityRemoved", "carremovedtrunk", CarRemoved)