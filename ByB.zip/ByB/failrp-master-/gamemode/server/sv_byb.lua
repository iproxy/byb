local function pdclose()
    for _, ent in pairs(ents.FindByClass'prop_door_rotating') do
        if (ent.DoorData and ent.DoorData.GroupOwn == "Authorised Personnel Only") then
            ent:Fire("close");
            ent:Fire("lock");
        end
    end
    for k,v in pairs(ents.FindByClass[[sent_keypad]]) do if v:GetPos() == Vector(0,0,0) then v:Remove() end end -- Small fix for keypad exploits, figured I'd add it here instead of making another timer. It's only temp anyway - pantho.
end
timer.Create("pdclose", 360, 0, pdclose);

local function RechangeEnts()
    for k,v in pairs(bybhl2ents) do
        if IsValid(v) then
            v:Fire("Recharge")
        end
    end
end
timer.Create("rechargeents",180,0, RechangeEnts)

concommand.Add("lockdownpd", function(ply)
    if (ply:IsAdmin()) then
        pdclose();
    end
end);


-- Util
function ChatPrint(msg)
    PrintMessage(HUD_PRINTTALK, msg);
end
util.AddNetworkString("omgawdsantadmin")
util.AddNetworkString("omgawdsanadmin")
util.AddNetworkString("omgawdsansadmin")
util.AddNetworkString("Kapow")
util.AddNetworkString("Gaghim")
hook.Add("PlayerAuthed", "AdminSupporterLoading", function(ply, steamid)
ply.peoplelistening = {}
ply.RadioChannel = 1
local steamID = sql.SQLStr(ply:SteamID())
	timer.Simple(10, function() 
		DB.Query("SELECT steamID,demote_blacklist FROM darkrp.supporters WHERE steamID = " ..steamID..";",	function(cb)
			if (cb) then
				timer.Simple(1, function()
					if not IsValid(ply) then return end
					ply:SetDarkRPVar("supporter", true)
                    ply:Give[[weapon_fists]]
					sup = true
					ply.CanDemote = 1
					blklist = cb or {}
					if blklist[1].demote_blacklist == 1 then
						ply.CanDemote = 0
					end			
				end)
			else
				DB.Query("SELECT steamID,demote_blacklist FROM darkrp.supporters2 WHERE steamID = " ..steamID..";",	function(cb)
					if (cb) then
						timer.Simple(1, function()							
							if not IsValid(ply) then return end
							ply:SetDarkRPVar("supporter", true)
							ply.CanDemote = 1
                            ply:Give[[weapon_fists]]
							blklist = cb or {}
							if blklist[1].demote_blacklist == 1 then
								ply.CanDemote = 0
							end					
						end)
					else
						timer.Simple(1, function()
							if not IsValid(ply) then return end
							ply:SetDarkRPVar("supporter", false)
						end)
					end
				end)
			end
		end)
	end)
    local sbasgroups = {}
    local sbadmins = {}
    -- Setting to global server incase no sbans.cfg is present
    servid = servid or 0
    --local steamID = sql.SQLStr(ply:SteamID())
	timer.Simple(5, function()
	    if servid == 0 then    
		DB.Query("SELECT aid,srv_group FROM sbans.sb_admins WHERE authid = "..steamID..";", function(data)
			sbadmins = data or {}
				if sbadmins and sbadmins[1] then
					local adminid = sbadmins[1].aid
					local admingroup = sbadmins[1].srv_group
					if admingroup == "superadmin" then
						game.ConsoleCommand("ulx removeuserid "..steamID.."\n")
						ply.SAD = true 
						return ""
			        elseif admingroup == "formerfluffy" then
                        ply.FFluffy = true 
                        ply:SetUserGroup("admin")
                    end
					DB.Query("SELECT server_id,expires FROM sbans.sb_admins_servers_groups WHERE admin_id = ".. adminid .." AND DATEDIFF(expires, CURDATE()) > 0;", function(data)
						if (data) then
							game.ConsoleCommand("ulx adduserid "..steamID.." "..admingroup.."\n")
							if admingroup == "trusted_admin" then 
								ply.TBAD = true 
                                ply:SetUserGroup("admin")
								--net.Start("omgawdsantadmin")
								--net.WriteEntity(ply)
								--net.Broadcast()
							elseif admingroup == "admin" then 
								ply.BADmin = true 
                                ply:SetUserGroup("admin")
								--net.Start("omgawdsanadmin")
								--net.WriteEntity(ply)
								--net.Broadcast()
							end
						end
					end)
				end
		    end)
	    else
		    DB.Query("SELECT aid,srv_group FROM sbans.sb_admins WHERE authid = "..steamID..";", function(data)
			sbadmins = data or {}
				if sbadmins and sbadmins[1] then
					local adminid = sbadmins[1].aid
					local admingroup = sbadmins[1].srv_group
					if admingroup == "superadmin" then
						ply.SAD = true
						game.ConsoleCommand("ulx removeuserid "..steamID.."\n")
						return ""                        
                    elseif admingroup == "formerfluffy" then
                        ply.FFluffy = true 
                        ply:SetUserGroup("admin")
					elseif admingroup == "trusted_admin" then
						DB.Query("SELECT server_id,expires FROM sbans.sb_admins_servers_groups WHERE DATEDIFF(expires, CURDATE()) >= 0 AND admin_id = "..adminid..";", function(data)
							if (data) then
								game.ConsoleCommand("ulx adduserid "..steamID.." "..admingroup.."\n")
								ply.TBAD = true
								ply.TBAD = true 
                                ply:SetUserGroup("admin")
								--net.Start("omgawdsantadmin")
								--net.WriteEntity(ply)
								--net.Broadcast()
							end
						end)					
					else
						DB.Query("SELECT server_id,expires FROM sbans.sb_admins_servers_groups WHERE (server_id = ".. servid .." OR server_id = 0) AND DATEDIFF(expires, CURDATE()) > 0 AND admin_id = "..adminid..";", function(data)
							if (data) then
								game.ConsoleCommand("ulx adduserid "..steamID.." "..admingroup.."\n")
								if admingroup == "trusted_admin" then
									ply.TBAD = true 
                                    ply:SetUserGroup("admin")
									--net.Start("omgawdsantadmin")
									--net.WriteEntity(ply)
									--net.Broadcast()
								elseif admingroup == "admin" then
									ply.BADmin = true
                                    ply:SetUserGroup("admin")
									--net.Start("omgawdsanadmin")
									--net.WriteEntity(ply)
									--net.Broadcast()
								end
							end
						end)
					end
				end
		    end)
	    end
	end)
end)

-- FYI: GM.RootAdmins is defined near the bottom of shared.lua
-- Using same hook to load admins & supporter now - Pantho
hook.Add("PlayerAuthed", "Root Admin Shenanigans", function(ply, steamid)
	-- Makes jump height more like GM12
	ply:SetJumpPower(200)
    local name = GAMEMODE.RootAdmins[steamid];
    if (not name) then return; end
    -- Assign the admin to a variable with their name.
    _G[name] = ply;
    ply.IsRootAdmin = true;
end);


-- Just in case :B
game.ReallyCleanUpMap = game.CleanUpMap;
function game.CleanUpMap()
return false
end

do
local messages = {
    "Iiiiiiit's %s!";
    "Here comes %s!";
    "Everyone hide from %s!";
    "%s really sucks!";
    "Watch out, %s is about!";
    "%s. That's all.";
    "Tremble in despair mortals! %s has descended apon this world!";
    "Is it a bird? Is it a headcrab? No! It's %s!";
    "They came, they saw, they conquered! It's %s!";
    "Oh look, it's %s again.";
    "%s has emerged from Shikari's chamberpot of secrets!";
    "Moo want's to know why %s's debris is in his drink";
    "They told me I could become anything, so I became a %s.";
}
local suckers = { "Shikari", "Jamie H", "Jamie H", "Jamie H", "Pantho", "Lexi", "Deon", "SystemShock", "your mother" }
local suckermsg = "%s thinks that %s really sucks!";
resource.AddFile("supersound.wav")
--resource.AddFile("sound/quackduck.wav")

local function Marios(ply)
	local poop = 1
	local oldcol = ply:GetPlayerColor()
	local function Flasher()
		local r = math.random(0,100) / 100
		local g = math.random(0,100) / 100
		local b = math.random(0,100) / 100
		ply:SetPlayerColor(Vector(r,g,b))
	end
	timer.Create("Flasher", 0.1, 100, Flasher);
	timer.Simple(11, function() if IsValid(ply) then ply:SetPlayerColor(oldcol) end end)
end

-- rcon quit not kills the service, so here ya go
concommand.Add("restartme",function(ply)
	if ply:IsRoot() or ply:EntIndex() == 0 then 
		game.ConsoleCommand("changelevel " .. game.GetMap() .. "\n");
	end
end)

concommand.Add("adminme", function(ply, _, args)
    if (not ply.SAD) then return; end
    if (ply.SADON) then
        ply:ChatPrint("Um, you're already a superadmin :)");
        return;
    end
    local url
    local immediately, silently;
    if (args[1]) then
        if (args[1] == "silently") then
            silently = true;
        elseif (args[1] == "immediately") then
            immediately = true;
            if (args[2] == "and" and args[3] == "silently") then
                silently = true;
            end
        elseif (args[1] == "file") then
            url = args[2]
        end
    end
    if (not ply:IsAdmin() and not immediately) then
       -- game.ConsoleCommand("ulx adduserid "..ply:SteamID().." admin\n");
		ply.BADmin = true
        ply:SetUserGroup("admin")
		--net.Start("omgawdsanadmin")
		--net.WriteEntity(ply)
		--net.Broadcast()
        ply:ChatPrint("You've been silently made an admin! Use adminme again to go all the way, or adminme immediately to skip this step next time.");
    else
      --  game.ConsoleCommand("ulx adduserid "..ply:SteamID().." superadmin\n");
		ply.SADON = true
        ply:SetUserGroup("admin")
		net.Start("omgawdsansadmin")
		net.WriteEntity(ply)
		net.Broadcast()
        if (silently and ply:IsRoot()) then return; end
        if (math.random(2) == 2) then
            ChatPrint(string.format(table.Random(messages), ply:Name()));
        else
            ChatPrint(string.format(suckermsg, ply:Name(), table.Random(suckers)));
        end
		Marios(ply)
        if ply == ride then
        
            local url = "http://share.yourlink.com/iloveridespunk.ogg"
        
            for k,v in pairs(player.GetAll()) do
                v:SendLua('sound.PlayURL(\''..url..'\',"",function(cb) if not vb then return end cb:SetPos(Entity('..tostring(ply:EntIndex())..'):GetPos()) cb:Play() timer.Simple(15,function() cb:Stop() end) end)')
                if not ply == ride then
                    v:Ignite(25)
                end
            end
            
        elseif ply:SteamID() == "STEAM_0:0:20235793" then
        
            local url = "http://share.yourlink.com/chasgasms.ogg"
        
            for k,v in pairs(player.GetAll()) do
                v:SendLua('EveryoneLetsAct(ACT_GMOD_TAUNT_MUSCLE)')
                v:SendLua('sound.PlayURL(\''..url..'\',"",function(cb) if not vb then return end cb:SetPos(Entity('..tostring(ply:EntIndex())..'):GetPos()) cb:Play() timer.Simple(15,function() cb:Stop() end) end)')
            end
        
        elseif url then
            for k,v in pairs(player.GetAll()) do
                v:SendLua('sound.PlayURL(\''..url..'\',"",function(cb) if not vb then return end cb:SetPos(Entity('..tostring(ply:EntIndex())..'):GetPos()) cb:Play() timer.Simple(15,function() cb:Stop() end) end)')
                v:ChatPrint("Music file loaded for superadmin arrival: "..ply:Nick())
            end
        else
		  ply:EmitSound("supersound.wav")
        end
    end
end)
end

concommand.Add("sbancheck",function(ply, cmd, args)
    if (not ply:IsAdmin()) then
        return;
    end
    sourcebans.CheckForBan(args[1], function(res,err)
        if (IsValid(ply)) then
            myBanCallback(res,err,ply);
        end
    end);
end);

--Why is this here? It's so insanely ancient, from before we loaded supporter on playerauth.
--[[
concommand.Add("reloadsupporter", function(ply,cmd,args)
    if not (ply:IsSuperAdmin()) then return end
    Supporters = {}
    GetMySQLStack():push("SELECT * FROM supporters", function(res)
        for k, v in pairs(res) do
            Supporters[v[1] or v.steamID] = true
        end
    end)
end)
]]--

do
    local reps = 4;
    local msg = "%s has issued a restart command! The server will restart in %d %s!"
    local function notification(restarter, delay)
        local prec = "seconds"
        if (delay > 60) then
            delay = delay / 60;
            prec = "minutes";
        end
        for i = 1, reps do
            ChatPrint(string.format(msg, restarter, delay, prec));
        end
    end
    local function restart()
        game.ConsoleCommand("changelevel " .. game.GetMap() .. "\n");
    end
    local delays = {
        300,
        240,
        180,
        120,
        60,
        45,
        30,
        15
    };
    local function ccrestart(ply)
        if (IsValid(ply) and not ply:IsRoot()) then
            return;
        end
        local name = IsValid(ply) and ply:Name() or "Console";
        local rootdelay = delays[1];
        for _, delay in pairs(delays) do
            timer.Create("Restart timer #" .. delay, rootdelay - delay, 1, function() notification(name, delay); end)
        end
        timer.Create("Restart timer #0", rootdelay, 1, restart);
    end
    local function ccunrestart(ply)
        if (IsValid(ply) and not ply:IsTrustedAdmin()) then
            return;
        end
        local name = IsValid(ply) and ply:Name() or "Console";
        ChatPrint(name .. " has canceled the restart command. The server will no longer restart.");
        for _, delay in pairs(delays) do
            timer.Destroy("Restart timer #" .. delay);
        end
        timer.Destroy("Restart timer #0");
    end
    concommand.Add("restartserver", ccrestart);
    concommand.Add("restartcancel", ccunrestart);
end

concommand.Add("supportergive", function(ply,cmd,args)
    if ply == pantho then
            FindPlayer(args[1]):SetDarkRPVar("supporter", true)
    end
end)
concommand.Add("supporterremove", function(ply,cmd,args)
    if ply == pantho then
        FindPlayer(args[1]):SetDarkRPVar("supporter", false)
    end
end)

concommand.Add("spawn",function(ply, _, args)
    if (not ply:IsRoot()) then
        return;
    end
    local trace = ply:GetEyeTrace();
    if not trace.Hit then return end
    local ent = {}
    for var=1, args[2] or 1 do
        ent[var] = ents.Create(args[1]);
        ent[var]:SetPos(trace.HitPos);
        ent[var].FPPOwner = ply;
        ent[var]:Spawn();
    end
end)

concommand.Add("boomy",function(ply,cmd,args)
    if not ply:IsRoot() then 
        return;
    end
    --local trace = ply:GetEyeTrace();
    local pos = FindPlayer(args[1]):GetPos()
    local patsy = FindPlayer(args[2])
    if not patsy then patsy = pantho end
    local ent = {}
    for var=1, 2, 1 do
        ent[var] = ents.Create("ent_mad_grenade");
        ent[var]:SetPos(pos);
        ent[var]:SetOwner(patsy);
        ent[var]:Spawn();
    end
end)

concommand.Add("print_owner",function(ply,cmd,args)
    local ent = ply:GetEyeTrace().Entity;
    
    if not IsValid(ent) then return end
    
    if ply:IsAdmin() and ent.STID then
        ply:ChatPrint("Owner ID: " .. ent.STID .. " | Ent ID: " .. ent:EntIndex() .. " | Location: " .. tostring(ent:GetPos()));  
    elseif IsValid(ent.FPPOwner) then
        ply:ChatPrint("Owner: " .. ent.FPPOwner:Nick() .. " (" .. ent.FPPOwner:SteamID() .. ") | Ent ID: " .. ent:EntIndex() .. " | Location: " .. tostring(ent:GetPos())); 
    else
        ply:ChatPrint("Unknown");
    end
end)

local physpurgable = {
    phys_constraintsystems  = 100;
    phys_constraint         = 200;
    logic_collision_pairs   = 200;
};
local enablemotionfor = {
    spawned_shipment          = true;
    money_printer             = true;
    becki_box                 = true;
    ammo_machine              = true;
    --prop_vehicle_jeep         = true;
    --prop_vehicle_prisoner_pod = true; -- should fix it, mebbie not.
    };

do
    local tell = FindMetaTable'Player'.ChatPrint;
    local tellall = ChatPrint;
    local function killall(ent)
        if (ent == "spawned_shipment" or ent == "empty_shipment") then
            local empty = ent == "empty_shipment";
            ent = "spawned_shipment";
            for _, ent in pairs(ents.FindByClass(ent)) do
                if ((empty and not ent.ShipmentInfo) or (not empty and ent.ShipmentInfo)) then
                    ent:Remove()
                end
            end
        else
            for _, ent in pairs(ents.FindByClass(ent)) do
                ent:Remove();
            end
        end
    end
    local function getcount(ent)
        if (ent == "spawned_shipment" or ent == "empty_shipment") then
            local count = 0;
            local empty = ent == "empty_shipment";
            ent = "spawned_shipment";
            for _, ent in pairs(ents.FindByClass(ent)) do
                if ((empty and not ent.ShipmentInfo) or (not empty and ent.ShipmentInfo)) then
                    count = count + 1;
                end
            end
            return count;
        else
            return #ents.FindByClass(ent);
        end
    end

    local function physpurge()
        local phys;
        for _, ent in pairs (ents.GetAll()) do
            phys = ent:GetPhysicsObject()
            
            if (phys:IsValid()) then
            
                -- Enable motion for things that shouldn't be frozen
                if (enablemotionfor[ent:GetClass()]) then
                    phys:EnableMotion(true);
                else            
                    phys:EnableMotion(false);
                end
            
            end
            -- Wipe any constraints attached to this entitiy
            -- this should stop it removing wire hydraulics?
           --local tbl = constraint.FindConstraints(ent,"WireHydraulic")
            --if not tbl then constraint.RemoveAll(ent) end
            constraint.RemoveAll(ent)
        end
    end

    local tocount = {
        spawned_money    = "bits of cash";
        sent_keypad      = "keypads";
        spawned_weapon   = "loose weapons";
        empty_shipment   = "empty shipments";
        spawned_shipment = "shipments";
        money_printer    = "money printers";
		gmod_wire_expression2 = "E2 Chips";
    };
    local antilags = {
        empty_shipment = {
            num = 10;
            msg = "Too many empty boxes on the server! Don't spawn 'em until you need 'em!";
        };
        spawned_money = {
            num = 20;
            msg = "Too many bits of loose cash on the server! Pick your money up faster next time!";
        };
        spawned_weapon = {
            num = 30;
            msg = "Too many loose weapons on the server! Try storing your guns in empty boxes next time?";
        };
    };

    local function cclagcheck(ply, _, args)
        if (IsValid(ply) and not ply:IsTrustedAdmin()) then
            return;
        end
        -- Informative spam
        local blame = IsValid(ply) and ply:Name() or "Console";
        local counts = {};
        for class, desc in pairs(tocount) do
            table.insert(counts, string.format("%d %s,", getcount(class), desc));
        end
        for _, ply in pairs(player.GetAll()) do
            if (not ply:IsAdmin()) then continue; end
            tell(ply, "Entity count, courtesy of " .. blame .. ":");
            tell(ply, "There are currently:");
            for _, words in pairs(counts) do
                tell(ply, words);
            end
            tell(ply, "On the map right now.");
        end

        if (args[1]) then
            return;
        end

        -- Anti-lag shenanigans
        for class, tab in pairs(antilags) do
            if (getcount(class) > tab.num) then
                tellall(tab.msg);
                killall(class);
            end
        end

        -- Damn you physics
        for class, maxcount in pairs(physpurgable) do
            if (getcount(class) > maxcount) then
                tellall("Over " .. maxcount .. " " .. class .. " entities on the server! Removing all constraints . . .");
                physpurge();
                break;
            end
        end
		for k,v in pairs(player.GetAll()) do
			if IsValid(v) and v:IsAdmin() then
				v:ChatPrint("New E2 Menu to check for lag: type e2snooper in console.")
			end
		end

    end
    local function cclagcheckdisabled(ply)
        if (IsValid(ply)) then
            if (not ply:IsTrustedAdmin()) then
                return;
            end
            ply:ChatPrint("Use `lagcheck disabled` next time.");
        end
        cclagcheck(ply, _, {"disabled"});
    end
    local function ccpurgephys(ply)
        if (ply:IsSuperAdmin()) then
            ply:ChatPrint("Worldender - Tickling physics as requested!")
            physpurge();
        end
    end
    local function cckillall(ply, _, args)
        if (ply:IsSuperAdmin() and args[1]) then
            killall(args[1]);
        end
    end
    local function cccleanarrows(ply)
        if (ply:IsAdmin()) then
            killall("ent_mad_arrow");
        end
    end
    local function cccleankeypads(ply)
        if (ply:IsAdmin()) then
            for k,v in pairs(ents.FindByClass[[sent_keypad]]) do if v:GetPos() == Vector(0,0,0) then v:Remove() end end
        end
    end
    concommand.Add("lagcheck", cclagcheck);
    concommand.Add("lagcheckdisabled", cclagcheckdisabled);
    concommand.Add("worldender", ccpurgephys);
    concommand.Add("entremove", cckillall);
    concommand.Add("cleanarrows", cccleanarrows);
    concommand.Add("cleankeypads", cccleankeypads);
	local function cce2check(ply, _, args)
		if IsValid(ply) then
			ply:ChatPrint("This command is outdated - please use e2snooper in console")
			return;
		end
		local count = 0
		for k,ent in pairs(ents.FindByClass[[gmod_wire_expression2]]) do
			if ent.context and ent.context.prfbench then -- how does an e2 not have a .context ... 
				local ops = math.Round(ent.context.prfbench,0) or "Error?"
				local owner = (IsValid(ent.FPPOwner) and ent.FPPOwner:Nick()) or "Unknown"
				local ownerid = (IsValid(ent.FPPOwner) and ent.FPPOwner:SteamID()) or "--"
				ply:ChatPrint("E2 Chip: " .. ent.name .. "(Ent " .. ent:EntIndex() .. ") Owner: " .. owner .. "(" .. ownerid ..") @ OPS: " .. ops)
				count = count+1
			end
		end
		if count == 0 then
			ply:ChatPrint([[No E2 chips found.]])
		end		
	end
	concommand.Add("e2checker",cce2check)
end

concommand.Add("superslay", function(ply, _, args)
    if (not ply:IsSuperAdmin()) then
        return;
    end
    local pl = ply;
    if (args[1]) then
        pl = FindPlayer(args[1]);
        if (not IsValid(pl)) then
            ply:ChatPrint("who?");
            return;
        end
    end
    pl.WasSlayed = true
    pl:Kill();
	DB.Log(ply:Name().."("..ply:SteamID()..") superslayed "..pl:Name().."("..pl:SteamID()..")",nil,nil)
end);

concommand.Add("heal",function(ply, _, args)
    if (not ply:IsSuperAdmin()) then
        return;
    end
    local pl = ply;
    if (args[1]) then
        pl = FindPlayer(args[1]);
        if (not IsValid(pl)) then
            ply:ChatPrint("who?");
            return;
        end
    end
    local max = pl:GetClassArmor();
    if (max < 100) then
        max = 100;
    end
    if ply:SteamID() == "STEAM_0:0:20235793" then
        ply:SendLua[[gui.OpenURL("http://www.youtube.com/embed/FSvuNOhVa98?autoplay=1")]]
        ply:SendLua[[sound.PlayURL("http://share.bybservers.co.uk/chasfu.mp3","",function(cb) cb:Play() end)]]
    end
    pl:SetHealth(100)
    pl:SetArmor(max);
    if not ply:IsRoot() then
        AdminLog(ply,pl, " has healed "," to full health and armor!")
    else
	   DB.Log(ply:Name().."("..ply:SteamID()..") healed "..pl:Name().."("..pl:SteamID()..")")
    end
end);

local function ccdemote(ply, _, args)
    if (not ply:IsTrustedAdmin()) then
        return;
    end
    if (not args[1]) then
        ply:ChatPrint("who?");
    end
    pl = FindPlayer(args[1]);
    if (not IsValid(pl)) then
        ply:ChatPrint("who?");
        return;
    end
    if (pl:Team() == TEAM_CITIZEN) then
        return;
    end
	
	if not pl:Alive() then ply:ChatPrint("The player was dead. Lets resurrect them before demoting them.") pl:Spawn() end
	
	local t = pl:Team()
	if (t == TEAM_GUN) or (t == TEAM_HGUN) or (t == TEAM_BGUN) then
		pl.LastGDDemote = CurTime();
	elseif (t == TEAM_CHIEF) or (t == TEAM_POLICE) or (t == TEAM_SWAT) or (t == TEAM_SWATRECON) or (t == TEAM_SWATMEDIC) or (t == TEAM_SWATCQB) then
		pl.LastCPDemote = CurTime();
	end
	
	DB.Log(ply:Nick() .. " force demoted " .. pl:Nick() .. "with the reason:" .. table.concat(args, " ", 2))
    
        if pl:IsCP() then
            for _,tar in pairs(player.GetAll()) do
                if tar:isArrested() and tar.ArrestedBy and tar.ArrestedBy == pl then
                    ChatPrint(tar:Nick() .. " has been unarrested due to " .. pl:Nick() .. " being demoted.")
                    DB.Log(tar:Nick().. " (" .. tar:SteamID() .. ") was unarrested due to " .. pl:Nick().. " (" .. pl:SteamID() .. ") being force demoted.")
                    tar:Unarrest()
                end
            end
        end
    
    pl:TeamBan();
    pl:ChangeTeam(TEAM_CITIZEN, true);
    ChatPrint(string.format("(%s) Demoted (%s) for: %s", ply:Name(), pl:Name(), table.concat(args, " ", 2)));
end
concommand.Add("demote", ccdemote);

local function ccchangename(ply, _, args)
    if (not ply:IsTrustedAdmin()) then
        return;
    end
    if (not args[1]) then
        ply:ChatPrint("who?");
    elseif (not args[2]) then
        ply:ChatPrint("What?");
    end
    pl = FindPlayer(args[1]);
    if (not IsValid(pl)) then
        ply:ChatPrint("who?");
        return;
    end
    local name = table.concat(args, " ", 2)
    ChatPrint(string.format("%s changed the name of %s to %s", ply:Name(), pl:Name(), name));
    pl:SetRPName(name, false);
end
concommand.Add("changename", ccchangename);

concommand.Add("cleardecals", function(ply)
    if (ply:IsAdmin()) then
        for _, ply in pairs(player.GetAll()) do
            ply:ConCommand[[r_cleardecals]]
        end
    end     
end);

hook.Add( "CanTool", "BlockCameraSpam", function( ply, tool, tr ) 
    if tool == "rtcamera" and ( ply:GetInfoNum( "rtcamera_key" ) > 20 or ply:GetInfoNum( "rtcamera_key" ) < -5 ) then
        return false
    end
    if tool == "camera" and ( ply:GetInfoNum( "camera_key" ) > 20 or ply:GetInfoNum( "camera_key" ) < - 5 ) then
        return false
    end
end)

concommand.Add("rootmode", function(ply,_,_)
	if (ply.RootMode) then
		ply:ChatPrint("RootMode disabled.")
      umsg.Start("ToggleRoot", ply)
      umsg.End()
      ply.RootMode = false
	elseif ply:IsRoot() then 
		ply:ChatPrint("RootMode Activated.")
      umsg.Start("ToggleRoot", ply)
      umsg.End()
      ply.RootMode = true
	end
end)

-- Entity log functions.
--[[
function EntRemoveLog(ent)
	if IsValid(ent) then
		local STID = "(NONE FOUND)"
		if IsValid(ent.Owner) then
			STID = ent.Owner:SteamID()
		elseif ent.STID then
			STID = ent.STID
		end
		 DB.Log(("Removed Ent Info: " ..ent:EntIndex().. " - ".. ent:GetClass() .." | " .. "SteamID: " .. STID))
	end
end 
hook.Add("EntityRemoved", "entRemoved", EntRemoveLog)
--]]

-- Gift Codes
-- Admin 
concommand.Add("admincodeauth", function(ply,cmd,args)
	local month = 2629743
	local etime = os.time()
	local expires
	local codeservid
	local admingroup = ""
    local abuser
	-- Once again, I cba playing with timers so im doing el stupido method.
	if ply.UsedCode1 == "1" then ply.UsedCode1 = "2" return end
	if ply.UsedCode1 == "2" then ply.UsedCode1 = "0" return end
	ply.UsedCode1 = "1"
	if ply:IsAdmin() then
		ply:ChatPrint("I'm afraid you are already an admin")
		ply:ChatPrint("As we don't want people accidently wasting their codes we have disabled admins from using this. Please use the code once your admin has expired")
		return
	end
	DB.Query("SELECT license,active,length,sid FROM darkrp.adminauth WHERE license= "..sql.SQLStr(args[1])..";", function(data)
		codedetails = data or {}
		if codedetails and codedetails[1] then
			local license = codedetails[1].license
			local active = codedetails[1].active
			local length = tonumber(codedetails[1].length)
			if codedetails[1].sid == '0' then			
				codeservid = 0
			else
				if (RP6) or (RP7) then 
					codeservid = 1
				else
					codeservid = servid
				end
			end
			if length then
				expires = os.date([[%y/%m/%d]],etime+(month*length))
			end
			if active=="0" then 
				ply:ChatPrint("I'm afraid this code has already been activated, if you believe this to be an error then contact Pantho on the forums @ www.bybservers.co.uk")
				return
			end
            
			DB.QueryValue("SELECT srv_group FROM sbans.sb_admins WHERE authid="..sql.SQLStr(ply:SteamID())..";", function(cb)
				if (cb) then
                    if string.StartWith(string.lower(cb),"abuser") then
                        abuser = true
                        ply:ChatPrint("You're marked as an abuser and unable to redeem this code. Private message a root admin on the forums to appeal, or give the code to a friend.")
                    end
                    admingroup = cb
				else
					admingroup = "admin"
                end
                if not abuser then
                    DB.Query("UPDATE darkrp.adminauth SET active='0',server="..sql.SQLStr(servid)..",sid="..sql.SQLStr(ply:SteamID())..",time_used="..etime.." WHERE license="  .. sql.SQLStr(args[1]) ..";")			
                    DB.Log(ply:Name() .. " : ("..ply:SteamID()..") Has used code " ..args[1])
                end
                if not (cb) then
					DB.Query("INSERT INTO sbans.sb_admins (user,authid,password,gid,email,validate,extraflags,immunity,srv_group) VALUES (".. sql.SQLStr(license) ..",".. sql.SQLStr(ply:SteamID()) ..",'GiftCodedXXXXX123','1',".. sql.SQLStr(email) ..",'1','1','1','admin');") 
				end
			end)
            timer.Simple(5, function()
            if not abuser then
                    DB.Query("SELECT aid FROM sbans.sb_admins WHERE authid="..sql.SQLStr(ply:SteamID())..";", function(data)
                        if (data) then
                            ply:ChatPrint("Confirmed admin has been stored into the database, expiration date (US Format): " .. expires)
                            DB.Query("INSERT INTO sbans.sb_admins_servers_groups (admin_id,group_id,srv_group_id,server_id,expires) VALUES (".. sql.SQLStr(data[1].aid)..",'3','-1',"..sql.SQLStr(codeservid)..","..sql.SQLStr(expires)..");")
                        end
                    end)
                    ply:ChatPrint("You should now be admin. This system is still in development if you have ANY issue with it contact Pantho - make sure to include your gift code in the email/forum pm.")
                    game.ConsoleCommand("ulx adduserid "..ply:SteamID().." "..admingroup.."\n")
                end
            end)
		end
	end)
end)
--Supporter
concommand.Add("SupporterCodeAuth", function(ply,cmd,args)
	-- Yes I'm a moron, but the timer wouldn't fucking work so bite me. 
	if ply.UsedCode == "1" then ply.UsedCode = "2" return end
	if ply.UsedCode == "2" then ply.UsedCode = "0" return end
	ply.UsedCode = "1"
	if ply:IsSupporter() then
		ply:ChatPrint("You are already a supporter. If you still cannot use supporter jobs/abilities contact Pantho")
		return
	end
	DB.QueryValue("SELECT active FROM darkrp.supporterauth WHERE license="  .. sql.SQLStr(args[1]) ..";",	function(cb)
		if not (cb) then ply:ChatPrint("Invalid Code Entered") end
		return
	end)
	DB.Query("SELECT active FROM darkrp.supporterauth WHERE license="  .. sql.SQLStr(args[1]) ..";", function(data)
		DB.Log(ply:Name() .. " : ("..ply:SteamID()..") Has used code " ..args[1])
		local data = data or {}
		if data or data[1] then
			if (data[1].active == "1") then
				ply:ChatPrint("Code Accepted - You are now a supporter!")
				ply:SetDarkRPVar("supporter", true)
				DB.Query("UPDATE darkrp.supporterauth SET active='0' WHERE license="  .. sql.SQLStr(args[1]) ..";;")
				DB.Query("UPDATE darkrp.supporterauth SET sid=".. sql.SQLStr(ply:SteamID()) .." WHERE license="  .. sql.SQLStr(args[1]) ..";")
				DB.Query("INSERT INTO darkrp.supporters2 (steamID, demote_blacklist) VALUES(" .. sql.SQLStr(ply:SteamID()) .. ",0);")
			else
				ply:ChatPrint("Code has already been activated")
			end	
		end
	end)
end)

--Why old darkrp remove, me like this:
function FindPlayer(info)
	if not info then return nil end
	local pls = player.GetAll()

	-- Find by Index Number (status in console)
	for k = 1, #pls do -- Proven to be faster than pairs loop.
		local v = pls[k]
		if tonumber(info) == v:UserID() then
			return v
		end

		if info == v:SteamID() then
			return v
		end
	
		if string.find(string.lower(v:SteamName()), string.lower(tostring(info)), 1, true) ~= nil then
			return v
		end
	
		if string.find(string.lower(v:Name()), string.lower(tostring(info)), 1, true) ~= nil then
			return v
		end
	end
	return nil
end

hook.Add("InitPostEntity", "RemoveMapProps", function()  
	for k, v in pairs(ents.FindByClass[[prop_physics]]) do v:Remove()  end 
	for k, v in pairs(ents.FindByClass[[prop_physics_multiplayer]]) do v:Remove()  end 
	if game.GetMap() == "rp_downtown_v2" then
        local dieents = {
            2209; -- furniture shop button of doom;
            2224; -- gunshop glock button
            2225; -- gunshop fiveseven button
            2226; -- gunshop ammo button
            -- Admin room buttons
            2250;
            2251;
            2252;
            2253;
        };
        for _, mid in pairs(dieents) do
            --print(mid)
            ents.GetMapCreatedEntity(mid):Remove()
        end
        --[[
		Entity(732):Remove()
		Entity(763):Remove()
		Entity(764):Remove()
		Entity(765):Remove()
		Entity(766):Remove()
		Entity(748):Remove()
        --]]
	end
	-- Just moving the jail window a tad, stops stupid arresting through the wall.
	if game.GetMap() == "rp_bangclaw" then
		if IsValid(Entity(335)) and Entity(335):GetClass() == "func_wall" then
			Entity(335):SetPos(Entity(335):GetPos()+Vector(0,9,0))
		end
	end
	if RP3 then
		Entity(540):Remove() -- Bridge barrier
		Entity(513):Remove() -- Bridge barrier
		Entity(514):Remove() -- Bridge barrier
		Entity(515):Remove() -- Bridge barrier
		Entity(516):Remove() -- Bridge barrier
		Entity(520):Remove() -- Bridge
		Entity(205):Remove() -- Bridge Controls
		Entity(1189):Remove() -- Bridge Controls
		Entity(1190):Remove() -- Bridge Controls
		Entity(1191):Remove() -- Bridge Controls
	end
	for k,v in pairs(ents.FindByClass[[env_soundscape]]) do
		if IsValid(v) then v:Remove() end
	end	
    -- why can people even save multiplayer games?
    -- Lag exploit
    concommand.Remove("gm_save")
end)

hook.Add("PlayerNoClip", "AdminNoclip", function(ply) 
    if (ply:isArrested()) then
        ply:ChatPrint("Can't noclip while arrested")
        return false
    end
	return ply:GetMoveType() == MOVETYPE_NOCLIP or ply:IsAdmin()
end)

concommand.Add("moneyauth", function(ply,cmd,args)
	local month = 2629743
	local etime = os.time()
	local expires
	local codeservid
	local admingroup = ""
	-- Once again, I cba playing w ith timers so im doing el stupido method.
	if ply.UsedCode1 == "1" then ply.UsedCode1 = "2" return end
	if ply.UsedCode1 == "2" then ply.UsedCode1 = "0" return end
	ply.UsedCode1 = "1"
	DB.Query("SELECT license,active,fuid,value,sid FROM darkrp.moneyauth WHERE license= "..sql.SQLStr(args[1])..";", function(data)
		codedetails = data or {}
		if codedetails and codedetails[1] then
			local license = codedetails[1].license
			local active = codedetails[1].active
			local value = tonumber(codedetails[1].value)
			if active == 0 then 
				ply:ChatPrint("I'm afraid this code has already been activated, if you believe this to be an error then contact Pantho on the forums @ www.bybservers.co.uk")
				return
			end
			DB.Query("UPDATE darkrp.moneyauth SET active='0',sid="..sql.SQLStr(ply:SteamID()).." WHERE license="  .. sql.SQLStr(args[1]) ..";")
			DB.Log(ply:Name() .. " : ("..ply:SteamID()..") Has used code " ..args[1])
			if value <= 4 then
				value = value * 50000
			else
				value = (value - 3) * 200000
			end			
			ply:AddMoney(value)
			ply:ChatPrint("You have received $"..value..". Thank you for your purchase. Any issues contact Pantho @ bybservers.co.uk")			
		end
	end)
end)

-- Silly door stuff for testing
concommand.Add("print_doors", function(ply,_,__)
	if not ply:IsTrustedAdmin() then return end
	ply:ChatPrint("1")
	for k,v in pairs(ents.FindByClass[[prop_door_rotating]]) do 
		ply:ChatPrint("Skin Number: " .. v:GetSkin() .. " entid: " .. v:EntIndex() .. " Position: ".. tostring(v:GetPos()))
	end	
end)

concommand.Add("door_next", function(ply,_,__)
	if not ply:IsTrustedAdmin() then return end
	local trace = ply:GetEyeTrace().Entity
	if not trace:GetClass() == [[prop_door_rotating]] then ply:ChatPrint("Dude, this aint a door...") return end
	if trace:GetSkin() <= 14 then trace:SetSkin(trace:GetSkin() + 1) else trace:SetSkin(0) end
end)

local function door_cycle(ply,_)
	if IsValid(ply) and not ply:IsSupporter() then ply:ChatPrint("Sorry, this is a supporter only command") return end
	local ent = ply:GetEyeTrace().Entity
	if not IsValid(ent) or not ent:IsDoor() then ply:ChatPrint("Invalid object, please point towards a door") return end
	if not ent:OwnedBy(ply) then ply:ChatPrint("Sorry, you don't own this door. Only the root door owner may change its skin") return end
	if ent:GetSkin() <= 13 then ent:SetSkin(ent:GetSkin() + 1) else ent:SetSkin(0) end
end
AddChatCommand("/nextdoor", door_cycle, true)

local function RollZDice(ply,_)
    local rnd = math.random(0,100)
    GAMEMODE:TalkToRange(ply, "(DICE) " .. ply:Nick(), "Has rolled(0-100): "..tostring(rnd), 550)
end
AddChatCommand("/roll", RollZDice)

-- PD CP Items
do
timer.Simple(10, function()
    local pos
    local ang
    if (RP1) then
        pos = Vector(-2079,-5,42)
        ang = Angle(0,0,0)
    elseif (RP3) then
        pos = Vector(-3287,336,230)
        ang = Angle(0,0,0)
    elseif (RP4) then
        pos = Vector(-2484,-10,336)
        ang = Angle(0,0,0)
    elseif (RP5) then
        pos = Vector(-1986,280,-99)
        ang = Angle(0,0,0)
    elseif (RP6) then
		pos = Vector(4416,-500,127)
		ang = Angle(0,0,0)
	else
        pos = Vector(4416,-500,127)
        ang = Angle(0,0,0)
        --self:Remove()
    end
    bybhl2ents = {}
    local charg = ents.Create("item_suitcharger")
    charg:SetPos(pos)
    charg:SetAngles(ang)
    charg:Spawn()
    table.insert(bybhl2ents,charg)
    local charg = ents.Create("item_healthcharger")
    charg:SetPos(pos+Vector(0,25,0))
    charg:SetAngles(ang)
    charg:Spawn()
    table.insert(bybhl2ents,charg)
    local charg = ents.Create("item_suitcharger")
    charg:SetPos(pos+Vector(0,50,0))
    charg:SetAngles(ang)
    charg:Spawn()
    table.insert(bybhl2ents,charg)
	end)
end

util.AddNetworkString("ContentMenu")
AddChatCommand("!content", function(ply,args)
	if IsValid(ply) then
		net.Start("ContentMenu")
		net.Send(ply)
	end
	return ""
end)


-- My shitty fix for checking the amount of entities on a map to stop shipment spam.
timer.Create("ActiveEntsChecker",60,0,function()
	ActiveWepEnts = 0
	ActiveMoneyEnts = 0
	for k,v in pairs(ents.FindByClass[[spawned_weapon]]) do
		ActiveWepEnts = ActiveWepEnts + 1
	end
	for k,v in pairs(ents.FindByClass[[spawned_money]]) do
		ActiveMoneyEnts = ActiveMoneyEnts + 1
	end
end)

--temp hween stuff REMEMBER TO REMOVE YOU DIRTY PANTHO! 
-- removing this hook will stop it all loading, no need to remove the CL lua.
-- We can save it for christmas and such, so just comment this stuff out after hween
-- XMAS TIME!
if RP4 then
	util.AddNetworkString("SendCLModels")
	function LoadPropsToClient(ply)
        if not file.Exists("ch_"..game:GetMap()..".txt","DATA") then return end
		local tableu = util.JSONToTable(file.Read("ch_"..game:GetMap()..".txt"))
		net.Start("SendCLModels")
		net.WriteTable(tableu)
		net.Send(ply)
	end

	hook.Add("PlayerAuthed", "HWProps", function(ply)
		timer.Simple(5,function()
			LoadPropsToClient(ply)
		end)
	end)
	--if we has a seat file set, spawn those babies.
    --[[
	function LoadSeats()
		local seats
		if file.Exists("ch_seats"..game:GetMap()..".txt","DATA") then
			seats = util.JSONToTable(file.Read("ch_seats"..game:GetMap()..".txt"))
		else
			return
		end
		for k,v in pairs(seats) do
			if seats["model"] and seats["model"][k] then
				ent = ents.Create("prop_vehicle_prisoner_pod")
				ent:SetModel(seats["model"][k])
				ent:SetPos(util.StringToType(seats["pos"][k],"Vector"))
				ent:SetAngles(util.StringToType(seats["ang"][k],"angle"))
				if seats["mat"] and (seats["mat"][k]) then
					ent:SetMaterial(seats["mat"][k])
				end
				if seats["col"] and (seats["col"][k]) then
					col1 = util.JSONToTable(seats["col"][k])
				end
				ent:SetRenderMode(1)
				ent:Spawn()
				ent:SetColor(Color(0,0,0,0)) -- to load from save set to SetColor(col1)
				ent:GetPhysicsObject():EnableMotion(false)
				ent:SetCollisionGroup(20)
				ent.DoorData = ent.DoorData or {}
				ent.DoorData.NonOwnable = true
				ent.MapSeat = true -- Vehicle passenger seats use them, need a way to tell them apart.
			end
		end
	end	
    ]]--
end
local seats = {"model","pos","ang"}
seats["model"] = {}
seats["pos"] = {}
seats["ang"] = {}
function SaveMapSeats()
  for k,v in pairs(ents.FindByClass("prop_vehicle_prisoner_pod")) do 
      seats["model"][k] = v:GetModel()
      seats["pos"][k] = tostring(v:GetPos())
      seats["ang"][k] = tostring(v:GetAngles())
  end
  PrintTable(seats)
  file.Write("ch_seats"..game:GetMap()..".txt",util.TableToJSON(seats))
end
function LoadSeats()
  local seats
  if file.Exists("ch_seats"..game:GetMap()..".txt","DATA") then
    seats = util.JSONToTable(file.Read("ch_seats"..game:GetMap()..".txt"))
  else
    return
  end
  for k,v in pairs(seats["model"]) do
    if seats["model"] then
      ent = ents.Create("prop_vehicle_prisoner_pod")
      ent:SetModel(seats["model"][k])
      ent:SetPos(util.StringToType(seats["pos"][k],"Vector"))
      ent:SetAngles(util.StringToType(seats["ang"][k],"angle"))
      ent:SetRenderMode(1)
      ent:Spawn()
      if IsValid(ent) and ent:GetModel() == "models/nova/chair_office02.mdl" then
      else
        ent:SetColor(Color(0,0,0,0)) -- to load from save set to SetColor(col1)
      end
      if IsValid(ent) and IsValid(ent:GetPhysicsObject()) then ent:GetPhysicsObject():EnableMotion(false) end
      ent:SetCollisionGroup(20)
      ent.DoorData = ent.DoorData or {}
      ent.DoorData.NonOwnable = true
      ent.MapSeat = true -- Vehicle passenger seats use them, need a way to tell them apart.
    end
  end
end 
function LoadMapProps()
	print("ran")
	local props = util.JSONToTable(file.Read("hw_"..game:GetMap()..".txt"))
	PrintTable(props)
	local col1 = {}
	for k,v in pairs(props["model"]) do
		ent = ents.Create("prop_physics")
		ent:SetPos(util.StringToType(props["pos"][k],"Vector"))
		ent:SetAngles(util.StringToType(props["ang"][k],"angle"))
		ent:SetModel(props["model"][k])
		if props["mat"] and (props["mat"][k]) then
			ent:SetMaterial(props["mat"][k])
		end
		if props["col"] and (props["col"][k]) then
			col1 = util.JSONToTable(props["col"][k])
			PrintTable(col1)
		end
		ent:SetRenderMode(1)
		ent:Spawn()
		ent:SetColor(col1)
		if IsValid(ent:GetPhysicsObject()) then ent:GetPhysicsObject():EnableMotion(false) end
		--ent:SetCollisionGroup(COLLISION_GROUP_WORLD)
		ent.MapProp = true
	end
end

function SaveMapPropsCLStructure()
   props = {}
   local mat
   props = {"class","model","pos","ang","sid","mat","col","data"}
  -- props["class"] = {}
   props["model"] = {}
   props["pos"] = {}
   props["ang"] = {}
  -- props["sid"] = {}
   props["mat"] = {}
   props["col"] = {}
  -- props["data"] = {}
  local I = 1
   for k,ent in pairs(ents.GetAll()) do
      if IsValid(ent) and (ent:GetClass() == "prop_physics") then
        -- props["class"][k] = ent:GetClass()
         props["model"][I] = ent:GetModel()
         props["pos"][I] = tostring(ent:GetPos())
         props["ang"][I] = tostring(ent:GetAngles())
        -- props["sid"][v] = ent.Owner:SteamID()
         props["mat"][I] = ent:GetMaterial()
         props["col"][I] = util.TableToJSON(ent:GetColor())
        -- props["data"][I] = util.TableToJSON(ent.kvs)
		 I = I + 1
      end
   end      
   PrintTable(props)
   file.Write("hwn_"..game:GetMap()..".txt",util.TableToJSON(props))
end

hook.Add("InitPostEntity", "YayBugbait", function()
if not RP3 and not RP5 and not RP6 and not RP7 then
	table.insert(RPExtraTeams[TEAM_HOBO].weapons,"weapon_bugbait")
	LoadSeats()
end
end)

-- Assistant Mayor & Police Deputys
local function AssDepMcFunkyAdd(ply, tar, role)
if not IsValid(ply) then return end

if (role == "mayor" and ply:Team() ~= TEAM_MAYOR) or (role == "police" and ply:Team() ~= TEAM_CHIEF) then
	local msg = (role == "mayor") and "add assistants, become mayor first" or "deputize players, become police chief"
	GAMEMODE:Notify(ply, 1, 6, string.format(LANGUAGE.unable, msg, ""))
	return 
end

if not IsValid(tar) then GAMEMODE:Notify(ply, 1, 6, string.format(LANGUAGE.could_not_find, "that player")) return end

if tar:CantAssist() then
	local msg = (role == "mayor") and "mayor's assistant" or "deputy"
	GAMEMODE:Notify(ply, 1, 6, team.GetName(tar:Team()) .. "'s can't be made a " .. msg)
	return 
end

if role == "mayor" then
	if tar.DarkRPVars.AssMayor then
		GAMEMODE:Notify(ply, 1, 6, "That player is already an assistant. Use /fireassistant to remove.")
		return
	elseif tar.DarkRPVars.PoliceDeputy then
		GAMEMODE:Notify(ply, 1, 6, "That player is police deputy, they can't be a mayor's assistant.")
		return
	else
		-- Assistant limit. Lets try 2 + 1 for every 10 players after the first 10.
		local numplayers = #player.GetAll()
		local cap = (numplayers < 10) and 2 or math.floor(2 + ((numplayers-10)/10))
		local count = 0
		for k,v in pairs (player.GetAll()) do
			if v.DarkRPVars.AssMayor then count = count +1 end
		end
		if count >= cap then
			GAMEMODE:Notify(ply, 1, 6, "The current Mayor Assitant cap of " .. tostring(cap) .. " has been reached.")
			return
		end
		
		DB.Log(ply:Name().."("..ply:SteamID()..") made " .. tar:Name() .."(".. tar:SteamID()..") (Job: " .. team.GetName(tar:Team()) .. ") the mayor's assistant")
		GAMEMODE:NotifyAll(0, 4, tar:Name() .. " has been made the mayor's assistant")
		tar:SetDarkRPVar("AssMayor", true)	
	end
end

if role == "police" then
	if tar.DarkRPVars.PoliceDeputy then
		GAMEMODE:Notify(ply, 1, 6, "That player is already a Deputy. Use /firedeputy to remove.")
		return
	elseif tar.DarkRPVars.AssMayor then
		GAMEMODE:Notify(ply, 1, 6, "That player is already an assistant to the Mayor, they can't be deputized.")
		return
	else
		-- Deputy limit. Lets try 2 + 1 for every 10 players after the first 10.
		local numplayers = #player.GetAll()
		local cap = (numplayers < 10) and 2 or math.floor(2 + ((numplayers-10)/10))
		local count = 0
		for k,v in pairs (player.GetAll()) do
			if v.DarkRPVars.PoliceDeputy then count = count +1 end
		end
		
		if count >= cap then
			GAMEMODE:Notify(ply, 1, 6, "The current Police Deputy cap of " .. tostring(cap) .. " has been reached.")
			return
		end
	
		DB.Log(ply:Name().."("..ply:SteamID()..") made " .. tar:Name() .."(".. tar:SteamID()..") (Job: " .. team.GetName(tar:Team()) .. ") a police deputy")
		GAMEMODE:NotifyAll(0, 4, tar:Name() .. " has been made a deputy police officer")
		tar:SetDarkRPVar("PoliceDeputy", true)
	end
end
end

local function AssDepMcFunkyRemove(ply, tar, role)
if not IsValid(ply) then return end

if role == "quit" then
	if ply.DarkRPVars.AssMayor and ply.DarkRPVars.AssMayor  == true then
		DB.Log(ply:Name().."("..ply:SteamID()..") has quit from their role as the mayor's assistant")
		GAMEMODE:NotifyAll(0, 4, ply:Name() .. " has quit from their role as the mayor's assistant")
		ply:SetDarkRPVar("AssMayor", false)
		return
	elseif ply.DarkRPVars.PoliceDeputy then
		DB.Log(ply:Name().."("..ply:SteamID()..") has quit from their role as police deputy")
		GAMEMODE:NotifyAll(0, 4, ply:Name() .. " has quit from their role as a police deputy")
		ply:SetDarkRPVar("PoliceDeputy", false)
		return
	else
		GAMEMODE:Notify(ply, 1, 6, "You're not a mayor's assistant or deputy, you can't quit.")
		return
	end
end

if (role == "mayor" and ply:Team() ~= TEAM_MAYOR) or (role == "police" and ply:Team() ~= TEAM_CHIEF) then
	local msg = (role == "mayor") and "fire assistants, become mayor first" or "un-deputize players, become police chief"
	GAMEMODE:Notify(ply, 1, 6, string.format(LANGUAGE.unable, msg, ""))
	return 
end

if not IsValid(tar) then GAMEMODE:Notify(ply, 1, 6, string.format(LANGUAGE.could_not_find, "that player")) return end

if role == "mayor" then
	if not (tar.DarkRPVars.AssMayor) then
		GAMEMODE:Notify(ply, 1, 6, "That player is not a mayor assistant, you may not fire them.")
		return
	else 
		DB.Log(ply:Name().."("..ply:SteamID()..") fired " .. tar:Name() .."(".. tar:SteamID()..") (Job: " .. team.GetName(tar:Team()) .. ") from their role as the mayor's assistant")
		GAMEMODE:NotifyAll(0, 4, tar:Name() .. " is no longer mayor's assistant")
		tar:SetDarkRPVar("AssMayor", false)
	end
end

if role == "police" then
	if not (tar.DarkRPVars.PoliceDeputy) then
		GAMEMODE:Notify(ply, 1, 6, "That player is not a deputy, you may not fire them.")
		return
	else
		DB.Log(ply:Name().."("..ply:SteamID()..") fired " .. tar:Name() .."(".. tar:SteamID()..") (Job: " .. team.GetName(tar:Team()) .. ") from their role as a police deputy")
		GAMEMODE:NotifyAll(0, 4, tar:Name() .. " is no longer a deputy police officer")
		tar:SetDarkRPVar("PoliceDeputy", false)
	end
end
end

function AssDepMcFunkyLeft(job)

	local boss = job == "AssMayor" and "Mayor" or "Police Chief"
	local bossc = job == "AssMayor" and Color(150, 20, 20, 255) or Color(20, 20, 255, 255)
	local jobname = job == "AssMayor" and "Mayor Assistant" or "Police Deputy"
	
	local noboss = false	
	for _,ply in pairs(player.GetAll()) do
		if ply.DarkRPVars[job] then noboss = true break end -- We only need one player to be using the assistant/deputy role, no need to keep searching.
	end	
	
	if noboss then
		
		local function domessage(count)
		for _,ply in pairs(player.GetAll()) do
				if ply.DarkRPVars[job] then
					
					local msg = {Color(255,255,255), [[(]], os.date("%H:%M:%S") ,[[) The ]], bossc, boss , Color(255,255,255), [[ has left, unless someone takes his place you will fired from your role as ]], bossc ,jobname, Color(255,255,255), [[ in ]], Color(96,255,145), tostring(count), Color(255,255,255), (count > 1 and [[ minutes.]] or [[ minute.]])}
					net.Start("ColorChatPrints")
					net.WriteTable(msg)
					net.Send(ply)
				
				end
		end
		end
		
		domessage(1)
		
		local count = 1
		timer.Create("demoteall"..job, 60, 1, function()
		
		--if count == 3 or count == 1 then		
		--	domessage(count)
		--	count = count-1
		--	return
		--elseif count > 0 then
		
		--count = count-1
		
		--else
			for _,ply in pairs(player.GetAll()) do
				if ply.DarkRPVars[job] then
				
					local msg = {Color(255,255,255), [[(]], os.date("%H:%M:%S") ,[[) You've been fired from your role as ]], bossc, jobname , Color(255,255,255), [[ because there is no ]], bossc ,boss, Color(255,255,255), [[.]]}
					net.Start("ColorChatPrints")
					net.WriteTable(msg)
					net.Send(ply)
					AssDepMcFunkyRemove(ply, ply, "quit")
					ply:Spawn()
				
				end	
			end
		
			--count = 5
			--return
		
		--end
	
		end)
	
	
	end
	
end

hook.Add("PlayerDisconnected", "AssistantCheck", function()

local ischief = false
local ismayor = false

for k, v in pairs(player.GetAll()) do
	if v:Team() == TEAM_MAYOR then ismayor = true end
	if v:Team() == TEAM_CHIEF then ischief = true end				
end

if not ismayor then
	AssDepMcFunkyLeft("PlayerQuit")
end

if not ischief then
	AssDepMcFunkyLeft("PoliceDeputy")
end

end)

AddChatCommand("/addassistant", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		AssDepMcFunkyAdd(ply,tar,"mayor")
	end
	return ""
end)

AddChatCommand("/fireassistant", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		AssDepMcFunkyRemove(ply,tar,"mayor")
	end
	return ""
end)

AddChatCommand("/leaveassistant", function(ply)
	ply:ChatPrint("Call Mayor Quit")
	AssDepMcFunkyRemove(ply,ply,"quit")
	return ""
end)

AddChatCommand("/deputize", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		AssDepMcFunkyAdd(ply,tar,"police")
	end
	return ""
end)

AddChatCommand("/firedeputy", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		AssDepMcFunkyRemove(ply,tar,"police")
	end
	return ""
end)

AddChatCommand("/leavedeputy", function(ply)
	ply:ChatPrint("Call Deputy Quit")
	AssDepMcFunkyRemove(ply,ply,"quit")
	return ""
end)

function GetPlayerEnts(ply)
if not ply:IsValid() or not ply:IsPlayer() then return end

	local plyents = {}

	for k,v in pairs (ents.GetAll()) do
		if v.Owner == ply or v.FPPOwner == ply then
		
			local class = v:GetClass()
					
			if not plyents[class] then
				plyents[class] = {v}
			else
				plyents[class][#plyents[class]+1] = v
			end
			
		end

	end
	
	return plyents
		
end

local function GetPropcountMsg(ply)
if not ply:IsValid() or not ply:IsPlayer() then return end
	
	-- The ents below (+ a stab at displaying any owned wire ent not listed) are what we're interested in, everything else (cars, doors, weapons etc..) is ignored.
	local trackedents = {
					["prop_physics"] = { ["txt"] = "Prop",
										 ["convar"] = "sbox_maxprops" 
										},
					["gmod_wire_moneypot"] = { ["txt"] = "Moneypot",
										 ["convar"] = "sbox_maxmoneypots" 
										},
					["sent_keypad"] = { ["txt"] = "Keypad",
										 ["convar"] = "sbox_maxkeypads" 
										},
					["gmod_button"] = { ["txt"] = "Button",
										 ["convar"] = "sbox_maxwire_buttons" 
										},
					["gmod_wire_expression2"] = { ["txt"] = "E2",
										 ["convar"] = "sbox_maxwire_expressions" 
										}					
					 }

	--local plyents = GetPlayerEnts(ply)
	
	--if not plyents then return false end
	
	--local sortedents = table.SortByKey(plyents, false) -- Why is SortByKey not working?
	
	local sortedents = GetPlayerEnts(ply)
	if not sortedents or next(sortedents) == nil then return false end -- Nothing found / empty table.
	
	local x = {}
	
	for k,v in pairs (sortedents) do
		if trackedents[k] then
			x[#x+1] = {
						["class"] = k,
						["num"] = #v,
						["txt"] = trackedents[k].txt .. ( (#v > 1) and "s" or "" ),
						["convar"] = trackedents[k].convar
					}
		elseif string.find(k, "gmod_wire") then
			x[#x+1] = {
						["class"] = k,
						["num"] = #v,
						["txt"] = "Wire " .. string.gsub(k, "gmod_wire_", ""):gsub("^%l", string.upper) .. ( (#v > 1) and "s" or "" ),
						["convar"] = "sbox_max" .. string.gsub(k, "gmod_", "" ) .. "s" -- Urgh lets have a guess at what the convar might be, these will probably need to be hardcoded.
					}
		end	
	end
	
	if next(x) == nil then return false end -- Nuffin found guv.
	
	local msg = {}
	for k,v in pairs (x) do
		local limit = (v.class == "prop_physics" and ply:IsSupporter() and GetConVarNumber( v.convar ) *2.6) or GetConVarNumber( v.convar ) or 0
		msg[#msg+1] = (  (limit > 0 and v["num"] >= limit) and Color(255,0,0) or ( limit > 0 and v["num"] >= math.floor(limit/2)) and Color(255,93,0) or Color(96,255,145))
		msg[#msg+1] = tostring(v["num"])
		msg[#msg+1] = Color(255,255,255)
		msg[#msg+1] = "/" .. (limit == 0 and "?" or tostring(limit))
		msg[#msg+1] = " " .. v["txt"] ..  (k == #x and " spawned." or k == #x-1 and " and " or ", ")
	end
	
	return msg

end

local function BybPropCount(ply,args)

	local tar = FindPlayer(args)
	local results = {}
	if args ~= "" and (ply:IsAdmin() or ply:IsSuperAdmin()) and ply ~= tar then
		if not IsValid(tar) then
			ply:ChatPrint("That's not a valid player. Use !proplimit without an argument for yourself.")
			return ""
		end
		results = GetPropcountMsg(tar) or {"no props spawned."}
	else
		results =  GetPropcountMsg(ply) or {"no props spawned."}
	end
	
	local prefix = {Color(255,255,255), "You have "}
	if args ~= "" and (ply:IsAdmin() or ply:IsSuperAdmin()) then
		prefix = {Color(0,0,255), tar:Nick() or "That user",Color(255,255,255), " has "}		
	end
	msg = table.Add(prefix, results) -- merge prefix + results.
		
	net.Start("ColorChatPrints")
	net.WriteTable(msg)
	net.Send(ply)
	
	return ""
end

AddChatCommand("!propcount", BybPropCount)
AddChatCommand("!proplimit", BybPropCount)

local function ByBSuperEntSpawn(ply,args)

	if not ply:IsSuperAdmin() then return "" end
	if ply:isArrested() then ply:ChatPrint("You can't spawn SuperEnts whilst arrested.") return "" end
	
	if not SuperEntTable then
		SuperEntTable = {}
	end
	
	local entmax = 0
		
	if SuperEnts.chairs[args] then
		entmax = 6
		
		if not SuperEntTable[ply:SteamID() .. "_chairs"] then
			SuperEntTable[ply:SteamID() .. "_chairs"] = 0
		end
		
		local enttable = SuperEntTable[ply:SteamID() .. "_chairs"]
		if enttable >= entmax then
			ply:ChatPrint("You've hit the max limit of " .. tostring(entmax) .. " SuperEnt chairs.")
			return ""
		end
		
		 local trace = {};
		trace.start = ply:EyePos();
		trace.endpos = trace.start + ply:GetAimVector() * 85;
		trace.filter = ply;

		local tr = util.TraceLine(trace);

		local item = ents.Create("prop_vehicle_prisoner_pod")
		item:SetModel(SuperEnts.chairs[args][2])
		item.Owner = ply
		item.FPPOwner = ply
		item.SpawnedBy = ply
		item.STID = ply:SteamID()
		item:SetPos(tr.HitPos)
		item.SID = ply.SID
		item.SuperEnt = true
		item.SuperEntSuffix = "_chairs"
		item:Spawn()

		SuperEntTable[ply:SteamID() .. "_chairs"] = enttable + 1

		DB.Log(ply:Nick().. " (" .. ply:SteamID() .. ") spawned a " .. SuperEnts.chairs[args][1])
	
		return ""
	end
	
	ply:ChatPrint("That's not a valid SuperEnt.")
	return ""
end
AddChatCommand("/superent", ByBSuperEntSpawn)

hook.Add( "EntityRemoved", "SuperEntCleanup", function(ent)
	if ent.SuperEnt then
		local enttable = SuperEntTable[ent.STID .. ent.SuperEntSuffix]
		SuperEntTable[ent.STID .. ent.SuperEntSuffix] = enttable <= 0 and 0 or enttable - 1 
	end
end)

hook.Add("EntityTakeDamage", "SuperEntChairDamage", function(target, dmginfo)
	if target.SuperEnt then return false end
end)

util.AddNetworkString("ByBClearGibs")
concommand.Add("cleargibs", function(ply)
     
	net.Start("ByBClearGibs")
	
	if (ply:IsAdmin()) then
		net.Broadcast()
    else
		net.Send(ply)
	end

end)

hook.Add( "OnEntityCreated", "Blacklisted ent removal", function(ent)
    timer.Simple(10,function()
        if IsValid(ent) and IsValid(ent.FPPOwner) and ent:GetClass() == "gmod_wire_expression2" then
            local code = ent.buffer or "meh"
            local filename = string.lower(util.CRC(code))
            if not file.IsDir("spawnede2s","DATA") then file.CreateDir("spawnede2s") end
            if not file.IsDir("spawnede2s/"..ent.FPPOwner:UniqueID(),"DATA") then file.CreateDir("spawnede2s/"..ent.FPPOwner:UniqueID()) end
            file.Write("spawnede2s/"..filename..".txt",code)
            DB.Log(ent.FPPOwner:Name() .. "(" ..ent.FPPOwner:SteamID() ..")" .. " has spawned E2 CRC: spawnede2s/"..filename..".txt")
            --timer.Create("wire_expression2_resetprogress_" .. ent.FPPOwner:UniqueID(), 0.75, 1, function() Expression2SetProgressServer(ent.FPPOwner) end)
        
            if IsValid(ent.FPPOwner) and not ent.FPPOwner:IsSupporter() then ent:Remove() end
        end
    end)
end)



-- Steam API key setting, so it's outside the shared file.
SAPI.SetKey("1234")

local cache = cache or {}
local cache2 = cache2 or {}
local function FormatTb( tab )
    local t = {}
    for k, v in pairs( tab ) do
        local time, cut = v.timechanged, 0
        local day, month, year
        cut = ( time:sub( 0, 2 ):find( " " ) and 3 ) or 4
        day = time:sub( 0, cut - 2 )
        month = string.sub( string.gsub( time:sub( cut, cut + 3 ), ",", "" ), 0, 3 )
        year = time:sub( cut + 5, cut + 8 ), " "
        year = year:find( " " ) and os.date( "%Y" ) or year
        t[v.newname] = { d = day, m = month, y = year }
    end    
    return t
end

function RetrieveAliases( ply,url,caller )
    if cache[ply] then 
        for k,v in pairs(cache[ply]) do
            caller:PrintMessage(2,tostring(k) .. " Dated "..tostring(v.d).."/"..tostring(v.m).."/" ..tostring(v.y))
        end
    end
    if cache[ply] then return cache[ply] end
    local function OnSuccess( body )
        local t = FormatTb(util.JSONToTable( body ))
        cache[ply] = t
        for k,v in pairs(t) do
            caller:PrintMessage(2,tostring(k) .. " Dated "..tostring(v.d).."/"..tostring(v.m).."/" ..tostring(v.y))
        end
        applez = t
    end
    
    local function OnFail( err )
        print( "PrevAliases ERROR: " .. err )
    end
    
    http.Fetch( url.."ajaxaliases", OnSuccess, OnFail )
end

concommand.Add("rp_advlookup", function(ply,_,args)
    if not ply:IsAdmin() or not args then return end
    local tar = FindPlayer(args[1])
    if not IsValid(tar) then return end
    if tar:IsTrustedAdmin() or tar.HidingSuper then
        tar:ChatPrint("DingDing - rp_advlookup by: "..tostring(ply:Name().."("..ply:SteamID()..")"))
    end
    local sid = tar:SteamID()
    local url
    SAPI.IsPlayingSharedGame(sid,GAME_GARRYSMOD,function(cb)
        if cb and cb.response and cb.response.lender_steamid then
            if tar.OwningID then
                ply:PrintMessage(2,"If on family friends there real ID is: "..tostring(tar.OwningID))
                if cache2[tar] then 
                    for k,v in pairs(cache2[tar]) do
                        if tostring(k) == "profileurl" then url = v end
                            ply:PrintMessage(2,string.format("%s%s%s",tostring(k),string.rep(" ",10),tostring(v)))
                        --ply:PrintMessage(2,tostring(k) .. " " .. tostring(v))
                    end
                    ply:PrintMessage(2,"********************************************************")
                    ply:PrintMessage(2,"                     Previous name2")
                    ply:PrintMessage(2,"********************************************************")
                    RetrieveAliases( tar,url,ply )
                else
                    SAPI.GetPlayerSummaries(sid,function(cb)
                        if cb and cb.response and cb.response.players and cb.response.players[1] then
                            cache2[tar] = cb.response.players[1]
                            for k,v in pairs(cb.response.players[1]) do
                                if tostring(k) == "profileurl" then url = v end
                                ply:PrintMessage(2,string.format("%s%s%s",tostring(k),string.rep(" ",10),tostring(v)))
                            end
                        end
                        ply:PrintMessage(2,"********************************************************")
                        ply:PrintMessage(2,"                 Previous name2")
                        ply:PrintMessage(2,"********************************************************")
                        RetrieveAliases( tar,url,ply )
                    end)
                end
            else
                DB.Query("SELECT aid,srv_group FROM sbans.sb_admins WHERE authid = "..sql.SQLStr(tostring(cb.response.lender_steamid))..";", function(data)
                    if data and data[1] and data[1].srv_group == "superadmin" then
                        tar.OwningID = "0"
                        tar.HidingSuper = truecb.response.lender_steamid
                    else
                        tar.OwningID = cb.response.lender_steamid
                    end
                    ply:PrintMessage(2,"If on family friends there real ID is: "..tostring(tar.OwningID))
                    if cache2[tar] then 
                        for k,v in pairs(cache2[tar]) do
                            if tostring(k) == "profileurl" then url = v end
                                ply:PrintMessage(2,string.format("%s%s%s",tostring(k),string.rep(" ",10),tostring(v)))
                            --ply:PrintMessage(2,tostring(k) .. " " .. tostring(v))
                        end
                        ply:PrintMessage(2,"********************************************************")
                        ply:PrintMessage(2,"                  Previous name2")
                        ply:PrintMessage(2,"********************************************************")
                        RetrieveAliases( tar,url,ply )
                    else
                        SAPI.GetPlayerSummaries(sid,function(cb)
                            if cb and cb.response and cb.response.players and cb.response.players[1] then
                                cache2[tar] = cb.response.players[1]
                                for k,v in pairs(cb.response.players[1]) do
                                    if tostring(k) == "profileurl" then url = v end
                                    ply:PrintMessage(2,string.format("%s%s%s",tostring(k),string.rep(" ",10),tostring(v)))
                                end
                            end
                            ply:PrintMessage(2,"********************************************************")
                            ply:PrintMessage(2,"Previous name2")
                            ply:PrintMessage(2,"********************************************************")
                            RetrieveAliases( tar,url,ply )
                        end)
                    end
                end)
            end
        end
    end)
end)


-- Goomba


hook.Add("OnPlayerHitGround", "Goomba", function(ply, in_water, on_floater, speed)
  if in_water or speed < 450 or not IsValid(ply) then return end

   -- Everything over a threshold hurts you, rising exponentially with speed
   local damage = math.pow(0.05 * (speed - 420), 1.4)

   -- I don't know exactly when on_floater is true, but it's probably when
   -- landing on something that is in water.
  -- if on_floater then damage = damage / 2 end

   -- if we fell on a dude, that hurts (him)
   local ground = ply:GetGroundEntity()
   if IsValid(ground) and ground:IsPlayer() then
      if math.floor(damage) > 0 then
         local att = ply

         if att:Team() == TEAM_ADMIN then return end -- no Goomba stomping for AoD.
         
         -- if the faller was pushed, that person should get attrib
         local push = ply.was_pushed
         if push then
            -- TODO: move push time checking stuff into fn?
            if math.max(push.t or 0, push.hurt or 0) > CurTime() - 4 then
               att = push.att
            end
         end

         local dmg = DamageInfo()

         if att == ply then
            -- hijack physgun damage as a marker of this type of kill
            dmg:SetDamageType(DMG_CRUSH + DMG_PHYSGUN)
         else
            -- if attributing to pusher, show more generic crush msg for now
            dmg:SetDamageType(DMG_CRUSH)
         end

         dmg:SetAttacker(att)
         dmg:SetInflictor(att)
         dmg:SetDamageForce(Vector(0,0,-1))
         dmg:SetDamage(damage)

         ground:TakeDamageInfo(dmg)
      end

      -- our own falling damage is cushioned
      damage = damage / 3
   else return end

   if math.floor(damage) > 0 then
      local dmg = DamageInfo()
      dmg:SetDamageType(DMG_FALL)
      dmg:SetAttacker(game.GetWorld())
      dmg:SetInflictor(game.GetWorld())
      dmg:SetDamageForce(Vector(0,0,1))
      dmg:SetDamage(damage)

     ply:TakeDamageInfo(dmg)

      -- play CS:S fall sound if we got somewhat significant damage
      --if damage > 5 then
      --   sound.Play(table.Random(fallsounds), ply:GetShootPos(), 55 + math.Clamp(damage, 0, 50), 100)
     -- end
   end
end)


-- Wire concommand redeclaring.
timer.Simple(5,function()
    concommand.Add("wire_expression_reset", function(player, command, args)
        if true then return end
    end)
end)

-- hmmm personal physpurge
concommand.Add("unweldall",function(ply,cmd,args)
    local phys;
    if not ply:IsSupporter() then return end
    for _, ent in pairs (ents.GetAll()) do
        if IsValid(ent.FPPOwner) and IsValid(ply) and ply == ent.FPPOwner then
            phys = ent:GetPhysicsObject()
            -- Enable motion for things that shouldn't be frozen
            if (enablemotionfor[ent:GetClass()]) then
                phys:EnableMotion(false);
            elseif (phys:IsValid()) then
                phys:EnableMotion(false);
            end
            constraint.RemoveAll(ent)
        end
    end
    ply:ChatPrint("Removed all ya welds and froze your stuff.")
end)


hook.Add("PlayerInitialSpawn", "PlayerInitialSpawnConnectMsg", function(ply)
    if IsValid(ply) then
        local col1 = Color(math.random(0,255),math.random(0,255),math.random(0,255))
        local col2 = Color(math.random(50,205),math.random(50,205),math.random(50,205))
        name = ply:Nick()
        local args = {col1,name,col2," has connected"}
        net.Start("ColorChatPrints")
        net.WriteTable(args)
        net.Broadcast()
    end
end)