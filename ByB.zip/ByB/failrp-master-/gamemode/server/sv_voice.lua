-- The idea of this quick module is to work exactly like DarkRP's chat /radio system.
-- Users will enter a channel number for there radios consisting of up to 5 digits.
-- All uses on the same bandwidth will here each other.

util.AddNetworkString("CreateChannel_voip")
util.AddNetworkString("JoinChannel_voip")
util.AddNetworkString("LeaveChannel_voip")
util.AddNetworkString("SendVG_voip")
util.AddNetworkString("OpenVG_voip")
util.AddNetworkString("toggle_voip")
VG = {}
VG.Channels = {}
local test = {}
test.Chan = 1
test.Pass = nil
test.Occupants = {}
test.Title = "Goverment Only (IsCP)"
test.Owner = nil
VG.Channels[test.Chan] = test
local test = {}
test.Chan = 2
test.Pass = nil
test.Occupants = {}
test.Title = "Public 1"
test.Owner = nil--Entity(1)
VG.Channels[test.Chan] = test

local function UpdateVG()
	net.Start("SendVG_voip")
	net.WriteTable(VG)
	net.Broadcast()
end

net.Receive("CreateChannel_voip", function (len,ply)
	if not IsValid(ply) then return end
	local title = net.ReadString()
	local pass = net.ReadString()
	local newchan = {}
	newchan.Chan = ply:EntIndex() + 10
	if pass == "*NO PASSWORD*" then
		newchan.Pass = nil
	else
		newchan.Pass = pass
	end
	newchan.Occupants = {}
	newchan.Title = title
	newchan.Owner = ply
	VG.Channels[ply:EntIndex()+10] = newchan
	if ply.VoipChannel and VG.Channels[ply.VoipChannel] and VG.Channels[ply.VoipChannel].Occupants then
		for k,v in pairs(VG.Channels[ply.VoipChannel].Occupants) do
			if v == ply then
				VG.Channels[ply.VoipChannel].Occupants[k] = nil
			end
		end
	end
	ply.VoipChannel = ply:EntIndex()+10
	table.insert(VG.Channels[ply:EntIndex()+10].Occupants,ply)
	UpdateVG()
end)

net.Receive("JoinChannel_voip", function (len,ply)
	if not IsValid(ply) then return end
	local chan = net.ReadInt(32)
	if chan == 1 and not ply:IsCP() then ply:ChatPrint("Authorized Personel Only!") return end
	--local pass = net.ReadString() WHY DID I DO THAT? Now you can clientside hack into channels, but i doubt anyone will.
	if ply.VoipChannel and VG.Channels[ply.VoipChannel] and VG.Channels[ply.VoipChannel].Occupants then
		for k,v in pairs(VG.Channels[ply.VoipChannel].Occupants) do
			if v == ply then
				VG.Channels[ply.VoipChannel].Occupants[k] = nil
				ply.VoipChannel = nil
			end
		end
	end
	if VG.Channels[chan] then
		ply.VoipChannel = chan
		table.insert(VG.Channels[chan].Occupants,ply)
		UpdateVG()
	 else ply:ChatPrint("Error sv_voice.lua line 73, no table") end
end)

net.Receive("LeaveChannel_voip", function (len,ply)
	if not IsValid(ply) then return end
	LeaveChan(ply)
end)

local function LeaveChan(ply)
	if IsValid(ply) and ply.VoipChannel then
		for k,v in pairs(VG.Channels[ply.VoipChannel].Occupants) do
			if v == ply then
				VG.Channels[ply.VoipChannel].Occupants[k] = nil
			end
		end
		if VG.Channels[ply.VoipChannel].Owner and VG.Channels[ply.VoipChannel].Owner == ply and VG.Channels[ply.VoipChannel].Occupants[1] then
			VG.Channels[ply.VoipChannel].Owner = VG.Channels[ply.VoipChannel].Occupants[1]
		end
		if #VG.Channels[ply.VoipChannel].Occupants < 1 then
			if tonumber(ply.VoipChannel) > 2 then VG.Channels[ply.VoipChannel] = nil end
		end
		ply.VoipChannel = nil
    	UpdateVG()
	end
end


concommand.Add("voip_kick", function(ply,_,args)
	local tar = Entity(args[1])
    if not IsValid(ply) or not ply.VoipChannel or not IsValid(tar) or not tar:IsPlayer() then return end
    if not VG.Channels[ply.VoipChannel] then ply:ChatPrint("Error, channel not found") return end
    if VG.Channels[ply.VoipChannel].Owner == ply then
		LeaveChan(tar)
		ply:ChatPrint("User has been kicked.")
		tar:ChatPrint("You've been kicked by a channel admin.")
		UpdateVG()
    end
end);

concommand.Add("voip_menu",function(ply)
	net.Start("OpenVG_voip")
	net.WriteTable(VG)
	net.Send(ply)
end)

AddChatCommand("/voip", function(ply,args)
	net.Start("OpenVG_voip")
	net.WriteTable(VG)
	net.Send(ply)
end)

concommand.Add("voip_leave",function(ply)
	if not IsValid(ply) or not ply.VoipChannel then ply:ChatPrint("Trying to leave channel, but it says you're not in a channel. Hax? - Report to pantho") end
	LeaveChan(ply)
end)

concommand.Add("voip_givechan", function(ply,_,args)
	local tar = Entity(args[1])
    if not IsValid(ply) or not ply.VoipChannel or not IsValid(tar) or not tar:IsPlayer() then return end
    if VG.Channels[ply.VoipChannel] and VG.Channels[ply.VoipChannel].Owner == ply then 
    	VG.Channels[ply.VoipChannel].Owner = tar
    	ply:ChatPrint("Ownership given to "..tar:Name())
    	tar:ChatPrint("You've been set as owner of VOIP: "..VG.Channels[ply.VoipChannel].Title)
    	UpdateVG()
    end
    ply:ChatPrint("Sorry, you're either not admin or I can't find the user.")
end);

timer.Create("PlayersCanHearVoiceCache",1,0, function()
	for k,talker in pairs(player.GetAll()) do
		talker.peoplelistening = {}
		for _,listener in pairs(player.GetAll()) do
			if tonumber(talker.Voip) == 1 then
				if talker.VoipChannel ~= nil and talker.VoipChannel == listener.VoipChannel then
					talker.peoplelistening[listener] = true
				else
					talker.peoplelistening[listener] = false
				end
			elseif listener:GetShootPos():Distance(talker:GetShootPos()) < 550 then
				talker.peoplelistening[listener] = true
			else
				talker.peoplelistening[listener] = false
			end
		end
	end
end)

--[[ TODO
4. Figure out how to set it up to a seperate keybind.
6. See if I can use RemoveItem for fluid menu loading.
]]--
concommand.Add("voip_toggle",function(ply,_,args)
	if IsValid(ply) then
		ply.Voip = args[1]
	end
end)
hook.Add("PlayerCanHearPlayersVoice","debugvarvoip", function(ply)  end)

hook.Add("PlayerDisconnected","playerdiscconect_voip", function(ply)
	if ply.VoipChan then
		LeaveChan(ply)
		UpdateVG()
	end
end)

hook.Add("PlayerAuth","playerauth_voip", function(ply)
	ply.Voip = 0
	ply.VoipChannel = nil
end)

timer.Create("FixChannels",5,0,function()
	local changed = false
	for k,v in pairs(VG.Channels) do
		if tonumber(k) > 2 then
			if v.Occupants and #v.Occupants <1 then 
				VG.Channels[k] = nil
				changed = true
			elseif v.Occupants then
				for n,c in pairs(v.Occupants) do
					if not IsValid(c) then
						v.Occupants[n] = nil
						changed = true
					end
				end
			end
		end
	end	
	if changed then 
		UpdateVG()
	end
end)