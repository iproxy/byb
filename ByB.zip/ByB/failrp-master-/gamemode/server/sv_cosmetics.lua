-- Server side affects to the cosmetics.
if true then return end
hook.Add("InitPostEntity", "CosmeticsPostEntHookk", function()
	-- Fire for the christmas campfire.
	local fire = ents.Create([[env_fire]])
	fire:SetPos(Vector(-2610,-1552,199))
	fire:SetKeyValue([[firesize]], 100) 
	fire:Fire([[enable]],[[]],0)
	fire:Fire([[StartFire]],[[]],0)

	-- All Z SEATS! ... actually i'll just modify the permaseats file me thinks.
end)