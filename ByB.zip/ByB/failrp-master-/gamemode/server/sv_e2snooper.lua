util.AddNetworkString("e2chipsnooper")
util.AddNetworkString("E2SnooperfileSend")
util.AddNetworkString("E2snopperfetch")
local Chips = {};
local Chip = {};
local e2name,e2ops,mathvar,owner,cputime;
local ophistory = {};
local function ScanE2s()
    for k,v in pairs(Chips) do
        if not IsValid(Entity(k)) then 
            Chips[k] = nil;
        end
        if IsValid(Entity(k)) and Entity(k):GetClass() == "gmod_wire_expression2" then
        else
            Chips[k] = nil;
        end
    end
    for _,ent in pairs(ents.FindByClass("gmod_wire_expression2")) do
        ophistory = {}
        mathvar = 0;
        owner = 0;
        cputime = 0;
        if Chips[ent:EntIndex()] then
            ophistory = Chips[ent:EntIndex()]["ophistory"];
        end
        if ent.FPPOwner then
            owner = ent.FPPOwner:EntIndex();
        end
        if ent.context and ent.context.prfbench and ent.context.timebench then
            e2ops = math.Round(ent.context.prfbench,0) or 0;
            cputime = math.Round(ent.context.timebench*1000000,0) or 0;
        else
            e2ops = 0;
        end

        e2name = ent.name or "Error?";
        table.insert(ophistory,e2ops);
        for _,num in pairs(ophistory) do
            mathvar = mathvar + num;
        end
        mathvar = math.Round(mathvar / #ophistory,0);
        Chip = {owner,e2name,mathvar,e2ops,cputime};
        Chip["ophistory"] = ophistory;
        Chips[ent:EntIndex()] = Chip;
    end
end

timer.Create("E2snooperscan",1,0, function()
    ScanE2s()
end)

local function Broadcasts(args)
    if args then
        net.Start("ColorChatPrints");
        net.WriteTable(args);
        net.Broadcast();
    end
end

local function E2SnopperUpdate(ply,_,args)    
    if not ply:IsAdmin() then return end
	if args and args[1] then
		local FilteredChips = {}
		for k,v in pairs(Chips) do
			if IsValid(Entity(k)) then
				if string.match(Entity(k).buffer,args[1]) then 
					FilteredChips[k] = v
				end
			end
		end		
		net.Start("e2chipsnooper");
		net.WriteTable(FilteredChips);
		net.Send(ply)
		return
	end
    net.Start("e2chipsnooper");
    net.WriteTable(Chips);
    net.Send(ply);
end
concommand.Add("e2snooper", function(ply,_,args)
	 E2SnopperUpdate(ply,_,args)
end)

local function FetchE2(ply,ent)
	if not IsValid(ent) then ply:ChatPrint("Error ent not real? Confused I am, e2snooper 68 sv") return end
    if not ply.RootMode then
        local args = {Color(255,50,0),ply:Name().."("..ply:SteamID()..") Has viewed an E2 owned by: " .. name};
        DB.Log(ply:Name().."("..ply:SteamID()..") Has viewed an E2 owned by: " .. name);
        Broadcasts(args);
    end
	code = ent.buffer
    net.Start("E2SnooperfileSend");
    net.WriteString(code);
    net.Send(ply);
end

net.Receive("E2snopperfetch", function(len, ply)
    if not ply:IsSuperAdmin() then return end
    ent = Entity(net.ReadInt(32));	
    name = "<Nameless>";
    if IsValid(ent) then
        if IsValid(ent.FPPOwner) then 
            name = ent.FPPOwner:Name();
        end
        FetchE2(ply,ent);
    end
end)