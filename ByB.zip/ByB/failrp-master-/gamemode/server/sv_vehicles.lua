local showcar1
local showcar2
local showcar3
local props
--resource.AddWorkshop("162028278") -- vhc skins p2
--resource.AddWorkshop("162029261") -- vhc skins p1
--resource.AddWorkshop("162033747") -- gui mats
--resource.AddWorkshop("162314092") -- horn wav files
hook.Add("InitPostEntity", "CarSellerSpawn", function()
	timer.Simple(5, function() 
		if RP3 then
			for k,v in pairs(ents.FindByClass[[func_tracktrain]]) do
				if v:GetPos():Distance(Vector(-3106,145,172)) > 200 then
					v:Remove()
				end
			end
		end
		--sql.Query("CREATE TABLE IF NOT EXISTS storedCars (steamid varchar(20), vehicleScript varchar(30));")
		theGuy = ents.Create("npc_vehicles")
		if(game.GetMap() == "rp_bangclaw") then
			theGuy:SetPos(Vector(773,947,72))
			theGuy:SetAngles(Angle(0,-90,0))
			local vhcmod = ents.Create("npc_vhcmod")
			vhcmod:SetPos(Vector(773,1000,72))
			vhcmod:SetAngles(Angle(0,-90,0))
			vhcmod:Spawn()
			vhcmod:Activate()
		--elseif(RP5) then
		--	theGuy:SetPos(Vector(-1310,-6734,-134))
		--	theGuy:SetAngles(Angle(0,90,0))
		--	local vhcmod = ents.Create("npc_vhcmod")
		--	vhcmod:SetPos(Vector(-1310,-6634,-134))
		--	vhcmod:SetAngles(Angle(0,90,0))
		--	vhcmod:Spawn()
		--	vhcmod:Activate()
		elseif(RP3) then
			theGuy:SetPos(Vector(1934,4453,49))
			theGuy:SetAngles(Angle(0,-90,0))
			local vhcmod = ents.Create("npc_vhcmod")
			vhcmod:SetPos(Vector(2244,4433,49))
			vhcmod:SetAngles(Angle(0,-180,0))
			vhcmod:Spawn()
			vhcmod:Activate()
		else
			return
		end
		theGuy:Spawn()
		theGuy:Activate()
		--[[timer.Create("npcpos", 180, 0, function()
			local pos = theGuy:GetPos()
			local npcradius = pos:Distance(Vector(-7265.040039, -6034.663574, 106.031250))
			if (npcradius >= 10) then
				theGuy:SetPos(Vector(-7265.040039, -6034.663574, 106.031250))
			end
		end)
		]]--
		timer.Simple(30, function()
		   if RP6 then props = util.JSONToTable(file.Read("mapprops/bangclaw.txt")) elseif RP5 then props = util.JSONToTable(file.Read("mapprops/rp_downtown_v4c.txt")) end
		   if RP3 then props = util.JSONToTable(file.Read("mapprops/evilmelon.txt")) end
		   local col1 = {}
		   for k,v in pairs(props["model"]) do
				 ent = ents.Create(props["class"][k])
				 ent:SetPos(util.StringToType(props["pos"][k],"Vector"))
				 ent:SetAngles(util.StringToType(props["ang"][k],"angle"))
				 ent:SetModel(props["model"][k])
				 if (props["mat"][k]) then
					ent:SetMaterial(props["mat"][k])
				 end
				 col1 = util.JSONToTable(props["col"][k])
				 PrintTable(col1)
				 ent:SetRenderMode(1)
				 ent:Spawn()
				 ent:SetColor(col1)
				 if IsValid(ent:GetPhysicsObject()) then ent:GetPhysicsObject():EnableMotion(false) end
				 --ent:SetCollisionGroup(COLLISION_GROUP_WORLD)
				 ent.MapProp = true
		   end
		end)
	end)
	if (RP6) then 
		for k,v in pairs(ents.FindInSphere(Vector(782,500,138),50)) do if IsValid(v)and v:IsDoor() then v:Remove() end end
	end
	if RP6 then
		timer.Simple(10,function() -- this code really makes me cry, but fuck it
			for k,v in pairs(ents.FindByClass[[prop_physics]]) do
				if IsValid(v) then
					if v:GetModel() == "models/tdmcars/murcielago.mdl" then
						showcar1 = v
					elseif v:GetModel() == "models/tdmcars/ferrari512tr.mdl" then
						showcar2 = v
					elseif v:GetModel() == "models/tdmcars/dbs.mdl" then
						showcar3 = v
					end
				end
			end
			timer.Create("showroomcarswitcher",360,0, function()
				local ding = false
				local rnd = math.random(1,table.Count(cars))
				local i = 0
				if IsValid(showcar1) then
					for k,v in pairs(cars) do
						i = i +1
						if i == rnd then
							showcar1:SetModel(v.Model)
						end
					end
				end
				local rnd = math.random(1,table.Count(cars))
				local i = 0
				if IsValid(showcar2) then
					for k,v in pairs(cars) do
						i = i +1
						if i == rnd then
							showcar2:SetModel(v.Model)
						end
					end
				end
				local rnd = math.random(1,table.Count(cars))
				local i = 0
				if IsValid(showcar3) then
					for k,v in pairs(cars) do
						i = i +1
						if i == rnd then
							showcar3:SetModel(v.Model)
						end
					end
				end
			end)
		end)
	end
end)


function VehicleExit(pl, vehicle)
	cooldown = CurTime()+3	
end
hook.Add("PlayerLeaveVehicle", "vehicleexitcooldown", VehicleExit)

local function SirenToggle( player,cmd,arg )
	local cdown = CurTime()
	local vehicle
	if player:InVehicle() then
		vehicle = player:GetVehicle()
		if player.SirenOn then
			player:ChatPrint("Siren Off")
			timer.Stop(player:UniqueID().."SirenNoise")
			vehicle.Siren:SetSkin(0)
			player.SirenOn = false
			return
		end
		if IsValid(vehicle) then
			if !vehicle.CopCar then return end
			if vehicle:GetDriver() and vehicle:GetDriver():IsCP() then
				player.SirenOn = true
				player:ChatPrint("30 Second Siren On")
				vehicle.Siren:SetSkin(1)
				vehicle:EmitSound("vehicles/psiren.wav", 100, 125)
				timer.Create(player:UniqueID().."SirenNoise",2,0, function()
					if !IsValid(vehicle) then return end
					if vehicle:GetDriver() and vehicle:GetDriver():IsCP() then
						vehicle:EmitSound("vehicles/psiren.wav", 100, 125)
					end
					timer.Create(player:UniqueID().."SirenOff30sec",30,1, function()
						if IsValid(player) then
							timer.Stop(player:UniqueID().."SirenNoise")
							vehicle.Siren:SetSkin(0)
							player.SirenOn = false
						end
					end)
				end)
			end
		end
	else
		player.SirenOn = false
	end
end
concommand.Add( "SirenToggle", SirenToggle )

local function HonkHorn( player,cmd,arg )
	if player:InVehicle() then
		local vehicle = player:GetVehicle()
		if IsValid(vehicle) then
			local Horn = vehicle.Horn or "vehicles/car-locked-honk-1.wav"
			if (vehicle.CopCar) then SirenToggle(player) return end
			if vehicle:GetClass() != "prop_vehicle_jeep" then return end
			vehicle:EmitSound(Horn, 100, 100)
	   end
	end
end
concommand.Add( "HonkHorn", HonkHorn )
 
hook.Add("CanPlayerEnterVehicle","disabledcarentry",function(ply,ent)
	local LastRammed = ent.LastRammed or 0
	if IsValid(ent) and ent:GetClass() == "prop_vehicle_jeep" and ent.CarDisabled == true then ply:ChatPrint("This cars disabled - cars autorepair after 3 minutes") return false end
	if IsValid(ent) and ent:GetClass() == "prop_vehicle_jeep" and (CurTime()-LastRammed) <= 15 then ply:ChatPrint("This car has been rammed. You may use it again after " .. tostring(math.floor(15-(CurTime()-LastRammed)))  .. " second(s).") return false end
	if IsValid(ent) and ply:IsRoot() then
		return true
	end
	if IsValid(ent) and ent.CopCar and !ply:IsCP() then
			return false 
	end
end)

local cooldown = CurTime()
local function vehiclepassengers( ply, entity )
	if not entity:IsVehicle() then return end
	if IsValid(entity:GetDriver()) then
		if entity.CarLocked then return false end
		if entity.CarDisabled == true then ply:ChatPrint("Car disabled for 3 minutes while self repairing") return false end
		if IsValid(entity.Passenger) then
			if cooldown <= CurTime() then
				cooldown = CurTime()+3
				if IsValid(entity.Passenger:GetDriver()) then	
					if IsValid(entity.Passenger2) then
						if IsValid(entity.Passenger2:GetDriver()) then
							if IsValid(entity.Passenger3) then
								if not IsValid(entity.Passenger3:GetDriver()) then								
									ply:EnterVehicle(entity.Passenger3)
								end							end
						else							
							ply:EnterVehicle(entity.Passenger2)
						end
					end
				else		
					ply:EnterVehicle(entity.Passenger)	
				end				
			end
		end
	end
end
hook.Add( "PlayerUse", "vehiclepassengers", vehiclepassengers )

function VehicleExit(pl, vehicle)
	cooldown = CurTime()+3	
end
hook.Add("PlayerLeaveVehicle", "vehicleexitcooldown", VehicleExit)

hook.Add("CanExitVehicle", "PAS_ExitVehicle", function( veh, ply )
	if IsValid(veh) and veh:GetClass() == "prop_vehicle_prisoner_pod" then
			// L+R
			if ply:VisibleVec( veh:LocalToWorld(Vector(90, 0, 5) )) then
					ply:ExitVehicle()
					ply:SetPos( veh:LocalToWorld(Vector(75, 0, 5) ))
			end
		   
			if ply:VisibleVec( veh:LocalToWorld(Vector(-90, 0, 5) )) then
					ply:ExitVehicle()
					ply:SetPos( veh:LocalToWorld(Vector(-75, 0, 5) ))
					--return false
			end
	end
end)


function SaveMapProps()
   props = {}
   local mat
   props = {"class","model","pos","ang","sid","mat","col","data"}
   props["class"] = {}
   props["model"] = {}
   props["pos"] = {}
   props["ang"] = {}
   props["sid"] = {}
   props["mat"] = {}
   props["col"] = {}
   props["data"] = {}
   for k,ent in pairs(ents.GetAll()) do
      if IsValid(ent) and (ent:GetClass() == "prop_physics") then
         props["class"][k] = ent:GetClass()
         props["model"][k] = ent:GetModel()
         props["pos"][k] = tostring(ent:GetPos())
         props["ang"][k] = tostring(ent:GetAngles())
        -- props["sid"][k] = ent.Owner:SteamID()
         props["mat"][k] = ent:GetMaterial()
         props["col"][k] = util.TableToJSON(ent:GetColor())
         props["data"][k] = util.TableToJSON(ent.kvs)
      end
   end      
   PrintTable(props)
   file.Write(game:GetMap()..".txt",util.TableToJSON(props))
end