-- Loading the settings.

local dupeblacklist = {"money_printer","weapon_crowbar", "weapon_physgun", "weapon_physcannon", "weapon_pistol", "weapon_stunstick", "weapon_357", "weapon_smg1",
	"weapon_ar2", "weapon_shotgun", "weapon_crossbow","pill_worldent", "weapon_frag", "weapon_rpg", "gmod_tool", "weapon_bugbait","ammo_machine","m9k_thrown_harpoon"} --for advanced duplicator, you can't use any IsWeapon...
ToolTable = {"Global","Supporter Only","Entities","EntCreation"}
TestTable = {}
ToolTable["Global"] = {}
ToolTable["Supporter Only"] = {}
ToolTable["Entities"] = {}
ToolTable["EntCreation"] = {}

timer.Simple(10, function()	
	for k,v in pairs(weapons.GetList()) do
		if v.ClassName then table.insert(dupeblacklist, v.ClassName) end -- Not sure why this has to go in a timer, it gets a bit bitchy at being ran on server load even inside a the initpost hook.
	end
	DB.Query("SELECT list FROM darkrp.tooltable_global;", function(data) -- globally blacklisted tools
		   for k,v in pairs(data) do
			ToolTable["Global"][k] = data[k].list
		   end	   
	end)
	DB.Query("SELECT list FROM darkrp.tooltable_supporter;", function(data) -- Tools only supporters can use
		   for k,v in pairs(data) do
			ToolTable["Supporter Only"][k] = data[k].list
		   end
	end)
	DB.Query("SELECT list FROM darkrp.tooltable_entities;", function(data) -- Entities nobody can use toolgun on
		   for k,v in pairs(data) do
			ToolTable["Entities"][k] = data[k].list
            table.insert(dupeblacklist, data[k].list)
		   end
	end)
	DB.Query("SELECT list FROM darkrp.tooltable_entitycreate;", function(data) -- Entities we always want to delete, no matter how they are spawned
		   for k,v in pairs(data) do
			ToolTable["EntCreation"][k] = data[k].list
            table.insert(dupeblacklist, data[k].list)
		   end
	end)
end)

-- The bases of my toolgun restriction
-- I've split this into multiple hooks while I'm developing it. Then if one dies the rest doesn't.
local Owner
hook.Add( "CanTool", "ToolRestrict", function( ply, tr, tool )
	local ent = tr.Entity
    
    -- textscreen is supporter only, lets make it clear!
    if tool == "textscreen" and not ply:IsSupporter() then
        ply:ChatPrint("This tool is supporter only. Type !supporter for details or, as an alternative, you may use the Wire > Visuals > Screen > Text Screen tool")    
    end
    
    if IsValid(ent.FPPOwner) then
        if ply == ent.FPPOwner then
            Owner = "themselves."
        else
            Owner = ent.FPPOwner:Name() .. " (" .. ent.FPPOwner:SteamID() .. ")"
        end
	elseif IsValid(ent.Owner) and ent.Owner:IsPlayer() then
        if ply == ent.Owner then
            Owner = "themselves."
        else
            Owner = ent.Owner:Name() .. " (" .. ent.Owner:SteamID() .. ")"
        end
	elseif ent:IsWorld() then
        Owner = "the world (pos: " .. tostring(tr.HitPos) .. ")"
    else
		Owner = "an -Invalid- ent?"
	end
    
	if ply:IsSuperAdmin() and ent.SuperEnt then
		local owner = ( IsValid(ent.SpawnedBy) and ent.SpawnedBy:Nick() or "--Unknown--" ) .. " (" .. ent.STID .. ")"
		DB.Log(ply:Name() .. " ("..ply:SteamID()..") has used tool " ..tool.." on a SuperEnt spawned by " .. Owner )
		return true
	end
	if ply.RootMode then 		
		DB.Log(ply:Name() .. " : ("..ply:SteamID()..") Has used tool " ..tool)
		return true 
	end
    
    -- Let supporters manipulate their own sammy screens
    if ent:GetClass() == "sammyservers_textscreen" and (tool == "remover" or tool == "textscreen") then
        if (IsValid(ent.FPPOwner) and ent.FPPOwner == ply) or ply:IsAdmin() then
            DB.Log(ply:Name() .. "("..ply:SteamID()..") has used tool " .. tool .. " on a textscreen beloning to " .. Owner)
            return true
        end
    end
    
	-- Remove Lawboards
	if ent:GetClass() == "darkrp_laws" and tool == "remover" and ((ply:Team() == TEAM_MAYOR) or (ply:Team() == TEAM_ADMIN) or ply:IsTrustedAdmin() or ply:IsSuperAdmin()) then
		DB.Log(ply:Name() .. " : ("..ply:SteamID()..") removed a lawboard.")
		return true
	end
	
	-- Remove empty shipments
	if ent:GetClass() == "spawned_shipment" and ent.dt.Contents == 0 and tool == "remover" and ((ply:Team() == TEAM_ADMIN) or ply:IsTrustedAdmin() or ply:IsSuperAdmin()) then
		DB.Log(ply:Name() .. " : ("..ply:SteamID()..") removed an empty shipment.")
		return true
	end
	
	-- Remove empty beckibox
	if ent:GetClass() == "becki_box" and #ent.Printers == 0 and tool == "remover" and ((ply:Team() == TEAM_ADMIN) or ply:IsTrustedAdmin() or ply:IsSuperAdmin()) then
		DB.Log(ply:Name() .. " : ("..ply:SteamID()..") removed an empty becki box.")
		return true
	end
    
    -- Allow trusted+ to view E2s, allow any other admin to remove.
    if ent:GetClass() == "gmod_wire_expression2" and not ply == ent.FPPOwner then
        if not (ply:IsSuperAdmin() or ply:IsTrustedAdmin()) then
            if ply:IsAdmin() and tool == "remover" then
                DB.Log(ply:Name() .. "("..ply:SteamID()..") has used tool " .. tool .. " on an E2 owned by " .. Owner)
                return true
            end
            return false
        end
        -- Player is trusted/super, we can just let the bunk below run its course.
    end    
    
    local function ToolTableMatch(tooltable,class)
          return string.StartWith(string.lower(class),string.lower(tooltable))
    end
	
	
	if ToolTable and ToolTable["Global"] then
		for k,v in pairs(ToolTable["Global"]) do
			if ToolTableMatch(v,tool) then
				ply:ChatPrint("Sorry, nobody can use this tool due to crash exploits / player abuse.")
				return false
			end
		end
	end	
	if ToolTable and ToolTable["Entities"] then
		for k,v in pairs(ToolTable["Entities"]) do
            if ToolTableMatch(v,ent:GetClass()) then
				print("RETURN FALSE YOU FUCKING THING")
				ply:ChatPrint("Sorry this is a roleplay entity, you may not use toolguns on it.")
				return false
			end
		end
	end
	if ToolTable and ToolTable["Supporter Only"] then
		for k,v in pairs(ToolTable["Supporter Only"]) do
			if ToolTableMatch(v,tool) then
				if ply:IsSupporter() then
					DB.Log(ply:Name() .. "("..ply:SteamID()..") has used tool " .. tool .. " on an ent beloning to " .. Owner)
					return
				else
					 ply:ChatPrint("This tool is supporter only. Type !supporter for details.")
					return false
				end
			end
		end
	end
end)
-- Backup ent creation removal and removes blocked models from entities.
hook.Add( "OnEntityCreated", "Blacklisted ent removal", function(ent)
	for _,v in pairs(ToolTable["EntCreation"]) do		
		if IsValid(ent) and string.match( string.lower(ent:GetClass()),v) then
         ent:Remove()
			return false
        end
        timer.Simple(0.1, function()
            if IsValid(ent) then	
                local entmod = ent:GetModel() or ""
				for _,d in pairs(BannedProps) do
                    if string.lower(entmod) == string.lower(d) then
                        if ent:GetClass() == "money_printer" or ent:GetClass() == "letter" or ent:GetClass() == "becki_box" or ent:GetClass() == "spawned_shipment" or ent:GetClass() == "ammo_machine" then
                            return
                        end
                    	ent:Remove()
                    	return
                    end
                end
			
			local model = ent:GetModel()
			if model ~= nil then
				if string.find(model,  "//") or string.find(model, "/%.%./") or string.find(model, "/ERROR/") then 
					ent:Remove() 
					return false
				end
			end
				
            end
        end)
	end
end)

util.AddNetworkString("IrSpecing") -- ULX spectate hook
local CantTouch = CurTime()
hook.Add( "PhysgunPickup", "PhysgunCanTickle", function( ply, ent )	
	if not IsValid(ent) and not IsValid(ply) then return end
	if ply:IsSuperAdmin() and ent.SuperEnt then return true	end
	if ent:GetClass() == "darkrp_laws" and ((ply:Team() == TEAM_MAYOR) or (ply:Team() == TEAM_ADMIN) or ply:IsTrustedAdmin() or ply:IsSuperAdmin()) then return true end
	if ply.RootMode then return true end
	if ent:GetClass() == "player" then

    if ent.RootMode or (ply:IsTrustedAdmin() and (ent.SADON or ent:IsFormerFluffy())) then
			return false
    end
        
        local physon = ply.PhysgunPickupOn and ply.PhysgunPickupOn or false 
        
        if physon and (ply:IsTrustedAdmin() or (ply:IsSuperAdmin() and ply.SADON)) then
            ent.Physgunned = true
            return true
        end
        
	end
	if ent.SatOn then return false end
end)

concommand.Add("physpower", function(ply)

    if not IsValid(ply) then return end
    if not (ply:IsTrustedAdmin() or ply:IsSuperAdmin() or ply:IsFormerFluffy()) then return end

    local physon = ply.PhysgunPickupOn and ply.PhysgunPickupOn or false
    
    if not physon then
        ply.PhysgunPickupOn = true
        ply:PrintMessage(HUD_PRINTCONSOLE,"Physgun player pickup enabled!")
    else
        ply.PhysgunPickupOn = false
        ply:PrintMessage(HUD_PRINTCONSOLE,"Physgun player pickup disabled.")
    end

end)

hook.Add( "PhysgunDrop", "PhysgunPlayerDropReset", function( ply, ent )

    if not IsValid(ply) or not IsValid(ent) then return end
    if ent:GetClass() == "player" then
        ent.Physgunned = false
    end
    
end)

-- Best add a PlayerSpawn hook too, just incase something happens to the player whilst being physgunned.
hook.Add("PlayerSpawn", "PhysgunPlayerSpawnReset", function(ply)
    if IsValid(ply) then
        ply.Physgunned = false
    end
end)

--seats behold, sod off sit anywhere and gravgun
local function CanIGrabThee(ply,ent)
	if not IsValid(ply) or not IsValid(ent) then return end
	if ply.RootMode then return true end
	if ent.SatOn then return false end
end
hook.Add("GravGunPickupAllowed", "CanIGrabSomething", CanIGrabThee)

-- Basic prop kill protection
local function GravPunter(ply, ent)
    if not IsValid(ply) then return end
    if ply.RootMode then return true end
	if ply.WhatAPunt then return true end
    if ply:Team() == TEAM_SADMIN then return true end
    return false
end
hook.Add("GravGunPunt", "Dontyapuntyme", GravPunter)

function AntiPropDamage( target, inflictor )
	if IsValid(inflictor) and inflictor:IsNPC() then
		return true
	end
	if not IsValid(inflictor) then return end
	if inflictor:IsVehicle() then return end
	if target:InVehicle() and inflcitor ~= target then return false end
    if inflictor:IsPlayer() and (IsValid(inflictor:GetActiveWeapon())) and inflictor:GetActiveWeapon():GetClass() == "weapon_physcannon" then return false end
	if inflictor.IsMoneyPrinter then return end
	if inflictor:GetClass() == "ent_snowball" then return end
	if not inflictor:IsPlayer() then return false end
end
hook.Add("PlayerShouldTakeDamage", "Anti PropDamage", AntiPropDamage)
local function AntiPropKill( ply, ent )
    if not IsValid(ent) then return end 
    ent:SetPos(ent:GetPos())--That trick resets velocity
end
hook.Add("PhysgunDrop", "Anti PropKill", AntiPropKill)
-- crushing is always 200, so here.
local function PropCrushingOff(target, dmginfo)
	if (dmginfo:GetAttacker() == game.GetWorld( ) and dmginfo:GetDamage() == 200) then
		dmginfo:SetDamage(0)
	end
end
hook.Add("EntityTakeDamage", "PropCrushingOff", PropCrushingOff)


local function HalfCarDmg(target, dmginfo)
	if IsValid(dmginfo:GetAttacker()) and dmginfo:GetAttacker():IsVehicle() then
		dmginfo:SetDamage(dmginfo:GetDamage()/15)
	end
end
hook.Add("EntityTakeDamage", "HalfCarDmg", HalfCarDmg)

local function MassWeld(ply)
	ply.MassWeldCD = ply.MassWeldCD or 0
	if not ply:IsSupporter() then return end
	local base = ply:GetEyeTrace().Entity
	
    if not IsValid(base) then ply:ChatPrint("You must be looking at a part of the base.") return end
    if not (base:GetClass() == "prop_physics" or string.StartWith(string.lower(base:GetClass()),"gmod_wire") or base:GetClass() == "sent_keypad") then ply:ChatPrint("That's not a valid base prop!") return end
    
	if not IsValid(base.FPPOwner) and not ply == base.FPPOwner then return end
	DB.Log("Mass Weld is happening, if this crashy crashy blame: "..ply:SteamID())
	if ply.MassWeldCD > CurTime() then ply:ChatPrint("You've ran this recently, weldall is limited to 1 use a minute to reduce abuse.") return end
	local WeldList = {}
	for k,ent in pairs(ents.GetAll()) do
		if (IsValid(ent.FPPOwner) and ent.FPPOwner == ply)then 
			--if ent:GetClass() == "money_printer" or ent:GetClass() == "spawned_money" or ent:GetClass() == "prop_vehicle_jeep" or FPP.Blocked.Spawning1[string.lower(ent:GetClass())] then 
			--else
			if ent:GetClass() == "prop_physics" or string.StartWith(string.lower(ent:GetClass()),"gmod_wire") or ent:GetClass() == "sent_keypad" then
				if IsValid(ent:GetPhysicsObject()) then 
					ent:GetPhysicsObject():EnableMotion(false)
					constraint.RemoveAll(ent)
					table.insert(WeldList,ent)
				end
			end
		end
	end	
	ply.MassWeldCD = CurTime() + 60
	ply:ChatPrint("Base welded - please report bugs via forums.")
	timer.Simple(1,function()
		for k,v in pairs(WeldList) do
			if IsValid(v) then
				constraint.Weld(base,v,0,0,0,true)
			end
		end
	end)
end
concommand.Add("pleaseweldthisstuff", MassWeld )
concommand.Add("weldall", MassWeld )
concommand.Add("pleasegagtobidantor",MassWeld)



local function DelayPlayerUnfreezeObject( pl, ent, object )

if not (ent.Owner == pl) or not (ent.FPPOwner == pl) then return 0 end

-- Not frozen!
if ( object:IsMoveable() ) then return 0 end

-- Unfreezable means it can't be frozen or unfrozen.
-- This prevents the player unfreezing the gmod_anchor entity.
if ( ent:GetUnFreezable() ) then return 0 end



-- NOTE: IF YOU'RE MAKING SOME KIND OF PROP PROTECTOR THEN HOOK "CanPlayerUnfreeze"
if ( !gamemode.Call( "CanPlayerUnfreeze", pl, ent, object ) ) then return 0 end

object:EnableMotion( true )
object:Wake()

gamemode.Call( "PlayerUnfrozeObject", pl, ent, object )

return 1

end

hook.Add( "OnEntityCreated", "byb_e2logger", function(ent)
	if IsValid(ent) and ent:GetClass() == "gmod_wire_expression2" then
		timer.Simple(5,function() 
			if IsValid(ent) and ent.buffer then
				local code = ent.buffer or "THAR BE NO CODE? Panthos stupid @ byb_pp.lua line 336"
				local name = string.lower(util.CRC(code)) or "CRCError"
				local ply = ent.FPPOwner
				if not file.IsDir("spawnede2s","DATA") then file.CreateDir("spawnede2s") end
				file.Write("spawnede2s/"..name..".txt",code)
				if IsValid(ply) then
					DB.Log(ply:Name() .. "(" ..ply:SteamID() ..")" .. " has spawned E2 CRC: spawnede2s/"..name..".txt")
				end
				ent.CRC = name
			end	
			if IsValid(ent) and IsValid(ent.FPPOwner) and not ent.FPPOwner:IsSupporter() then
				ent:Remove()
			end	
		end)
	end
end)


-- Cheap I know, but for regular morons we'll just not let them have a prop that isn't collided while being unfrozen.
-- if dropped, collide again
hook.Add( "PhysgunDrop", "PhysFreezeAutoCollide_drop", function(ply, ent)
	if not ply:IsSupporter() then
   		if IsValid(ent) and ent:GetClass() == "prop_physics" then
            local phy = ent:GetPhysicsObject()
            if phy:IsValid() and phy:IsMotionEnabled() then
   			   ent:SetCollisionGroup(20)
            end
   		end
   	end
end )
-- If it unfreezes, collide it again
hook.Add( "CanPlayerUnfreeze", "PhysFreezeAutoCollide_unfreeze", function( weapon, phys, ent, ply )
	if IsValid(ply) and (not ply:IsSupporter() or not ply:IsAdmin()) then
   		if IsValid(ent) and ent:GetClass() == "prop_physics" then
   			ent:SetCollisionGroup(20)
   		end
   	end
end )
-- Sets it back to being collided when frozen
hook.Add("OnPhysgunFreeze", "PhysFreezeAutoReCollide_freeze", function(weapon, phys, ent, ply)
	if not ply:IsSupporter() or not ply:IsAdmin() then
   		if IsValid(ent) and ent:GetClass() == "prop_physics" then
   			ent:SetCollisionGroup(0)
   		end
   	end
end )