Badmin = {}
local meta = FindMetaTable("Player")
Badmin.LastBanCheck = ""
util.AddNetworkString("spectatepos") -- ULX spectate hook
util.AddNetworkString("clmutemenu") -- ULX spectate hook
util.AddNetworkString("funlogsend") -- ULX spectate hook
util.AddNetworkString("CloseDeathMenu") -- Close Death Menu for !revive command.
net.Receive("spectatepos", function (len,ply)
	if IsValid(ply) and ply:IsTrustedAdmin() then
		local pos = net.ReadVector() or ply:GetPos()
		ply:SetPos(pos)
	end
end)

function meta:DoFreeze()

    if not IsValid(self) then return false end
    
    if self:HasGodMode() then
        self.HadGodMode = true
    end
    
    self:AddFlags(FL_FROZEN + FL_GODMODE)
    
    return true
    
end

function meta:DoUnfreeze()

    if not IsValid(self) then return false end
    
    local hadgod = self.HadGodMode or false
    
    if hadgod then
        self.HadGodMode = false
        self:RemoveFlags(FL_FROZEN)    
    else
        self:RemoveFlags(FL_FROZEN + FL_GODMODE)
    end

    return true

end

hook.Add("PlayerDeath", "UnsetHadGodMode", function(ply) 

    -- This should never happen as players should not be able to die whilst frozen, but things like superslay ignore it & you never know.
    if ply.HadGodMode then
        ply.HadGodMode = false
    end

end)


function Badmin.HasPerms(ply,command)
	-- By setting a command to be IsBAdmin anyone who is admin or higher can run it, by setting it to be IsTrustedAdmin then anyone who is trusted or higher etc etc.
	-- bools are meta:IsAdmin() meta:IsTrustedAdmin() meta:IsSuperAdmin() meta:IsRoot()
	-- RootMode will always return true, even if you're a user rootmode lets you run any command
	if ply:EntIndex() == 0 or ply.RootMode then return true end
	Badmin.Admincmds = {"banid","ban","kick","slay","goto","bring","slap","freeze","unfreeze","return","forcespray","revive"}
	Badmin.Trustedcmds = {"spectate","unban","warn","shock","forcesell","gag"}
	Badmin.Supercmds = {"god","ungod","giveammo"}
	Badmin.Rootcmds = {}
	for k,v in pairs(Badmin.Admincmds) do
		if command == v then 
			if ply.SAD then return ply.SAD end
			if ply:IsTrustedAdmin() then return ply:IsTrustedAdmin() else return ply:IsAdmin() end
		end
	end
	for k,v in pairs(Badmin.Trustedcmds) do
		if command == v then
			if ply.SAD then return ply.SAD end
			return ply:IsTrustedAdmin()
		end
	end
	for k,v in pairs(Badmin.Supercmds) do
		if command == v then
			if ply.SAD then return ply.SAD end
			return ply:IsSuperAdmin()
		end
	end
	for k,v in pairs(Badmin.Rootcmds) do
		if command == v then
			return ply:IsRoot()
		end
	end
	DB.Log("um, I think we're failing somewhere here over in byb_admin.lua. I should never be checking for this command: "..command)
	return false
end

function Badmin.Denied(ply)
	if IsValid(ply) then ply:ChatPrint("Sorry but you do not have permission to run this command")end
end

function Badmin.Announce(msg)
	-- I should probably work on this, color and crap ... but for now it is what it is.
	--PrintMessage(HUD_PRINTCENTER,msg)
	PrintMessage(HUD_PRINTCONSOLE,msg)
end

local function propSpawn( ply, model, ent )
	ply.AntiSpams = ply.AntiSpams or 1
	ply.AntiSpams = ply.AntiSpams + 1
	ply.LastModel = ply.LastModel or ""
	ply.PropDisable = ply.PropDisable or false
	if ply.LastModel == model then
		timer.Create(ply:UniqueID().."AntiSpams",60,1, function()
			if IsValid(ply) then
				ply.AntiSpams = 0
				ply.PropDisable = false
			end
		end)
		--if ply.AntiSpams > 50 then
		--	ply:ChatPrint("More than 50 of this prop? What are you, a spamzor?")
		--	for k,v in pairs(ents.GetAll()) do
		--		if IsValid(v:GetNetworkedEntity[[ppowner]]) and v:GetNetworkedEntity[[ppowner]] == ply then v:Remove() end
		--	end
		--	for k,v in pairs(player.GetAll()) do if v:IsAdmin() then v:ChatPrint("Possible prop spam detection triggered, admins please check console.") end end
			--ply:ChatPrint("Prop removed from flooding - wait 60 seconds to be removed from flood protection")
			--ply.PropDisable = true
		--end
	end
	ply.LastModel = model
    local logstring = string.format( "%s<%s> spawned model %s (EntID: %s)", ply:Nick(), ply:SteamID(), model, ent:EntIndex())
	DB.Log(logstring)
	ColorConsolePrint({Color(255,255,0),logstring})
	print(logstring)
        
	local phys = ent:GetPhysicsObject()
	if ply.AntiSpams > 3 then		
		if phys:IsValid() then
			phys:EnableMotion(false)
		end
	end
end
hook.Add( "PlayerSpawnedProp", "LogPropSpawn", propSpawn)

local function propRemove(ent)
    if ent:GetClass() == "prop_physics" and IsValid(ent.FPPOwner) then
        local model = ent:GetModel() or "Unknown Model"
        local ply = ent.FPPOwner
        local logstring = string.format( "%s (EntID: %s) beloning to %s<%s> has been removed.", model, ent:EntIndex(), ply:Nick(), ply:SteamID())
        DB.Log(logstring)
        ColorConsolePrint({Color(150,150,150),logstring})
        print(logstring)
    end
end
hook.Add("EntityRemoved","LogPropDeletion", propRemove)

function Badmin.isValidSteamID( steamid )
	return steamid:match( "^STEAM_%d:%d:%d+$" ) ~= nil
end
function Badmin.Ban(ply,vicsid,len,reason)
	if not Badmin.HasPerms(ply,"ban") then Badmin.Denied(ply) return end
	local reason = reason or "Something went wrong, no reason was found in arguments?"
	local len = math.floor(tonumber(len)) or 1440
	if len < 1 then len = 1440 elseif len > 1440 then  ply:ChatPrint("ingame bans are limtied to 24hours") len = 1440 end
	local victim = FindPlayer(vicsid)
	local name = "BannedID"
	if IsValid(victim) then
		name = victim:Name()
	end
	local bandata = sql.SQLStr(ply:Name()) .. "," .. sql.SQLStr(ply:SteamID()) .. "," .. sql.SQLStr(name) .. "," .. sql.SQLStr(vicsid) .. "," .. sql.SQLStr(reason) .. "," .. os.time() ..",".. len..",".. sql.SQLStr(ServID)
	DB.Query("INSERT INTO byb_tempbans (adminname,adminid,plyname,plyid,reason,bantime,banlen,server) VALUES("..bandata..");");
	local msg = name.." ("..vicsid..") was banned by " .. ply:Name().."("..ply:SteamID()..") for "..len.." minutes for the reason "..reason
	local tar = FindPlayer(vicsid)
	DB.Log(msg)
	Badmin.Announce(msg)
	AdminLog(ply,(name == "BannedID" and vicsid or victim), " Has banned ", " ".. len .. " minute(s) for " ..reason)
    
    if IsValid(tar) and len >= 5 then
        -- Did they arrest any players? If so, lets unarrest any players they arrested. Worth it in the case of Mass RDM & general mingery.
        for _,prisoner in pairs(player.GetAll()) do
            if prisoner:isArrested() and prisoner.ArrestedBy and prisoner.ArrestedBy == victim then
                ChatPrint(prisoner:Nick() .. " has been unarrested due to " .. victim:Nick() .. " being banned")
                DB.Log(prisoner:Nick().. " (" .. prisoner:SteamID() .. ") was unarrested due to " .. victim:Nick().. " (" .. victim:SteamID() .. ") being banned.")
                prisoner:Unarrest()
            end
        end

        -- Cleanup their props, they're banned - they don't need them.
        for k,v in pairs(ents.GetAll()) do
            if v.Owner == tar then
                v:Remove()
            end 
        end
    end
    
	if IsValid(tar) then tar:Kick(msg) end
end	

--[[function Badmin.BanCheck(ply,vicsid,len,reason)
	DB.Query("SELECT * FROM byb_tempbans WHERE plyid=" .. sql.SQLStr(vicsid) .." AND server=".. sql.SQLStr(ServID) .." AND unban=0 order by `id` desc limit 1;",function(data)
		local bandata = data or {}
		if bandata[1] then
			if bandata[1].unban == "0" then 
				local expired = bandata[1].bantime + (bandata[1].banlen*60)
				if not bandata[1].server == ServID then return end
				if expired > os.time() then 
					ply:ChatPrint("The guys already banned you fool")
					return true
				end
			end
		end		
		Badmin.Ban(ply,vicsid,len,reason)
	end)
end]]--

-- Lets move everything into Badmin.BanCheck for effieiency.
function Badmin.BanCheck(ply,args)

    if not IsValid(ply) then return end
    if not ply:IsAdmin() then return end
    
    if type(args) != "table" then
        args = string.Explode(" ", args)
    end
    
    -- SteamID or player?
    local tar = FindPlayer(args[1])
    local steamid
    if not IsValid(tar) then
        steamid = string.Replace(args[1],"\"","") -- Remove any quotemarks from the string, as chatcommands send them. 
        if util.SteamIDTo64(steamid) == "0" then
            ply:ChatPrint("Invalid player. Try using the !menu or use their full steamid. SteamIDs should be \"enclosed in quotes\".")
            return false
        end
    else
        steamid = tar:SteamID()
    end
    
    local reason = ""
	local len = args[2]
	if type(len) == "number" then
        ply:ChatPrint("Wrong ban layout, you should use \"!ban target time reason\", or if they're on the server use !menu") 
        return
    end
    
    if #args == 3 then
        reason = args[3]
    else
        for k,v in pairs(args) do
            if v == args[1] or v == args[2] then
            else			
                reason = reason .. " " .. v
            end
        end
    end
    
    DB.Query("SELECT * FROM byb_tempbans WHERE plyid=" .. sql.SQLStr(steamid) .." AND server=".. sql.SQLStr(ServID) .." AND (bantime+(banlen*60)) >= UNIX_TIMESTAMP() AND unban=0 order by `id` desc limit 1;",function(data)
		local bandata = data or {}
		if bandata[1] then
            ply:ChatPrint("That player has already been banned.")
            return true
		end
		Badmin.Ban(ply,steamid,len,reason)
	end)
end


function Badmin.Unban(ply,vicsid)
	if not Badmin.HasPerms(ply,"unban") then Badmin.Denied(ply) return end
	DB.Query("SELECT * FROM byb_tempbans WHERE plyid=" .. sql.SQLStr(vicsid) .." order by `id` desc limit 1;",function(data)
		local bandata = data or {}
		if bandata[1] then
			local expired = bandata[1].bantime + (bandata[1].banlen*60)
			if expired > os.time() then 
				DB.Query("UPDATE byb_tempbans SET unban=1 WHERE id="..bandata[1].id.." order by `id`;")
				DB.Log(ply:Name() .. " has unbanned " .. vicsid)
				Badmin.Announce(ply:Name() .. " has unbanned " .. vicsid)
			end
		end
	end)
end
	
function Badmin.Kick(ply,victim,reason)
	if not Badmin.HasPerms(ply,"kick") then Badmin.Denied(ply) return end
	if not IsValid(victim) then ply:ChatPrint("I can't find the guy to kick, what happend?") return end
    if victim:IsAdmin() then
        if not ply:IsSuperAdmin() then Badmin.Denied(ply) return end
	end
	local reason = reason or "Kicked for - error - reason lost in terrible lua code"
	local msg = victim:Name().."("..victim:SteamID()..") was kicked by " .. ply:Name().."("..ply:SteamID()..") for"..reason
	DB.Log(msg)
	Badmin.Announce(msg)
	AdminLog(ply,victim, " Has Kicked ", " for ".. reason)
	victim:Kick(reason)
end

function Badmin.Slay(ply,victim,reason)
	if not Badmin.HasPerms(ply,"slay") then Badmin.Denied(ply) return end
	if not IsValid(victim) then ply:ChatPrint("I can't find the guy to slay, what happend?") return end
    if victim:IsAdmin() then
        if not ply:IsSuperAdmin() then Badmin.Denied(ply) return end
	end
	local reason = reason or "Slayed for - error - reason lost in terrible lua code"
    victim.WasSlayed = true
	victim:Kill()
	local msg = victim:Name().."("..victim:SteamID()..") was slayed by " .. ply:Name().."("..ply:SteamID()..") for"..reason
	DB.Log(msg)
	Badmin.Announce(msg)
	AdminLog(ply,victim, " Has Smited ", " for "..reason)
end
  
function Badmin.Slap(ply,victim,reason)
	if not Badmin.HasPerms(ply,"slap") then Badmin.Denied(ply) return end
	if not IsValid(victim) then ply:ChatPrint("I can't find the guy to slap, what happend?") return end
    if victim:IsAdmin() then
        if not ply:IsSuperAdmin() then Badmin.Denied(ply) return end
	end
	local reason = reason or "Slayed for - error - reason lost in terrible lua code"
	slap(victim)
	local msg = victim:Name().."("..victim:SteamID()..") was slapped by " .. ply:Name().."("..ply:SteamID()..") for"..reason
	DB.Log(msg)
	Badmin.Announce(msg)	
	if string.len(reason)<5 then
		AdminLog(ply,victim, " Has Slapped ")	
	else
		AdminLog(ply,victim, " Has Slapped ", " for "..reason)
	end
end
  
function Badmin.Warn(ply,victim,reason)
	if not Badmin.HasPerms(ply,"warn") then Badmin.Denied(ply) return end
	if not IsValid(victim) then ply:ChatPrint("I can't find the guy to slap, what happend?") return end
    if victim:IsAdmin() then
        if not ply:IsSuperAdmin() then Badmin.Denied(ply) return end
	end
	local reason = reason or ""
	victim:SendLua("DrawByBWarning(\""..reason.."\")")
	local msg = victim:Name().."("..victim:SteamID()..") was warned by " .. ply:Name().."("..ply:SteamID()..") for"..reason
	DB.Log(msg)
	ply:ChatPrint("Warning issued.")
	--Badmin.Announce(msg)
end

function Badmin.Freeze(ply,victim)
	if not Badmin.HasPerms(ply,"freeze") then Badmin.Denied(ply) return end
	if not IsValid(victim) then ply:ChatPrint("I can't find the guy to turn to ice, what happend?") return end
    if victim:IsAdmin() then
        if not ply:IsSuperAdmin() then Badmin.Denied(ply) return end
	end
    if victim:IsFrozen() then ply:ChatPrint("They're already frozen.") return end
	victim:DoFreeze()
	local msg = victim:Name().."("..victim:SteamID()..") was frozen by " .. ply:Name().."("..ply:SteamID()..")"
	DB.Log(msg)
	Badmin.Announce(msg)
	AdminLog(ply,victim, " Has Frozen ")
end

function Badmin.God(ply,victim)
	if not Badmin.HasPerms(ply,"god") then Badmin.Denied(ply) return end
	if not IsValid(victim) then ply:ChatPrint("I can't find the god you want to create, what happend?") return end
	victim:GodEnable()
	local msg = victim:Name().."("..victim:SteamID()..") was given god mode by " .. ply:Name().."("..ply:SteamID()..")"
	DB.Log(msg)
	Badmin.Announce(msg)
	AdminLog(ply,victim, " Has Goded ")
end

function Badmin.Revive(ply,args)
	if not Badmin.HasPerms(ply,"revive") then Badmin.Denied(ply) return end
    
    if type(args) != "table" then
        args = string.Explode(" ", args)
    end
    local tar = FindPlayer(args[1])
    
    if not IsValid(tar) then ply:ChatPrint("I can't find that player. Try using their steamid or !menu") return end
    
    if tar:Alive() then ply:ChatPrint("They're already alive & kicking") return end
    
    tar:Spawn()
    net.Start("CloseDeathMenu")
    net.Send(tar)
    
	local msg = tar:Name().."("..tar:SteamID()..") was force resurrected by " .. ply:Name().."("..ply:SteamID()..")"
	DB.Log(msg)
	Badmin.Announce(msg)
	AdminLog(ply,tar, " Has Resurrected ")
end

function Badmin.UnGod(ply,victim)
	if not Badmin.HasPerms(ply,"god") then Badmin.Denied(ply) return end
	if not IsValid(victim) then ply:ChatPrint("I can't find the guy to make squishy, what happend?") return end
	victim:GodDisable()
	local msg = victim:Name().."("..victim:SteamID()..") had god mode revoked by " .. ply:Name().."("..ply:SteamID()..")"
	DB.Log(msg)
	Badmin.Announce(msg)
	AdminLog(ply,victim, " Has Revoked God from ")
end

function Badmin.UnFreeze(ply,victim)
	if not Badmin.HasPerms(ply,"freeze") then Badmin.Denied(ply) return end
	if not IsValid(victim) then ply:ChatPrint("I can't find the guy to defrost, what happend?") return end
    if victim:IsAdmin() then
        if not ply:IsSuperAdmin() then Badmin.Denied(ply) return end
	end
	victim:DoUnfreeze()
	local msg = victim:Name().."("..victim:SteamID()..") was unfrozen by " .. ply:Name().."("..ply:SteamID()..")"
	DB.Log(msg)
	Badmin.Announce(msg)
	AdminLog(ply,victim, " Has Unfrozen ")
end


-- THIEF! THIEF! GET THE ULiB THIEF! 
do
local slapSounds = {
	"physics/body/body_medium_impact_hard1.wav",
	"physics/body/body_medium_impact_hard2.wav",
	"physics/body/body_medium_impact_hard3.wav",
	"physics/body/body_medium_impact_hard5.wav",
	"physics/body/body_medium_impact_hard6.wav",
	"physics/body/body_medium_impact_soft5.wav",
	"physics/body/body_medium_impact_soft6.wav",
	"physics/body/body_medium_impact_soft7.wav",
}
function slap( ent, damage, power, nosound )
	if ent:GetMoveType() == MOVETYPE_OBSERVER then return end -- Nothing we can do.
	damage = damage or 0 
	power = power or 500
	if ent:IsPlayer() then
		if not ent:Alive() then
			return -- Nothing we can do.
		end
		if ent:InVehicle() then
			ent:ExitVehicle()
		end
		if ent:GetMoveType() == MOVETYPE_NOCLIP then
			ent:SetMoveType( MOVETYPE_WALK )
		end
	end
	if not nosound then -- Play a slap sound
		local sound_num = math.random( #slapSounds ) -- Choose at random
		ent:EmitSound( slapSounds[ sound_num ] )
	end
	local angle_punch_pitch = math.Rand( -20, 20 )
	local angle_punch_yaw = math.sqrt( 20*20 - angle_punch_pitch * angle_punch_pitch )
	if math.random( 0, 1 ) == 1 then
		angle_punch_yaw = angle_punch_yaw * -1
	end
	ent:ViewPunch( Angle( angle_punch_pitch, angle_punch_yaw, 0 ) )
	local newHp = ent:Health() - damage
	if newHp <= 0 then
		if ent:IsPlayer() then
			ent:Kill()
		else
			ent:Fire( "break", 1, 0 )
		end
		return
	end
	ent:SetHealth( newHp )
end
end
-- Utility function for bring, goto, and send - Stolen from the friendly neighborhood ulib.
local function playerSend( from, to, force )
	if not to:IsInWorld() and not force then return false end -- No way we can do this one
	local yawForward = to:EyeAngles().yaw
	local directions = { -- Directions to try
		math.NormalizeAngle( yawForward - 180 ), -- Behind first
		math.NormalizeAngle( yawForward + 90 ), -- Right
		math.NormalizeAngle( yawForward - 90 ), -- Left
		yawForward,
	}
	local t = {}
	t.start = to:GetPos() + Vector( 0, 0, 32 ) -- Move them up a bit so they can travel across the ground
	t.filter = { to, from }

	local i = 1
	t.endpos = to:GetPos() + Angle( 0, directions[ i ], 0 ):Forward() * 47 -- (33 is player width, this is sqrt( 33^2 * 2 ))
	local tr = util.TraceEntity( t, from )
	while tr.Hit do -- While it's hitting something, check other angles
		i = i + 1
		if i > #directions then	 -- No place found
			if force then
				return to:GetPos() + Angle( 0, directions[ 1 ], 0 ):Forward() * 47
			else
				return false
			end
		end
		t.endpos = to:GetPos() + Angle( 0, directions[ i ], 0 ):Forward() * 47
		tr = util.TraceEntity( t, from )
	end
	return tr.HitPos
end

function Badmin.Bring(ply,tar,frozen)

    frozen = frozen or false

	if not Badmin.HasPerms(ply,"bring") then Badmin.Denied(ply) return end
    if (frozen and tar:IsAdmin()) and not ply:IsSuperAdmin() then Badmin.Denied(ply) return end    
    
	if not IsValid(tar) and not IsValid(ply) then return end
	if tar:InVehicle() then tar:ExitVehicle() end
	
	if ply == tar then ply:ChatPrint("You're as close to yourself as we're willing to get on a family friendly server.") return end
	
	if not tar:Alive() then ply:ChatPrint("The player was dead, summoning him from the afterlife! He might be afk, or dazed from resurrection though.") tar:Spawn() end
	local newpos = playerSend( tar, ply, tar:GetMoveType() == MOVETYPE_NOCLIP )
	if not newpos then
		ply:ChatPrint("No room to place your victim, try flying above a crater?")
		return
	end
	
	if tar:InVehicle() then
		if tar:GetVehicle():GetClass() == "prop_vehicle_jeep" then
			ply:ChatPrint("Ejecting that player from a car. Don't blame us if this makes them grumpy!")
			tar:ExitVehicle()
		end
	end
	
	if tar.DarkRPVars.Arrested then
		ply:ChatPrint("The player has been arrested. They will be brought, but will remain arrested.")
		timer.Create( tar:SteamID() .. "keeparrest",math.floor(tar.ArrestedTime - CurTime()),1,function()
			ply:ChatPrint( tar:Nick() .. "'s jailtime has expired and they've been unarrested.")
			
			-- Lets keep them in place. This will happen automatically if the jail distance is over 600, but some smelly admin might be talking to the player within jailpos.
			local pos = tar:GetPos() 
			tar:Unarrest()
			tar:SetPos(pos)
		end)
	end	
		
	local newang = (ply:GetPos() - newpos):Angle()
	
	tar.ReturnPos = tar:GetPos()
	tar.ReturnTime = os.time()
	tar.ReturnAdmin = ply:SteamID()
	
	tar:SetPos( newpos )
	tar:SetEyeAngles( newang )
	tar:SetLocalVelocity( Vector( 0, 0, 0 ) ) -- Stop!
    
    if (frozen) then
        if not tar:IsFrozen() then
            tar:DoFreeze()
            DB.Log(ply:Name().."("..ply:SteamID()..") summoned & froze " .. tar:Name() .."("..tar:SteamID()..")")
            Badmin.Announce(ply:Name().."("..ply:SteamID()..") summoned & froze " .. tar:Name() .."("..tar:SteamID()..")")
            AdminLog(ply,tar, " Has Summoned & Frozen ")
            return
         end
         
    end
    
    DB.Log(ply:Name().."("..ply:SteamID()..") summoned " .. tar:Name() .."("..tar:SteamID()..")")
    Badmin.Announce(ply:Name().."("..ply:SteamID()..") summoned " .. tar:Name() .."("..tar:SteamID()..")")
    AdminLog(ply,tar, " Has Summoned ")	
end

--local TheGagged = {}
function Badmin.Gag(ply,tar)
	if IsValid(ply) then return end
	if not Badmin.HasPerms(ply,"gag") then Badmin.Denied(ply) return end
	if not IsValid(tar) or not IsValid(ply) then return end
	local msg
	if tar.AdminGagged then
		tar.AdminGagged = false
		msg = ply:Name() .. "(" ..ply:SteamID()..") has ungagged " .. tar:Name() .."("..tar:SteamID()..")"
	else
		tar.AdminGagged = true
		msg = ply:Name() .. "(" ..ply:SteamID()..") has gagged " .. tar:Name() .."("..tar:SteamID()..")"
	end	
	DB.Log(msg)
	Badmin.Announce(msg)
	AdminLog(ply,tar, " Has (Ball?)Gag Toggled ")	
end

function Badmin.Goto(ply,tar)
	if not Badmin.HasPerms(ply,"goto") then Badmin.Denied(ply) return end
	if not IsValid(tar) and not IsValid(ply) then return end
	
	if ply == tar then ply:ChatPrint("You're as close to yourself as we're willing to get on a family friendly server.") return end
	
	if not tar:Alive() then ply:ChatPrint("Your target is dead, there is only one way to meet the dead...") return end
	local newpos = playerSend( ply,tar, ply:GetMoveType() == MOVETYPE_NOCLIP )
	if not newpos then
		ply:ChatPrint("The person you are trying to goto is in a tight spot, try again while noclipped")
		return
	end
	local newang = (tar:GetPos() - newpos):Angle()
	
	ply.ReturnPos = ply:GetPos()
	ply.ReturnTime = os.time()
	
	ply:SetPos( newpos )
	ply:SetEyeAngles( newang )
	ply:SetLocalVelocity( Vector( 0, 0, 0 ) ) -- Stop!
	DB.Log(ply:Name().."("..ply:SteamID()..") teleported to " .. tar:Name() .."("..tar:SteamID()..")")
	Badmin.Announce(ply:Name().."("..ply:SteamID()..") teleported to " .. tar:Name() .."("..tar:SteamID()..")")
	AdminLog(ply,tar, " Has Appeared near ")
end

function Badmin.Return(ply, tar)
    if not Badmin.HasPerms(ply,"return") then Badmin.Denied(ply) return end
    if not IsValid(ply) then return end

    local vic

    if IsValid(tar) then
            if tar == ply then
                vic = ply
                tar = nil
            else
                if not ply:IsSuperAdmin() then
                    if not (tar.ReturnAdmin == ply:SteamID()) then
                        ply:ChatPrint("You did not bring this player, so you may not return this player")
                        return
                    end
                end
            vic = tar
            end
    else
        vic = ply	
    end

    if not (type(vic.ReturnPos) == "Vector") then

        if IsValid(tar) then
            ply:ChatPrint("There is nowhere to return them to!")
        else
            ply:ChatPrint("There is nowhere to return you to!")
        end
        
        return
    end

    if not (vic.ReturnTime) then
        ply:ChatPrint("No teleport time on record. How strange.")
        return
    end


    if not ply:IsSuperAdmin() then
        if ( os.time() - vic.ReturnTime > 600) then
            if IsValid(tar) then
                ply:ChatPrint("It's been more then 10 minutes since they were last teleported. They'll have to walk.")
                return
            else
                ply:ChatPrint("It's been more then 10 minutes since you teleported. You'll have to walk.")
                return
            end
        end
    end

	vic:SetPos( vic.ReturnPos )
	vic:SetLocalVelocity( Vector( 0, 0, 0 ) ) -- Stop!
    
    
    local dude = IsValid(vic) and vic or ply
    if dude:IsFlagSet(FL_FROZEN) then
        dude:DoUnfreeze()
    end
	
	if IsValid(vic) and ply != vic then
	
		timer.Destroy(vic:SteamID() .. "keeparrest") -- If they're being returned to jail, we won't need this anymore.
        DB.Log(ply:Name().."("..ply:SteamID()..") returned " .. vic:Name() .."("..vic:SteamID()..") to their previous location (" .. tostring(vic.ReturnPos) ..")")
		Badmin.Announce(ply:Name().."("..ply:SteamID()..") returned " .. vic:Name() .."("..vic:SteamID()..") to their previous location.")
		AdminLog(ply, vic, " has returned ", " to their previous location.")
		return
		
	else
		DB.Log(ply:Name().."("..ply:SteamID()..") returned to their previous location (" .. tostring(ply.ReturnPos) ..")")
		Badmin.Announce(ply:Name().."("..ply:SteamID()..") returned to their previous location.")
				
		if IsValid(ply) then name = ply:Nick() pcol = team.GetColor(ply:Team()) end
		local args = {pcol,name,Color(255,140,0),[[ returned to their previous position after dealing with admin reports]]}
		net.Start("ColorChatPrints")
		net.WriteTable(args)
		net.Broadcast()
		return
	end

	return
end

function Badmin.PlayerConnect(ply,vicsid)
	--Extremely simple flag to stop join spammers from flooding mysql queries
	if Badmin.LastBanCheck == vicsid then
		ply:Kick("Bans are cached for a few minutes, if you where recently unbanned try again in 5 minutes")
		timer.Create("LastBan",60,1, function() Badmin.LastBanCheck = "" end)
		return
	end
	DB.Query("SELECT * FROM byb_tempbans WHERE plyid=" .. sql.SQLStr(vicsid) .."  AND unban=0 order by `id` desc limit 1;",function(data)
		bandata = data or {}
		if bandata[1] then
			--print(bandata[1].server)
			if tostring(bandata[1].server) == tostring(ServID) then
				local expired = bandata[1].bantime + (bandata[1].banlen*60)
				if expired > os.time() then 
					ply:Kick("BANNED: Expires in : " ..math.floor(((expired-os.time())/60)) .."minutes. REASON : \""..bandata[1].reason.."\"")
					Badmin.LastBanCheck = vicsid
				end
			end
		end		
	end)
end

concommand.Add("byb_goto", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if IsValid(tar) then
		Badmin.Goto(ply,tar)
	end
end)
AddChatCommand("!goto", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		Badmin.Goto(ply,tar)
	end
	return ""
end)

concommand.Add("byb_return", function(ply,_,args)

	if next(args) == nil then
		Badmin.Return(ply)
	else
	
		local tar = FindPlayer(args[1])
		if IsValid(tar) then
			Badmin.Return(ply, tar)		
		end
	
	end
	
end)
AddChatCommand("!return", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		Badmin.Return(ply, tar)
	else
		Badmin.Return(ply)
	end
	return ""
end)

concommand.Add("byb_god", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if IsValid(tar) then
		Badmin.God(ply,tar)
	end
end)
AddChatCommand("!god", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		Badmin.God(ply,tar)
		return ""
	end
	if not (args) then Badmin.God(ply,ply) end
	return ""
end)

concommand.Add("byb_ungod", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if IsValid(tar) then
		Badmin.UnGod(ply,tar)
	end
end)
AddChatCommand("!ungod", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		Badmin.UnGod(ply,tar)
	end
	return ""
end)

concommand.Add("byb_freeze", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if IsValid(tar) then
		Badmin.Freeze(ply,tar)
	end
end)
AddChatCommand("!freeze", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		Badmin.Freeze(ply,tar)
	end
	return ""
end)

concommand.Add("byb_unfreeze", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if IsValid(tar) then
		Badmin.UnFreeze(ply,tar)
	end
	return ""
end)
AddChatCommand("!unfreeze", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		Badmin.UnFreeze(ply,tar)
	end
	return ""
end)
concommand.Add("byb_bring", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if IsValid(tar) then
		Badmin.Bring(ply,tar)
	end
end)
concommand.Add("byb_breeze", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if IsValid(tar) then
		Badmin.Bring(ply,tar,true)
	end
end)
concommand.Add("byb_gag", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if IsValid(tar) then
		Badmin.Gag(ply,tar)
	end
end)
AddChatCommand("!bring", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		Badmin.Bring(ply,tar)
	end
	return ""
end)
AddChatCommand("!breeze", function(ply,args)
	local tar = FindPlayer(args)
	if IsValid(tar) then
		Badmin.Bring(ply,tar,true)
	end
	return ""
end)
AddChatCommand("!gag", function(ply,args)
	if not IsValid(ply) then return "" end
	local tar = FindPlayer(args)
	if IsValid(tar) then
		Badmin.Gag(ply,tar)
	end
	return ""
end)

concommand.Add("byb_kick", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if not IsValid(tar) then ply:ChatPrint("Cooooooey, where are you? I can't find this guy, try using the menu !menu") return end
	local reason = ""
	local fuckit = false -- Pretty sure you're reading this and going 'what the fuck?'.
	for k,v in pairs(args) do
		if not fuckit then fuckit = true else
			reason = reason .. " " .. args[k]
		end
	end
	if IsValid(tar) then
		Badmin.Kick(ply,tar,reason)
	end
end)
AddChatCommand("!kick", function(ply,args)
	local reason = ""
	args = string.Explode(" ", args)
	local tar = FindPlayer(args[1])
	local reason = ""
	for k,v in pairs(args) do
		if v == args[1] then
		else
			reason = reason .. " " .. v
		end
	end
	if IsValid(tar) then
		Badmin.Kick(ply,tar,reason)
	end
	return ""
end)

concommand.Add("byb_slap", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if not IsValid(tar) then ply:ChatPrint("Cooooooey, where are you? I can't find this guy, try using the menu !menu") return end
	local reason = ""
	local fuckit = false -- Pretty sure you're reading this and going 'what the fuck?'.
	for k,v in pairs(args) do
		if not fuckit then fuckit = true else
			reason = reason .. " " .. args[k]
		end
	end
	if IsValid(tar) then
		Badmin.Slap(ply,tar,reason)
	end
end)

concommand.Add("byb_warn", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if not IsValid(tar) then ply:ChatPrint("Cooooooey, where are you? I can't find this guy, try using the menu !menu") return end
	local reason = ""
	local fuckit = false -- Pretty sure you're reading this and going 'what the fuck?'.
	for k,v in pairs(args) do
		if not fuckit then fuckit = true else
			reason = reason .. " " .. args[k]
		end
	end
	if IsValid(tar) then
		Badmin.Warn(ply,tar,reason)
	end
end)

AddChatCommand("!warn", function(ply,args)
	local tar = FindPlayer(args[1])
	if not IsValid(tar) then ply:ChatPrint("Cooooooey, where are you? I can't find this guy, try using the menu !menu") return end
	local reason = ""
	local fuckit = false -- Pretty sure you're reading this and going 'what the fuck?'.
	args = string.Explode(" ", args)
	for k,v in pairs(args) do
		if not fuckit then fuckit = true else
			reason = reason .. " " .. args[k]
		end
	end
	if IsValid(tar) then
		Badmin.Warn(ply,tar,reason)
	end
	return ""
end)

AddChatCommand("!slap", function(ply,args)
	local reason = ""
	args = string.Explode(" ", args)
	local tar = FindPlayer(args[1])
	local reason = ""
	for k,v in pairs(args) do
		if v == args[1] then
		else
			reason = reason .. " " .. v
		end
	end
	if IsValid(tar) then
		Badmin.Slap(ply,tar,reason)
	end
	return ""
end)

concommand.Add("byb_slay", function(ply,_,args)
	local tar = FindPlayer(args[1])
	if not IsValid(tar) then ply:ChatPrint("Cooooooey, where are you? I can't find this guy, try using the menu !menu") return end
	local reason = ""
	local fuckit = false -- Pretty sure you're reading this and going 'what the fuck?'.
	for k,v in pairs(args) do
		if not fuckit then fuckit = true else
			reason = reason .. " " .. args[k]
		end
	end
	if IsValid(tar) then
		Badmin.Slay(ply,tar,reason)
	end
end)
AddChatCommand("!slay", function(ply,args)
	local reason = ""
	args = string.Explode(" ", args)
	local tar = FindPlayer(args[1])
    if not IsValid(tar) then ply:ChatPrint("Target player not found. Try using !menu.") return end
	if not tar:Alive() then ply:ChatPrint("This chicks already dead.") return end
	local reason = ""
	for k,v in pairs(args) do
		if v == args[1] then
		else
			reason = reason .. " " .. v
		end
	end
	if IsValid(tar) then
		Badmin.Slay(ply,tar,reason)
	end
	return ""
end)


concommand.Add("byb_ban", function(ply,_,args)
    if not IsValid(ply) then return end
    Badmin.BanCheck(ply,args)
    return ""
end)

AddChatCommand("!ban", function(ply,args)
    if not IsValid(ply) then return end
    Badmin.BanCheck(ply,args)
    return ""
end)

concommand.Add("byb_revive", function(ply,_,args)
    if not IsValid(ply) then return end
    Badmin.Revive(ply,args)
    return ""
end)

AddChatCommand("!revive", function(ply,args)
    if not IsValid(ply) then return end
    Badmin.Revive(ply,args)
    return ""
end)

AddChatCommand("!respawn", function(ply,args)
    if not IsValid(ply) then return end
    Badmin.Revive(ply,args)
    return ""
end)

concommand.Add("byb_unban", function(ply,_,args)
	local sid = FindPlayer(args[1]) or ""
	Badmin.UnBan(ply,sid)
end)

AddChatCommand("!motd", function(ply,args)
	ply:SendLua("DrawMoTD()")
	return ""
end)
AddChatCommand("!rules", function(ply,args)
	ply:SendLua("DrawRules()")
	return ""
end)
AddChatCommand("!supporter", function(ply,args)
	ply:SendLua([[gui.OpenURL("http://www.bybservers.co.uk/index.php?topic=378#post_juicydetails")]])
	return ""
end)
AddChatCommand("!stats", function(ply,args)
	ply:SendLua("DrawStatsMenu()")
	return ""
end)
AddChatCommand("!rules", function(ply,args)
	ply:SendLua("DrawMoTD()")
	return ""
end)
AddChatCommand("!donate", function(ply,args)
	ply:SendLua("DrawMoTD()")
	return ""
end)

util.AddNetworkString("GroupUpdates")
local function bybMenu(ply)

	if not ply:IsAdmin() then return "" end
	local ugroups = {"supers","trusteds","admins"}
	ugroups["supers"] = {}
    ugroups["formerfluffy"] = {}
	ugroups["trusteds"] = {}
	ugroups["admins"] = {}
		for k,v in pairs(player.GetAll()) do
		
		if v:IsRoot() then
		
			if v.SADON then
				table.insert(ugroups["supers"],v)
			elseif v.BADmin then
				table.insert(ugroups["admins"],v)
			end
		
		
		elseif v:IsSuperAdmin() then
		
			if v.SADON then
				table.insert(ugroups["supers"],v)
			elseif v.BADmin then
				table.insert(ugroups["admins"],v)
			end
            
        elseif v:IsFormerFluffy() then
        
            table.insert(ugroups["formerfluffy"],v)
		
		elseif v:IsTrustedAdmin() then
		
			table.insert(ugroups["trusteds"],v)
		
		elseif v:IsAdmin() then
		
			table.insert(ugroups["admins"],v)
		
		end
		
			-- if v.SADON then table.insert(ugroups["supers"],v)
			-- elseif v:IsTrustedAdmin() then table.insert(ugroups["trusteds"],v)
			-- elseif v:IsAdmin() then table.insert(ugroups["admins"],v)
			-- end
		end
	net.Start("GroupUpdates")
	net.WriteTable(ugroups)
	net.Send(ply)
	return ""
end


AddChatCommand("!menu",function(ply,args)
    bybMenu(ply)
end)
concommand.Add("bybmenu", function(ply,_,args)
	bybMenu(ply)
end)
		
hook.Add("PlayerAuthed", "byb ban checker", function(ply,sid)
	if IsValid(ply) then Badmin.PlayerConnect(ply,sid) end
	--for k,v in pairs(player.GetAll()) do
	--	if v:IsSuperAdmin() then				
	--		net.Start("omgawdsansadmin")
	--		net.WriteEntity(v)
	--		net.Send(ply)
	--	end
	--end
	SAPI.IsPlayingSharedGame(sid,GAME_GARRYSMOD,function(cb)
		if cb.response.lender_steamid == "0" then
			return
		else
			DB.Log("Family Sharing Alert: There real ID of "..ply:Name().."(" ..sid..") is "..tostring(cb.response.lender_steamid))
			local acol = Color(math.random(0,255),math.random(0,255),math.random(0,255))
            local args = {Color(0,255,0),ply:Nick().."("..sid..")", acol ," is using steam family sharing: Real details: " ..sid}
			net.Start("ColorChatPrints")
			net.WriteTable(args)
			net.Broadcast()
		end
	end)
end)

local function playerDrop( ply, ent )
	if ent:GetClass() == "player" then
		ent:SetMoveType( MOVETYPE_WALK )
	end
end
hook.Add( "PhysgunDrop", "physgunplayerdrop", playerDrop )



-- Stolen from FPP * 

local OnPlayerSay
local function Spectate(ply, cmd, args)
	if not Badmin.HasPerms(ply,"spectate") then Badmin.Denied(ply) return end
	--if not FAdmin.Access.PlayerHasPrivilege(ply, "Spectate") then FAdmin.Messages.SendMessage(ply, 5, "No access!") return end

	local target = FindPlayer(args[1])
	target = IsValid(target) and target ~= ply and target or nil

	ply.FAdminSpectatingEnt = target
	ply.FAdminSpectating = true

	ply:ExitVehicle()
	
	ply.ReturnPos = ply:GetPos()
	ply.ReturnTime = os.time()	

	umsg.Start("FAdminSpectate", ply)
		umsg.Bool(target == nil) -- Is the player roaming?
		umsg.Entity(ply.FAdminSpectatingEnt)
	umsg.End()

	hook.Add("PlayerSay", ply, OnPlayerSay)

	local targetText = IsValid(target) and (target:Nick() .. " ("..target:SteamID()..")") or ""
	ply:ChatPrint("You are now spectating "..targetText)
end
concommand.Add("byb_spectate",Spectate)

local function SpectateVisibility(ply, viewEnt)
	if not ply.FAdminSpectating then return end

	if IsValid(ply.FAdminSpectatingEnt) then
		AddOriginToPVS(ply.FAdminSpectatingEnt:GetShootPos())
	end

	if ply.FAdminSpectatePos then
		AddOriginToPVS(ply.FAdminSpectatePos)
	end
end
hook.Add("SetupPlayerVisibility", "FAdminSpectate", SpectateVisibility)

local function setSpectatePos(ply, cmd, args)
	--if not FAdmin.Access.PlayerHasPrivilege(ply, "Spectate") then FAdmin.Messages.SendMessage(ply, 5, "No access!") return end

	if not ply.FAdminSpectating or not args[3] then return end
	local x, y, z = tonumber(args[1] or 0), tonumber(args[2] or 0), tonumber(args[3] or 0)

	ply.FAdminSpectatePos = Vector(x, y, z)
end
concommand.Add("_FAdmin_SpectatePosUpdate", setSpectatePos)

local function endSpectate(ply, cmd, args)
	ply.FAdminSpectatingEnt = nil
	ply.FAdminSpectating = nil
	ply.FAdminSpectatePos = nil
	hook.Remove("PlayerSay", ply)
end
concommand.Add("_FAdmin_StopSpectating", endSpectate)

local function playerVoice(listener, talker)
	if not IsValid(listener.FAdminSpectatingEnt) then return end

	-- You can hear someone if your spectate target can hear them
	canhear, surround = GAMEMODE:PlayerCanHearPlayersVoice(listener.FAdminSpectatingEnt, talker)
	canHearLocal = GAMEMODE:PlayerCanHearPlayersVoice(listener, talker)

	-- you can always hear the person you're spectating
	return canhear or canHearLocal or listener.FAdminSpectatingEnt == talker, surround
end
hook.Add("PlayerCanHearPlayersVoice", "FAdminSpectate", playerVoice)

OnPlayerSay = function(spectator, sender, message, isTeam)
	-- the person is saying it close to where you are roaming
	if spectator.FAdminSpectatePos and sender:GetShootPos():Distance(spectator.FAdminSpectatePos) <= 400 and
		sender:GetShootPos():Distance(spectator:GetShootPos()) > 250 then-- Make sure you don't get it twice

		GAMEMODE:TalkToPerson(spectator, team.GetColor(sender:Team()), sender:Nick(), Color(255, 255, 255, 255), message, sender)
		return
	end

	-- The person you're spectating or someone near the person you're spectating is saying it
	if IsValid(spectator.FAdminSpectatingEnt) and
		sender:GetShootPos():Distance(spectator.FAdminSpectatingEnt:GetShootPos()) <= 300 and
		sender:GetShootPos():Distance(spectator:GetShootPos()) > 250 then
		GAMEMODE:TalkToPerson(spectator, team.GetColor(sender:Team()), sender:Nick(), Color(255, 255, 255, 255), message, sender)
	end
end
--[[
FAdmin.StartHooks["Spectate"] = function()
	FAdmin.Commands.AddCommand("Spectate", Spectate)

	FAdmin.Access.AddPrivilege("Spectate", 2)
end
]]--

util.AddNetworkString("ColorChatPrints")
util.AddNetworkString("ColorConsolePrints")
function AdminLog(ply,tar,action,reason)
	local ActCol = Color(math.random(0,255),math.random(0,255),math.random(0,255))
	local name = "(CONSOLE)"
	local pcol = Color(0,0,255)
	local vic = (type(tar) == "string" and tar or "<PLAYER MISSING???>")
	local vcol = Color(0,0,255)
	local reason = reason or ""
	if IsValid(ply) then name = ply:Nick() pcol = team.GetColor(ply:Team()) end
	if type(tar) != "string" and IsValid(tar) then vic = tar:Nick() vcol = team.GetColor(tar:Team()) end
	local args = {pcol,name,ActCol,action,vcol,vic,ActCol,reason}
	net.Start("ColorChatPrints")
	net.WriteTable(args)
	net.Broadcast()
end

function ColorConsolePrint(msg)
    local args = (type(msg) == "string" and {msg} or msg)
    args[#args+1] = "\n"
	net.Start("ColorConsolePrints")
	net.WriteTable(args)
	net.Broadcast()
end

AddChatCommand("!parkcar", function(ply)
	local acol = Color(math.random(0,255),math.random(0,255),math.random(0,255))
    if IsValid(ply) and ply:IsAdmin() then
	if ply:Team() != 21 then if not ply:IsSuperAdmin() then return end end
        local ent = ply:GetEyeTrace().Entity
        if IsValid(ent) and ent:GetClass() == "prop_vehicle_jeep" then
            local args = {team.GetColor(ply:Team()),ply:Nick(), acol ," Has reset(returned to npc!) a bugged car!"}
			net.Start("ColorChatPrints")
			net.WriteTable(args)
			net.Broadcast()
            ent:Remove()
			ent.Owner.CarsOut = (ent.Owner.CarsOut or 1) - 1
        end
	end
end)
AddChatCommand("!spectate", function(ply,_,args)
	Spectate(ply, _,args)
end)


concommand.Add("byb_who", function(ply,_,args)
	local group = "User" 
	for k,v in pairs(player.GetAll()) do	
		
		if v:IsRoot() then
		
			if v.SADON then
				group = "Root Admin"
			else
				if v:IsAdmin() then
					group = "Admin"
				elseif v:IsSupporter() then
					group = "Supporter"
				else
					group = "User"
				end
			end
				
		elseif v:IsSuperAdmin() then
		
			if v.SADON then
				group = "Super Admin"
			else
				if v:IsAdmin() then
					group = "Admin"
				elseif v:IsSupporter() then
					group = "Supporter"
				else
					group = "User"
				end
			end
            
        elseif v:IsFormerFluffy() then
        
            group = "Former Fluffy"
            
		elseif v:IsTrustedAdmin() then
		
			group = "Trusted Admin"
		
		elseif v:IsAdmin() then
		
			group = "Admin"
		
		elseif v:IsSupporter() then
		
			group = "Supporter"
			
		else
		
			group = "User"	
		
		end
		
		
		-- if v.SADON then group = "Super Admin" elseif v:IsTrustedAdmin() then group =  "TrustedAdmin" elseif v:IsAdmin() then group = "Admin" elseif v:IsSupporter() then group = "Supporter" else group = "User" end
		local nick = v:Nick().."("..v:SteamID()..")"
		local id = tostring( v:EntIndex() )
		local text = string.format( "%i%s %s%s ", id, string.rep( " ", 2 - id:len() ), nick, string.rep( " ", 51 - nick:len() ) )
		text = text .. group
		ply:PrintMessage(2, text)
	end
end)

function Badmin.shock(ply)
	--local ply = FindPlayer(tar)
	if not IsValid(ply) then return end
	if not ply:Alive() then end
	local pos = ply:GetPos()
	--WorldSound( "ambient/levels/labs/electric_explosion"..math.random( 2 , 4 )..".wav" , pos , 95 , math.random( 95 , 105 ) )
	sound.Play(	"ambient/levels/labs/electric_explosion"..math.random( 2 , 4 )..".wav",pos)
	local tes = ents.Create( "point_tesla" )
	tes:SetPos( ply:GetShootPos() )
	tes:SetKeyValue( "m_SoundName", "" )
	tes:SetKeyValue( "texture", "sprites/bluelight1.spr" )
	tes:SetKeyValue( "m_Color", "100 225 255" )
	tes:SetKeyValue( "m_flRadius", "100" )
	tes:SetKeyValue( "beamcount_min", "15" )
	tes:SetKeyValue( "beamcount_max", "20" )
	tes:SetKeyValue( "thick_min", "10" )
	tes:SetKeyValue( "thick_max", "15" )
	tes:SetKeyValue( "lifetime_min", "0.1" )
	tes:SetKeyValue( "lifetime_max", "0.3" )
	tes:SetKeyValue( "interval_min", "0.1" )
	tes:SetKeyValue( "interval_max", "0.3" )
	tes:Spawn()
	tes:Fire( "DoSpark", "", 0 )
	tes:Fire( "DoSpark", "", 0.2 )
	tes:Fire( "DoSpark", "", 0.4 )
	tes:Fire( "DoSpark", "", 0.6 )
	tes:Fire( "kill", "", 1 )

	local Effect = EffectData()
	Effect:SetOrigin( pos )
	Effect:SetStart( pos )
	Effect:SetMagnitude( 512 )
	Effect:SetScale( 128 )
	util.Effect( "cball_explode" , Effect )
	util.ScreenShake( pos , 5 , 5 , 1.5 , 100 )

	local dmginfo = DamageInfo()
	dmginfo:SetDamage( 500 )
	dmginfo:SetDamageType( DMG_DISSOLVE )
    
    ply.WasSlayed = true
	ply:GodDisable()
	ply:TakeDamageInfo( dmginfo )
end
concommand.Add("byb_shock", function(ply,_,args)
	if not Badmin.HasPerms(ply,"shock") then Badmin.Denied(ply) return end
	local tar = FindPlayer(args[1])
	if IsValid(tar) then
		Badmin.shock(tar)
		AdminLog(ply,tar, " thinks that "," is shocking!")
	end
end)
AddChatCommand("!shock", function(ply,args)
	if not Badmin.HasPerms(ply,"shock") then Badmin.Denied(ply) return end
	local tar = FindPlayer(args)
	if IsValid(tar) then
		Badmin.shock(tar)
		AdminLog(ply,tar, " thinks that "," is shocking!")
	end
	return ""
end)

function Badmin.ForceSpray(ply,victim)
    if not Badmin.HasPerms(ply,"forcespray") then Badmin.Denied(ply)
    	return
	end
	if not IsValid(victim) then ply:ChatPrint("I can't find the guy, typo? Or has he left to avoid your wrath?")
		return
	end
	if victim:IsSuperAdmin() then victim:ChatPrint(ply:name().." "..ply:SteamID().." tried to make you shoot your load!")
		return
	end
	victim:ConCommand("impulse 201")
	AdminLog(ply,victim, " forced "," to spray!")
end
concommand.Add("byb_forcespray", function(ply,_,args)
	if not Badmin.HasPerms(ply,"forcespray") then Badmin.Denied(ply) return end
	local tar = FindPlayer(args[1])
	if IsValid(tar) and not tar:IsSuperAdmin() then
		Badmin.ForceSpray(ply,tar)
    else return
	end
end)
AddChatCommand("!forcespray", function(ply,args)
	if not Badmin.HasPerms(ply,"forcespray") then Badmin.Denied(ply) return end
	local tar = FindPlayer(args)
	if IsValid(tar) and not tar:IsSuperAdmin() then
		Badmin.ForceSpray(ply,tar)
	end
	return ""
end)

function Badmin.ForceSell(ply)
if not Badmin.HasPerms(ply,"forcesell") then Badmin.Denied(ply) return end

	if timer.Exists(ply:SteamID() .. "DoorForceSell") then
		GAMEMODE:Notify(ply, 1, 4, "Don't spam the force sell command please.")
	return
	end	


	local trace = ply:GetEyeTrace()
	local doorowner = trace.Entity.DoorData.Owner

	if IsValid(trace.Entity) and trace.Entity:IsOwnable() and ply:GetPos():Distance(trace.Entity:GetPos()) < 300 then
		trace.Entity.DoorData = trace.Entity.DoorData or {}
		
		if trace.Entity.DoorData.NonOwnable or trace.Entity.DoorData.GroupOwn or trace.Entity.DoorData.TeamOwn then
			GAMEMODE:Notify(ply, 1, 5, LANGUAGE.door_unownable)
			return ""
		end

		if not IsValid(doorowner) then
			GAMEMODE:Notify(ply, 1, 4, string.format(LANGUAGE.invalid_x, "door owner", ""))
			return ""
		end
		
		timer.Create( ply:SteamID() .. "DoorForceSell",1,1,function() end)

		trace.Entity:Fire("unlock", "", 0)
		trace.Entity:UnOwn(doorowner)
		doorowner:GetTable().Ownedz[trace.Entity:EntIndex()] = nil
		doorowner:GetTable().OwnedNumz = math.abs(doorowner:GetTable().OwnedNumz - 1)
		local GiveMoneyBack = math.floor(((trace.Entity:IsVehicle() and GAMEMODE.Config.vehiclecost) or GAMEMODE.Config.doorcost))
		hook.Call("PlayerSoldDoor", GAMEMODE, doorowner, trace.Entity, GiveMoneyBack );
		doorowner:AddMoney(GiveMoneyBack)
		local bSuppress = hook.Call("HideSellDoorMessage", GAMEMODE, doorowner, trace.Entity );
		if( !bSuppress ) then
			GAMEMODE:Notify(doorowner, 0, 4, "Your door has been force sold. You've been refunded $" .. tostring(GiveMoneyBack) .. ".")
		end
		DB.Log(ply:Name().."("..ply:SteamID()..") force sold " .. doorowner:Name() .."("..doorowner:SteamID()..")'s door.")
		Badmin.Announce(ply:Name().."("..ply:SteamID()..") force sold " .. doorowner:Name() .."("..doorowner:SteamID()..")'s door. They've been fully refunded.")
		AdminLog(ply, doorowner, " force sold a door belonging to ", " who's been fully refunded.")
		
		
		
	end
end

concommand.Add("forcesell", function(ply)
	if not Badmin.HasPerms(ply,"forcesell") then Badmin.Denied(ply) return end
	Badmin.ForceSell(ply)
end)
AddChatCommand("!forcesell", function(ply)
	if not Badmin.HasPerms(ply,"forcesell") then Badmin.Denied(ply) return end
	Badmin.ForceSell(ply)
	return ""
end)
AddChatCommand("/forcesell", function(ply)
	if not Badmin.HasPerms(ply,"forcesell") then Badmin.Denied(ply) return end
	Badmin.ForceSell(ply)
	return ""
end)

hook.Add("PlayerDeath", "SavePlayerDeathInfo", function(ply, killer)
	if not IsValid(ply) or not IsValid(killer) then return end
	ply.LastDied = os.time()
	ply.LastKiller = killer
end)

if not RP7 then
	local FunLog = {}
	local FunLogCount = 1
	hook.Add("PlayerDeath", "FunLogDeath", function(ply, weapon , killer)
		local x = {os.time(),ply:Name().."("..ply:SteamID() ..") was killed by: "..tostring(killer)}
		FunLogCount = FunLogCount + 1
		if FunLogCount >= 501 then FunLogCount = 1 end
		FunLog[FunLogCount] = x
	end)
	hook.Add("EntityTakeDamage", "FunLogDmg", function(target,dmginfo)
		local atk = dmginfo:GetAttacker()
		if IsValid(atk) and IsValid(target) then
			if 
				atk:GetClass() == "prop_physics" or
				atk:GetClass() == "becki_box" or
				atk:GetClass() == "empty_shipment" or
				target:GetClass() == "prop_physics" or
				target:GetClass() == "becki_box" or
				target:GetClass() == "empty_shipment" or
                ( atk:GetClass() == "entityflame" && target:GetClass() == "money_printer")
			then return end
			local atkd
			local tard
			if atk:IsPlayer() then
				atkd = atk:Name() .. "(" ..atk:SteamID() ..")"
			else
				atkd = tostring(atk)
			end
			if target:IsPlayer() then
				tard = target:Name() .. "("..target:SteamID()..")"
			else
				tard = tostring(target)
			end
			FunLogCount = FunLogCount + 1
			if FunLogCount >= 501 then FunLogCount = 1 end
			FunLog[FunLogCount] = {os.time(),atkd .. " has dealt damage to: "..tard}
			--table.insert(FunLog,x)
		end
	end)
	function SendFunLog(ply)	
		net.Start("FunLogSend")
		net.WriteTable(FunLog)
		net.Send(ply)
	end

	
    function doDamageLog(ply)

        ply.LastFL = ply.LastFL or 1
        if ply:IsAdmin() and ply.LastFL and ply.LastFL <= CurTime()+60 then
            ply.LastFL = CurTime()
            SendFunLog(ply)
        else
             ply:ChatPrint("This command is network heavy, you may only use it only use it once a minute")
        end

    end

    concommand.Add("dmglog", function(ply)
        doDamageLog(ply)
    end)
        
    AddChatCommand("!dmglog", function(ply)
        doDamageLog(ply)
        return ""
    end)

end

function NLRTimeThing(ply)
	if not IsValid(ply) then return end
	
	local killer = IsValid(ply.LastKiller) and ply ~= ply.LastKiller and ply.LastKiller:Name() or false
	local nlrtime = ply.LastDied and (ply.LastDied + 300) - os.time() or 0
	
	local msg = {Color(255,255,255),"The current time is: ",Color(96,255,145),os.date("%H:%M:%S")}
	
	if ply.LastDied then
		msg[#msg+1] = Color(255,255,255)
		msg[#msg+1] = ". You last died at "
		msg[#msg+1] = Color(96,255,145)
		msg[#msg+1] = os.date("%H:%M:%S", ply.LastDied)
	end	
	if killer then
		msg[#msg+1] = Color(255,255,255)
		msg[#msg+1] = ", killed by "
		msg[#msg+1] = Color(255,0,0) 
		msg[#msg+1] = killer
	end
	if nlrtime and nlrtime > 0 and killer then
	
		local mins = math.floor(nlrtime/60)
		local secs = math.floor(nlrtime%60)
	
		msg[#msg+1] = Color(255,255,255)
		msg[#msg+1] = ". NLR expires in "
		msg[#msg+1] = Color(96,255,145)
		if mins > 0 then
		msg[#msg+1] = tostring(mins)
		msg[#msg+1] = Color(255,255,255)
		msg[#msg+1] = " minutes"
		msg[#msg+1] = Color(96,255,145)
		end
		msg[#msg+1] = " " .. tostring(math.floor(secs))
		msg[#msg+1] = Color(255,255,255)
		msg[#msg+1] = " seconds. ("
		msg[#msg+1] = Color(200,170,150)
		msg[#msg+1] = "Feel to ask politely over ooc or pm whether you may return yet. See "
		msg[#msg+1] = Color(255,255,255)
		msg[#msg+1] = "!rules"
		msg[#msg+1] = Color(200,170,150)
		msg[#msg+1] = " for more details"
		msg[#msg+1] = Color(255,255,255)
		msg[#msg+1] = ")"
	end
	
	if not (nlrtime and nlrtime > 0 and killer) then
		msg[#msg+1] = Color(255,255,255)
		msg[#msg+1] = "."
	end
	
	net.Start("ColorChatPrints")
	net.WriteTable(msg)
	net.Send(ply)

end

AddChatCommand("!thetime", function(ply)
	NLRTimeThing(ply)
	return ""
end)

AddChatCommand("!nlr", function(ply)
	NLRTimeThing(ply)
	return ""
end)

AddChatCommand("!mute", function(ply)
	net.Start("clmutemenu")
	net.Send(ply)
	return ""
end)

concommand.Add("giveammo", function(ply,_,args)
	if not Badmin.HasPerms(ply,"giveammo") then Badmin.Denied(ply) return end
    
     if args[1] and not tonumber(args[1]) then
        ply:PrintMessage(HUD_PRINTCONSOLE, "Invalid amount specified")
        return
    end
    
    if args[2] and not FindPlayer(args[2]) then
        ply:PrintMessage(HUD_PRINTCONSOLE, "Player not found")
        return
    end
    
    local amount = tonumber(args[1]) or 100
	local tar = args[2] and FindPlayer(args[2]) or ply
    local ammotype = IsValid(tar:GetActiveWeapon()) and tar:GetActiveWeapon().Primary and tar:GetActiveWeapon().Primary.Ammo or "pistol"
    local friendlyname = ammotype
    
    if IsValid(tar:GetActiveWeapon()) and tar:GetActiveWeapon():GetClass() == "weapon_crossbow" then
        ammotype = "XBowBolt"
        friendlyname = "XBow"
    end    
    if friendlyname == "pistol" then
        friendlyname = "NanoFlex"
    end
        
    GAMEMODE:NotifyAll(0,6, ply:Nick() .. " gave " .. (ply == tar and "themselves" or tar:Name()) .. " some " .. friendlyname .. " ammo.")
    DB.Log(ply:Name().." ("..ply:SteamID()..") gave " .. (ply == tar and "themselves " or tar:Name() .. " (" .. tar:SteamID() ..") ") .. tostring(amount) .. " " .. ammotype .. " ammo")
    tar:GiveAmmo(amount,ammotype)
	
end)