local function GetSaveableEntity( Ent, Offset )
	
	if ( Ent.PreEntityCopy ) then Ent:PreEntityCopy() end
	
	--we're going to be a little distructive to this table, let's not use the orginal
	local Tab = table.Copy( Ent:GetTable() )
	
	if ( Ent.PostEntityCopy ) then Ent:PostEntityCopy() end
	
	--let's junk up the table a little
	Tab.Angle = Ent:GetAngles()
	Tab.Pos = Ent:GetPos()
	Tab.CollisionGroup = Ent:GetCollisionGroup()
	
	-- Physics Objects
	Tab.PhysicsObjects =  Tab.PhysicsObjects or {}
	local iNumPhysObjects = Ent:GetPhysicsObjectCount()
	for Bone = 0, iNumPhysObjects-1 do 
		local PhysObj = Ent:GetPhysicsObjectNum( Bone )
		if ( PhysObj:IsValid() ) then
			Tab.PhysicsObjects[ Bone ] = Tab.PhysicsObjects[ Bone ] or {}
			Tab.PhysicsObjects[ Bone ].Pos = PhysObj:GetPos()
			Tab.PhysicsObjects[ Bone ].Angle = PhysObj:GetAngles()
			Tab.PhysicsObjects[ Bone ].Frozen = !PhysObj:IsMoveable()
		end
	end
	
	-- Flexes (WTF are these?)
	local FlexNum = Ent:GetFlexNum()
	for i = 0, FlexNum do
		Tab.Flex = Tab.Flex or {}
		Tab.Flex[ i ] = Ent:GetFlexWeight( i )
	end
	Tab.FlexScale = Ent:GetFlexScale()
	
	-- Let the ent fuckup our nice new table if it wants too
	if ( Ent.OnEntityCopyTableFinish ) then Ent:OnEntityCopyTableFinish( Tab ) end
	
	--moved from ConvertPositionsToLocal
	Tab.Pos = Tab.Pos - Offset
	Tab.LocalPos = Tab.Pos * 1
	Tab.LocalAngle = Tab.Angle * 1
	if ( Tab.PhysicsObjects ) then
		for Num, Object in pairs(Tab.PhysicsObjects) do
			Object.Pos = Object.Pos - Offset
			Object.LocalPos = Object.Pos * 1
			Object.LocalAngle = Object.Angle * 1
			Object.Pos = nil
			Object.Angle = nil
		end
	end
	
	--Save CollisionGroupMod
	if ( Tab.CollisionGroup ) then
		if ( !Tab.EntityMods ) then Tab.EntityMods = {} end
		Tab.EntityMods.CollisionGroupMod = Tab.CollisionGroup
	end
	
	--fix for saving key on camera
	if (Ent:GetClass() == "gmod_cameraprop") then
		Tab.key = Ent:GetNetworkedInt("key")
	end
	
	--Saveablity
	local SaveableEntity = {}
	SaveableEntity.Class		 = Ent:GetClass()
	
	-- escape the model string properly cause something out there rapes it sometimes
   local entstr
   if not Ent:GetModel() then entstr = "" else entstr = Ent:GetModel() end
	SaveableEntity.Model = table.concat( dupeshare.split( entstr, '\\+' ), "/" )
	
	SaveableEntity.Skin				= Ent:GetSkin()
	SaveableEntity.LocalPos			= Tab.LocalPos
	SaveableEntity.LocalAngle		= Tab.LocalAngle
	SaveableEntity.BoneMods			= table.Copy( Tab.BoneMods )
	SaveableEntity.EntityMods		= table.Copy( Tab.EntityMods )
	SaveableEntity.PhysicsObjects	= table.Copy( Tab.PhysicsObjects )
	
	if ( Ent:GetParent() ) and ( Ent:GetParent():IsValid() ) then
		SaveableEntity.SavedParentIdx = Ent:GetParent():EntIndex()
	end
	
	local EntityClass = duplicator.FindEntityClass( SaveableEntity.Class )
	if (!EntityClass) then return SaveableEntity end -- This class is unregistered. Just save what we have so far
	
	--filter functions, we only want to save what will be used
	for iNumber, key in pairs( EntityClass.Args ) do
		--we dont need this crap, it's already added
		if (key != "pos") and (key != "position") and (key != "Pos") and ( key != "model" ) and (key != "Model")
		and (key != "ang") and (key != "Ang") and (key != "angle") and (key != "Angle") and (key != "Class") then
			SaveableEntity[ key ] = Tab[ key ]
		end
	end	
	return SaveableEntity	
end

local function AutoSave( Ent, EntTable, ConstraintTable, Offset )
	
	if ( !Ent or !Ent:IsValid() ) or ( EntTable[ Ent:EntIndex() ] ) 
	or ( ( Ent:GetClass() == "prop_physics" ) and ( Ent:GetVar("IsPlug",nil) == 1 ) ) then
		return EntTable, ConstraintTable
	end
	
	EntTable[ Ent:EntIndex() ] = GetSaveableEntity( Ent, Offset )
	if ( !constraint.HasConstraints( Ent ) ) then return EntTable, ConstraintTable end
	
	for key, ConstraintEntity in pairs( Ent.Constraints ) do
		if ( !ConstraintTable[ ConstraintEntity ] ) then
			local ConstTable, ents = AdvDupe.GetSaveableConst( ConstraintEntity, Offset )
			ConstraintTable[ ConstraintEntity ] = ConstTable
			for k,e in pairs(ents) do
				if ( e and ( e:IsWorld() or e:IsValid() ) ) and ( !EntTable[ e:EntIndex() ] ) then
					AdvDupe.Copy( e, EntTable, ConstraintTable, Offset )
				end
			end
		end
	end
	
	return EntTable, ConstraintTable
	
end
-- TODO
-- Whitelist create - or figure out why fpp whitelist is being bypassed.
local function SaveDupes()
    local NilVec = Vector(1,2,3)
    local NilAng = Angle(5,6,7)
    local LeEnts
    local EntOwn
	local Stupid = false
   --local whitelist = {"physics_props","sent_keypad","gmod_button"
   for k,v in pairs(player.GetAll()) do 
		if v:IsSupporter() then
		  if v.AutoSaveOn == false then v:ChatPrint("If you are building and want to toggle 10minute auto save intervals please type AutoSaveToggle into console") else
			  LeEnts = {} 
			  for k,ent in pairs(ents.GetAll()) do	
				EntOwn = ent:GetNetworkedEntity[[ppowner]]
				if IsValid(EntOwn) and EntOwn == v then
					if not Stupid then EntInd = ent:EntIndex() Stupid = true end
					LeEnts = AutoSave(ent, LeEnts, {},NilVec)
					--pantho:ChatPrint("2")
				end
			  end
			  filename = AdvDupe.GetPlayersFolder(v) .. "/autosaves/byb_autosave.txt"
			  if (file.Exists(filename,"data")) then file.Delete(filename) end
			  AdvDupe.SaveDupeTablesToFile(v, LeEnts, {}, Entity(EntInd):EntIndex(), NilAng, NilVec, filename, [[]], NilVec,0)
			  GAMEMODE:Notify(v,0,4,[[byb_autosave.txt dupe has been saved.]])
		  end
		end
   end
end
--timer.Create("Autosave wireadvdupe",600,0, SaveDupes)

local function ToggleAutoSave(ply)
	if ply.AutoSaveOn == true then
		ply.AutoSaveOn = false 
		ply:ChatPrint("AutoSave Off")
	else 
		ply.AutoSaveOn = true
		ply:ChatPrint("AutoSave on")
	end
end
--concommand.Add("AutoSaveToggle",ToggleAutoSave)