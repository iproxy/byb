hook.Add("PlayerInitialSpawn", "Stat Vars", function(ply)	
	timer.Simple(1, function()
		if not IsValid(ply) then return end
		ply.stats = ply.stats or {}
		ply.stats.TIME = os.time()
		ply.stats.PCONFIG = true
		ply.stats.PSFIRED = 0
		ply.stats.PLAWYER = 0
		ply.stats.PCHEQUES = 0
		ply.stats.PCHEQUER = 0
		ply.stats.PDEATHS = 0
		ply.stats.PKILLS = 0
		ply.stats.PEMO = 0
		ply.stats.PPRINTERDESTROYER = 0
		ply.stats.PARRESTED = 0
		ply.stats.PPEOPLEARRESTED = 0
		ply.stats.PPRINTER = 0
		ply.stats.POTHERENTS = 0
		ply.stats.PMONEYFOUND = 0
		ply.stats.PMONEYDROPPED = 0
		ply.stats.PMONEYGIVEN = 0
		ply.stats.PMONEYPRINTED = 0
		ply.stats.PSALARY = 0
		ply.stats.PKEYPADCRACKS = 0
		ply.stats.PLOCKPICKS = 0
		ply.stats.PTOOLGUNCLICKS = 0
		ply.stats.SOLDCARS = 0 
		ply.CarsOut = 0 
		ply.AutoSaveOn = false
	end)
	if not RP7 then
		DB.QueryValue("SELECT sid FROM byb_darkrp_stats WHERE server='"..Serv.."' AND uid='"..ply:UniqueID().."' AND session='"..SessID.."';", function(cb)
			if not (cb) then
				DB.Query("INSERT INTO byb_darkrp_stats (server,session,uid,sid) VALUES ('"..Serv.."','"..SessID.."','"..ply:UniqueID().."','"..ply:SteamID().."');")
			end
		end)
		DB.QueryValue("SELECT uid FROM byb_darkrp_team_stats WHERE uid = '"..ply:UniqueID().."';",function(cb)
			if not (cb) then
				DB.Query("INSERT INTO byb_darkrp_team_stats (uid,sid) VALUES ('"..ply:UniqueID().."','"..ply:SteamID().."');")
			end
		end)
	end
end)

hook.Add("InitPostEntity", "Session ID for Stats", function()
	if RP1 then
		Serv = "RP1"
	elseif RP1M then
		Serv = "RP1M"
	elseif RP3 then
		Serv = "RP3"
	elseif RP4 then
		Serv = "RP4"
	elseif RP4M then
		Serv = "RP4M"
	elseif RP5 then
		Serv = "RP5"
	elseif RP7 then
		Serv = "ZRP(RP7)"
	elseif RP6 then
		Serv = "RP6"
	else
		Serv = "noeD I ma yhW"
	end
	SessID = os.time()
end)

function UpdateStatsSQL()
	for n,ply in pairs(player.GetAll()) do
		timer.Simple(n*2, function()
			if not IsValid(ply) then return end
			if not ply.stats.PCONFIG then return end
			--The one thing that always changes is time
			local tim = os.time() - ply.stats.TIME
			ply.stats.TIME = os.time()
			QueryUpdate = " playtime=playtime +"..tim.." "
			if ply.stats.PSFIRED ~= 0 then
				QueryUpdate = QueryUpdate .. ",shotsfired=shotsfired +"..ply.stats.PSFIRED.." "
				ply.stats.PSFIRED = 0
			end
			if ply.stats.PDEATHS ~= 0 then
				QueryUpdate = QueryUpdate .. ",deaths=deaths +"..ply.stats.PDEATHS.." "
				ply.stats.PDEATHS = 0
			end
			if ply.stats.PKILLS ~= 0 then
				QueryUpdate = QueryUpdate .. ",kills=kills +"..ply.stats.PKILLS.." "
				ply.stats.PKILLS = 0
			end
			if ply.stats.PEMO ~= 0 then
				QueryUpdate = QueryUpdate .. ",suicide=suicide +"..ply.stats.PEMO.." "
				ply.stats.PEMO = 0
			end
			if ply.stats.PPRINTERDESTROYER ~= 0 then
				QueryUpdate = QueryUpdate .. ",printersdestroyed=printersdestroyed +"..ply.stats.PPRINTERDESTROYER.." "
				ply.stats.PPRINTERDESTROYER = 0
			end
			if ply.stats.PARRESTED ~= 0 then
				QueryUpdate = QueryUpdate .. ",arrested=arrested +"..ply.stats.PARRESTED.." "
				ply.stats.PARRESTED = 0
			end
			if ply.stats.PPEOPLEARRESTED ~= 0 then
				QueryUpdate = QueryUpdate .. ",peoplearrested=peoplearrested +"..ply.stats.PPEOPLEARRESTED.." "
				ply.stats.PPEOPLEARRESTED = 0
			end
			if ply.stats.PPRINTER ~= 0 then
				QueryUpdate = QueryUpdate .. ",printers=printers +"..ply.stats.PPRINTER.." "
				ply.stats.PPRINTER = 0
			end	
			if ply.stats.PMONEYPRINTED ~= 0 then
				QueryUpdate = QueryUpdate .. ",moneyprinted=moneyprinted +"..ply.stats.PMONEYPRINTED.." "
				ply.stats.PMONEYPRINTED = 0
			end
			if ply.stats.POTHERENTS ~= 0 then
				QueryUpdate = QueryUpdate .. ",otherents=otherents +"..ply.stats.POTHERENTS.." "
				ply.stats.POTHERENTS = 0
			end
			if ply.stats.PMONEYFOUND ~= 0 then
				QueryUpdate = QueryUpdate .. ",moneyfound=moneyfound +"..ply.stats.PMONEYFOUND.." "
				ply.stats.PMONEYFOUND = 0
			end
			if ply.stats.PMONEYDROPPED ~= 0 then
				QueryUpdate = QueryUpdate .. ",moneydropped=moneydropped +"..ply.stats.PMONEYDROPPED.." "
				ply.stats.PMONEYDROPPED  = 0
			end
			if ply.stats.PMONEYGIVEN ~= 0 then
				QueryUpdate = QueryUpdate .. ",moneygiven=moneygiven +"..ply.stats.PMONEYGIVEN.." "
				ply.stats.PMONEYGIVEN = 0   
			end
			if ply.stats.PSALARY ~= 0 then
				QueryUpdate = QueryUpdate .. ",salary=salary +"..ply.stats.PSALARY.." "
				ply.stats.PSALARY = 0   
			end
			if ply.stats.PKEYPADCRACKS ~= 0 then
				QueryUpdate = QueryUpdate .. ",keypadscracked=keypadscracked +"..ply.stats.PKEYPADCRACKS.." "
				ply.stats.PKEYPADCRACKS = 0   
			end
			if ply.stats.PTOOLGUNCLICKS ~= 0 then
				QueryUpdate = QueryUpdate .. ",toolgunclicks=toolgunclicks +"..ply.stats.PTOOLGUNCLICKS.." "
				ply.stats.PTOOLGUNCLICKS = 0   
			end
			if ply.stats.PLOCKPICKS ~= 0 then
				QueryUpdate = QueryUpdate .. ",lockpicks=lockpicks +"..ply.stats.PLOCKPICKS.." "
				ply.stats.PLOCKPICKS = 0   
			end
			if ply.stats.PLAWYER ~= 0 then
				QueryUpdate = QueryUpdate .. ",lawyer=lawyer +"..ply.stats.PLAWYER.." "
				ply.stats.PLAWYER = 0   
			end
			if ply.stats.PCHEQUES ~= 0 then
				QueryUpdate = QueryUpdate .. ",chequespend=chequespend +"..ply.stats.PCHEQUES.." "
				ply.stats.PCHEQUES = 0   
			end
			if ply.stats.PCHEQUER ~= 0 then
				QueryUpdate = QueryUpdate .. ",chequerec=chequerec +"..ply.stats.PCHEQUER.." "
				ply.stats.PCHEQUER = 0   
			end
			if ply.stats.SOLDCARS ~= 0 then
				QueryUpdate = QueryUpdate .. ",soldcars=soldcars +"..ply.stats.SOLDCARS.." "
				ply.stats.SOLDCARS = 0   
			end
			DB.Query("UPDATE byb_darkrp_stats SET ".. QueryUpdate .." WHERE uid = ".. ply:UniqueID().." AND session='"..SessID.."' AND server='"..Serv.."';")
			DB.Query("UPDATE byb_darkrp_team_stats SET `"..team.GetName(ply:Team()).."`=`"..team.GetName(ply:Team()).."` +"..tim .." WHERE uid="..ply:UniqueID()..";")
		end)
	end 
end
 
-- I've no idea how to do this, so I guess a loop to add time every xx seconds?
timer.Create("Time statistics 3min loop",180,0, function()
	UpdateStatsSQL()   
end)

hook.Add("PlayerDeath", "Death stats", function(ply,weapon,killer)
	if IsValid(ply) then
		ply.stats.PDEATHS = ply.stats.PDEATHS + 1
	end
	if IsValid(killer) then
		if weapon == ply then 
			ply.stats.PEMO = ply.stats.PEMO + 1 
		elseif killer:IsPlayer() then
			killer.stats.PKILLS = killer.stats.PKILLS + 1 
		end
	end
end)		

hook.Add( "CanTool", "Toolgun stats", function( ply, tr, tool )
	if IsValid(ply) then
		ply.stats.PTOOLGUNCLICKS = ply.stats.PTOOLGUNCLICKS + 1
	end
end)

timer.Simple(1,function()
	if RP7 then
		timer.Destroy("Time statistics 3min loop")
		hook.Remove("CanTool", "Toolgun stats")
		hook.Remove("PlayerDeath", "Death stats")
		hook.Remove("CanTool", "Toolgun stats")
		--hook.Remove("PlayerInitialSpawn", "Stat Vars")
	end
end)

