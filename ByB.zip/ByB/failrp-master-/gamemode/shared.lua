-- ByB Map based crap
-- I should move this server check to a shared file at some point.

RP1 = false
RP1M = false
RP3 = false
RP4 = false
RP4M = false
RP2 = false
RP5 = false
RP6 = false
RP7 = false
RPX = false
PlayerTable = "darkrp_player"
StoredCarsTable = "storedcars"
local Workshop = 133342076 -- This is the blank pack for the police skin. If the file is set to include the map on a specific server this will also include the police skin.
M9K = false -- loads M9K files.
if SERVER then
	local function band( x, y )
		local z, i, j = 0, 1
		for j = 0,31 do
			if ( x%2 == 1 and y%2 == 1 ) then
				z = z + i
			end
			x = math.floor( x/2 )
			y = math.floor( y/2 )
			i = i * 2
		end
		return z
	end

	function GetIP()
		local hostip = tonumber(string.format("%u", GetConVar("hostip"):GetString()))
		
		local parts = {
			band( hostip / 2^24, 0xFF );
			band( hostip / 2^16, 0xFF );
			band( hostip / 2^8, 0xFF );
			band( hostip, 0xFF );
		}
		
		return string.format( "%u.%u.%u.%u", unpack( parts ) )
	end
	if GetIP() == "178.18.22.76" then RP1M = true RunConsoleCommand([[exec]], [[ByB | RP#1M - With Added Cake [WIRE]Modified] -bybservers.co.uk]]) end
	if GetIP() == "192.223.24.129" then RP4M = true end
end

ServID = "Undefined"
EvidenceRoom = Vector(-2097,-47,344)
if game.GetMap() == "rp_downtown_v2" then
	Workshop = 159021304
    RP1 = true
    ServID = "RP1"
	EvidenceRoom = Vector(-1730,-10,75)
end
if string.lower(game.GetMap()) == "rp_downtown_evilmelon_v1" then
	Workshop = 145177582
    RP3 = true
	M9K = true -- loads M9K job and entity page, does NOT change !content to load m9k page.
    ServID = "RP3"
	EvidenceRoom = Vector(-3792,237,-370)
	--if SERVER then resource.AddWorkshop(145177582) end
end
if game.GetMap() == "rp_downtown_v2_fiend_v2b" then
    RP4 = true
    ServID = "RP4"
	EvidenceRoom = Vector(-2097,-47,344)
end
if game.GetMap() == "rp_downtown_v4c" then
    RP5 = true
	M9K = false
    ServID = "RP5"
	EvidenceRoom = Vector(-1901,270,-78)	
end
if string.lower(game.GetMap()) == "rp_evocity_v33x" then
    RP2 = true
    PlayerTable = "darkrp_player_rp2"
    StoredCarsTable = "storedcars_rp2"
    ServID = "RP2"
	EvidenceRoom = Vector(-2097,-47,344)	
end
if game.GetMap() == "zombiesurvival_invasion_v2x" then
    RP7 = true
    ServID = "RP7"
	EvidenceRoom = Vector(-2097,-47,344)	
end
if game.GetMap() == "rp_bangclaw" then
	RP6 = true
	ServID = "RP6"
	EvidenceRoom = Vector(4006,-1060,163)
end
if (RP7) then
	include("zrp_addteams.lua")
elseif (RP2) then
	include("rp2_addteams.lua")
elseif M9K then
	include("addteams_m9k.lua")
	print("Loaded M9K")
else
	include("addteams.lua")
	print("Loaded default")
end
if SERVER then
	--resource.AddWorkshop(Workshop)
	--resource.AddWorkshop(180184594)
	if M9K then
		--resource.AddWorkshop(128093075) -- small arms pack
		--resource.AddWorkshop(128089118) -- assault rifles pack
		--resource.AddWorkshop(128091208)	-- heavy weapons pack
	end
end

--ADD CUSTOM TEAMS UNDER THIS LINE:


--[[
--------------------------------------------------------
HOW TO MAKE A DOOR GROUP
--------------------------------------------------------
AddDoorGroup("NAME OF THE GROUP HERE, you see this when looking at a door", Team1, Team2, team3, team4, etc.)

WARNING: THE DOOR GROUPS HAVE TO BE UNDER THE TEAMS IN SHARED.LUA. IF THEY ARE NOT, IT MIGHT MUCK UP!


The default door groups, can also be used as examples:
--]]
AddDoorGroup("Cops and Mayor only", TEAM_CHIEF, TEAM_POLICE, TEAM_MAYOR)
AddDoorGroup("Gundealer only", TEAM_GUN)


--[[
--------------------------------------------------------
HOW TO MAKE AN AGENDA
--------------------------------------------------------
AddAgenda(Title of the agenda, Manager (who edits it), Listeners (the ones who just see and follow the agenda))

WARNING: THE AGENDAS HAVE TO BE UNDER THE TEAMS IN SHARED.LUA. IF THEY ARE NOT, IT MIGHT MUCK UP!

The default agenda's, can also be used as examples:
--]]
if (RP7) then

elseif (RP2) then

else
    AddAgenda("Gangster's agenda", TEAM_MOB, {TEAM_GANG})
    AddAgenda("Police agenda", TEAM_MAYOR, {TEAM_CHIEF, TEAM_POLICE,TEAM_SWAT,TEAM_SWATRECON,TEAM_SWATMEDIC,TEAM_SWATCQB})
end

--[[
---------------------------------------------------------------------------
HOW TO MAKE A GROUP CHAT
---------------------------------------------------------------------------
Pick one!
GAMEMODE:AddGroupChat(List of team variables separated by comma)

or

GAMEMODE:AddGroupChat(a function with ply as argument that returns whether a random player is in one chat group)
This one is for people who know how to script Lua.

--]]
GM:AddGroupChat(function(ply) return ply:IsCP() or ply.DarkRPVars.PoliceDeputy or ply.DarkRPVars.AssMayor end)
GM:AddGroupChat(function(ply) return not (ply.DarkRPVars.AssMayor or ply.DarkRPVars.PoliceDeputy) and (ply:Team() == TEAM_MOB or ply:Team() == TEAM_GANG) end)

-- ByB Shared meta functions.

local plymeta = FindMetaTable'Player';
function plymeta:IsSupporter()
	if self:IsSuperAdmin() then
        return true;
    elseif self.DarkRPVars and self.DarkRPVars.supporter then
		return true;
	elseif self.GetRank then
		return self:GetRank():lower():find("supporter", 1, true) ~= nil;
	elseif self.GetUserGroup then
		return self:GetUserGroup():lower():find("supporter", 1, true) ~= nil;
	end
	return false
end
function plymeta:UniqueID()
	if not self.UIDCache then self.UIDCache = util.CRC( "gm_"..self:SteamID().."_gm" ) end
	return self.UIDCache
end

function plymeta:IsCP()
	if not IsValid(self) then return false end
	local Team = self:Team() -- clientside doesn't have the names, so added numbers.
	return  Team == TEAM_POLICE    or Team == 3  or
            Team == TEAM_CHIEF     or Team == 23 or
            Team == TEAM_MAYOR     or Team == 24 or
            Team == TEAM_SWAT      or Team == 4  or
            Team == TEAM_SWATRECON or Team == 7  or
            Team == TEAM_SWATMEDIC or Team == 5  or
            Team == TEAM_SWATCQB   or Team == 6  or
            Team == TEAM_ADMIN     or Team == 21 or
            Team == TEAM_SADMIN    or Team == 22 or
            -- Add extra cops here    
            false;
end

function plymeta:IsSWAT()
	local Team = self:Team()
	return  
            Team == TEAM_SWAT      or Team == 4  or
            Team == TEAM_SWATRECON or Team == 7  or
            Team == TEAM_SWATMEDIC or Team == 5  or
            Team == TEAM_SWATCQB   or Team == 6  or
			Team == TEAM_ADMIN     or Team == 21 or
            Team == TEAM_SADMIN    or Team == 22 or
            false;
end

function plymeta:CantAssist()
	local Team = self:Team() -- clientside doesn't have the names, so added numbers.
	return  
			Team == TEAM_THIEF     or Team == 19 or
            Team == TEAM_MTHIEF    or Team == 20 or
            Team == TEAM_GUN       or Team == 13 or
            Team == TEAM_HGUN      or Team == 14 or  
			Team == TEAM_BGUN      or Team == 4  or
			Team == TEAM_POLICE    or Team == 3  or
            Team == TEAM_CHIEF     or Team == 23 or
            Team == TEAM_MAYOR     or Team == 24 or
            Team == TEAM_SWAT      or Team == 4  or
            Team == TEAM_SWATRECON or Team == 7  or
            Team == TEAM_SWATMEDIC or Team == 5  or
            Team == TEAM_SWATCQB   or Team == 6  or
            Team == TEAM_ADMIN     or Team == 21 or
            Team == TEAM_SADMIN    or Team == 22 or
            -- Add extra cops here    
            false;
end

-- THESE NAMES DO NOT HAVE SPACES IN THEM. DO NOT PUT SPACES IN NEW ENTRIES
GM.RootAdmins = {
    ["STEAM_0:1:16678762"] = "lexi";
    ["STEAM_0:0:12921574"] = "pantho";
    ["STEAM_0:1:25946072"] = "proxy";
    ["STEAM_0:1:11392510"] = "deon";
	["STEAM_0:0:30280339"] = "ride";
	["STEAM_0:0:22533649"] = "rock";
    ["STEAM_0:1:24400282"] = "weasel";
	["STEAM_0:0:27609078"] = "shikari";
    ["STEAM_0:1:22015892"] = "conor";
};

function plymeta:IsRoot()
    return self.IsRootAdmin or GAMEMODE.RootAdmins[self:SteamID()];
end

ugroups = ugroups or {}
ugroups["admins"] = ugroups["admins"] or {}
ugroups["supers"] = ugroups["supers"] or {}
ugroups["trusteds"] = ugroups["trusteds"] or {}

function plymeta:IsAdmin()
	if self:GetUserGroup() == "admin" then return true end
	if self.RootMode then return true end
	if self.BADmin then return true end
	if self:IsTrustedAdmin() then return true end
	if self.SADON then return true end
	if CLIENT then 
		for k,v in pairs(ugroups["admins"]) do
			if v == self then return true end
		end
	end
	return false
end

function plymeta:IsFormerFluffy()
    if self.FFluffy then return true end    
    if CLIENT then 
		for k,v in pairs(ugroups["formerfluffy"]) do
			if v == self then return true end
		end
	end
    return false
end

function plymeta:IsTrustedAdmin()
    if self.SADON then return true end
	if self.TBAD then return true end
    if self.FFluffy then return true end
	if self.RootMode then return true end
	if CLIENT then 
		for k,v in pairs(ugroups["trusteds"]) do
			if v == self then return true end
		end
	end
	return false
end

function plymeta:IsSuperAdmin()
	if self:GetUserGroup() == "superadmin" then return true end
	if self.RootMode then return true end
	if self.SADON then return true end
	if SERVER then
		--if self.SAD then return true end
		if self:IsRoot() then return true end -- testing, should only trigger server checks I guess.
	end
	if CLIENT then 
		for k,v in pairs(ugroups["supers"]) do
			if v == self then return true end
		end
	end
	return false
end

--Stops the annoying jittery effect non admins get when trying to noclip. Although none admins shouldn't be trying anyway, but w/e.
hook.Add("PlayerNoClip", "AdminNoclip", function(ply) 
   return ply:IsAdmin()
end)

SuperEnts = { ["chairs"] = {
								["Seat_Airboat"] = {"Seat_Airboat","models/nova/airboat_seat.mdl","Airboat Seat"},
								["Seat_Jeep"] = {"Seat_Jeep","models/nova/jeep_seat.mdl","Jeep Seat"},
								["Chair_Office1"] = {"Chair_Office1","models/nova/chair_office01.mdl","Deer-Grade\nOffice Chair"},
								["Chair_Office2"] = {"Chair_Office2","models/nova/chair_office02.mdl","Super Sexy\nOffice Chair"},
								["Chair_Wood"] = {"Chair_Wood","models/nova/chair_wood01.mdl","Wooden Chair"},
								["Prisoner_Pod"] = {"Prisoner_Pod","models/vehicles/prisoner_pod_inner.mdl","Prisoner Pod"},
							}
				
			}

local PLY = {}
DEFINE_BASECLASS( "player_default" )
function PLY:StartMove( move )
end

function PLY:FinishMove( move )

end

player_manager.RegisterClass("player_sandbox", PLY, "player_default")



--- Z Anti crash test stuff

-- AntiCrash coded by Flapadar
-- Fixed by Leystryku
-- Modified by Agentmass

-- 30/11/12

AntiCrash = {}
--AddCSLuaFile()

CreateConVar("anticrash_enabled", "1", FCVAR_ARCHIVE)

if ( not GetConVar("anticrash_enabled"):GetBool() ) then

	return

end

if SERVER then

	util.AddNetworkString("AntiCrash.Pong")
	--AddCSLuaFile()

	function AntiCrash.Ping( ply, cmd, args )
	
		if ( not ply.LastPing or ply.LastPing + 5 < CurTime() ) then
		
			ply.LastPing = CurTime()
			
			net.Start("AntiCrash.Pong")
			net.Send( ply )

			--MsgN("Ping !")
		end
		
	end
	
	concommand.Add("_anticrash_ping", AntiCrash.Ping)

	return
end

AntiCrash.LastMoveTime = CurTime() + 10
AntiCrash.ShouldRetry = true
AntiCrash.Crashed = false
AntiCrash.Spawned = false
AntiCrash.Pending = false
AntiCrash.Active = false
AntiCrash.SpawnTime = 0

timer.Simple(30,function()
	AntiCrash.Active = true
end)

function AntiCrash.IsCrashed()

	if ( not AntiCrash.Spawned or not LocalPlayer or AntiCrash.Crashed ) then return end
		
	if ( AntiCrash.SpawnTime > CurTime() ) then return end

	if ( AntiCrash.LastMoveTime > CurTime() ) then return end

	if ( not IsValid(LocalPlayer()) ) then return end

	if ( not LocalPlayer():IsFrozen() and not LocalPlayer():InVehicle() ) then

		return true

	end

end

function AntiCrash.Pong( um )

	AntiCrash.LastMoveTime = CurTime() + 10
	MsgN("[AntiCrash] Connection regained - received pong")

end

function AntiCrash.Move()

	AntiCrash.LastMoveTime = CurTime() + 1
	
end

function AntiCrash.InitPostEntity()

	AntiCrash.Spawned = true
	AntiCrash.SpawnTime = CurTime() + 5

end

function AntiCrash.ServerCrash()

	local menucrashtime = CurTime()
	local retrytime = menucrashtime + 35
	
	for k , v  in ipairs(player.GetAll()) do
		v.CrashedPing = v:Ping()
	end

	local dframe = vgui.Create("DFrame")
	dframe:SetSize(200 , 150)
	dframe:SetTitle("AntiCrash")
	dframe:Center()
	dframe:MakePopup()

	function dframe:Close(...)
		AntiCrash.ShouldRetry = false
		return DFrame.Close(self , ...)
	end

	local dlabel = vgui.Create("DLabel")
	dlabel:SetParent(dframe)
	dlabel:SetPos(27 , 30)
	dlabel:SetSize(195 , 25)
	dlabel:SetText(string.format("Autoreconnect in %d seconds!" , retrytime - CurTime()))

	function dlabel:Paint( ... )
	
		self:SetText(string.format("Autoreconnect in %d seconds!" , retrytime - CurTime()))

	end

--	local dbutton = vgui.Create("DButton")
--	dbutton:SetParent(dframe)
--	dbutton:SetPos(5 , 55)
--	dbutton:SetSize(190 , 22)
--	dbutton:SetText("Reconnect now")
--	dbutton.DoClick = function()
--		RunConsoleCommand("retry")
--	end

	local dlabel = vgui.Create("DLabel")
	dlabel:SetParent(dframe)
	dlabel:SetPos(22 , 60)
	dlabel:SetSize(195 , 50)
	dlabel:SetText("Please wait until the above timer \nhits 0 in order to auto-reconnect \nwhen the server has been fully \n                restarted.")

	local dbutton = vgui.Create("DButton")
	dbutton:SetParent(dframe)
	dbutton:SetPos(5 , 120)
	dbutton:SetSize(190 , 22)
	dbutton:SetText("Cancel")
	dbutton.DoClick = function()
		AntiCrash.ShouldRetry = false
		dframe:SetVisible(false)
	end
	
	hook.Add("Think" , "Crashed" , function()
		for k , v in ipairs(player.GetAll()) do
			if v.CrashedPing != v:Ping() then
				MsgN("[AntiCrash] Connection regained - ping changed.")
				hook.Remove("Think" , "Crashed")
				AntiCrash.Crashed = false
				AntiCrash.LastMoveTime = CurTime() + 5
			end
		end
		
		/*
		local moving = false
		
		for k , v in ipairs(ents.GetAll()) do
			if v:GetVelocity():Length() > 5 then
				-- Well, not everything's stopped moving.
				-- 5 incase some props stuck in another prop and is spazzing or something
				-- It should stop moving, but i'm not entirely sure
				
				moving = true
			end
		end
		
		if moving then
			hook.Remove("Think" , "Crashed")
			MsgN("[AntiCrash] Connection regained - movement detected")
			AntiCrash.Crashed = false
			AntiCrash.LastMoveTime = CurTime() + 5
		end
		
		*/
		
		if AntiCrash.Crashed and (retrytime - CurTime() - 0.5) < 0 and AntiCrash.LastMoveTime + 5 < CurTime() then
			if AntiCrash.ShouldRetry then
				RunConsoleCommand("retry")
			end
		elseif AntiCrash.LastMoveTime > CurTime() then
			hook.Remove("Think" , "Crashed")
			AntiCrash.Crashed = false
			if dframe and dframe:IsValid() then
				dframe:Remove()
			end
		end
	end )
	
end

function AntiCrash.Think()

	if not AntiCrash.Crashed and AntiCrash.IsCrashed() then

		RunConsoleCommand("_anticrash_ping")
		
		if AntiCrash.Active and AntiCrash.LastMoveTime < CurTime() then
			MsgN("[AntiCrash] Connection down - Did not receive pong")
			AntiCrash.Crashed = true
			AntiCrash.ShouldRetry = true -- This is a seperate crash from the previous, the user might want to reconnect this time.

			AntiCrash.ServerCrash()
			hook.Call( "ServerCrash" , nil ) -- Incase anyone else wants to hook into server crashes.
		else
			AntiCrash.Crashed = false
		end

		MsgN("[AntiCrash] Connection lost - sending ping")
	end
	
end

hook.Add("InitPostEntity" , "AntiCrash.InitPostEntity", AntiCrash.InitPostEntity)
hook.Add("Move" , "AntiCrash.Move", AntiCrash.Move)
hook.Add("Think" , "AntiCrash.Think", AntiCrash.Think)
net.Receive("AntiCrash.Pong", AntiCrash.Pong)
