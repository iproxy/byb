Shipment "Desert eagle" {
    Model = "models/weapons/w_pist_deagle.mdl";
    Class = "weapon_mad_deagle";
    Price = 2299;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 250;
    Teams = {TEAM_GUN, TEAM_HITMAN, TEAM_BGUN};
};
Shipment "Glock" {
    Model = "models/weapons/w_pist_glock18.mdl";
    Class = "weapon_mad_glock";
    Price = 1499;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 160;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "USP" {
    Model = "models/weapons/w_pist_usp.mdl";
    Class = "weapon_mad_usp";
    Price = 1499;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 160;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "P228" {
    Model = "models/weapons/w_pist_p228.mdl";
    Class = "weapon_mad_p228";
    Price = 1599;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 170;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
--[[
Shipment "Knife" {
    Model = "models/weapons/w_knife_t.mdl";
    Class = "weapon_mad_knife";
    Price = 599;
    Amount = 5;
    AvailableSeperately = true;
    SeperatePrice = 199;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
]]--
Shipment "Elites" {
    Model = "models/weapons/w_pist_elite.mdl";
    Class = "weapon_mad_dual";
    Price = 2399;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 240;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "AK47" {
    Model = "models/weapons/w_rif_ak47.mdl";
    Class = "weapon_mad_ak47";
    Price = 3299;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 350;
    Teams = {TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "MP5" {
    Model = "models/weapons/w_smg_mp5.mdl";
    Class = "weapon_mad_mp5";
    Price = 2699;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 280;
    Teams = {TEAM_GUN, TEAM_CHIEF, TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "M4A1" {
    Model = "models/weapons/w_rif_m4a1.mdl";
    Class = "weapon_mad_m4";
    Price = 3550;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 370;
    Teams = {TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "Mac 10" {
    Model = "models/weapons/w_smg_mac10.mdl";
    Class = "weapon_mad_mac10";
    Price = 2099;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 210;
    Teams = {TEAM_GUN, TEAM_BGUN};
}; 
Shipment "TMP" {
    Model = "models/weapons/w_smg_tmp.mdl";
    Class = "weapon_mad_tmp";
    Price = 2150;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 230;
    Teams = {TEAM_GUN, TEAM_BGUN};
}; 
Shipment "Spas Shotgun" {
    Model = "models/weapons/w_shot_xm1014.mdl";
    Class = "weapon_mad_spas";
    Price = 1850;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 190;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_SWATCQB};
};
Shipment "AWP" {
    Model = "models/weapons/w_snip_awp.mdl";
    Class = "weapon_mad_awp";
    Price = 9099;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1300;
    Teams = {TEAM_HGUN, TEAM_BGUN, TEAM_SWATRECON};
}; 

Shipment "HK GS3G1" {
    Model = "models/weapons/w_snip_g3sg1.mdl";
    Class = "weapon_mad_g3";
    Price = 9500;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1350;
    Teams = {TEAM_HGUN, TEAM_BGUN, TEAM_SWATRECON};
}; 
Shipment "M3 Shotgun" {
    Model = "models/weapons/w_shot_m3super90.mdl";
    Class = "weapon_mad_m3";
    Price = 2199;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 230;
    Teams = {TEAM_GUN, TEAM_BGUN, TEAM_SWATCQB};
};
--[[Shipment "Pump Shotgun" {
    Model = "models/weapons/w_shot_m3super90.mdl";
    Class = "weapon_pumpshotgun2";
    Price = 2199;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 230;
    Teams = {TEAM_GUN, TEAM_BGUN, TEAM_SWATCQB};
};]]--
Shipment "Scout" {
    Model = "models/weapons/w_snip_scout.mdl";
    Class = "weapon_mad_scout";
    Price = 3999;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 499;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_SWATRECON};
}; 
Shipment "Flash grenade" {
    Model = "models/weapons/w_eq_flashbang.mdl";
    Class = "weapon_mad_flash";
    Price = 999;
    Amount = 3;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
};

Shipment "Swat flash grenade" {
    Model = "models/weapons/w_eq_flashbang.mdl";
    Class = "weapon_mad_flash";
    Price = 999;
    Amount = 3;
	AvailableSeperately = true;
    SeperatePrice = 399;
    Teams = {TEAM_SWAT, TEAM_SWATMEDIC, TEAM_SWATCQB, TEAM_SWATRECON};
}; 
 
Shipment "P90" {
    Model = "models/weapons/w_smg_p90.mdl";
    Class = "weapon_mad_p90";
    Price = 2850;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 285;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
};
Shipment "Famas" {
    Model = "models/weapons/w_rif_famas.mdl";
    Class = "weapon_mad_famas";
    Price = 2950;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 295;
    Teams = {TEAM_HGUN, TEAM_BGUN};
};
Shipment "Galil" {
    Model = "models/weapons/w_rif_galil.mdl";
    Class = "weapon_mad_galil";
    Price = 3199;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 320;
    Teams = {TEAM_HGUN, TEAM_BGUN};
};
Shipment "M249" {
    Model = "models/weapons/w_mach_m249para.mdl";
    Class = "weapon_mad_m249";
    Price = 4150;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 415;
    Teams = {TEAM_HGUN, TEAM_BGUN};
};
Shipment "UMP" {
    Model = "models/weapons/w_smg_ump45.mdl";
    Class = "weapon_mad_ump";
    Price = 2799;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 290;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
};
Shipment "SG552" {
    Model = "models/weapons/w_rif_sg552.mdl";
    Class = "weapon_mad_sg552";
    Price = 3350;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 335;
    Teams = {TEAM_HGUN, TEAM_BGUN};
};
Shipment "Alyx" {
    Model = "models/weapons/w_alyx_gun.mdl";
    Class = "weapon_mad_alyxgun";
    Price = 8099;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1099;
    Teams = {TEAM_GUN, TEAM_CHIEF, TEAM_BGUN};
};
Shipment "Armor" {
    Model = "models/Items/BoxMRounds.mdl";
    Price = 1599;
    Amount = 5;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
    function (ply)	
	if (ply:GetMoveType() == 6) then -- wire users now return true for IsPlayer, this is a quick fix - pantho.
		self:Remove()
		return false;
	end
        local max = ply:GetClassArmor();
        if (max < 100) then
            max = 100;
        end
        if (ply:Armor() >= max) then
            return false;
        end
        ply:SetArmor(max);
    end
};
Shipment ".357 Magnum" {
    Model = "models/weapons/w_357.mdl";
    Class = "weapon_mad_357";
    Price = 6099;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 799;
    Teams = {TEAM_BGUN};
};
if !RP6 or !RP3 then
Shipment "StunStick" {
    Model = "models/weapons/W_stunbaton.mdl";
    Class = "stunstick";
    Price = 10099;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1299;
    Teams = {TEAM_BGUN};
};
end
Shipment "Keypad Cracker" {
    Model = "models/weapons/w_c4.mdl";
    Class = "weapon_keypad_cracker";
    Price = 10099;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1299;
    Teams = {TEAM_BGUN};
};
Shipment "Nomad" {
    Model = "models/weapons/w_smg1.mdl";
    Class = "weapon_nomad";
    Price = 10099;
    Amount = 10;
    Teams = {TEAM_BGUN};
};
Shipment "Nano-Flex Ammo" {
    -- TODO: Fix capitilisation in model name
    Model = "models/items/boxsrounds.mdl";
    Price = 1099;
    Amount = 10;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_MOB};
    function(ply)
	if (ply:GetMoveType() == 6) then -- wire users now return true for IsPlayer, this is a quick fix - pantho.
		self:Remove()
		return;
	end
        ply:GiveAmmo(100, "pistol");
    end
};
Shipment "Lockpick" {
    Model = "models/weapons/w_crowbar.mdl";
    Class = "lockpick";
    Price = 6099;
    Amount = 5;
    Teams = {TEAM_MOB,TEAM_BGUN};
};
Shipment "Explosive Charge" {
    Model = "models/weapons/w_slam.mdl";
    Class = "weapon_mad_charge";
    Price = 1099;
    Amount = 10;
    AvailableSeperately = false;
    Teams = {TEAM_MOB, TEAM_GUN, TEAM_BGUN, TEAM_CHIEF};
};
Shipment "Swat Explosive Charge" {
    Model = "models/weapons/w_slam.mdl";
    Class = "weapon_mad_charge";
    Price = 1099;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 199;
    Teams = {TEAM_SWAT, TEAM_SWATMEDIC, TEAM_SWATCQB, TEAM_SWATRECON};
};



Shipment "Medkit" {
    Model = "models/items/healthkit.mdl";
    Price = 1099;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 150;
    Teams = {TEAM_MEDIC, TEAM_SWATMEDIC};
    function(ply)
        if (ply:Health() >= 100) then
            return false;
        end
        ply:SetHealth(100);
        -- TODO: ply:EmitSound("medit_sound.wav");
    end
};
Shipment "Bananas" {
    Model = "models/props/cs_italy/bananna.mdl";
    Price = 10;
    Amount = 10;
    Teams = {-1};
    function() end
};

--------------------------
--                      --
--    Money Printers    --
--                      --
--------------------------

MoneyPrinter "Iron" {
    Price       = 1099;
	Material	= "models/props_pipes/pipeset_metal";
    PrintMin    = 1;
    PrintMax    = 2;
    MaxCanHave  = 4;
    CanExplode  = true;
};
MoneyPrinter "Silver" {
    Price       = 2099;
    Colour      = Color(255, 255, 255);
    PrintMin    = 2;
    PrintMax    = 3;
    MaxCanHave  = 2;
    CanExplode  = true;
};
MoneyPrinter "Golden" {
    Price       = 4099;
    Colour      = Color(255, 238, 0);
    PrintMin    = 2;
    PrintMax    = 4;
    MaxCanHave  = 1;
    CanExplode  = true;
};
MoneyPrinter "Emerald" {
    Price         = 5099;
    Colour        = Color(255, 0, 0);
	Material	  = "models/props_combine/Combine_Citadel001";
    PrintMin      = 2;
    PrintMax      = 4;
    MaxCanHave    = 1;
    CanExplode    = false;
    SupporterOnly = true;
};
MoneyPrinter "Ruby" {
    Price         = 5099;
    Colour        = Color(0, 255, 0);
	Material	  = "models/props_combine/Combine_Citadel001";
    PrintMin      = 2;
    PrintMax      = 4;
    MaxCanHave    = 1;
    CanExplode    = false;
    SupporterOnly = true;
};
MoneyPrinter "Amethyst" {
    Price         = 6099;
    Colour        = Color(255, 0, 255);
	Material	  = "models/props_combine/Combine_Citadel001";
    PrintMin      = 3;
    PrintMax      = 7;
    MaxCanHave    = 1;
    CanExplode    = true;
	ExplodeRadiusMin = 499;
	ExplodeRadiusMax = 999;
    SupporterOnly = true;
}
AddEntity("Beckis Box", "becki_box", "models/props_phx/oildrum001_explosive.mdl", 50, 5, "/buybeck", {TEAM_AGENT, TEAM_BGUN, TEAM_HITMAN, TEAM_MERC, TEAM_MTHIEF})
--AddEntity("Gun lab", "gunlab", "models/props_c17/TrapPropeller_Engine.mdl", 500, 1, "/buygunlab", TEAM_BGUN)
AddEntity("Ammo Machine", "ammo_machine", "models/props_lab/reciever_cart.mdl", 5000, 1, "/buyammomachine")
AddEntity("Crossbow Ammo", "xbow_ammo", "models/items/crossbowrounds.mdl", 8000, 0, "/buyxbowammo", {TEAM_HGUN, TEAM_BGUN})

AddCPDealerItem(1, "MP5 SMG n Ammo", "models/weapons/w_smg_mp5.mdl", "weapon_mad_mp5", 250)
AddCPDealerItem(1, "Nomad", "models/weapons/w_smg1.mdl", "weapon_nomad", 250)
AddCPDealerItem(1, "Spas Shotgun n Ammo", "models/weapons/w_shotgun.mdl", "weapon_mad_spas", 250)
AddCPDealerItem(1, "M3 Shotgun n Ammo", "models/weapons/w_shot_m3super90.mdl", "weapon_mad_m3", 250)
--AddCPDealerItem(1, "M3 Shotgun n Ammo", "models/weapons/w_shot_m3super90.mdl", "weapon_pumpshotgun2", 250)
AddCPDealerItem(3, "Health n Armor", "models/items/healthkit.mdl", "healthyou", 250)

-- TODO: EMPTY BOXES ARE NOW DIFEREINTENTSIDNGOSIDNG
AddEntity("Empty Box", "spawned_shipment", "models/Items/item_item_crate.mdl", 50, 5, "/buyemptyshipment")


AddEntity("Heal Drug[TEST]", "healpill", "models/healthvial.mdl", 500, 1, "/buthealpill", {TEAM_MEDIC,TEAM_SWATMEDIC})
--AddEntity("Damage Resistance Drug[TEST]", "dmgpill", "models/effects/resist_shield/resist_shield.mdl", 500, 1, "/butdmgpill", {TEAM_MEDIC,TEAM_SWATMEDIC})