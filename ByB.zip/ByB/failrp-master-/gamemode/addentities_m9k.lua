Shipment "Desert eagle" {
    Model = "models/weapons/w_tcom_deagle.mdl";
    Class = "m9k_deagle";
    Price = 2200;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 250;
    Teams = {TEAM_GUN, TEAM_HITMAN, TEAM_BGUN};
};
Shipment "Colt 1911" {
    Model = "models/weapons/s_dmgf_co1911.mdl";
    Class = "m9k_colt1911";
    Price = 1400;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 160;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "Colt Python" {
    Model = "models/weapons/w_colt_python.mdl";
    Class = "m9k_coltpython";
    Price = 2100;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 160;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "P228" {
    Model = "models/weapons/w_sig_229r.mdl";
    Class = "m9k_sig_p229r";
    Price = 1500;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 170;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
--[[
Shipment "Knife" {
    Model = "models/weapons/w_knife_t.mdl";
    Class = "weapon_mad_knife";
    Price = 500;
    Amount = 5;
    AvailableSeperately = true;
    SeperatePrice = 100;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
]]--
Shipment "Remington 1858" {
    Model = "models/weapons/w_remington_1858.mdl";
    Class = "m9k_remington1858";
    Price = 2300;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 240;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "AK47" {
    Model = "models/weapons/w_ak47_m9k.mdl";
    Class = "m9k_ak47";
    Price = 3200;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 350;
    Teams = {TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "MP5SD" {
    Model = "models/weapons/w_hk_mp5sd.mdl";
    Class = "m9k_mp5sd";
    Price = 2600;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 280;
    Teams = {TEAM_GUN, TEAM_CHIEF, TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "M4A1" {
    Model = "models/weapons/w_m4a1_iron.mdl";
    Class = "m9k_m4a1";
    Price = 3550;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 370;
    Teams = {TEAM_HGUN, TEAM_BGUN};
}; 
Shipment "Uzi" {
    Model = "models/weapons/w_uzi_imi.mdl";
    Class = "m9k_uzi";
    Price = 2000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 210;
    Teams = {TEAM_GUN, TEAM_BGUN};
}; 
Shipment "TEC9" {
    Model = "models/weapons/w_intratec_tec9.mdl";
    Class = "m9k_tec9";
    Price = 2150;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 230;
    Teams = {TEAM_GUN, TEAM_BGUN};
}; 
Shipment "Winchester 1897" {
    Model = "models/weapons/w_winchester_1897_trench.mdl";
    Class = "m9k_1897winchester";
    Price = 1850;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 190;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_SWATCQB};
}; 
Shipment "Barret M82" {
    Model = "models/weapons/w_barret_m82.mdl";
    Class = "m9k_barret_m82";
    Price = 9000;
    Amount = 10;
    Teams = {TEAM_HGUN, TEAM_BGUN, TEAM_SWATRECON};
}; 
Shipment "SPAS 12" {
    Model = "models/weapons/w_spas_12.mdl";
    Class = "m9k_spas12";
    Price = 2100;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 230;
    Teams = {TEAM_GUN, TEAM_BGUN, TEAM_SWATCQB};
}; 
Shipment "Mossberg 590" {
    Model = "models/weapons/w_mossberg_590.mdl";
    Class = "m9k_mossberg590";
    Price = 2100;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 230;
    Teams = {TEAM_GUN, TEAM_BGUN, TEAM_SWATCQB};
}; 
Shipment "SVT 40" {
    Model = "models/weapons/w_svt_40.mdl";
    Class = "m9k_svt40";
    Price = 3900;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 400;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_SWATRECON};
}; 
Shipment "Flash grenade" {
    Model = "models/weapons/w_eq_flashbang.mdl";
    Class = "weapon_mad_flash";
    Price = 900;
    Amount = 3;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
};

Shipment "Swat flash grenade" {
    Model = "models/weapons/w_eq_flashbang.mdl";
    Class = "weapon_mad_flash";
    Price = 900;
    Amount = 3;
	AvailableSeperately = true;
    SeperatePrice = 300;
    Teams = {TEAM_SWAT, TEAM_SWATMEDIC, TEAM_SWATCQB, TEAM_SWATRECON};
}; 
 
Shipment "P90" {
    Model = "models/weapons/w_fn_p90.mdl";
    Class = "m9k_smgp90";
    Price = 2850;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 285;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
};
Shipment "Famas" {
    Model = "models/weapons/w_tct_famas.mdl";
    Class = "m9k_famas";
    Price = 2950;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 295;
    Teams = {TEAM_HGUN, TEAM_BGUN};
};
Shipment "FN FAL" {
    Model = "models/weapons/w_fn_fal.mdl";
    Class = "m9k_fal";
    Price = 3100;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 320;
    Teams = {TEAM_HGUN, TEAM_BGUN, TEAM_MERC};
};
Shipment "KRISS Vector" {
    Model = "models/weapons/w_kriss_vector.mdl";
    Class = "m9k_vector";
    Price = 4150;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 415;
    Teams = {TEAM_GUN, TEAM_BGUN};
};
Shipment "Magpul PDR" {
    Model = "models/weapons/w_magpul_pdr.mdl";
    Class = "m9k_magpulpdr";
    Price = 2700;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 290;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN};
};
Shipment "Double Barreled SG" {
    Model = "models/weapons/w_double_barrel_shotgun.mdl";
    Class = "m9k_dbarrel";
    Price = 8500;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 900;
    Teams = {TEAM_HGUN, TEAM_BGUN};
};
Shipment "Luger" {
    Model = "models/weapons/w_luger_p08.mdl";
    Class = "m9k_luger";
    Price = 7000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 800;
    Teams = {TEAM_GUN, TEAM_CHIEF, TEAM_BGUN};
};
Shipment "Armor" {
    Model = "models/Items/BoxMRounds.mdl";
    Price = 1500;
    Amount = 5;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_MERC};
    function (ply)	
	if (ply:GetMoveType() == 6) then -- wire users now return true for IsPlayer, this is a quick fix - pantho.
		self:Remove()
		return false;
	end
        local max = ply:GetClassArmor();
        if (max < 100) then
            max = 100;
        end
        if (ply:Armor() >= max) then
            return false;
        end
        ply:SetArmor(max);
    end
};
Shipment "Raging Bull" {
    Model = "models/weapons/w_taurus_raging_bull.mdl";
    Class = "m9k_ragingbull";
    Price = 6000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 700;
    Teams = {TEAM_BGUN};
};
if !RP6 or !RP3 then
Shipment "StunStick" {
    Model = "models/weapons/W_stunbaton.mdl";
    Class = "stunstick";
    Price = 10000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1200;
    Teams = {TEAM_BGUN};
};
end
Shipment "Keypad Cracker" {
    Model = "models/weapons/w_c4.mdl";
    Class = "weapon_keypad_cracker";
    Price = 10000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 1200;
    Teams = {TEAM_BGUN};
};
Shipment "Nomad" {
    Model = "models/weapons/w_smg1.mdl";
    Class = "weapon_nomad";
    Price = 10000;
    Amount = 10;
    Teams = {TEAM_BGUN};
};
Shipment "Nano-Flex Ammo" {
    -- TODO: Fix capitilisation in model name
    Model = "models/items/boxsrounds.mdl";
    Price = 1000;
    Amount = 10;
    Teams = {TEAM_GUN, TEAM_HGUN, TEAM_BGUN, TEAM_MOB};
    function(ply)
	if (ply:GetMoveType() == 6) then -- wire users now return true for IsPlayer, this is a quick fix - pantho.
		self:Remove()
		return;
	end
        ply:GiveAmmo(100, "pistol");
    end
};
Shipment "Lockpick" {
    Model = "models/weapons/w_crowbar.mdl";
    Class = "lockpick";
    Price = 6000;
    Amount = 5;
    Teams = {TEAM_MOB,TEAM_BGUN};
};
Shipment "Explosive Charge" {
    Model = "models/weapons/w_slam.mdl";
    Class = "weapon_mad_charge";
    Price = 1000;
    Amount = 10;
    AvailableSeperately = false;
    Teams = {TEAM_MOB, TEAM_GUN, TEAM_BGUN, TEAM_CHIEF};
};
Shipment "Swat Explosive Charge" {
    Model = "models/weapons/w_slam.mdl";
    Class = "weapon_mad_charge";
    Price = 1000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 100;
    Teams = {TEAM_SWAT, TEAM_SWATMEDIC, TEAM_SWATCQB, TEAM_SWATRECON};
};



Shipment "Medkit" {
    Model = "models/items/healthkit.mdl";
    Price = 1000;
    Amount = 10;
    AvailableSeperately = true;
    SeperatePrice = 150;
    Teams = {TEAM_MEDIC, TEAM_SWATMEDIC};
    function(ply)
        if (ply:Health() >= 100) then
            return false;
        end
        ply:SetHealth(100);
        -- TODO: ply:EmitSound("medit_sound.wav");
    end
};
Shipment "Bananas" {
    Model = "models/props/cs_italy/bananna.mdl";
    Price = 10;
    Amount = 10;
    Teams = {-1};
    function() end
};

--------------------------
--                      --
--    Money Printers    --
--                      --
--------------------------

MoneyPrinter "Iron" {
    Price       = 1000;
	Material	= "models/props_pipes/pipeset_metal";
    PrintMin    = 1;
    PrintMax    = 2;
    MaxCanHave  = 4;
    CanExplode  = true;
};
MoneyPrinter "Silver" {
    Price       = 2000;
    Colour      = Color(255, 255, 255);
    PrintMin    = 2;
    PrintMax    = 3;
    MaxCanHave  = 2;
    CanExplode  = true;
};
MoneyPrinter "Golden" {
    Price       = 4000;
    Colour      = Color(255, 238, 0);
    PrintMin    = 2;
    PrintMax    = 4;
    MaxCanHave  = 1;
    CanExplode  = true;
};
MoneyPrinter "Emerald" {
    Price         = 5000;
    Colour        = Color(255, 0, 0);
	Material	  = "models/props_combine/Combine_Citadel001";
    PrintMin      = 2;
    PrintMax      = 4;
    MaxCanHave    = 1;
    CanExplode    = false;
    SupporterOnly = true;
};
MoneyPrinter "Ruby" {
    Price         = 5000;
    Colour        = Color(0, 255, 0);
	Material	  = "models/props_combine/Combine_Citadel001";
    PrintMin      = 2;
    PrintMax      = 4;
    MaxCanHave    = 1;
    CanExplode    = false;
    SupporterOnly = true;
};
MoneyPrinter "Amethyst" {
    Price         = 6000;
    Colour        = Color(255, 0, 255);
	Material	  = "models/props_combine/Combine_Citadel001";
    PrintMin      = 3;
    PrintMax      = 7;
    MaxCanHave    = 1;
    CanExplode    = true;
	ExplodeRadiusMin = 400;
	ExplodeRadiusMax = 900;
    SupporterOnly = true;
}
AddEntity("Beckis Box", "becki_box", "models/props_phx/oildrum001_explosive.mdl", 50, 5, "/buybeck", {TEAM_AGENT, TEAM_BGUN, TEAM_HITMAN, TEAM_MERC, TEAM_MTHIEF})
-- AddEntity("Gun lab", "gunlab", "models/props_c17/TrapPropeller_Engine.mdl", 500, 1, "/buygunlab", TEAM_BGUN)
AddEntity("Ammo Machine", "ammo_machine", "models/props_lab/reciever_cart.mdl", 5000, 1, "/buyammomachine")
AddCPDealerItem(1, "SCAR", "models/weapons/w_fn_scar_h.mdl", "m9k_scar", 250)
AddCPDealerItem(1, "Nomad", "models/weapons/w_smg1.mdl", "weapon_nomad", 250)
AddCPDealerItem(1, "Striker 12", "models/weapons/w_striker_12g.mdl", "m9k_striker12", 250)
AddCPDealerItem(3, "Health and Armor", "models/items/healthkit.mdl", "healthyou", 250)

-- TODO: EMPTY BOXES ARE NOW DIFEREINTENTSIDNGOSIDNG
AddEntity("Empty Box", "spawned_shipment", "models/Items/item_item_crate.mdl", 50, 5, "/buyemptyshipment")