-- Instead of adding to cl_init.lua im going to add to this from now on, incase we ever need to jump ship to a newer darkrp revision.
-- Love Pantho
local name,steamname,teamname;
timer.Simple(10, function()
	-- Removing options from entitiy context menu
	properties.Add("Remove",{})
	properties.Add("Ignite",{})
	properties.Add("Statue",{})
	properties.Add("Persist",{})
	--if not LocalPlayer():IsSupporter() then
	properties.Add("collision_off",{})
	properties.Add("collision_on",{})
	--end
	properties.Add("drive",{})
	properties.Add("gravity",{})
	properties.Add("keepupright",{})
	properties.Add("skin",{})
	properties.Add("bodygroups",{})
	for k, v in pairs( g_SpawnMenu.CreateMenu.Items ) do
		if (v.Tab:GetText() == language.GetPhrase("spawnmenu.category.saves") or 
			v.Tab:GetText() == language.GetPhrase("spawnmenu.category.loads") or 
			v.Tab:GetText() == language.GetPhrase("spawnmenu.category.dupes")) then
			g_SpawnMenu.CreateMenu:CloseTab( v.Tab, true )
		end
	end
end)
net.Receive("IrSpecing", function ()
    local ply = net.ReadEntity()
	if not IsValid(ply) then return end
	if ply.Spectating then 
		ply.Spectating = false
	else 
		ply.Spectating = true 
	end
end)
-- The simple ent and player tracking for super admin on duty
hook.Add("HUDPaint", "EntTracker", function() 
	if not LocalPlayer().HaxOn then
		LocalPlayer().TrackEnt = ""
		return
	end
	for k,v in pairs ( player.GetAll() ) do 		
		local TeamCol = team.GetColor( v:Team()  )
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen() 
		draw.SimpleText( v:Name(), "Default", Position.x, Position.y, TeamCol )
                
	end 
	local ent = LocalPlayer():GetEyeTrace().Entity;
	if IsValid(ent) then
		draw.SimpleText( "Ent ClassName: " .. ent:GetClass(), "Default", 5, 1,  color_white )
		draw.SimpleText( "Ent Model: " ..     ent:GetModel(), "Default", 5, 30, color_white )
		draw.SimpleText( "Ent ID: " ..        ent:EntIndex(), "Default", 5, 60, color_white )
	end
	if not LocalPlayer().TrackEnt or LocalPlayer().TrackEnt == "" then
		return
	end
	
	local TrackEnt = string.Explode(";", LocalPlayer().TrackEnt)
		
	local colours = {
	Color(255,255,255,255), 	-- white
	Color(255,0,0,255),			-- red
	Color(0,255,0,255),			-- green
	Color(0,0,255,255),			-- blue
	Color(158,61,255,255),		-- purple
	Color(127,255,0,255),		-- chartreuse (happy ride?)
	}
	
	local ccount = 1
	
	for k,v in pairs(TrackEnt) do
	
		for k,v in pairs ( ents.FindByClass(v) ) do
			local Position = ( v:GetPos() + Vector( 0,0,0 ) ):ToScreen() 
			draw.SimpleText( v:GetClass(), "Default", Position.x, Position.y, colours[ccount] )
		end
	
		if ccount >= table.getn(colours) then ccount = 1 else ccount = ccount + 1 end
	
	end
	
end)

concommand.Add("TrackEnt", function(ply,_,args)

	if not LocalPlayer().HaxOn then
		ply:ChatPrint("You don't appear to be allowed to use this command.")
		return
	end

	if next(args) == nil then
		ply:ChatPrint("Tracking cleared.")
		LocalPlayer().TrackEnt = ""
	else
	
		local ttext = ""

		for k,v in pairs(args) do
			ttext = ttext .. " " .. v
		end
	
		ply:ChatPrint("Tracking:" .. ttext)
	
		LocalPlayer().TrackEnt = tostring(table.concat(args, ";"))
	
	end
end)

local copcalls = copcalls or {}
local cin = (math.sin(CurTime()) + 1) / 2
local col = Color(cin * 255, 0, 255 - (cin * 255), 255)
local pos
local ct = CurTime()
surface.CreateFont( "CopFont", {
 font = "coolvetica",
 size = 22,
 weight = 500,
 antialias = true,
 shadow = true,
} )
net.Receive("911calls", function ()
	if CurTime() < ct then return end
	if not LocalPlayer():IsCP() then return end
    local callpos = net.ReadVector()
    local caller = net.ReadString()
	table.insert(copcalls,{callpos,caller})
	timer.Simple(15, function() ct = CurTime() + 15 copcalls = {} end)
end)
hook.Add("HUDPaint", "911callsforhud", function()
	if not IsValid(LocalPlayer()) then return end
	cin = (math.sin(CurTime()) + 1) / 2
	for k,v in pairs(copcalls) do 
		pos = (v[1] + Vector(0,0,50)):ToScreen()
		dist = v[1]:Distance(LocalPlayer():GetPos())
		draw.SimpleText(v[2] .. "'s 911 Call @ " .. math.floor(dist,1), "CopFont",pos.x ,pos.y , Color(cin * 255, 0, 255 - (cin * 255), 255))
	end
end)

local function RootToggle() 
   if (LocalPlayer().RootMode)
      then LocalPlayer().RootMode = false
   else
      LocalPlayer().RootMode = true
   end
end
usermessage.Hook("ToggleRoot", RootToggle)

concommand.Add("HaxToggle", function(ply,_,_)
	if ply.HaxOn == true then
		ply.HaxOn = false
		ply:ChatPrint("Hax are now off darling!")
	elseif ply:IsRoot() then 
		ply.HaxOn = true 
		ply:ChatPrint("Hax enabled Mr Root Slut!")
	elseif (ply:IsSuperAdmin() and ply:Team() == 22) then
		ply.HaxOn = true
		ply:ChatPrint("Hax on babeh!")
	else
		ply.HaxOn = false
		ply:ChatPrint("You don't appear to be allowed to use this command.")
	end
end)

concommand.Add("debugpantho", function(ply,_,_)
	if ply.RootMode then
	print("check")
		hook.Add( "HUDPaint", "DBugHUD", DBug.Draw );
	end
	print("fail")
end)

timer.Create( "haxcheck", 5, 0, function()
	if IsValid(LocalPlayer()) then
		if LocalPlayer():IsRoot() then return end
		if LocalPlayer().HaxOn == true and LocalPlayer():Team() ~= 22 then
			LocalPlayer():ChatPrint("Hax disabled due to job change")
			LocalPlayer().HaxOn = false
		end
	end
end)

--[[ Admin Gettr ]]--
local numbers = {
	user = 0,
	players = 0,
	respected = 1,
	moderators = 2,
	admin = 3,
    trusted_admin = 4,
	superadmin = 5,
	owners = 6,
}
local function comp3(p1, p2)
	local r1, r2 = p1:IsRoot(), p2:IsRoot();
    if (r1 == r2) then 
        return p1:Name() < p2:Name()
    else
        return r1
    end
end

local supporter = function(ply) return ply.IsSupporter and ply:IsSupporter() or false end
local function comp2(p1, p2)
    local s1,s2 = supporter(p1), supporter(p2);
    if (s1 == s2) then 
        return comp3(p1, p2);
    else
        return s1
    end
end
local function comp(p1, p2)
	local n1, n2 = numbers[p1.ug] or -1, numbers[p2.ug] or -1
	if (n1 == n2) then
		return comp2(p1, p2)
	else
		return n1 > n2;
	end
end

local line = "| %-3i | %-3s | %-32s | %-19s | %-18s | %-14s | %-32s |"
concommand.Add("getplayers",function()
	if (not (LocalPlayer():IsSuperAdmin() or LocalPlayer():IsRoot())) then
		return;
	end
	print([[
+-----+-----+----------------------------------+---------------------+--------------------+----------------+----------------------------------+
| EID | Tag | Name                             | Team                | SteamID            | Usergroup      | Steam Name                       |
+-----+-----+----------------------------------+---------------------+--------------------+----------------+----------------------------------+]])
	local plytab = player.GetAll();
	for _,ply in pairs(plytab) do
		ply.ug = ply:GetNWString('usergroup');
	end
	table.sort(plytab, comp);
	local ug, tag, name, steamname, teamname
	for _, ply in ipairs(plytab) do
		ug = ply.ug;
		tag = " ";
		if (ug == "superadmin" or ply:IsSuperAdmin()) then
			tag = "^";
		elseif (ug == "admin" or ply:IsAdmin()) then
			tag = "*";
		elseif (ply.IsModerator and ply:IsModerator()) then
			tag = "@";
		end
		if (supporter(ply)) then
			tag = tag .. "#";
		end
		if (ply:IsRoot()) then
			tag = tag .. "~";
		end
		name = string.sub(ply:Name(), 1, 32);
		steamname = string.sub(ply:SteamName(), 1, 32);
		teamname = string.sub(team.GetName(ply:Team()), 1, 20)
		print(string.format(line, ply:EntIndex(), tag, name, teamname, ply:SteamID(), ug, steamname));
	end
	print("+-----+-----+----------------------------------+---------------------+--------------------+----------------+----------------------------------+");
end);

--[[ PROP INFO ]]--
function EntInFront()
	local ent = LocalPlayer():GetEyeTrace().Entity;
	if (IsValid(ent)) then
		return ent;
	end
end

local function Notify(words)
	words = tostring(words);
	if GAMEMODE.AddNotify then
		GAMEMODE:AddNotify(words, NOTIFY_GENERIC, 3);
	else
		LocalPlayer():ChatPrint(words);
	end
end

function math.DecimalPlaces(numb,places)
	return math.Round(numb*10^places)/10^places;
end
local a = "-- %-10s: %-73s --"
local function f(b,c)
	print(string.format(a,b,c))
end
local b = "Vector(%9.4f, %9.4f, %9.4f)";
local function makepos(a)
	return string.format(b,a.x,a.y,a.z);
end
local c = "Angle(%4i, %4i, %4i)";
local function makeang(b)
	return string.format(c,b.p,b.y,b.r);
end

concommand.Add("propinfo", function()
	if (not (LocalPlayer():IsAdmin() or LocalPlayer():IsRoot())) then
		return;
	end
	local ent = EntInFront();
	if (not ent) then
		Notify("No Entity");
		return;
	end
	print("-------------------------------------------------------------------------------------------")
	print("--                                      Prop info                                        --")
	print("-------------------------------------------------------------------------------------------")
	f("Info",  tostring(ent))	
	f("Model", '"' .. ent:GetModel() .. '"')
	local str = tostring(ent) .. "[" .. ent:GetModel() .. "]"
	local owner = ent:GetNWEntity("OwnerObj")
	if (IsValid(owner) and owner:IsPlayer()) then
		owner = owner:Name()
	else
		owner = ent:GetNWString("Owner")
		if (owner == "") then
			owner = nil
			if (ent.FAPPData and ent.FAPPData.OwnerName) then
				owner = ent.FAPPData.OwnerName;
			end
		end
	end
	if (owner) then
		str = str .. "[" .. owner .. "]"
		f("Owner", owner)
	end
	f("Quick", str)
	Notify(str)
	print("-------------------------------------------------------------------------------------------")
	if(ent:IsPlayer()) then
		print("--                                     Player info                                       --")
		print("-------------------------------------------------------------------------------------------")
		local name, sid, uid = ent:Name(), ent:SteamID(), ent:UniqueID()
		f("Name", 	  name)
		f("SteamID",  sid)
		f("UniqueID", uid)
		local str = "[" .. name .. "][" .. sid .. "][" .. uid .. "]"
		Notify(str)
		f("Quick",    str)
		print("-------------------------------------------------------------------------------------------")
	end
	print("--                                     Other info                                        --")
	print("-------------------------------------------------------------------------------------------")
	f("Position", 	makepos(ent:GetPos()))
	f("Angle", 		makeang(ent:GetAngles()))
	local c = ent:GetColor()
	f("Colour", 	"Color("..c.r..",  "..c.g..",  "..c.b..",  "..c.a..")")
	f("Material", 	tostring(ent:GetMaterial()))
	f("Size", 		tostring(ent:OBBMaxs() - ent:OBBMins()))
	f("Radius", 	tostring(ent:BoundingRadius()))
	print("-------------------------------------------------------------------------------------------")
end)

net.Receive("ColorChatPrints", function ()
    local text = net.ReadTable() or {}
	chat.AddText(unpack(text))
end)

net.Receive("ColorConsolePrints", function ()
    local text = net.ReadTable() or {}    
    MsgC(unpack(text))
end)

-- trololololololololo when pantho gets bored at 5am.
local col = Color(255,0,0,255)
local col2 = Color(255,255,0,255)
surface.CreateFont( "DeonsIcky", {
 font = "akbar",
 size = 50,
 weight = 1000,
 blursize = 0,
 scanlines = 0,
 antialias = true,
 underline = false,
 italic = false,
 strikeout = false,
 symbol = false,
 rotary = false,
 shadow = false,
 additive = false,
 outline = false
} )
function ByeByeDeon()
	hook.Add("HUDPaint", "BADPUPPY", function()
		draw.SimpleText("People we love see balls, people we don't see deformed evil squares!","DeonsIcky",(ScrW()+(ScrW()/4))-ScrW(),(ScrH()+50)-ScrH(),col)
		surface.SetDrawColor(0, 255, 0, 255)
		surface.DrawRect((ScrW()+100)-ScrW() , (ScrH()+300)-ScrH(), ScrW()-200, ScrH()-400 )
		draw.SimpleText("Seriously, your 'ball' is not only a square but it's not even yellow :( Deon you are the product of incest","DeonsIcky",(ScrW()+(ScrW()/4))-ScrW(),(ScrH()+600)-ScrH(),col2)
		end)
		timer.Simple(60, function() hook.Remove("HUDPaint","BADPUPPY") end)
end

--- Car stuffs.
local spamzor = 0

hook.Add( "Tick","HornOnReload",function()
	if IsValid(LocalPlayer()) then
		if ( LocalPlayer():KeyPressed( IN_RELOAD )) and LocalPlayer():InVehicle() then 
			spamzor = spamzor + 1
			if (spamzor >= 10) then
				chat.AddText(Color(255,0,0),"Horn disabled for 30 seconds, usage is limited to 10 horns every 30 seconds")
			else
				timer.Create("SPAMZORShorn",1,30, function() spamzor = 0 end)
				LocalPlayer():ConCommand("HonkHorn")
			end
		end
	end
end )


net.Receive("ContentMenu", function()
	if RP6 then
		steamworks.ViewFile(150139465) -- just tdm
	elseif RP3 then
		steamworks.ViewFile(149373045)	-- m9k plus tdm
	else
	--	steamworks.ViewFile(133342076)	-- just police model
	end
end)

-- Checks for police model, requests players to view content page if not found.

timer.Simple(30, function()	
	if RP3 then
		chat.AddText(Color(255,0,0),"You are playing RP3 which is testing M9K Weapons Pack. Please type !content if you experience any error with the weapon/player models.")
	--elseif not file.Exists("models/player/elispolice/police.mdl","GAME") then
	--	chat.AddText(Color(255,0,0),"Warning - Workshop file failure detected, custom content page will force open in 5 seconds. To fix potentiall errors please subscribe to the addon. If the page fails to open you may type !content to force refresh")
	--	chat.AddText(Color(0,0,255),"www.bybservers.co.uk")
	--	timer.Simple(5,function()
	--		steamworks.ViewFile(133342076)
	--	end)
	--else
	--	chat.AddText(Color(0,255,0),"Our content appears to be loaded, if you view any errors please make sure you have downloaded all workshop file required, you may subscribe manually by typing !content")
	end
end)
--[[
timer.Simple(20,function()
	local check = 0
	if file.Exists("models/player/elispolice/police.mdl","GAME") then
		check = 1
	end
	net.Start("workshopwork")
	net.WriteString(tostring(check))
	net.SendToServer()
end)
]]--
-- Let's be kind.
timer.Simple(120,function()
    if LocalPlayer():IsRoot() then
        return
    end
	if LocalPlayer():IsSuperAdmin() then
		chat.AddText(Color(0,0,255),"You're a Super: ",Color(0,255,0),"Be nicer with warnings you jerks! That or become Deon 2.0...")
	elseif LocalPlayer():IsAdmin() then
		chat.AddText(Color(0,0,255),"You're an Admin: ",Color(0,255,0),"Please treat people kindly. Often people just need a polite word about breaking rules. Instead of being instantly punished.")
	end
end)

net.Receive("omgawdsansadmin", function()
	local ply = net.ReadEntity()
	if IsValid(ply) then ply.SADON = true end	
end)

net.Receive("ByBClearGibs", function ()
    for k,v in pairs (ents.GetAll()) do
	local class = v:GetClass()
		if v:IsValid() and class == "class C_PhysPropClientside" or class == "class C_ClientRagdoll" then 
			v:Remove()
		end 
	end
end)
--[[
hook.Add("InitPostEntity", "vivalapudding", function()
	local num = 0
	timer.Simple(60,function() 
		for k,v in pairs(hook.GetTable()) do
			num = num + 1
		end
		net.Start("VivaLaPudding")
		net.WriteInt(num,32)
		net.SendToServer()
	end)
end)
]]

-- silly quick dmglog thing, makes life simpler
function FunLogDraw(data)
	if not data then return end
	local menu = vgui.Create("DFrame")
	menu:SetSize(600,600)
	menu:Center()
	menu:SetTitle("FunLog: Super simple, only records last 500 events!")
	local panel = vgui.Create("DPanel",menu)
	panel:SetSize(menu:GetWide()-10,menu:GetTall()-25)
	panel:SetPos(5,20)
	panel.Paint = function()
		surface.SetDrawColor(Color(125,20,90,255))
		surface.DrawRect(0,0,panel:GetWide(),panel:GetTall())
	end
	local DataBox = vgui.Create("DListView",panel)
	DataBox:SetSize(panel:GetWide()-10,panel:GetTall()-10)
	DataBox:Center()
	DataBox:AddColumn("ID"):SetFixedWidth(5)
	DataBox:AddColumn("Time"):SetFixedWidth(100)
	DataBox:AddColumn("Event")
	for k,v in pairs(data) do
		DataBox:AddLine(v[1],os.date("%a,%H:%M:%S",tonumber(v[1])),v[2])
	end
	DataBox:SortByColumn(1)
	menu:MakePopup()
end
net.Receive("funlogsend", function()
	local x = net.ReadTable()
	if x then FunLogDraw(x) else print("Failure loading funlog table") end
end)
function EveryoneLetsAct(action)
    for k,v in pairs(player.GetAll()) do
        if v:IsValid() then 
            v:AnimRestartGesture(GESTURE_SLOT_CUSTOM, action, true)
        end
    end
end