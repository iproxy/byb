-- hurf
if (SERVER) then
    return;
end

-- This leaves the option open to /not/ using fucking chat commands for fucking everything
local function runcmd(cmd, ...)
    --LocalPlayer():ConCommand("say /" .. cmd .. " " .. table.concat({...}, " "));
    RunConsoleCommand("say", "/" .. cmd .. " " .. table.concat({...}, " "));
end

local function cmdclick(cmd, arg)
    return function()
        runcmd(cmd, arg)
    end
end
local function cmdvalue(cmd)
    return function(pnl)
        runcmd(cmd, pnl:GetValue())
    end
end

local function plycmd(cmd, ply, noreason)
    return function(...)
        if (IsValid(ply)) then
            runcmd(cmd, ply:UserID(), noreason and "" or ...);
        end
    end
end

local function playermenu(action, predicate)
    local lpl = LocalPlayer();
    local menu = DermaMenu();
    local entries = false;
    for _, ply in pairs(player.GetAll()) do
        if (ply == lpl or predicate and not predicate(ply)) then
            continue;
        end
        menu:AddOption(ply:Name(), action(ply));
        entries = true;
    end
    if not entries then
        menu:AddOption(LANGUAGE.noone_available, function() end)
    end
    menu:Open();
end

local function playerreasonmenu(title, message, command, predicate)
    playermenu(function(ply)
        return function()
            if (not IsValid(ply)) then return; end
            Derma_StringRequest(
                title,
                string.format(message, ply:Name()),
                "",
                plycmd(command, ply)
            )
        end
    end, predicate);
end

--------------------------------------
--                                  --
--           Money Panel            --
--                                  --
--------------------------------------
local PANEL = {}
function PANEL:Init()

    self.give = vgui.Create("DButton", self);
    self.drop = vgui.Create("DButton", self);

    self.give:SetText(LANGUAGE.give_money);
    self.drop:SetText(LANGUAGE.drop_money);

    function self.give:DoClick()
        Derma_StringRequest(
            "Amount of money",
            "How much money do you want to give?",
            "",
            function(value)
                runcmd("give", value);
            end
        )
    end
    function self.drop:DoClick()
        Derma_StringRequest(
            "Amount of money",
            "How much money do you want to drop?",
            "",
            function(value)
                runcmd("dropmoney", value);
            end
        )
    end

    self.give:Dock(TOP);
    self.drop:Dock(TOP);
end

function PANEL:PerformLayout()
    --[[
    self.give:SizeToContents();
    self.drop:SizeToContents();
    --]]
    self:SizeToChildren(false, true);
end

local moneypanel = vgui.RegisterTable(PANEL, "DPanel");

--------------------------------------
--                                  --
--          Command Panel           --
--                                  --
--------------------------------------
local PANEL = {};

function PANEL:Init()

    self.rename      = vgui.Create("DPanel", self);
    self.renamelabel = vgui.Create("DLabel", self.rename);
    self.renamebox   = vgui.Create("DTextEntry", self.rename);
    self.job         = vgui.Create("DPanel", self);
    self.joblabel    = vgui.Create("DLabel", self.job);
    self.jobbox      = vgui.Create("DTextEntry", self.job);
    self.colour      = vgui.Create("DPanel", self);
    self.colourlabel = vgui.Create("DLabel", self.colour);
    self.colourbox   = vgui.Create("DTextEntry", self.colour);
    self.gundrop     = vgui.Create("DButton", self);
    self.selldoors   = vgui.Create("DButton", self);
    self.stats   = vgui.Create("DButton", self);

    self.renamelabel:SetText(LANGUAGE.change_name);
    self.renamebox:  SetText(LocalPlayer():Name());
    self.joblabel:   SetText(LANGUAGE.set_custom_job);
    self.colourlabel:SetText("Enter a color for your player clothing. This must be in R G B. Example: 255 0 0 would be red, or 254 0 255 would be pink");
    self.colourbox:  SetText("255 255 255");
    self.gundrop:    SetText(LANGUAGE.drop_weapon);
    self.selldoors:  SetText("Sell all of your doors2");
    self.stats:  SetText("GamePlayer Statistics(BETA)");

    self.renamelabel:SetColor(Color(0,0,0));
    self.joblabel:SetColor(Color(0,0,0));
    self.colourlabel:SetColor(Color(0,0,0));

    local rename = cmdvalue("rpname");
    self.renamebox.OnEnter = rename;
    self.renamebox.OnLoseFocus = rename;
    local job = cmdvalue("job");
    self.jobbox.OnEnter = job;
    self.jobbox.OnLoseFocus = job;
    local colour = cmdvalue("clothescolour")
    self.colourbox.OnEnter = colour;
    self.colourbox.OnLoseFocus = colour;

    self.gundrop.DoClick = cmdclick("drop");
    self.selldoors.DoClick = cmdclick("unownalldoors");
    self.stats.DoClick = DrawStatsMenu();

    self.rename:Dock(TOP);
    self.renamelabel:Dock(TOP);
    self.renamebox:Dock(TOP);
    self.job:Dock(TOP);
    self.joblabel:Dock(TOP);
    self.jobbox:Dock(TOP);
    self.colour:Dock(TOP);
    self.colourlabel:Dock(TOP);
    self.colourbox:Dock(TOP);
    self.gundrop:Dock(TOP);
    self.selldoors:Dock(TOP);
    self.stats:Dock(TOP);

    self.renamelabel:DockMargin(5, 0, 0, 0);
    self.joblabel:DockMargin(5, 0, 0, 0);
    self.colourlabel:DockMargin(5, 0, 0, 0);

    self.issupporter = LocalPlayer():IsSupporter();
    if (self.issupporter) then
        self.demote = vgui.Create("DButton", self);
        self.demote:SetText(LANGUAGE.demote_player_menu);
        function self.demote:DoClick()
            playerreasonmenu("Demote", "Why do you want to demote %s?", "demote");
        end
        self.demote:Dock(TOP);
    end
end

function PANEL:PerformLayout()
    self.rename:SizeToChildren(false, true)
    self.job:SizeToChildren(false, true)
    self.colour:SizeToChildren(false, true)
    --[[
    self.gundrop:SizeToContents();
    self.selldoors:SizeToContents();
    if (self.issupporter) then
        self.demote:SizeToContents();
    end
    --]]
    self:SizeToChildren(false, true)
end

local commandspanel = vgui.RegisterTable(PANEL, "DPanel");

--------------------------------------
--                                  --
--          Citizen Panel           --
--                                  --
--------------------------------------
local PANEL = {};

function PANEL:Init()
    self.label = vgui.Create("DLabel", self);
    self.entry = vgui.Create("DTextEntry", self);

    self.label:DockMargin(5, 0, 0, 0);
    self.label:SetColor(Color(0,0,0));
    self.label:SetText(LANGUAGE.set_custom_job);

    self.entry.OnEnter = cmdvalue("job");

    self.label:Dock(TOP);
    self.entry:Dock(TOP);
end

function PANEL:PerformLayout()
    self:SizeToChildren(false, true);
end

local citizenpanel = vgui.RegisterTable(PANEL, "DPanel");

--------------------------------------
--                                  --
--          Police Panel            --
--                                  --
--------------------------------------
local PANEL = {};

function PANEL:Init()
    self.warrant  = vgui.Create("DButton", self);
    self.wanted   = vgui.Create("DButton", self);
    self.unwanted = vgui.Create("DButton", self);

    self.wanted:SetText(LANGUAGE.make_wanted);
    self.warrant:SetText(LANGUAGE.request_warrant);
    self.unwanted:SetText(LANGUAGE.unwarrantbutton);

    function self.wanted:DoClick()
        playerreasonmenu("Wanted", "Why do you want to make %s wanted?", "wanted", function(ply) return not ply.DarkRPVars.wanted; end);
    end
    function self.warrant:DoClick()
        playerreasonmenu("Search Warrant", "Why do you want a search warrant for %s?", "wanted", function(ply) return not ply.DarkRPVars.warrant; end);
    end
    function self.unwanted:DoClick()
        playermenu(function(ply) return plycmd("unwanted", ply, true) end, function(ply) return ply.DarkRPVars.wanted end);
    end

    self.warrant:Dock(TOP);
    self.wanted:Dock(TOP);
    self.unwanted:Dock(TOP);
end

function PANEL:PerformLayout()
    self:SizeToChildren(false, true);
end

local policepanel = vgui.RegisterTable(PANEL, "DPanel");

--------------------------------------
--                                  --
--          Mayor Panel             --
--                                  --
--------------------------------------
local PANEL = {};

function PANEL:Init()
    self.policepanel = vgui.CreateFromTable(policepanel, self);
    self.lockdown    = vgui.Create("DButton", self);
    self.unlockdown  = vgui.Create("DButton", self);
    self.lotto       = vgui.Create("DButton", self);

    self.lockdown:SetText(LANGUAGE.initiate_lockdown);
    self.unlockdown:SetText(LANGUAGE.stop_lockdown);
    self.lotto:SetText(LANGUAGE.start_lottery);

    self.lockdown.DoClick = cmdclick("lockdown");
    self.unlockdown.DoClick = cmdclick("unlockdown");
    self.lotto.DoClick = cmdclick("lottery");

    self.policepanel:Dock(TOP);
    self.lockdown:Dock(TOP);
    self.unlockdown:Dock(TOP);
    self.lotto:Dock(TOP);
end

function PANEL:PerformLayout()
    self.policepanel:InvalidateLayout(true);
    self:SizeToChildren(false, true);
end

local mayorpanel = vgui.RegisterTable(PANEL, "DPanel");

--------------------------------------
--                                  --
--           Full Panel             --
--                                  --
--------------------------------------
local PANEL = {}

function PANEL:Init()
    local money = vgui.Create("DCollapsibleCategory");
    money:SetContents(vgui.CreateFromTable(moneypanel, money));
    money:SetLabel("Money");

    local cmds  = vgui.Create("DCollapsibleCategory");
    cmds:SetContents(vgui.CreateFromTable(commandspanel, cmds));
    cmds:SetLabel("Actions");

    self:AddItem(money);
    self:AddItem(cmds);

    money:Dock(TOP);
    cmds:Dock(TOP);

    self.money = money;
    self.cmds  = cmds;
end

function PANEL:PerformLayout()
    self.money:InvalidateLayout(true);
    self.cmds:InvalidateLayout(true);
    if (self.teampanel) then
        self.teampanel:InvalidateLayout(true);
    end
    self.BaseClass.PerformLayout(self);
    self:SizeToChildren(false, true);
end

function PANEL:Update()
    local teamname, teampanel;
    local team = LocalPlayer():Team();
    if (self.lastteam == team) then
        return;
    end
    self.lastteam = team;
    if (team == TEAM_CITIZEN) then
        teamname = "Citizen";
        teampanel = citizenpanel;
    elseif (team == TEAM_MAYOR) then
        teamname = "Mayor";
        teampanel = mayorpanel;
    elseif (team == TEAM_POLICE or team == TEAM_CHIEF) then
        teamname = "Police";
        teampanel = policepanel;
    end
    if (not teampanel) then
        if (IsValid(self.teampanel)) then
            self.teampanel:Remove();
            self.teampanel = nil;
            self:InvalidateLayout(true);
        end
        return;
    end
    if (IsValid(self.teampanel)) then
        if (IsValid(self.teampanel.Contents)) then
            self.teampanel.Contents:Remove();
            self.teampanel.Contents = nil;
        end
    else
        self.teampanel = vgui.Create("DCollapsibleCategory");
        self:AddItem(self.teampanel);
        self.teampanel:Dock(TOP);
    end
    self.teampanel:SetLabel(teamname .. " Options");
    self.teampanel:SetContents(vgui.CreateFromTable(teampanel, pnl));
    self:InvalidateLayout(true);
end

local fullpanel = vgui.RegisterTable(PANEL, "DScrollPanel");

function MoneyTab()
    return vgui.CreateFromTable(fullpanel);
end
