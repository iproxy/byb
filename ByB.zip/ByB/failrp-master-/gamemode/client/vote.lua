
local PANEL = {}

AccessorFunc(PANEL, "big", "IsQuestion", FORCE_BOOL);
AccessorFunc(PANEL, "voteid", "VoteID");

function PANEL:SetLabel(question)
    if (self.label) then
        self.label:SetText(question);
    end
end

function PANEL:SetTimeout(num)
    if (num == 0) then
        num = 100;
    end
    self.EndTime = CurTime() + num;
end

-- FIXME: This isn't clickable w/ the context menu for some reason
function PANEL:Init()
    -- (Invalid) Defaults
    self:SetIsQuestion(false);
    self:SetVoteID(-1);
    self:SetLabel('?')

    self:ShowCloseButton(false);
    self:SetDraggable(false)
    self:SetFocusTopLevel(false);
	self:SetKeyboardInputEnabled(false)
	self:SetMouseInputEnabled(true)

    -- ???
	self.btnClose.Paint = function() end
	self.btnMaxim.Paint = function() end
	self.btnMinim.Paint = function() end

	self.label   = vgui.Create("DLabel", self)
	--self.divider = vgui.Create("Divider", self)
	self.ybutton = vgui.Create("DButton", self)
	self.nbutton = vgui.Create("DButton", self)

    self:SetTitle("Vote")
	self.label:SetText("?")
	self.ybutton:SetText("Yes")
	self.nbutton:SetText("No")

	function self.ybutton:DoClick()
        local p = self:GetParent();
		RunConsoleCommand(p:_GetConCommand(), p:GetVoteID(), '1');
		p:Close()
	end

	function self.nbutton:DoClick()
        local p = self:GetParent();
		RunConsoleCommand(p:_GetConCommand(), p:GetVoteID(), '2');
		p:Close()
	end

    -- Bong!
	LocalPlayer():EmitSound("Town.d1_town_02_elevbell1", 100, 100)

    -- Slot up alongside our peers
    self:Dock(LEFT);
end

function PANEL:PerformLayout()
    if (self.big) then
        self:SetSize(300, 140)
        self.label:SetSize(380, 40)
        --self.divider:SetSize(380, 2)
        self.ybutton:SetSize(40, 20)
        self.nbutton:SetSize(40, 20)

        self.label:SetPos(5, 30)
        --self.divider:SetPos(2, 80)
        self.ybutton:SetPos(105, 100)
        self.nbutton:SetPos(155, 100)
    else
        self:SetSize(140, 140)
        self.label:SetSize(180, 40)
        --self.divider:SetSize(180, 2)
        self.ybutton:SetSize(40, 20)
        self.nbutton:SetSize(40, 20)

        self.label:SetPos(5, 30)
        --self.divider:SetPos(2, 80)
        self.ybutton:SetPos(25, 100)
        self.nbutton:SetPos(70, 100)
    end
    self.BaseClass.PerformLayout(self)
end

function PANEL:Think()
    self.BaseClass.Think(self);
    if (self.EndTime) then
        local timeleft = self.EndTime - CurTime();
        if (timeleft < 0) then
            self:Close()
        else
            self:SetTitle(tostring(math.ceil(timeleft)) .. "s left");
        end
    end
end

function PANEL:VoteYes()
    self.ybutton:DoClick();
end

function PANEL:VoteNo()
    self.nbutton:DoClick();
end

function PANEL:OnClose()
    self:GetParent():VoteClosed(self);
end

function PANEL:_GetConCommand()
    return self.big and "ans" or "vote";
end

local votepanel = vgui.RegisterTable(PANEL, "DFrame");

----------------------
--                  --
--     Vote Dock    --
--                  --
----------------------
local PANEL = {}

function PANEL:Init()
    self.Panels = {};
    self:SetDrawBackground(false);
    --self:ParentToHUD();
end

function PANEL:_DoPanel(label, voteid, timeout, kind)
    local panel = vgui.CreateFromTable(votepanel, self);
    panel:SetLabel(label);
    panel:SetVoteID(voteid);
    panel:SetTimeout(timeout);
    self.Panels[panel] = kind .. voteid;
    return panel;
end

function PANEL:AddVote(question, voteid, timeout)
    return self:_DoPanel(question, voteid, timeout, "vote");
end

function PANEL:AddQuestion(question, questionid, timeout)
    local panel = self:_DoPanel(question, questionid, timeout, "question");
    panel:SetIsQuestion(true);
    return panel;
end

function PANEL:_DoKill(id, kind)
    id = kind .. id;
    for panel, pid in pairs(self.Panels) do
        if (pid == id) then
            if (IsValid(panel)) then
                panel:Remove();
            end
            self.Panels[panel] = nil;
            return;
        end
    end
end

function PANEL:KillVote(voteid)
    self:_DoKill(voteid, "vote");
end

function PANEL:KillQuestion(questionid)
    self:_DoKill(questionid, "question");
end

function PANEL:GetPanels()
    -- Make sure we're clean first
    self:Cleanup();
    return self.Panels;
end

function PANEL:Clear()
    for panel in pairs(self.Panels) do
        if (IsValid(panel)) then
            panel:Remove();
        end
        self.Panels[panel] = nil;
    end
end

function PANEL:Cleanup()
    for panel in pairs(self.Panels) do
        if (not IsValid(panel)) then
            self.Panels[panels] = nil;
        end
    end
end

function PANEL:VoteClosed(panel)
    self.Panels[panel] = nil;
end

local votecontainer = vgui.RegisterTable(PANEL, "DPanel");

local function GetVoteContainer()
    if (not GAMEMODE.VoteContainer) then
        local panel = vgui.CreateFromTable(votecontainer)
        panel:SetPos(3, ScrH() / 2 - 150);
        panel:SetSize(ScrW() - 6, 140);
        GAMEMODE.VoteContainer = panel;
    end
    return GAMEMODE.VoteContainer;
end

usermessage.Hook("DoVote", function(um)
    GetVoteContainer():AddVote(um:ReadString(), um:ReadString(), um:ReadFloat());
end);
usermessage.Hook("DoQuestion", function(um)
    GetVoteContainer():AddQuestion(um:ReadString(), um:ReadString(), um:ReadFloat());
end);

usermessage.Hook("KillVoteVGUI", function(um)
    GetVoteContainer():KillVote(um:ReadString());
end);
usermessage.Hook("KillQuestionVGUI", function(um)
    GetVoteContainer():KillQuestion(um:ReadString());
end);

concommand.Add("rp_vote", function(ply, _, args)
    if (not args[1]) then
        print("No args specified!");
        return;
    end

    local panel = next(GetVoteContainer():GetPanels());
    if (not panel) then
        print("No question!");
        return;
    end

	if tonumber(args[1]) == 1
    or string.lower(args[1]) == "yes"
    or string.lower(args[1]) == "true"
    then
        panel:VoteYes();
    else
        panel:VoteNo();
    end
end);
--[[
timer.Create("VotePanelCleanup", 5, 0, function()
    if (IsValid(GAMEMODE.VoteContainer)) then
        GAMEMODE.VoteContainer:Cleanup();
    end
end);
--]]
