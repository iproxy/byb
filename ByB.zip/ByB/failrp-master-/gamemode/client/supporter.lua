-- hurf
if (SERVER) then
    return;
end
local PANEL = {};

function PANEL:Init()
    self:DockPadding(10, 10, 10, 10);

    self.title = vgui.Create("DLabel", self);
    self.entry = vgui.Create("DTextEntry", self);
    self.padding = vgui.Create("DPanel", self);
    self.warning = vgui.Create("DLabel", self);
    self.info = vgui.Create("DLabel", self);

    local black = Color(0,0,0);
    self.padding:SetPaintBackground(false);
    self.title:SetColor(black);
    self.warning:SetColor(black);
    self.info:SetColor(black);

    self.title:SetText  ("Enter your activation code here - then press enter");
    self.warning:SetText([[
This system is new, any issues contact a Root admin (Forum ticket).
You are able to purchase activation codes via the website @ www.bybservers.co.uk

There are many perks to being a supporter, without people buying items popular servers such as these could not exist.
We use the best hardware, at the best places so you may have the best experience. ByB's current operational costs are around 1100$ per month.

For a full list of supporter benefits visit the website, the highlights are:
* Double prop limit
* Tool Access- Access a few of the restricted tools such as E2.
  - Some tools will still be blacklisted. Due to server crashing exploits.
* Extra jobs:
  - SWAT Classes - Heavily armoured police.
  - Secret Agent - A flexible class, good or evil with bonus weapons.
  - Master Thief - (1 per server) Fast and silent, sneaky but squishy.
  - Black Market Dealer - Illegal weapons dealer, for backstreet dealing.
  - Hitman - The best way to take out the trash.
  - Mercenary - May be recruited by anyone to assist in evil tasks.]]);
  self.info:SetText([[
* 2 Supporter Printers. These print around the same as a Gold printer but will never randomly explode.
* Printer Barrel. Carries a few printers home from a local raid.
* Vote bypass. No longer need to vote to access any RP job.
* Demote Access. May demote players.
* Increased salary, increased pocket size, increased door limit.

*** Bonuses to every GarrysMod server current and future ByB runs from TTT to Stronghold. ***]]);

    function self.entry:OnEnter()
        LocalPlayer():ConCommand("SupporterCodeAuth " .. tostring(self:GetValue()));
    end
    self.entry.OnLoseFocus = self.entry.OnEnter;

    self.title:Dock(TOP);
    self.entry:Dock(TOP);
    self.padding:Dock(TOP);
    self.warning:Dock(TOP);
    self.info:Dock(TOP);
end

function PANEL:PerformLayout()
    self.title:SizeToContents();
    self.padding:SetTall(30);
    self.warning:SizeToContents();
    self.info:SizeToContents();
    self:SizeToChildren(false, true);
end

function PANEL:GetExpanded()
    return true;
end

local supporterpanel = vgui.RegisterTable(PANEL, "DPanel");

function GM:SupporterTab()
    local panel = vgui.Create("DCollapsibleCategory");
    panel:SetContents(vgui.CreateFromTable(supporterpanel));
    panel:SetLabel("Supporter Activation");
    panel.Header.DoClick = function() end
    -- Grr
    panel.Update = function() 
	end
    return panel;
end
