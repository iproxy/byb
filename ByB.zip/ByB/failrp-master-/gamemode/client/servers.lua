-- hurf
if (SERVER) then
    return;
end
local PANEL = {};
surface.CreateFont("ServerHeader", {
    font   = "Arial";
    size   = 24;
    weight = 500;
})
function PANEL:Init()
	local WK = 143 
	local HK = 228
	local Height = 160
	local W = 0
	local done = false
	
	local GameTrackerURL = "http://cache.www.gametracker.com/server_info/%s/b_160_400_1_ffffff_c5c5c5_ffffff_000000_0_1_0.png"
	
	local IPList = {"178.32.55.151:27015", -- RP1
					"31.186.251.183:27015", -- RP3
					"70.42.74.6:27015", -- RP4
					"192.223.27.16:27015", --RP5
					"70.42.74.6:27018", -- RP6
					}
					
	self.Header = vgui.Create("DLabel",self)
	self.Header:SetPos(0,0)
	self.Header:SetSize(740,490) 
	self.Header.Paint = function()		
			draw.SimpleText("These are the current active ByB Servers.","ServerHeader",self.Header:GetWide()/2,0,Color(0,0,0,255),TEXT_ALIGN_CENTER)
			draw.SimpleText("Clicking any of the gmod server images will send you to that server.","DefaultSmall",self.Header:GetWide()/2,25,Color(0,0,0,255),TEXT_ALIGN_CENTER)
			draw.SimpleText("Supporter is global on all Gmod servers.","DefaultSmall",self.Header:GetWide()/2,40,Color(0,0,0,255),TEXT_ALIGN_CENTER)
			draw.SimpleText("RP6 (below) is testing a new version of DarkRP. Please report any bugs!","DefaultSmall",self.Header:GetWide()/2,55,Color(0,0,0,255),TEXT_ALIGN_CENTER)
	end
	
	-- This weeks top/advert server or whatever.
	self.RP1Img = vgui.Create("HTML",self)
	self.RP1Img:SetSize(740,105) 
	self.RP1Img:SetPos(10,60)
	self.RP1Img:SetHTML( "<body style=\"overflow: hidden; text-align:center\"> <img src=\"http://cache.www.gametracker.com/server_info/" .. IPList[5] .. "/b_560_95_1.png\" width=\"560\" height=\"95\">" )
	self.RP1ImgB = vgui.Create("DButton", self.RP1Img) 
	self.RP1ImgB:SetSize(self.RP1Img:GetWide(),self.RP1Img:GetTall())
	self.RP1ImgB:SetText("") 
	self.RP1ImgB.Paint = function()
		surface.SetDrawColor( 0,0,0,0 ) 
	end
	self.RP1ImgB.DoClick = function()
		LocalPlayer():ConCommand("connect " .. IPList[5])
	end
	-- Now powered by external sourcery.
	-- Edit /home/bybforum/www/serverbrowser.php to change the html content & the "goto" url.
	self.RP1Img = vgui.Create("HTML",self)
	self.RP1Img:SetSize(420,125) 
	self.RP1Img:SetPos(160,350)
	--self.RP1Img:SetHTML( "<body style=\"overflow: hidden\"> <img src=\"http://share.yourlink.com/minecraft_build_competition_2013_panthofluffy.jpg\" width=\"420\" height=\"175\">" )
	self.RP1Img:OpenURL("http://www.bybservers.co.uk/serverbrowser.php")
	self.RP1ImgB = vgui.Create("DButton", self.RP1Img)
	--self.RP1ImgB:SetPos(295,360)
	self.RP1ImgB:SetSize(self.RP1Img:GetWide(),self.RP1Img:GetTall())
	self.RP1ImgB:SetText("")
	self.RP1ImgB.Paint = function()
		surface.SetDrawColor( 0,0,0,0 ) 
	end		
	self.RP1ImgB.DoClick = function()
		gui.OpenURL("http://www.bybservers.co.uk/serverbrowser.php?go")
	end
	
	local count = 0
	for k,v in pairs(IPList) do
		W = W + 1
		if count > 5 and not done then Height = Height + 180 W = 1 done = true end -- I dispise this code...
		self.RP1Img = vgui.Create("HTML",self)
		self.RP1Img:SetSize(WK,HK) 
		self.RP1Img:SetPos(10+(WK * (W-1)),Height)
		self.RP1Img:SetHTML( "<img src=\"" .. string.format(GameTrackerURL, v) .. "\" width=\"135\" height=\"175\">" )
		self.RP1ImgB = vgui.Create("DButton",self)
		self.RP1ImgB:SetPos(10+(WK * (W-1)),Height)
		self.RP1ImgB:SetSize(self.RP1Img:GetWide(),self.RP1Img:GetTall())
		self.RP1ImgB:SetText("")
		self.RP1ImgB.Paint = function() 
			surface.SetDrawColor( 0,0,0,0 ) 
		end		
		self.RP1ImgB.DoClick = function()
			LocalPlayer():ConCommand("connect " .. v)
		end
	count = count + 1
	end
	done = false
end

function PANEL:PerformLayout()
  --  self.warning:SizeToContents();
    self:SizeToChildren(false, true);
end

function PANEL:GetExpanded()
    return true;
end

local supporterpanel = vgui.RegisterTable(PANEL, "DPanel");

function GM:ServersTab()
    local panel = vgui.Create("DCollapsibleCategory");
    panel:SetContents(vgui.CreateFromTable(supporterpanel));
    panel:SetLabel("Server List");
    panel.Header.DoClick = function() end
    -- Grr
    panel.Update = function() 
	end
    return panel;
end
