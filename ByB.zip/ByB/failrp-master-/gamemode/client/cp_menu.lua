function CPTerminal()
		local wanted
	local arrested = "No"
    local CPTerm = vgui.Create("DFrame") or LawMenu
    CPTerm:SetPos(ScrW()/2-400,ScrH()/2-300) --(SrH()/2,ScrW/2)
    CPTerm:SetSize(800,600)
    CPTerm:SetTitle("                                                                                                   -BYPD- Departmental Computer System")
    CPTerm:SetVisible(true)
    CPTerm:SetDraggable(true)
    CPTerm:ShowCloseButton(true)
    CPTerm:MakePopup()
	
	
	local FramePan = vgui.Create("DPanel", CPTerm)
    FramePan:SetPos(10,32.5)
    FramePan:SetSize(760,540)
    FramePan.Paint = function() 
        surface.SetDrawColor(50,50,50,255)
        surface.DrawRect(0,0,FramePan:GetWide(),FramePan:GetTall())
    end
	
	local CitizenSheetOne = vgui.Create("DListView")
    CitizenSheetOne:SetParent(FramePan)
    CitizenSheetOne:SetPos(1,1)
    CitizenSheetOne:SetSize(770,520)
    CitizenSheetOne:AddColumn("Name")
    CitizenSheetOne:AddColumn("Job")
    CitizenSheetOne:AddColumn("Warranted")
    CitizenSheetOne:AddColumn("Wanted/Reason")
    CitizenSheetOne:AddColumn("Arrested") 
    for k,v in pairs(player.GetAll()) do
		if v.DarkRPVars.wanted then 
			wanted = v.DarkRPVars.wantedReason or "For criminal activity" 
		end
		if v.DarkRPVars.warrant then 
			warrant = v.DarkRPVars.warrantReason or "For criminal activity" 
		else warrant = "" end
		if v.DarkRPVars.Arrested then 
			arrested = "Sentence Remaining:" .. math.floor(v.DarkRPVars.arrestedTime+300 - CurTime())
		else arrested = "" end
        CitizenSheetOne:AddLine(v:Name(),v.DarkRPVars.job, warrant, wanted,arrested)
    end  
	function CitizenSheetOne.OnRowRightClick(panel,line) 
		local RightClickMenu = DermaMenu()
		RightClickMenu:SetPos(gui.MousePos())
		RightClickMenu:AddOption("Request Arrest Warrent", function() WantedRequest(CitizenSheetOne:GetLine(line):GetValue(1)) end)
		RightClickMenu:AddOption("Request Search Warrant", function() WarrantRequest(CitizenSheetOne:GetLine(line):GetValue(1)) end)	
		--RightClickMenu:AddOption("Release from jail", function() end)	
		RightClickMenu:Open()
	end
	
	local PlayerSheet = vgui.Create( "DPropertySheet" )
	PlayerSheet:SetParent( CPTerm )
	PlayerSheet:SetPos( 10, 30 )    
	PlayerSheet:SetSize( 790, 560 )
	PlayerSheet:AddSheet( "Citizen Status", FramePan, "gui/silkicons/user", false, false, "Citizens" )
end

function WarrantRequest(name)
	local args = string.Explode(" ", name)
	local name = args[1]
	local Req = vgui.Create("DFrame")
	Req:SetPos(ScrW()/2-300,ScrH()/2-35)
	Req:SetSize(600,50)
	Req:SetTitle("                                   Type a reason for the warrant then hit enter.")
	Req:SetVisible(true)
	Req:SetDraggable(true)
	Req:ShowCloseButton(false)
	Req:MakePopup()
	
	local Reason = vgui.Create("DTextEntry",Req)
	Reason:SetPos(5,25)
	Reason:SetTall(20)
	Reason:SetWide(590)
	Reason:SetEnterAllowed(true)
	Reason:SetVisible(true)
	Reason.OnEnter = function()
		RunConsoleCommand("say","/warrant "..name.." "..Reason:GetValue())
		Reason:GetParent():Close()
	end
end
function WantedRequest(name)
	local args = string.Explode(" ", name)
	local name = args[1]
	local Req = vgui.Create("DFrame")
	Req:SetPos(ScrW()/2-300,ScrH()/2-35)
	Req:SetSize(600,50)
	Req:SetTitle("                                   Type a reason for the warrant then hit enter.")
	Req:SetVisible(true)
	Req:SetDraggable(true)
	Req:ShowCloseButton(false)
	Req:MakePopup()
	
	local Reason = vgui.Create("DTextEntry",Req)
	Reason:SetPos(5,25)
	Reason:SetTall(20)
	Reason:SetWide(590)
	Reason:SetEnterAllowed(true)
	Reason:SetVisible(true)
	Reason.OnEnter = function()
		RunConsoleCommand("say","/wanted "..name.." "..Reason:GetValue())
		Reason:GetParent():Close()
	end
end
