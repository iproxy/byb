timer.Simple(60,function() 
	--chat.AddText(Color(255,0,0),"We have a built in voice radio chat room for gangs.")
	--chat.AddText(Color(0,255,0),"To try this new system please type voip_menu in console, or /voip in chat.")
	--chat.AddText(Color(192,114,21),"ByB ZRP Returns, with FA:S Weapons!. Admin shared(all admins get it free on zrp) @ :",Color(0,0,255),"192.223.27.16:27015")
	chat.AddText(Color(192,114,21),"Welcome to ByB, don't be a git.",Color(0,0,255)," - we love you.")
end)
--if not RP4 then return end
net.Receive("SendCLModels",function()
	props = net.ReadTable()
	--for k,v in pairs(props) do
	--	print("number ".. tostring(k) .." Model: " ..props["model"][k])
	--	DrawThisCLThingPlease(props["model"][k],props["pos"][k],props["ang"][k])
	--end
	--if file.Exists("models/props_halloween/jackolantern_01.mdl","GAME") then DrawThisCLThingPlease() end
	DrawThisCLThingPlease()
end)

local CLProps = {}
function DrawThisCLThingPlease(model,pos,ang)
	chat.AddText(Color(255,0,0),"Christmas props have been loaded - Merry Christmas.",Color(0,0,255),"Type: humbug in console to remove decorations.")
	for k,v in pairs(props["model"]) do
		if (props["model"][k]) then
			--print("Added HWProp"..k)
			local item = ClientsideModel(props["model"][k],RENDERGROUP_OPAQUE)
			pos = util.StringToType( props["pos"][k], "Vector" )
			ang = util.StringToType( props["ang"][k], "Angle" )
			if props["col"] and props["col"][k] then
				col = util.JSONToTable(props["col"][k])
				item:SetColor(col)
			end
			item:SetPos(pos)
			item:SetAngles(ang)
			if (props["mat"]) and (props["mat"][k]) then
				item:SetMaterial(props["mat"][k])
			end
			if (props["scale"]) and (props["scale"][k]) then
				item:SetModelScale(props["scale"][k],0)
				end
			item:DrawModel()
			table.insert(CLProps,item)
		end
	end
end

local function DonaldDuck()
	if CLProps then
		for k,v in pairs(CLProps) do
			if IsValid(v) then v:Remove() end
		end
	end
	chat.AddText(Color(0,255,0),"THE DEVIL COMPELLS YOU!!!")
end
concommand.Add("humbug",DonaldDuck)


if true then return end
-- stuff below is all old crap, not used or stuff in dev.


local timer = 180 + (math.random(180,360))
timer.Create([[RP1advert]],timer,0,function()
	chat.AddText(Color(255,0,0), "RP1 Chaos Weekend: Free supporter, RP4 admins get free extension, Admin&Support gift code raffle - For duration of Christmas")
	chat.AddText(Color(0,0,255), "31.186.250.131:27015")
end)
if RP1 then timer.Destroy("RP1advert") end

do
if not RP7 then return end

inv = {}
local InvUpdated = false
function UpdateItems()
	InvItems = InvItems or {}
	for k,v in pairs(InvItems) do
		if v.Model then
			local Icon = vgui.Create('SpawnIcon')
			Icon:SetModel(v.Model)
			Icon:SetToolTip(v.Name)
			Icon.OnCursorEntered = function()
				inv.MouseEventUpdate(v)
			end
			Icon.DoClick = function()
				local IconMenu = DermaMenu()
				IconMenu:AddOption("Equip", function() ZRPDrop(k,"Equip") end)
				IconMenu:AddOption("Drop", function() ZRPDrop(k,"Drop") end)
				IconMenu:AddOption("Delete", function() ZRPDrop(k,"Delete") end)
				IconMenu:Open()
			end
			inv.ItemList:AddItem(Icon)
		end
	end
	ArmorItems = ArmorItems or {}
	if ArmorItems[1] then
		inv.HIcon:SetModel(ArmorItems[1].Model)
		inv.HIcon:SetToolTip(ArmorItems[1].Name)
		inv.MouseEventUpdate(ArmorItems[1])
		inv.HIcon:SetVisible(true)
		inv.HPic:SetVisible(false)
		inv.HIcon.OnCursorEntered = function()
				inv.MouseEventUpdate(ArmorItems[1])
			end
	else
		inv.HIcon:SetVisible(false)
		inv.HPic:SetVisible(true)
	end
	if ArmorItems[2] then
		inv.TIcon:SetModel(ArmorItems[2].Model)
		inv.TIcon:SetToolTip(ArmorItems[2].Name)
		inv.MouseEventUpdate(ArmorItems[2])
		inv.TIcon:SetVisible(true)
		inv.TPic:SetVisible(false)
		inv.TIcon.OnCursorEntered = function()
				inv.MouseEventUpdate(ArmorItems[2])
			end
	else
		inv.TIcon:SetVisible(false)
		inv.TPic:SetVisible(true)
	end
	if ArmorItems[3] then
		inv.LIcon:SetModel(ArmorItems[3].Model)
		inv.LIcon:SetToolTip(ArmorItems[3].Name)
		inv.MouseEventUpdate(ArmorItems[3])
		inv.LIcon:SetVisible(true)
		inv.LPic:SetVisible(false)
		inv.LIcon.OnCursorEntered = function()
				inv.MouseEventUpdate(ArmorItems[3])
			end
	else
		inv.LIcon:SetVisible(false)
		inv.LPic:SetVisible(true)
	end
end
function CreateInv()
	local x = 200
	local y = 50
	local v = 5
	inv.Main = vgui.Create('DFrame')
	inv.Main:SetSize(500,500)
	inv.Main:Center()
	inv.Main:SetTitle('Temp Inventory')
	inv.Main:ShowCloseButton(true)	
	inv.Main:MakePopup()
				
	inv.MainSheet = vgui.Create( "DPropertySheet",inv.Main)
	inv.MainSheet:SetPos(10, 30)
	inv.MainSheet:SetSize(480, 460)
	
	ItemSheet = vgui.Create( "DPropertySheet",inv.MainSheet)
	ItemSheet:SetPos(120, 10)
	ItemSheet:SetSize(350, 300)
		inv.ItemList = vgui.Create("DPanelList",ItemSheet)
		inv.ItemList:SetPos(10,10)
		inv.ItemList:SetSize(280,280)
		inv.ItemList:EnableHorizontal(true)
		
	--CharSheet = vgui.Create( "DPropertySheet",inv.MainSheet)
	--CharSheet:SetPos(10, 10)
	--CharSheet:SetSize(150, 410)
		HeadSlot = vgui.Create("DPropertySheet",inv.MainSheet)
		HeadSlot:SetPos(10,10)
		HeadSlot:SetSize(100,100)
		TorsoSlot = vgui.Create("DPropertySheet",inv.MainSheet)
		TorsoSlot:SetPos(10,110)
		TorsoSlot:SetSize(100,100)
		LegsSlot = vgui.Create("DPropertySheet",inv.MainSheet)
		LegsSlot:SetPos(10,210)
		LegsSlot:SetSize(100,100)
		inv.HPic = vgui.Create('HTML',HeadSlot)
		inv.HPic:SetSize(90,90)
		inv.HPic:SetHTML( "<body style=\"overflow: hidden\"> <img src=\"http://bybservers.co.uk/sharex/pantho/helm.png\" width=\"90\" height=\"90\">" )
		inv.TPic = vgui.Create('HTML',TorsoSlot)
		inv.TPic:SetSize(100,140)
		inv.TPic:SetPos(-5,0)
		inv.TPic:SetHTML( "<body style=\"overflow: hidden\"> <img src=\"http://bybservers.co.uk/sharex/pantho/chest.png\" width=\"100\" height=\"140\">" )
		inv.LPic = vgui.Create('HTML',LegsSlot)
		inv.LPic:SetSize(90,90)
		inv.LPic:SetHTML( "<body style=\"overflow: hidden\"> <img src=\"http://bybservers.co.uk/sharex/pantho/legs.png\" width=\"90\" height=\"90\">" )
		
		inv.HIcon = vgui.Create('SpawnIcon',HeadSlot)
		inv.TIcon = vgui.Create('SpawnIcon', TorsoSlot)
		inv.LIcon = vgui.Create('SpawnIcon', LegsSlot)
		inv.HIcon:SetPos(30,10)		
		inv.HIcon:SetVisible(true)
		inv.HIcon.DoClick = function()
			local IconMenu = DermaMenu()
			IconMenu:AddOption("Unequip", function() ZRPDrop(1,"Unequip") end)
			IconMenu:Open()
		end
		inv.TIcon:SetPos(30,10)
		inv.TIcon:SetVisible(true)
		inv.TIcon.DoClick = function()
			local IconMenu = DermaMenu()
			IconMenu:AddOption("Unequip", function() ZRPDrop(2,"Unequip") end)
			IconMenu:Open()
		end
		inv.LIcon:SetPos(30,10)
		inv.LIcon:SetVisible(true)
		inv.LIcon.DoClick = function()
			local IconMenu = DermaMenu()
			IconMenu:AddOption("Unequip", function() ZRPDrop(3,"Unequip") end)
			IconMenu:Open()
		end
		
	MouseEvent = vgui.Create( "DPropertySheet",inv.MainSheet)
	MouseEvent:SetPos(10, 320)
	MouseEvent:SetSize(460, 100)
		ItemName = vgui.Create("DLabel",MouseEvent)
		ItemName:SetPos(10,10)
		ItemName:SetText("Item Name: ")
		ItemPrice = vgui.Create("DLabel",MouseEvent)
		ItemPrice:SetPos(10,25)
		ItemPrice:SetText("Item Price: ")
		ItemType = vgui.Create("DLabel",MouseEvent)
		ItemType:SetPos(10,40)
		ItemType:SetText("Item Type: ")
		ItemRare = vgui.Create("DLabel",MouseEvent)
		ItemRare:SetPos(10,55)
		ItemRare:SetText("Drop Rate: ")
		ItemProt = vgui.Create("DLabel",MouseEvent)
		ItemProt:SetPos(240,10)
		ItemProt:SetText("Armor Bonus: ")
	 
	
	Exit = vgui.Create('DButton',inv.MainSheet)
	Exit:SetSize(50,25)
	Exit:SetPos(425,430)
	Exit:SetText("Exit")
	Exit.DoClick = function()
		inv.Main:Close()
	end	
	function inv.Main:Think()
		if InvUpdated == true then		
			inv.Refresh()
		end
	end
	UpdateItems()
end
function inv.Refresh()
	inv.ItemList:Clear()
	inv.HIcon:SetModel('models/props_borealis/bluebarrel001.mdl')
	inv.TIcon:SetModel('models/props_borealis/bluebarrel001.mdl')
	inv.LIcon:SetModel('models/props_borealis/bluebarrel001.mdl')
	--LegsSlot:Clear()
	InvUpdated = false
	UpdateItems()
end
-- fake items
net.Receive("UpdateZRPInv",function()
	InvItems = net.ReadTable() or {}
	ArmorItems = net.ReadTable() or {}
	InvUpdated = true
end)
function inv.MouseEventUpdate(item)
	if not item then return end
		local itemtype = "Weapon"
		if item.Slot then itemtype = item.Slot end
	ItemName:SetText('Item Name: ' .. item.Name)
	ItemPrice:SetText('Item Price: ' .. item.Value)
	ItemType:SetText('Item Type: ' .. itemtype)
	ItemRare:SetText('Rare Item: '.. tostring(item.DRate))
	ItemName:SizeToContents()
	ItemPrice:SizeToContents()
	ItemType:SizeToContents()
	ItemRare:SizeToContents()
end
function ZRPDrop(item,action)
	net.Start("ZRPInvRemove")
	net.WriteString(action)
	net.WriteInt(tonumber(item),32)
	net.SendToServer()
	--inv.Main:Close()
end

concommand.Add("invshow",CreateInv)
end