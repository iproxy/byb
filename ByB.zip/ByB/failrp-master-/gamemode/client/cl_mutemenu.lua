surface.CreateFont("UiBold", {
	size = 16,
	weight = 800,
	antialias = true,
	shadow = false,
	font = "Default"})
local function GenColor()
	local cin = math.sin(CurTime()+math.random(0,100000) + 1) / 2
	return Color(cin * 255, 0, 255 - (cin * 255), 255)
end

local function DrawMenu()
	local dmenu = vgui.Create("DFrame") or dmenu
	dmenu:SetSize(260,510)
	dmenu:Center()
	dmenu:MakePopup()
	local fmenu = vgui.Create("DPanel",dmenu)
	fmenu:SetSize(250,500)
	fmenu:Center()

	local PanelBox = vgui.Create("DPanelList",fmenu)
	PanelBox:SetSize(fmenu:GetWide()-10,fmenu:GetTall()-35)
	PanelBox:SetPos(5,5)
	PanelBox:EnableVerticalScrollbar(true)

	for i,ply in pairs(player.GetAll()) do
		local col = GenColor()
		local panel = vgui.Create("DPanel")
		panel:SetSize(PanelBox:GetWide()-10,70)
		panel.Paint = function()
			surface.SetDrawColor(col)
			surface.DrawRect(0,0,panel:GetWide(), panel:GetTall())
		end

		local avatar = vgui.Create("AvatarImage",panel)
		avatar:SetPos(3,3)
		avatar:SetSize(64,64)
		avatar:SetPlayer(ply, 64)

		local namebox = vgui.Create("DLabel",panel)
		namebox:SetPos(100,7)
		namebox:SetText(ply:Name())

		local muted = ply:IsMuted() or false
		local status = vgui.Create("DLabel",panel)
		status:SetText(tostring(muted))
		status:SetFont("UiBold")
		status:SetPos(100,22)
		status:SizeToContents()

		local togmute = vgui.Create("DButton",panel)
		togmute:SetText("Toggle Mute")
		togmute:SetSize(100,20)
		togmute:SetPos(100,39)
		togmute.DoClick = function()
			ply:SetMuted(not ply:IsMuted())
			chat.AddText(Color(180,50,0),ply:Name() .. " Has been muted, The menu closed as Pantho was lazy and didn't make it auto refresh :)")
			dmenu:Close()
		end
		PanelBox:AddItem(panel)
	end
	local cbutton = vgui.Create("DButton",fmenu)
	cbutton:SetSize(fmenu:GetWide()-10,20)
	cbutton:SetPos(5,fmenu:GetTall()-22)
	cbutton:SetText("Exit")
	cbutton.DoClick = function()
		cbutton:GetParent():GetParent():Close()
	end
end
net.Receive("clmutemenu", function ()    
	DrawMenu()
end)