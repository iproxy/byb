VG = VG or {}
--VG.Players = {}
--test channel



local function ChannelAdmin(ply)
	if not LocalPlayer().VoipChannel then return end
	if ply == LocalPlayer() then
		local menu = DermaMenu()
		menu:AddOption("Leave", function()
			LocalPlayer():ConCommand("voip_leave")
			LocalPlayer().VoipChannel = nil
			VG.Menu:Close()
		end)
		menu:Open()
		return
	end
	if Chans.Channels[LocalPlayer().VoipChannel].Owner == LocalPlayer() then -- or ply:IsRoot() then
		local menu = DermaMenu()
		menu:AddOption("Kick", function()
			LocalPlayer():ConCommand("voip_kick " .. ply:EntIndex())
			VG.Menu:Close()
		end)
		menu:AddOption(" ", function() end)
		menu:AddOption("*Set Owner*", function()
			LocalPlayer():ConCommand("voip_givechan " .. ply:EntIndex())
			end)
		menu:Open()
	end
end

local function CreateChannel()
	local new = vgui.Create("DFrame")
	new:SetSize(325,200)
	new:Center()
	new:SetTitle("Channel Creation")
	new.Paint = function()
		surface.SetDrawColor( Color(90,80,80,255) ) 
		surface.DrawRect(0,0,new:GetWide(), new:GetTall())
	end
	new:MakePopup()
	local frame = vgui.Create("DPanel",new)
	frame:SetSize(new:GetWide()-10,new:GetTall()-30)
	frame:SetPos(5,25)
	frame.Paint = function()
		surface.SetDrawColor( Color(90,90,80,255) ) 
		surface.DrawRect(0,0,frame:GetWide(), frame:GetTall())
	end
	local title = vgui.Create("DLabel",frame)
	title:SetText("Please choose an appropriate / non offensive channel name.\nClose this window to cancel channel creation.\nYou will automatically join a channel you create.")
	title:SizeToContents()
	title:SetPos(10,10)
	local namelbl = vgui.Create("DLabel",frame)
	namelbl:SetPos(10,70)
	namelbl:SetText("Channel Name:")
	namelbl:SizeToContents()
	local nametxt = vgui.Create("DTextEntry",frame)
	nametxt:SetSize(200,15)
	nametxt:SetPos(110,70)
	local passlbl = vgui.Create("DLabel",frame)
	passlbl:SetPos(10,100)
	passlbl:SetText("Channel Password:")
	passlbl:SizeToContents()
	local passtxt = vgui.Create("DTextEntry",frame)
	passtxt:SetSize(200,15)
	passtxt:SetPos(110,100)
	passtxt:SetText("*NO PASSWORD*")
	local submit = vgui.Create("DButton",frame)
	submit:SetText("Submit")
	submit:SetSize(frame:GetWide()-10,25)
	submit:SetPos(5,frame:GetTall()-30)
	submit.DoClick = function()
		local title = nametxt:GetValue()
		local pass = passtxt:GetValue()
		net.Start("CreateChannel_voip")
		net.WriteString(title)
		net.WriteString(pass)
		net.SendToServer()
		LocalPlayer().VoipChannel = LocalPlayer():EntIndex()
		if VG.Menu then VG.Menu:Close() end
		new:Close()
	end
end


local function JoinChannel(chan)
	--if chan.Chan == 1 and not LocalPlayer():IsCP() then chat.AddText(Color(255,0,0,255),"Sorry, this chat is reserved for authorized goverment personel only!") retun end
	if not chan.Pass then
		net.Start("JoinChannel_voip")
		net.WriteInt(chan.Chan,32)
		net.SendToServer()
		--AddPlayer(LocalPlayer(),chan.DCat)
		VG.Menu:Close()
		LocalPlayer().VoipChannel = chan.Chan
	else
		local passplz = vgui.Create("DFrame")
		passplz:SetSize(400,50)
		passplz:Center()
		passplz:MakePopup()
		passplz.Paint = function()
			surface.SetDrawColor( Color(90,90,80,255) ) 
			surface.DrawRect(0,0,passplz:GetWide(), passplz:GetTall())
		end
		passplz:SetTitle("Please enter the channel password.")
		local entry = vgui.Create("DTextEntry",passplz)
		entry:SetSize(passplz:GetWide()-10,passplz:GetTall()-25)
		entry:SetPos(5,20)
		entry.OnEnter = function()
			if entry:GetValue() == chan.Pass then 
				chat.AddText(Color(0,255,0,255),"Password accepted, joining channel.")
				net.Start("JoinChannel_voip")
				net.WriteInt(chan.Chan,32)
				net.SendToServer()
				LocalPlayer().VoipChannel = chan.Chan
				--AddPlayer(LocalPlayer(),chan.DCat)
				VG.Menu:Close()
				passplz:Close()
			else
				chat.AddText(Color(255,0,0,255),"Wrong password provided")
				passplz:Close()
			end
		end
	end
end

function DrawMain()
	VG.Menu = vgui.Create("DFrame");
	VG.Menu:SetSize(200,600);
	VG.Menu:Center();
	VG.Menu:SetTitle("Voip Channels");
	VG.Menu:ShowCloseButton(true);
	--VG.Menu:SetDeleteOnClose(true);
	VG.Menu:MakePopup()
	VG.Menu.Paint = function()
		surface.SetDrawColor( Color(90,80,80,255) ) 
		surface.DrawRect(0,0,VG.Menu:GetWide(), VG.Menu:GetTall())
	end
	VG.Panel = vgui.Create("DPanel",VG.Menu)
	VG.Panel:SetSize(VG.Menu:GetWide()-10,VG.Menu:GetTall()-50)
	VG.Panel:SetPos(5,25);
	VG.Panel.Paint = function()
		surface.SetDrawColor( Color(100,100,100,255) ) 
		surface.DrawRect(0,0,VG.Panel:GetWide(), VG.Panel:GetTall())
	end
	VG.List = vgui.Create("DPanelList",VG.Panel)
	VG.List:SetSize(VG.Panel:GetWide()-5,VG.Panel:GetTall()-5)
	VG.List:SetPos(2.5,5)
	VG.List:EnableHorizontal(false)
	VG.List:EnableVerticalScrollbar(false)
	VG.Create = vgui.Create("DButton",VG.Menu)
	VG.Create:SetText("Create Channel")
	VG.Create:SetSize(VG.Panel:GetWide()-20,15)
	VG.Create:SetPos(5,VG.Menu:GetTall() -20)
	VG.Create.DoClick = function() 
		CreateChannel()
	end
	VG.Help = vgui.Create("DButton",VG.Menu)
	VG.Help:SetText("?")
	VG.Help:SetSize(15,15)
	VG.Help:SetPos(VG.Create:GetWide()+6,VG.Menu:GetTall()-20)
	VG.Help.DoClick = function()
		local help = vgui.Create("DFrame")
		help:SetSize(600,300)
		help:Center()
		help:SetTitle("Voip Channel Instructions")
		help.Paint = function()
			surface.SetDrawColor( Color(100,80,80,255) ) 
			surface.DrawRect(0,0,help:GetWide(), help:GetTall())
		end
		local frame = vgui.Create("DPanel",help)
		frame:SetSize(help:GetWide()-10,help:GetTall()-30)
		frame:SetPos(5,25)
		frame.Paint = function()
			surface.SetDrawColor( Color(100,90,90,255) ) 
			surface.DrawRect(0,0,frame:GetWide(), frame:GetTall())
		end
		local title = vgui.Create("DLabel",frame)
		title:SetText([[
The voip system allows you to talk privately between yourselfs
and anyone else in the same channel as you.

Instructions:
Once you have joined a channel then you will hear all chat that channel.
To speak into the channel you must press your SPRINT(default shit) key along with your voice key.
To confirm you're speaking in private you will see a "SPEAKING IN VOIP" display above your hud.

You may create channels below with a password. Channel creator will get Admin powers.
You may give the powers to anyone you wish by right clicking on there picture (You lose your powers doing this)
If the admin of a channel disconnects it will be passed to the next client.

Only rule is, no obsene channel names & a common sense approach to NLR/Metagaming.




Made by Pantho, the terrible ByB Coder. If anyone else made it it might have been interactive -bybservers.co.uk]])
		title:SetPos(10,30)
		title:SizeToContents()
		help:MakePopup()
	end

	for k,chan in pairs(Chans.Channels) do
		local cat = vgui.Create("DCollapsibleCategory",VG.List)
		if #chan.Occupants and #chan.Occupants >1 then 
			cat:SetSize(VG.List:GetWide()-5,18+(50 * #chan.Occupants ))
		else
			cat:SetSize(VG.List:GetWide()-5,68)
		end
		cat:SetLabel(chan.Title)
		cat:SetExpanded(false)
		local plylist = vgui.Create("DPanelList",cat)
		plylist:SetSize(cat:GetWide(),cat:GetTall())
		plylist:SetPos(2.5,20)
		plylist:SetSpacing(1)
		local join = vgui.Create("DButton",cat)
		join:SetSize(cat:GetWide(),15)
		join:SetPos(5,20)
		join:SetText("Join!")
		join.DoClick = function()
				JoinChannel(chan)
		end
		plylist:AddItem(join)
		if chan.Occupants then 
			for k,v in pairs(chan.Occupants) do
				AddPlayer(v,plylist)
			end
		end
		chan.DCat = plylist
		VG.List:AddItem(cat)
	end
end



function AddPlayer(ply,plylist)
	if IsValid(ply) then
		local frame = {}
		frame.Panel = vgui.Create("DPanel",plylist)
		frame.Panel:SetSize(plylist:GetWide()-5,50)
		frame.Icon = vgui.Create("SpawnIcon",frame.Panel)
		frame.Icon:SetSize(32,32)
		frame.Icon:SetPos(10,10)
		frame.Icon:SetModel(ply:GetModel())
		frame.LabelName = vgui.Create("DLabel",frame.Panel)
		frame.LabelName:SetText(ply:Nick())
		frame.LabelName:SetPos(50,10)
		frame.LabelName:SizeToContents()
		frame.LabelName:SetTextColor(Color(0,0,0,255))
		frame.LabelJob = vgui.Create("DLabel",frame.Panel)
		frame.LabelJob:SetText(ply.DarkRPVars.job or "Cake")
		frame.LabelJob:SetPos(50,25)
		frame.LabelJob:SizeToContents()
		frame.LabelJob:SetTextColor(Color(0,0,0,255))
		frame.Icon.DoRightClick = function() ChannelAdmin(ply) end
		--VG.Players[ply:UniqueID()] = frame
		plylist:AddItem(frame.Panel)
	end
end

--DrawMain()
--CreatePlayer(LocalPlayer())

net.Receive("SendVG_voip", function(len,ply)
	Chans = net.ReadTable()
	--if VG.Menu then
		--VG.Menu:SetVisible(true)
	--else
		--DrawMain()
	--end
end)

net.Receive("OpenVG_voip",function(len,ply)
	Chans = net.ReadTable()
	DrawMain()
end)


hook.Add("PlayerStartVoice","PlayerStartVoice_voip",function(ply)
	if not IsValid(ply) or not ply == LocalPlayer() then return end
	local client = LocalPlayer()
	if client == ply then
		if not LocalPlayer().VoipChannel or LocalPlayer().VoipChannel == 0 then return end
		if client:KeyDown(IN_SPEED) then
			client.Voip = true
			RunConsoleCommand("voip_toggle", "1")
			hook.Add("HUDPaint","hudpaint_voip",function()
				local w, h = ScrW()/80, ScrH() /1.172
				draw.WordBox(2,w,h,"SPEAKING IN VOIP","DarkRPHUD1",Color(0,0,0,160), Color(150,80,80,255))
			end)
		else
			client.Voip = false
			RunConsoleCommand("voip_toggle", "0")
		end
	end
end)
hook.Add("PlayerEndVoice","PlayerEndVoice",function(ply)
	if voip_hud then voip_hud.Main:Close() end
	hook.Remove("HUDPaint","hudpaint_voip")
end)