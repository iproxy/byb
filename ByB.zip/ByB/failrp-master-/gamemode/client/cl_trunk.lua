
local function WithdrawItem(car,index)
	net.Start("TrunkWithdraw")
	net.WriteEntity(car)
	net.WriteInt(index,32)
	net.SendToServer()
end

local trunkinv
local trunkrow
local trunkrowlist
local trunksize
function DrawTrunk(car)
	if not IsValid(car) then return end
	trunksize = car:GetNetworkedInt("trunksize",5)
	local items = car.Trunk
	trunkinv = vgui.Create("DFrame")
	trunkinv:SetSize(340,300)
	trunkinv:Center()
	trunkinv:SetTitle("Vehicle Trunk")
	trunkinv:SetDraggable(true)
	trunkinv:SetVisible(true)
	trunkinv:ShowCloseButton(true)
	trunkinv:MakePopup()
	trunkrow = vgui.Create("DPanel",trunkinv)
	trunkrow:SetSize(330,365)
	trunkrow:SetPos(5,30)
	trunkrow:SetSkin("DarkRP")
	trunkrow.Paint = function()
		surface.SetDrawColor(50,50,50,50)
		surface.DrawRect(0,0,trunkrow:GetWide(),trunkrow:GetTall())
	end	
	trunkrowlist = vgui.Create("DPanelList",trunkrow)
	trunkrowlist:SetSize(330,365)
	trunkrowlist:SetSkin("DarkRP")
	trunkrowlist:EnableHorizontal(true)
	trunkrowlist:EnableVerticalScrollbar(false)
	for k,v in pairs(items) do
		local ent = v
		local iicon = vgui.Create("SpawnIcon")
		iicon:SetModel(ent:GetModel())
		if v:GetClass() == "money_printer" then
			iicon:SetToolTip(MoneyPrinters[ent.dt.Edition].Prefix.." Printer")
		else
			iicon:SetToolTip("Uknown item")
		end
		iicon.DoClick = function()
			WithdrawItem(car,k)
		end
		trunkrowlist:AddItem(iicon)
	end
	trunkinv:SetTitle("Trunk Contents: "..table.Count(trunkrowlist:GetItems()).."/"..trunksize .." Spaces Used.")
end

net.Receive("UpdateTrunk", function ()
	local car = net.ReadEntity()
	local trunk = net.ReadTable()
	trunksize = car:GetNetworkedInt("trunksize",5)
	if not IsValid(car) then return end
	car.Trunk = trunk
	--add fluffy print
	LocalPlayer():ChatPrint("Item Withdrawn")
	trunkrowlist:Clear()
	for k,ent in pairs(trunk) do
		local iicon = vgui.Create("SpawnIcon",trunkrow)
		iicon:SetModel(ent:GetModel())
		iicon:SetToolTip(ent:GetClass())
		--iicon:Dock(LEFT)
		iicon.DoClick = function()
			WithdrawItem(car,k)			
		end
		trunkrowlist:AddItem(iicon)
	end
	trunkinv:SetTitle("Trunk Contents: "..table.Count(trunkrowlist:GetItems()).."/"..trunksize .." Spaces Used.")
end)

net.Receive("OpenTrunk", function()
	local car = net.ReadEntity()
	local trunk = net.ReadTable()
	if not IsValid(car) then return end
	car.Trunk = trunk
	DrawTrunk(car)
end)

properties.Add("trunkopen",
{
	MenuLabel = "#Open Trunk",
	Order = 6,
	MenuIcon = "icon16/gun.png",
Filter = function(self,ent,ply)
		if (!IsValid(ent)) then return false end
		if ent:GetClass() != "prop_vehicle_jeep" then
			return false
		end
		if ent:GetPos():Distance(LocalPlayer():GetPos()) <=100 then return true else return false end
		return true
	end,
Action = function(self,ent)
		if ent:GetClass() == "prop_vehicle_jeep" then
			net.Start("RequestTrunk")
			net.WriteEntity(ent)
			net.SendToServer()
		end
	end
});

properties.Add("trunkdeposit",
{
	MenuLabel = "#Place in Trunk",
	Order = 5,
	MenuIcon = "icon16/gun.png",
Filter = function(self,ent,ply)
		if (!IsValid(ent)) then return false end
		if ent:GetClass() != "prop_vehicle_jeep" then
			return false
		end
		if ent:GetPos():Distance(LocalPlayer():GetPos()) <=100 then return true else return false end
		return true
	end,
Action = function(self,ent)
		if ent:GetClass() == "prop_vehicle_jeep" then
			net.Start("TrunkDeposit")
			net.WriteEntity(ent)
			net.SendToServer()
		end
	end
});