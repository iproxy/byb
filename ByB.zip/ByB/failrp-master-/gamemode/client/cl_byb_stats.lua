local sid
hook.Add("InitPostEntity", "stupid localplayer", function()
	timer.Simple(5, function() sid = LocalPlayer():SteamID() end)
end)
local stat = 1
local statpage = "gsummary2"
function DrawStatsMenu()
	sid = LocalPlayer():SteamID()
	local smenu = vgui.Create("DFrame") or smenu
	smenu:SetSize(ScrW()-100,ScrH()-100)
	smenu:Center()
	smenu:SetTitle("ByB Player Statistics")
	smenu:SetVisible(true)
	smenu:ShowCloseButton(true)
	smenu:MakePopup()
	
	local function DrawHTML(sid,page)
		local shtml = vgui.Create("HTML",smenu) or shtml
		shtml:SetPos(220,31)
		shtml:SetSize(ScrW()-325,ScrH()-160)
		local url = "http://www.bybservers.co.uk/index.php?page=ingamestats_"..statpage.."&sid=" ..sid
		shtml:OpenURL(url)
	end  
	
	local plylist = vgui.Create("DListView",smenu)
	plylist:SetPos(7,31)
	local plyh = (ScrH()/2)-100
	plylist:SetSize(200,plyh)
	plylist:AddColumn("SteamID")
	plylist:AddColumn("Player")
	for k,ply in pairs(player.GetAll()) do 
		plylist:AddLine(ply:SteamID(),ply:Name())
	end
	function plylist.OnRowSelected(panel,line)
		sid = plylist:GetLine(line):GetValue(1)
	end
	local options = vgui.Create("DListView",smenu)
	options:SetPos(7,plyh+30)
	options:SetSize(200,plyh)
	options:AddColumn("Statistic")
	options:AddLine("Global Summary")
	options:AddLine("Global Money")
	options:AddLine("Global Combat")
	options:AddLine("Top 100 Play Time(Global)")
	options:AddLine("Top 100 Play Time(Local)")
	options:AddLine("Top 100 Combat Stats")
	options:AddLine("Top 100 Money Stats")
	options:AddLine("Local Money")
	options:AddLine("Local Combat")
	function options.OnRowSelected(panel,line)
		stat = options:GetLine(line):GetID()
	end
	local fetch = vgui.Create("DButton",smenu)
	fetch:SetPos(27,(plyh+plyh+35))
	fetch:SetSize(160,60)
	fetch:SetText("Fetch Selected Stats")
	function fetch:DoClick()
		if stat == 1 then
			statpage = "gsummary2"
		elseif stat == 2 then
			statpage = "gmoney"
		elseif stat == 3 then
			statpage = "gcombat"
		elseif stat == 4 then
			statpage = "top100playtime"
		elseif stat == 5 then
			statpage = "top100splaytime&serv"..ServID
		elseif stat == 6 then
			statpage = "top100combat"
		elseif stat == 7 then
			statpage = "top100money"
		elseif stat == 8 then
			statpage = "lmoney&serv="..ServID
		elseif stat == 9 then
			statpage = "lcombat&serv="..ServID
		end
		DrawHTML(sid,statpage)
	end
		DrawHTML(sid,statpage)
	
end