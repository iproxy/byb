-- hurf
if (SERVER) then
    return;
end
local PANEL = {};

function PANEL:Init()
    self:DockPadding(10, 10, 10, 10);

    self.title = vgui.Create("DLabel", self);
    self.entry = vgui.Create("DTextEntry", self);
    self.padding = vgui.Create("DPanel", self);
    self.warning = vgui.Create("DLabel", self);

    local black = Color(0,0,0);
    self.padding:SetPaintBackground(false);
    self.title:SetColor(black);
    self.warning:SetColor(black);

    self.title:SetText  ("Enter your activation code here - then press enter");
    self.warning:SetText([[
This system is new, any issues contact a Root admin (Forum ticket).
This system is only when you purchase a GIFT CODE. If you simply purchased admin it will be automated after rejoining.
You are able to purchase activation codes via the website @ www.bybservers.co.uk

While we do sell admin, we also are very strict. You get 3 chances,
after you're 3rd confirmed abuse report you are demoted and may never repurchase admin.
We try to be strict but fair, we hope you are the same.]]);

    function self.entry:OnEnter()
        LocalPlayer():ConCommand("admincodeauth " .. tostring(self:GetValue()));
    end
    self.entry.OnLoseFocus = self.entry.OnEnter;

    self.title:Dock(TOP);
    self.entry:Dock(TOP);
    self.padding:Dock(TOP);
    self.warning:Dock(TOP);
end

function PANEL:PerformLayout()
    self.title:SizeToContents();
    self.padding:SetTall(30);
    self.warning:SizeToContents();
    self:SizeToChildren(false, true);
end

function PANEL:GetExpanded()
    return true;
end

local supporterpanel = vgui.RegisterTable(PANEL, "DPanel");

function GM:AdminTab()
    local panel = vgui.Create("DCollapsibleCategory");
    panel:SetContents(vgui.CreateFromTable(supporterpanel));
    panel:SetLabel("Admin Code Activation");
    panel.Header.DoClick = function() end
    -- Grr
    panel.Update = function() end
    return panel;
end
