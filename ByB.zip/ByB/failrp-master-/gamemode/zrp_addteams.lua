/*--------------------------------------------------------
Default teams. If you make a team above the citizen team, people will spawn with that team!
--------------------------------------------------------*/
TEAM_CITIZEN = AddExtraTeam("Survivor", Color(20, 150, 20, 255), {
        "models/player/Group01/Female_01.mdl",
        "models/player/Group01/Female_02.mdl",
        "models/player/Group01/Female_03.mdl",
        "models/player/Group01/Female_04.mdl",
        "models/player/Group01/Female_06.mdl",
        "models/player/group01/male_01.mdl",
        "models/player/Group01/Male_02.mdl",
        "models/player/Group01/male_03.mdl",
        "models/player/Group01/Male_04.mdl",
        "models/player/Group01/Male_05.mdl",
        "models/player/Group01/Male_06.mdl"},
[[The Survivor is the most basic level of society you can hold
besides being a zombie.
You have no specific role in city life (except for trying to stay alive).]], {"weapon_fists"}, "survivor", 0, 45, 0, false, false)
 
TEAM_MERC = AddExtraTeam( "Mercenary", Color( 187, 25, 0, 255), "models/player/guerilla.mdl" , [[(ByB Supporter Class only) You are a lapdog. Get hired,
and do what youre told. (This is not a ticket to
RDM)]], {"weapon_fists", "weapon_mad_knife", "weapon_mad_deagle"}, "mercenary", 3 , 45, 3, false,  false)
     
TEAM_MPOLICE = AddExtraTeam("Military Police", Color(25, 25, 170, 255), "models/player/urban.mdl", [[The protector of every citizen that lives in the city .
You have the responsibility to protect innocents.
This is a post-apocalyptic world, any criminal activity
will result in quick death from you. Bash them with a
stunstick and they might learn better than to disobey
the law. The Battering Ram can break down the door of
a criminal with a warrant for his/her arrest.
Type /wanted <name> to alert the public to this criminal
OR go to tab and warrant someone by clicking the warrant button]], {"weapon_fists", "weapon_keypad_cracker", "weapon_mad_sg550", "stunstick", "door_ram", "lockpick" }, "mp", 5, 65, 0, true, true)
     
TEAM_MCOM = AddExtraTeam("Military Commander", Color(20, 20, 255, 255), "models/player/swat.mdl", [[The Commander is the leader of the Military.
Coordinate the police forces to bring law to the city
Bash them with a stunstick and they might learn better than to
disrespect your authority!
The Battering Ram can break down the door of a criminal with a
warrant for his/her arrest.
Type /wanted <name> to alert the public to this criminal
Type /jailpos to set the Jail Position]], {/*"Taser", */"weapon_keypad_cracker", "weapon_fists", "lockpick", "weapon_mad_sg550", "stunstick", "door_ram"}, "mpcommander", 1, 75, 0, false, true, TEAM_MPOLICE)
     
TEAM_RESOP = AddExtraTeam("Resistance Operative", Color(75, 75, 75, 255), {
        "models/player/Group03/Female_01.mdl",
        "models/player/Group03/Female_02.mdl",
        "models/player/Group03/Female_03.mdl",
        "models/player/Group03/Female_04.mdl",
        "models/player/Group03/Female_06.mdl",
        "models/player/group03/male_01.mdl",
        "models/player/Group03/Male_02.mdl",
        "models/player/Group03/male_03.mdl",
        "models/player/Group03/Male_04.mdl",
        "models/player/Group03/Male_05.mdl",
        "models/player/Group03/Male_06.mdl"}, 
[[The lowest person of crime.
You follow the orders of the Resistance Leader. 
He is the God of the resistance.
The Resistance Leader sets your agenda and 
you follow it or you might be punished.]], {"weapon_fists"}, "resop", 5, 45, 0, false, false)
     
TEAM_RESLEADER = AddExtraTeam("Resistance Leader", Color(25, 25, 25, 255), "models/player/gman_high.mdl", [[The Resistance Leader is the boss of the Resistance.
With his power he coordinates the Resistance and forms an efficent crime
organization.
He has the ability to break into houses by using a lockpick.
The Resistance Leader can also unarrest you like a boss.]], {"weapon_fists", "lockpick"}, "resleader", 1, 60, 0, false, false)
     
TEAM_AGENT = AddExtraTeam("Recon Specialist", Color(150, 150, 150, 255), "models/player/barney.mdl", [[(ByB Supporter Job Only)
You do secret stuff like Secret Agents do.]], {"weapon_fists", "weapon_mad_usp", "weapon_mad_famas","weapon_keypad_cracker", "lockpick"}, "secretagent", 5, 55, 3, false, false)
     
--TEAM_HITMAN = AddExtraTeam("Hitman", Color(255, 0, 0, 255), "models/player/phoenix.mdl", [[(ByB Supporter Job Only)
--You are the only class allowed to be a Hitman]], {"weapon_mad_scout","weapon_mad_knife", "weapon_mad_charge"}, "Hitman", 1, 55, 3, false, false)
     
TEAM_GUN = AddExtraTeam("Gun Merchant", Color(255, 140, 0, 255), "models/player/monk.mdl", [[A Merchant is the only person who can sell guns to other
people legally.
However, make sure you aren t caught selling guns that are illegal to
the public.
/Buyshipment <name> to Buy a  weapon shipment
/Buygunlab to Buy a gunlab that spawns P228 Pistols]], {"weapon_fists"}, "merchant", 3, 45, 0, false, false)
     
TEAM_BGUN = AddExtraTeam("Black Market Dealer", Color(75, 75, 75, 255), "models/player/odessa.mdl", [[(ByB Supporter Job Only)
Sell the bad guys!
You may not own a shop to sell your products, remember they re off the black market, and therefor illegal.
If you decide to own a shop anyways, police may warrant and arrest you for it. Also admins may remove it, if it s obviously not RP.
If seen with any illegal items, or spotted selling them, you will be arrested.
You are not a 1 man killing machine, do not use your class to dispense gear for yourself then go on an RDM rampage.
Do not sell to police/mayor. They do not buy illegal weapons. Saying "I m corrupt." does not matter.
]], {"weapon_fists","weapon_mad_usp"}, "bmd", 3, 55, 3, false, false)
 
TEAM_MEDIC = AddExtraTeam("Doctor", Color(47, 79, 79, 255), "models/player/kleiner.mdl", [[With your medical knowledge, you heal players to proper
health.
Without a medic, people can not be healed.
Left click with the Medical Kit to heal other players.
Right click with the Medical Kit to heal yourself.]], {"weapon_fists","med_kit"}, "doctor", 3, 45, 0, false, false)

TEAM_SCIENCE = AddExtraTeam("Military Scientist", Color(60,130,170,255), "models/player/Hostage/Hostage_04.mdl", 
[[You are the egghead of the military. Sent
to this area to find out what causes the zombies.
You reside within the military headquarters. You
do all sorts of weird experiments on captive 
zombie specimens.]], {"weapon_fists"}, "scientist", 3, 45, 0, false, false)
     
TEAM_BODYGUARD = AddExtraTeam("Zombie Hunter", Color(230,230,0,200), "models/player/leet.mdl", [[You kill Zombies, pretty simple.
You can also be hired to protect a player from zombies.]], {"weapon_fists", "weapon_mad_ak47"}, "zombiehunter", 2, 60, 0, false)
     
TEAM_THIEF = AddExtraTeam("Thief", Color(190,190,190,255), "models/player/arctic.mdl", [[Break into people s house for money.]],
{"weapon_fists", "weapon_keypad_cracker", "lockpick"}, "thief", 3, 35, 0, false)
     
TEAM_ADMIN = AddExtraTeam("Admin On Duty", Color(255, 0, 0, 255), "models/player/Combine_Super_Soldier.mdl", [[ Your job is just to watch people
that they follow rules.
And things like that.
(You are NOT allowed to RP when this class!) ]], {"weapon_keypad_cracker","unarrest_stick"}, "adminduty", 3, 0, 1, false)
     
TEAM_SADMIN = AddExtraTeam("Superadmin On Duty", Color(255, 95, 220, 255), "models/player/soldier_stripped.mdl", [[ Cause havok, uphold rules.
And Murder Chas whenever possible.
(You are NOT allowed to RP when this class!) ]], {"weapon_keypad_cracker","unarrest_stick","weapon_mad_admin"}, "sadminduty", 4, 100, 2, false)

/*
--------------------------------------------------------
HOW TO MAKE AN EXTRA CLASS!!!!
--------------------------------------------------------

You can make extra classes here. Set everything up here and the rest will be done for you! no more editing 100 files without knowing what you re doing!!!
Ok here s how:

To make an extra class do this:
AddExtraTeam( "<NAME OF THE CLASS>", Color(<red>, <Green>, <blue>, 255), "<Player model>" , [[<the description(it can have enters)>]], { "<first extra weapon>","<second extra weapon>", etc...}, "<chat command to become it(WITHOUT THE /!)>", <maximum amount of this team> <the salary he gets>, 0/1/2 = public /admin only / superadmin only, <1/0/true/false Do you have to vote to become it>,  true/false DOES THIS TEAM HAVE A GUN LICENSE?, TEAM: Which team you need to be to become this team)

The real example is here: it s the Hobo:		*/

--VAR without /!!!			The name    the color(what you see in tab)                   the player model					The description
--TEAM_HOBO = AddExtraTeam("Hobo", Color(80, 45, 0, 255), "models/player/corpse1.mdl", [[The lowest member of society. All people see you laugh. 
--You have no home.
--Beg for your food and money
--Sing for everyone who passes to get money
--Make your own wooden home somewhere in a corner or 
--outside someone else s door]], {"weapon_fists", "weapon_bugbait"}, "hobo", 5, 0, 0, false)
//No extra weapons           say /hobo to become hobo  Maximum hobo's = 5		his salary = 0 because hobo's don't earn money.          0 = everyone can become hobo ,      false = you don't have to vote to become hobo
// MAKE SURE THAT THERE IS NO / IN THE TEAM NAME OR IN THE TEAM COMMAND:
// TEAM_/DUDE IS WROOOOOONG !!!!!!
// HAVING "/dude" IN THE COMMAND FIELD IS WROOOOOOOONG!!!!
//ADD TEAMS UNDER THIS LINE:









/*
--------------------------------------------------------
HOW TO MAKE A DOOR GROUP
--------------------------------------------------------
AddDoorGroup("NAME OF THE GROUP HERE, you see this when looking at a door", Team1, Team2, team3, team4, etc.)

WARNING: THE DOOR GROUPS HAVE TO BE UNDER THE TEAMS IN SHARED.LUA. IF THEY ARE NOT, IT MIGHT MUCK UP!


The default door groups, can also be used as examples:
*/
AddDoorGroup("Authorised Personnel Only", TEAM_CHIEF, TEAM_POLICE, TEAM_MAYOR, TEAM_SWAT, TEAM_SWATRECON, TEAM_SWATMEDIC, TEAM_SWATCQB)
AddDoorGroup("Mayor Only", TEAM_MAYOR)
AddDoorGroup("Police Chief Only", TEAM_CHIEF)
AddDoorGroup("Gundealer Only", TEAM_GUN)


/*
--------------------------------------------------------
HOW TO MAKE An agenda
--------------------------------------------------------
AddAgenda(Title of the agenda, Manager (who edits it), Listeners (the ones who just see and follow the agenda))

WARNING: THE AGENDAS HAVE TO BE UNDER THE TEAMS IN SHARED.LUA. IF THEY ARE NOT, IT MIGHT MUCK UP!

The default agenda's, can also be used as examples:

AddAgenda("Gangster's agenda", TEAM_MOB, {TEAM_GANG})
AddAgenda("Police agenda", TEAM_MAYOR, {TEAM_CHIEF, TEAM_POLICE})
*/

AddDoorGroup("Authorised Personnel Only", TEAM_CHIEF, TEAM_POLICE, TEAM_MAYOR, TEAM_SWAT, TEAM_SWATRECON, TEAM_SWATMEDIC, TEAM_SWATCQB)
AddDoorGroup("Mayor Only", TEAM_MAYOR)
AddDoorGroup("Police Chief Only", TEAM_CHIEF)
AddDoorGroup("Gundealer Only", TEAM_GUN)