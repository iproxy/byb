-- Not sure if Lexi or Falco wrote this, but we use it so I'll copy it in - Pantho
local fuckups = {};
local function AddFuckup(failtext)
    table.insert(fuckups, failtext);
end
hook.Add("PlayerSpawn", "Fuckup Announcer", function(ply)
    if (not ply:IsTrustedAdmin()) then
        return;
    end
    for _, fuckup in pairs(fuckups) do
        ply:ChatPrint("WARNING: " .. fuckup);
    end
end);
local fuckupformat = "Shipment %s doesn't have a %s set!";
local failed = false;
local function shipfuck(tab, what)
    if (not tab[what]) then
        AddFuckup(string.format(fuckupformat, tab.Name, what));
        failed = true;
    end
end


RPExtraTeams = {}
function AddExtraTeam(Name, colorOrTable, model, Description, Weapons, command, maximum_amount_of_this_class, Salary, admin, Vote, Haslicense, NeedToChangeFrom, CustomCheck)
	local tableSyntaxUsed = colorOrTable.r == nil -- the color is not a color table.

	if not Name or not colorOrTable or not tableSyntaxUsed and (not model or not Description or
	not Weapons or not command or not maximum_amount_of_this_class or not Salary or not admin or Vote == nil) then
		local text = "One of the custom teams is wrongly made! Attempting to give name of the wrongly made team!(if it's nil then I failed):\n" .. tostring(Name)
		print(text)
		hook.Add("PlayerSpawn", "TeamError", function(ply)
			if ply:IsAdmin() then ply:ChatPrint("WARNING: "..text) end
		end)
	end

	local CustomTeam = tableSyntaxUsed and colorOrTable or
		{color = colorOrTable, model = model, description = Description, weapons = Weapons, command = command,
			max = maximum_amount_of_this_class, salary = Salary, admin = admin or 0, vote = tobool(Vote), hasLicense = Haslicense,
			NeedToChangeFrom = NeedToChangeFrom, customCheck = CustomCheck
		}
	CustomTeam.name = Name

	table.insert(RPExtraTeams, CustomTeam)
	team.SetUp(#RPExtraTeams, Name, CustomTeam.color)
	local Team = #RPExtraTeams

	timer.Simple(0, function() GAMEMODE:AddTeamCommands(CustomTeam, CustomTeam.max) end)

	// Precache model here. Not right before the job change is done
	if type(CustomTeam.model) == "table" then
		for k,v in pairs(CustomTeam.model) do util.PrecacheModel(v) end
	else
		util.PrecacheModel(CustomTeam.model)
	end
	return Team
end

RPExtraTeamDoors = {}
function AddDoorGroup(name, ...)
	RPExtraTeamDoors[name] = {...}
end

CustomVehicles = {}
CustomShipments = {}
function AddCustomShipment(name, model, entity, price, Amount_of_guns_in_one_shipment, Sold_seperately, price_seperately, noshipment, classes, shipmodel, CustomCheck)
	local tableSyntaxUsed = type(model) == "table"
	if not name or not model or not tableSyntaxUsed and (not entity or not price or not Amount_of_guns_in_one_shipment or (Sold_seperately and not price_seperately)) then
		local text = "One of the custom shipments is wrongly made! Attempt to give name of the wrongly made shipment!(if it's nil then I failed):\n" .. tostring(name)
		print(text)
		hook.Add("PlayerSpawn", "ShipmentError", function(ply)
			if ply:IsAdmin() then ply:ChatPrint("WARNING: "..text) end end)
		return
	end

	local AllowedClasses = classes or {}
	if not classes then
		for k,v in pairs(team.GetAllTeams()) do
			table.insert(AllowedClasses, k)
		end
	end

	local price = tonumber(price)
	local shipmentmodel = shipmodel or "models/Items/item_item_crate.mdl"

	local customShipment = tableSyntaxUsed and model or
		{model = model, entity = entity, price = price, amount = Amount_of_guns_in_one_shipment,
		seperate = Sold_seperately, pricesep = price_seperately, noship = noshipment, allowed = AllowedClasses,
		shipmodel = shipmentmodel, customCheck = CustomCheck, weight = 5}

	customShipment.name = name
	customShipment.allowed = customShipment.allowed or {}

	if SERVER and not util.IsValidModel(customShipment.model) then
		local text = "The model of shipment "..name.." is incorrect! can not create custom shipment!"
		print(text)
		hook.Add("PlayerSpawn", "ShipmentError", function(ply)
			if ply:IsAdmin() then ply:ChatPrint("WARNING: "..text) end end)
		return
	end

	table.insert(CustomShipments, customShipment)
	util.PrecacheModel(customShipment.model)
end

function AddCustomVehicle(Name_of_vehicle, model, price, Jobs_that_can_buy_it)
	local function warn(add)
		local text
		if Name_of_vehicle then text = Name_of_vehicle end
		text = text.." FAILURE IN CUSTOM VEHICLE!"
		print(text)
		hook.Add("PlayerSpawn", "VehicleError", function(ply)
			if ply:IsAdmin() then ply:ChatPrint("WARNING: "..text.." "..add) end end)
	end
	if not Name_of_vehicle or not price or not model then
		warn("The name, model or the price is invalid/missing")
		return
	end
	local found = false
	for k,v in pairs(list.Get("Vehicles")) do
		if string.lower(k) == string.lower(Name_of_vehicle) then found = true break end
	end
	if not found and SERVER then
		warn("Vehicle not found!")
		return
	end
	table.insert(CustomVehicles, {name = Name_of_vehicle, model = model, price = price, allowed = Jobs_that_can_buy_it})
end

DarkRPEntities = {}
function AddEntity(name, entity, model, price, max, command, classes, CustomCheck)
	local tableSyntaxUsed = type(entity) == "table"

	if not name or not entity or not tableSyntaxUsed and (not price or not command) then
		hook.Add("PlayerSpawn", "ItemError", function(ply)
		if ply:IsAdmin() then ply:ChatPrint("WARNING: Item made incorrectly, failed to load!") end end)
		return
	end

	local tblEnt = tableSyntaxUsed and entity or
		{ent = entity, model = model, price = price, max = max,
		cmd = command, allowed = classes, customCheck = CustomCheck}
	tblEnt.name = name

	if type(tblEnt.allowed) == "number" then
		tblEnt.allowed = {tblEnt.allowed}
	end

	table.insert(DarkRPEntities, tblEnt)
end

DarkRPAgendas = {}

function AddAgenda(Title, Manager, Listeners)
	if not Manager then
		hook.Add("PlayerSpawn", "AgendaError", function(ply)
		if ply:IsAdmin() then ply:ChatPrint("WARNING: Agenda made incorrectly, there is no manager! failed to load!") end end)
		return
	end
	DarkRPAgendas[Manager] = {Title = Title, Listeners = Listeners}
end

GM.DarkRPGroupChats = {}
function GM:AddGroupChat(funcOrTeam, ...)
	-- People can enter either functions or a list of teams as parameter(s)
	if type(funcOrTeam) == "function" then
		table.insert(self.DarkRPGroupChats, funcOrTeam)
	else
		local teams = {funcOrTeam, ...}
		table.insert(self.DarkRPGroupChats, function(ply) return table.HasValue(teams, ply:Team()) end)
	end
end

GM.AmmoTypes = {}

function GM:AddAmmoType(ammoType, name, model, price, amountGiven, customCheck)
	table.insert(self.AmmoTypes, {
		ammoType = ammoType,
		name = name,
		model = model,
		price = price,
		amountGiven = amountGiven,
		customCheck = customCheck
	})
end

-- Lexis printer code, crudely ported in by Pantho.

MoneyPrinters = {};
--[[
MoneyPrinter "Fake" {
    Price = 0;
    Colour = Color(255,255,255);
    PrintMin = 0;
    PrintMax = 0;
    MaxCanHave = 0;
    CanExplode = false;
    SupporterOnly = false;
}
--]]

local function makeprinter(tab)
    if (not (
        tab.Price and
        tab.PrintMin and
        tab.PrintMax and
        tab.MaxCanHave))
    then
        AddFuckup("Incorrectly set up money printer '" .. prefix .. "'!");
        return;
    end
    if (not tab.Colour) then
        tab.Colour = Color(255, 255, 255);
    end
    table.insert(MoneyPrinters, tab);
end

function MoneyPrinter(prefix)
    return function(tab)
        tab.Prefix = prefix;
        makeprinter(tab);
    end
end

-- Lexis Shipment code, again copied in poorly by Pantho :)

Shipments = {};
local addshipment;
do
    local classlookup = {};
    local namelookup = {};
    function addshipment(tab)
        table.insert(Shipments, tab);
        tab.ShipmentID = #Shipments;
        namelookup[tab.Name] = tab;
        if (tab.Class) then
            classlookup[tab.Class] = tab;
        end
    end
    function FindShipment(id)
        return Shipments[tonumber(id)] or classlookup[id] or namelookup[id];
    end
end
local function makeshipment(tab)
    tab.Callback = tab[1];
    shipfuck(tab, "Model");
    shipfuck(tab, "Price");
    if (not tab.SeperateOnly) then
        shipfuck(tab, "Amount");
        if (tab.AvilableSeperately) then
            shipfuck(tab, "SeperatePrice");
        end
    else
        -- Ensure that anything using the seperate only sytnax still works like normal sperate items
        tab.AvailableSeperately = true
        tab.SeperatePrice = tab.Price;
        tab.SeperateTeams = nil;
    end
    if (not (tab.Class or tab.Callback)) then
        shipfuck(tab, "Class or Callback");
    end
    if (failed) then
        failed = false;
        return;
    end
    util.PrecacheModel(tab.Model);
    local teams = tab.Teams or team.GetAll();
    tab.Teams = {};
    for _, id in pairs(teams) do
        tab.Teams[id] = true;
    end
    if (tab.SeperateTeams) then
        local teams = tab.SeperateTeams;
        tab.SeperateTeams = {};
        for _, id in pairs(teams) do
            tab.SeperateTeams[id] = true;
        end
    else
        tab.SeperateTeams = tab.Teams;
    end
    addshipment(tab);
end

function Shipment(name)
    if (type(name) ~= "string") then
        AddFuckup(tostring(name) .. " is not a valid name for a shipment!");
        return function() end;
    end
    return function(tab)
        tab.Name = name;
        makeshipment(tab);
    end
end

CPDealer = {}

function AddCPDealerItem(Menu, Name, model, Weapon, Cost, Ammo)

	if not Menu or not Name or not model or not Weapon or not Cost then
		local text = "One of the CP dealers weapons is wrongly made! Attempt to give name of the wrongly made entity!(if it's nil then I failed):\n" .. tostring(Name)
		print(text)
		hook.Add("PlayerSpawn", "TeamError", function(ply)
			if ply:IsTrustedAdmin() then ply:ChatPrint("WARNING: "..text) end
		end)	
	end
	
	local CPW = {Menu = Menu, Name = Name, model = model, Weapon = Weapon, Cost = Cost, Ammo = Ammo}
	table.insert(CPDealer, CPW)
	
end