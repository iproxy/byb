if SERVER then
	-- guess what goes here?
end
if CLIENT then
	-- :)
end

--[[ any shared functions/code here. Remember just because a value is shared does not mean it will network instantly.
if you do:

local apple = 123

if SERVER then
	apple = 1234
end

it will still = 123 on the client as it's not been networked, see net.start for best network methods.
]]