if SERVER then
	--resource.AddWorkshop("133342076")
end
--[[--------------------------------------------------------
Default teams. If you make a team above the citizen team, people will spawn with that team!
----------------------------------------------------------]]
TEAM_CITIZEN = AddExtraTeam("Citizen", Color(20, 150, 20, 255), {
	"models/player/Group01/Female_01.mdl",
	"models/player/Group01/Female_02.mdl",
	"models/player/Group01/Female_03.mdl",
	"models/player/Group01/Female_04.mdl",
	"models/player/Group01/Female_06.mdl",
	"models/player/group01/male_01.mdl",
	"models/player/Group01/Male_02.mdl",
	"models/player/Group01/male_03.mdl",
	"models/player/Group01/Male_04.mdl",
	"models/player/Group01/Male_05.mdl",
	"models/player/Group01/Male_06.mdl",
	"models/player/Group01/Male_07.mdl",
	"models/player/Group01/Male_08.mdl",
	"models/player/Group01/Male_09.mdl"},
[[The Citizen is the most basic level of society you can hold
besides being a hobo. 
You have no specific role in city life.]], {}, "citizen", 0, 45, 0, false, false)

TEAM_MERC = AddExtraTeam( "Mercenary", Color( 187, 25, 0, 255), "models/player/guerilla.mdl" , [[(ByB Supporter Class only) You are a lapdog. Get hired, 
and do what youre told. (This is not a ticket to 
RDM)]], {"weapon_mad_knife", "weapon_mad_deagle", "weapon_mad_galil"}, "mercenary", 7 , 45, 3, false,  false)

TEAM_POLICE = AddExtraTeam("Police Officer", Color(25, 25, 170, 255), {"models/player/police.mdl", "models/player/police_fem.mdl"}, [[The protector of every citizen that lives in the city . 
You have the power to arrest criminals and protect innocents. 
Hit them with your arrest baton to put them in jail
Bash them with a stunstick and they might learn better than to disobey 
the law.
The Battering Ram can break down the door of a criminal with a warrant 
for his/her arrest.
The Battering Ram can also unfreeze frozen props(if enabled).
Type /wanted <name> to alert the public to this criminal
OR go to tab and warrant someone by clicking the warrant button]], {"weapon_keypad_cracker", "arrest_stick", "unarrest_stick", "weapon_mad_glock", "stunstick", "door_ram", "lockpick" }, "police", 5, 65, 0, true, true)

TEAM_SWAT = AddExtraTeam("SWAT", Color(0, 30, 255, 255), {
	"models/player/gasmask.mdl",
	"models/player/swat.mdl",
	"models/player/urban.mdl",
	"models/player/riot.mdl"}, [[(ByB Supporter Job Only)
The protector of every citizen that lives in the city . 
You have the power to arrest criminals and protect innocents. 
Hit them with your arrest baton to put them in jail
Bash them with a stunstick and they might learn better than to disobey 
the law.
The Battering Ram can break down the door of a criminal with a warrant 
for his/her arrest.
The Battering Ram can also unfreeze frozen props(if enabled).
Type /wanted <name> to alert the public to this criminal
OR go to tab and warrant someone by clicking the warrant button]], {"weapon_mad_charge","weapon_mad_charge","weapon_mad_charge","weapon_mad_charge","swat_cracker", "arrest_stick", "unarrest_stick", "weapon_bd_mp7", "stunstick", "door_ram", "lockpick"}, "SWAT", 7, 65, 3, false, true)

TEAM_SWATMEDIC = AddExtraTeam("SWAT Medic", Color(0, 15, 255, 255), {
	"models/player/gasmask.mdl",
	"models/player/swat.mdl",
	"models/player/urban.mdl",
	"models/player/riot.mdl"}, [[(ByB Supporter Job Only)
You are the elite of the elite. When called upon,
you are literally the guardian angel of the city
police. You are the lifeline of your fellow SWAT
members, you also are equipped to access
even the most dangerous of areas, and clear them
with deadly efficiency.]], {"weapon_mad_charge","weapon_mad_charge","weapon_mad_charge","weapon_mad_charge","weapon_keypad_cracker", "arrest_stick", "unarrest_stick","weapon_bd_mp7", "stunstick", "door_ram", "lockpick", "med_kit"}, "swatmedic", 3, 65, 3, false, true, TEAM_SWAT)

TEAM_SWATCQB = AddExtraTeam("SWAT CQB", Color(0, 15, 255, 255), {
	"models/player/gasmask.mdl",
	"models/player/swat.mdl",
	"models/player/urban.mdl",
	"models/player/riot.mdl"}, [[(ByB Supporter Job Only)
You are the elite of the elite. When called upon,
you are literally the guardian angel of the city
police. You are a master of Close Quarters combat,
you also are equipped to access even the most dangerous
of areas, and clear them with deadly efficiency.]], {"weapon_mad_charge","weapon_mad_charge","weapon_mad_charge","weapon_mad_charge","swat_cracker", "arrest_stick", "unarrest_stick", "weapon_bd_mp7", "weapon_mad_glock", "stunstick", "door_ram", "lockpick"}, "swatcqb", 2, 65, 3, false, true, TEAM_SWAT)

TEAM_SWATRECON = AddExtraTeam("SWAT Recon", Color(0, 15, 255, 255), {
	"models/player/gasmask.mdl",
	"models/player/swat.mdl",
	"models/player/urban.mdl",
	"models/player/riot.mdl"}, [[(ByB Supporter Job Only)
You are the elite of the elite. When called upon,
you are literally the guardian angel of the city
police. You are silent, efficient, and deadly, 
You also are equipped to access even the most
dangerous of areas, and clear them with deadly 
efficiency.]], { "weapon_keypad_cracker", "arrest_stick", "unarrest_stick", "weapon_mad_usp", "weapon_bd_mp7", "weapon_mad_scout",  "stunstick", "door_ram", "lockpick"}, "swatrecon", 2, 65, 3, false, true, TEAM_SWAT)

TEAM_GANG = AddExtraTeam("Gangster", Color(75, 75, 75, 255), {
	"models/player/Group03/Female_01.mdl",
	"models/player/Group03/Female_02.mdl",
	"models/player/Group03/Female_03.mdl",
	"models/player/Group03/Female_04.mdl",
	"models/player/Group03/Female_06.mdl",
	"models/player/group03/male_01.mdl",
	"models/player/Group03/Male_02.mdl",
	"models/player/Group03/male_03.mdl",
	"models/player/Group03/Male_04.mdl",
	"models/player/Group03/Male_05.mdl",
	"models/player/Group03/Male_06.mdl",
	"models/player/Group03/Male_07.mdl",
	"models/player/Group03/Male_08.mdl",
	"models/player/Group03/Male_09.mdl"}, [[The lowest person of crime. 
A gangster generally works for the Mobboss who runs the crime family. 
The Mobboss sets your agenda and you follow it or you might be punished.]], {}, "gangster", 8, 45, 0, false, false)

TEAM_MOB = AddExtraTeam("Mob boss", Color(25, 25, 25, 255), "models/player/gman_high.mdl", [[The Mobboss is the boss of the criminals in the city. 
With his power he coordinates the gangsters and forms an efficent crime
organization. 
He has the ability to break into houses by using a lockpick. 
The Mobboss also can unarrest you.]], {"lockpick", "unarrest_stick"}, "mobboss", 2, 60, 0, false, false)

TEAM_AGENT = AddExtraTeam("Secret Agent", Color(150, 150, 150, 255), {"models/player/barney.mdl",
	"models/player/alyx.mdl"}, [[(ByB Supporter Job Only)
This is NOT just another raiding job. 
You may do anything you like buy customising the job. 
You may help the police (With there approval) or join a gang.
Or protect the hobos from the corruption of all evil.]], {"weapon_mad_usp", "weapon_crossbow","weapon_keypad_cracker", "lockpick"}, "secretagent", 7, 55, 3, false, false)

TEAM_HITMAN = AddExtraTeam("Hitman", Color(255, 0, 0, 255), {"models/player/phoenix.mdl",
"models/player/Group03/Male_06.mdl",
"models/player/Group03/Female_04.mdl",
"models/player/barney.mdl",	
"models/player/alyx.mdl"}, [[(ByB Supporter Job Only)
You are the only class allowed to be a Hitman]], {"weapon_mad_scout","weapon_mad_knife"}, "Hitman", 1, 55, 3, false, false)

TEAM_BGUN = AddExtraTeam("Black Market Dealer", Color(75, 75, 75, 255), {"models/player/odessa.mdl","models/player/alyx.mdl","models/player/mossman_arctic.mdl"}, [[(ByB Supporter Job Only)
Sell the bad guys!
You may not own a shop to sell your products, remember they re off the black market, and therefor illegal.
If you decide to own a shop anyways, police may warrant and arrest you for it. Also admins may remove it, if it s obviously not RP.
If seen with any illegal items, or spotted selling them, you will be arrested.
You are not a 1 man killing machine, do not use your class to dispense gear for yourself then go on an RDM rampage.
Do not sell to police/mayor. They do not buy illegal weapons. Saying "I m corrupt." does not matter.
]], {"weapon_mad_usp"}, "bmd", 3, 55, 3, false, false)


TEAM_GUN = AddExtraTeam("Gun Dealer", Color(255, 140, 0, 255), {"models/player/mossman.mdl",
																"models/player/monk.mdl"}, [[A gun dealer is the only person who can sell guns to other 
people. 
However, make sure you aren t caught selling guns that are illegal to 
the public.
/Buyshipment <name> to Buy a  weapon shipment
/Buygunlab to Buy a gunlab that spawns P228 pistols]], {}, "gundealer", 3, 45, 0, false, false)

TEAM_HGUN = AddExtraTeam("Heavy Gun Dealer", Color(255, 140, 0, 255), {"models/player/mossman.mdl",
																		"models/player/monk.mdl"}, [[A gun dealer is the only person who can sell guns to other 
people. 
However, make sure you aren t caught selling guns that are illegal to 
the public.
/Buyshipment <name> to Buy a  weapon shipment
/Buygunlab to Buy a gunlab that spawns P228 pistols]], {}, "heavygundealer", 2, 45, 0, false, false)


TEAM_MEDIC = AddExtraTeam("Doctor", Color(47, 79, 79, 255), {"models/player/kleiner.mdl",
															 "models/player/mossman.mdl",
															 "models/player/magnusson.mdl"}, [[With your medical knowledge, you heal players to proper 
health. 
Without a medic, people can not be healed. 
Left click with the Medical Kit to heal other players.
Right click with the Medical Kit to heal yourself.]], {"med_kit"}, "doctor", 3, 45, 0, false, false)

--[=[TEAM_MECHANIC = AddExtraTeam("Mechanic", Color(238, 99, 99, 255), "models/player/mossman.mdl", [[As a mechanic,
your job is to help people with trouble with their cars.
Like no fuel or broken engine.]], {}, "mechanic", 2, 45, 0, 0, false)--]=]


TEAM_BANKER = AddExtraTeam("Banker", Color(119,118,60,255), "models/player/Hostage/hostage_02.mdl", [[Make a bank to store peoples things safely.]], {}, "banker", 3, 65, 0, false)


TEAM_LAWYER = AddExtraTeam("Lawyer", Color(60,130,170,255), "models/player/Hostage/Hostage_04.mdl", [[Fight for the right of people. Go to court with clients. Try to bail people out of jail.]], {"unarrest_stick"}, "lawyer", 2, 70, 0, false)

--[=[TEAM_VEH = AddExtraTeam("Vehicle Dealer", Color(125, 0, 255, 255), "models/player/alyx.mdl", [[Vehicles is something peaople need
Buy the jeeps and sell them for good money!]], {""}, "vehicledealer", 2, 50, 0, true)--]=]

TEAM_BODYGUARD = AddExtraTeam("Body Guard", Color(3,180,200,255), "models/player/leet.mdl", [[You must guard/protect those who hire you and/or their items. 
You may only use violence (including your fists) for self defence or 
against those who try to harm your employer. You may not be in a gang.]], {"weapon_fists"}, "bodyguard", 4, 60, 0, false)

TEAM_THIEF = AddExtraTeam("Thief", Color(128,0,128,255), "models/player/arctic.mdl", [[Break into people s house for money.]], 
{"weapon_keypad_cracker", "lockpick"}, "thief", 5, 35, 0, false)

TEAM_MTHIEF = AddExtraTeam("Master Thief", Color(125, 38, 235, 255), "models/player/arctic.mdl", [[(ByB Supporter Job Only)
You are the best thief known to man.]], {"weapon_mad_tmp", "super_lockpick","super_cracker"}, "masterthief", 2, 55, 3, false, false)

TEAM_ADMIN = AddExtraTeam("Admin On Duty", Color(255, 0, 0, 255), "models/player/Combine_Super_Soldier.mdl", [[ Your job is just to watch people
that they follow rules.
And things like that. 
(You are NOT allowed to RP when this class!) ]], {"weapon_keypad_cracker","unarrest_stick"}, "adminduty", 3, 0, 1, false)

TEAM_SADMIN = AddExtraTeam("Superadmin On Duty", Color(255, 95, 220, 255), {
	"models/player/soldier_stripped.mdl",
	"models/player/charple.mdl",
	"models/player/p2_chell.mdl",
	"models/player/zombie_fast.mdl",
	"models/player/magnusson.mdl",
	"models/player/zombie_classic.mdl",
	"models/player/skeleton.mdl",
	"models/player/eli.mdl"
	}, [[ Cause havok, uphold rules.
And Murder Chas whenever possible.
(You are NOT allowed to RP when this class!) ]], {"weapon_keypad_cracker","unarrest_stick","weapon_mad_admin","weapon_nomad_sniper"}, "sadminduty", 4, 100, 2, false)

TEAM_CHIEF = AddExtraTeam("Police Chief", Color(20, 20, 255, 255), "models/player/combine_soldier_prisonguard.mdl", [[The Chief is the leader of the Civil Protection unit. 
Coordinate the police forces to bring law to the city
Hit them with arrest baton to put them in jail
Bash them with a stunstick and they might learn better than to 
disobey the law (rawr).
The Battering Ram can break down the door of a criminal with a 
warrant for his/her arrest.
Type /wanted <name> to alert the public to this criminal
Type /jailpos to set the Jail Position]], {--[["Taser", --]]"weapon_keypad_cracker", "arrest_stick","lockpick", "unarrest_stick", "weapon_mad_deagle", "stunstick", "door_ram"}, "chief", 1, 75, 0, false, true, {TEAM_POLICE,TEAM_SWAT,TEAM_SWATCQB,TEAM_SWATMEDIC,TEAM_SWATRECON})

TEAM_MAYOR = AddExtraTeam("Mayor", Color(150, 20, 20, 255), "models/player/breen.mdl", [[The Mayor of the city creates laws to serve the greater good 
of the people.
If you are the mayor you may create and accept warrants.
Type /wanted <name>  to warrant a player
Type /jailpos to set the Jail Position
Type /lockdown initiate a lockdown of the city. 
Everyone must be inside during a lockdown. 
The cops patrol the area
/unlockdown to end a lockdown]], {"weapon_mad_57"}, "mayor", 1, 85, 0, true, false--[[, {TEAM_CHIEF, TEAM_POLICE}--]])
--[=[
--------------------------------------------------------
HOW TO MAKE AN EXTRA CLASS!!!!
--------------------------------------------------------

You can make extra classes here. Set everything up here and the rest will be done for you! no more editing 100 files without knowing what you re doing!!!
Ok here s how:

To make an extra class do this:
AddExtraTeam( "<NAME OF THE CLASS>", Color(<red>, <Green>, <blue>, 255), "<Player model>" , [[<the description(it can have enters)>]], { "<first extra weapon>","<second extra weapon>", etc...}, "<chat command to become it(WITHOUT THE /!)>", <maximum amount of this team> <the salary he gets>, 0/1/2 = public /admin only / superadmin only, <1/0/true/false Do you have to vote to become it>,  Unused (set to nil), TEAM: Which team you need to be to become this team)

The real example is here: it s the Hobo:		--]=]

--VAR without /!!!			The name    the color(what you see in tab)                   the player model					The description
TEAM_HOBO = AddExtraTeam("Hobo", Color(80, 45, 0, 255), "models/player/corpse1.mdl", [[The lowest member of society. All people see you laugh. 
You have no home.
Beg for your food and money
Sing for everyone who passes to get money
Make your own wooden home somewhere in a corner or 
outside someone else s door]], {"weapon_fists"}, "hobo", 7, 0, 0, false)
--No extra weapons           say /hobo to become hobo  Maximum hobo's = 5		his salary = 0 because hobo's don't earn money.          0 = everyone can become hobo ,      false = you don't have to vote to become hobo
-- MAKE SURE THAT THERE IS NO / IN THE TEAM NAME OR IN THE TEAM COMMAND:
-- TEAM_/DUDE IS WROOOOOONG !!!!!!
-- HAVING "/dude" IN THE COMMAND FIELD IS WROOOOOOOONG!!!!
--ADD TEAMS UNDER THIS LINE:

--[[
--------------------------------------------------------
HOW TO MAKE A DOOR GROUP
--------------------------------------------------------
AddDoorGroup("NAME OF THE GROUP HERE, you see this when looking at a door", Team1, Team2, team3, team4, etc.)

WARNING: THE DOOR GROUPS HAVE TO BE UNDER THE TEAMS IN SHARED.LUA. IF THEY ARE NOT, IT MIGHT MUCK UP!


The default door groups, can also be used as examples:
--]]
AddDoorGroup("Authorised Personnel Only", TEAM_CHIEF, TEAM_POLICE, TEAM_MAYOR, TEAM_SWAT, TEAM_SWATRECON, TEAM_SWATMEDIC, TEAM_SWATCQB)
AddDoorGroup("Mayor Only", TEAM_MAYOR)
AddDoorGroup("Police Chief Only", TEAM_CHIEF)
AddDoorGroup("Gundealer Only", TEAM_GUN)
