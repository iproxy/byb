
-- Please reaplasy the numbers to were you want to spawn the NPC dealer
CPSpawnPos = Vector(-2084.631592, 217.932220,101.031235)
 




hook.Add("InitPostEntity","SpawnTheEntity",function()

local ent = ents.Create( "Cpdealer" )
ent:SetPos( CPSpawnPos )

ent:Spawn()
ent:Activate()

end)
