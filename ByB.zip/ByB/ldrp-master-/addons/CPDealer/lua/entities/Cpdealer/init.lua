
AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )

function ENT:Initialize( ) 
 
	self:SetModel( "models/Combine_Soldier.mdl" ) 
	self:SetHullType( HULL_HUMAN ) 
	self:SetHullSizeNormal( )
	self:SetNPCState( NPC_STATE_SCRIPT )
	self:SetSolid( SOLID_BBOX ) 
	self:CapabilitiesAdd( CAP_ANIMATEDFACE | CAP_TURN_HEAD )
	self:SetUseType( SIMPLE_USE )
	self:DropToFloor()
	self:Give("weapon_ar2")

	self:SetMaxYawSpeed( 90 )
 
end

function ENT:AcceptInput( Name, Activator, Caller )	
	if Name == "Use" and Caller:IsPlayer() and Caller:IsCP() then
		umsg.Start("CPMenu", Caller) 
		umsg.End()
	end
end

function ENT:Think()

CPDPos = self.Entity:GetPos()

end






-- IF SOME ONE FROM BYB IS LOOKING AT THIS I KNOW THERE IS ALOT OF IF'S AND I KNOW I COULD MAKE IT SMALLER BUT HAY IT WORKS AND I KNOW ITS ALL OVER THE PLAYS BUT NO PlAYER IS GOING TO LOOK HERE :D
-- And if you are asking Why is there returns there just beouce the loop the function ran more then once
-- Madness

function Buy(ply,command,args)
 
 if CPDPos:Distance(ply:GetPos()) < 80 then
 
	if ply:IsPlayer() and ply:IsCP() then

	for k,v in pairs(CPDealer) do
	
	if v.Weapon == args[1] then

	if v.Menu == 2 then
	
	if ply:CanAfford(v.Cost) == true then
	
	if ply:GetWeapon(v.Weapon):IsValid() then

	ply:GiveAmmo(1,v.Ammo)

	Notify(ply, 1, 7, "You have bought a " .. v.Name .. " for $" .. v.Cost)
	
	ply:AddMoney(-v.Cost)
	
	return
	
	else
	
	ply:Give(v.Weapon)
	
	ply:AddMoney(-v.Cost)
	
	Notify(ply, 1, 7, "You have bought a " .. v.Name .. " for $" .. v.Cost)
	
	return
	
	end
	
	
	else
	
	Notify(ply, 1, 7, "You can't Afford this Item")
	
	return
	
	end
	
	else
	
	-- End of menu 2 
	
	if ply:GetWeapon(v.Weapon):IsValid() then
	
	Notify(ply, 1, 7, "You all ready have this weapon")
	
	else
	
	if ply:CanAfford(v.Cost) == true then 
	
	ply:Give(v.Weapon)
	
	ply:AddMoney(-v.Cost)
	
	Notify(ply, 1, 7, "You have bought a " .. v.Name .. " for $" .. v.Cost)
	
	else
	
	Notify(ply, 1, 7, "You can't Afford this weapon")
	
							end
						end
					end
				end
			end
		end
	end
end
concommand.Add("BCPDealer",Buy)