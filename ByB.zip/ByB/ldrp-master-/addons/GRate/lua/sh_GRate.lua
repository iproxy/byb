function EmptyFunction() end

GR.Version = 1.02

function GR.ChatMessage(Message, Recipients, Console)
	if (CLIENT) then
		chat.AddText(Color(0, 0, 250), "GRate :: ", GR.Info.ServerTextColor, Message)
	else
		if (Console) then print("GRate :: " .. Message) end
		if (!Recipients) then Recipients = RecipientFilter() Recipients:AddAllPlayers() end
		umsg.Start("GRate.ChatMessage", Recipients)
			umsg.String(Message)
		umsg.End()
	end
end
if (CLIENT) then usermessage.Hook("GRate.ChatMessage", function(Data) GR.ChatMessage(Data:ReadString()) end) end

function GR.RequestPage(URL, Callback)
	Callback = Callback or EmptyFunction

	local Time = CurTime()
	local HTTPElement = HTTPGet()
	
	HTTPElement:Download(URL, "")
	
	hook.Add("Think", "GRate.HTTP." .. Time, function()
		if (HTTPElement:GetBuffer()) and (HTTPElement:GetBuffer():len() > 0) then
			Callback(HTTPElement:GetBuffer())
			hook.Remove("Think", "GRate.HTTP." .. Time)
		end
	end)
end

if (SERVER) then return end

function GR.GetMinimumWidth()
	surface.SetFont(GR.Info.ServerFont)
	GR.Info.MinimumWidth = surface.GetTextSize("GRate | " .. GR.Info.ServerName)
	for k, v in pairs{"Server information loaded.", "Casting vote. Please wait..."} do
		local W = surface.GetTextSize(v) + 8
		if (W > GR.Info.MinimumWidth) then GR.Info.MinimumWidth = W end
	end
end