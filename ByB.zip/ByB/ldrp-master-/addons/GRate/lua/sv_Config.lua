GR.Config = {}

/*	This is where you can set your server's information for GRate's appearance on clients.
	Colors are strings in RGB format. Each color is seperated by a space.	*/

GR.Config.ServerName		= "Sample Server"	-- Appears as "GRate | <ServerName>"
GR.Config.ServerTicket		= "692908321797b6495318cfcad56ab9e732203b6e"			-- Unique server ticket given by GRate
GR.Config.ServerFont		= "Trebuchet22"
GR.Config.ServerBorderColor	= "0 0 0"			-- Outline on the GRate UI
GR.Config.ServerBGColor		= "50 50 50"		-- Background
GR.Config.ServerTextColor	= "255 255 255"		-- Text
GR.Config.ChatRateCommand	= "!rate"
GR.Config.ChatVerifyCommand	= "!verify"
