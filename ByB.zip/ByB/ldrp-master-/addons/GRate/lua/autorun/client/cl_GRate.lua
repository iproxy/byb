GR =  {}

include("sh_GRate.lua")

-- Local controllers
local First = false
local Drawing = false
local FadingOut = false
local FadingIn = false
local CurrentWaitingPosition = 1
local CurrentWaitingPosition2 = 21
local CurrentWaitingPosition3 = 11
local CurrentWaitingPosition4 = 31
local Waiting = true
local WaitMessage = "Retrieving server info..."

-- Initialization
GR.Info = {}
GR.Info.ServerFont = "Trebuchet22"
GR.Info.ServerName = "Loading"
GR.Info.ServerBorderColor = Color(0, 0, 0, 0)
GR.Info.ServerBGColor = Color(50, 50, 50, 0)
GR.Info.ServerTextColor = Color(255, 255, 255, 0)

GR.GetMinimumWidth()

function GR.RetrieveServerInfo(Data)
	if (GR.Info.ServerTicket) then return end

	-- Server Information
	GR.Info.ServerTicket		= Data:ReadString()
	GR.Info.ServerName			= Data:ReadString()
	GR.Info.ServerFont			= Data:ReadString()
	
	local color
		-- Border Color
	color = Data:ReadString()
	color = string.Explode(" ", color)
		GR.Info.ServerBorderColor = Color(tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), GR.Info.ServerBorderColor.a)
	
		-- Background Color
	color = Data:ReadString()
	color = string.Explode(" ", color)
		GR.Info.ServerBGColor = Color(tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), GR.Info.ServerBGColor.a)
	
		-- Text Color
	color = Data:ReadString()
	color = string.Explode(" ", color)
		GR.Info.ServerTextColor = Color(tonumber(color[1]), tonumber(color[2]), tonumber(color[3]), GR.Info.ServerTextColor.a)
	
	GR.GetMinimumWidth()
	
	Waiting = false
	CurrentWaitingPosition = 0
	CurrentWaitingPosition2 = 20
	CurrentWaitingPosition3 = 10
	CurrentWaitingPosition4 = 30
	WaitMessage = "Server information loaded."
	
	GR.ChatMessage("Version " .. GR.Version .. " initialized.")
	
	local Time = true
	
	if (GR.Version != "BETA") then GR.RequestPage("http://grate.pngskin.com/votelib/version.txt", function(Text)
		if (tonumber(Text) > GR.Version) then
			WaitMessage = "GRate out of date!"
			GR.Info.ServerTextColor = Color(255, 30, 30, GR.Info.ServerTextColor.a)
			GR.Info.ServerBorderColor = Color(255, 30, 30, GR.Info.ServerBorderColor.a)
			Time = false
			hook.Add("KeyPress", "GRate.OutOfDate", function()
				FadingOut = true
				hook.Remove("KeyPress", "GRate.OutOfDate")
			end)
		end
	end) end
	
	if (Time) then
		timer.Simple(1.5, function() FadingOut = true end)
	else
		FadingOut = false
		FadingIn = true
	end
end
usermessage.Hook("GRate.Info", GR.RetrieveServerInfo)

function GR.Message(Message, Wait, Timer)
	surface.SetFont(GR.Info.ServerFont)
	
	local MWidth = surface.GetTextSize(Message) + 8
	if (MWidth > GR.Info.MinimumWidth) then GR.Info.MinimumWidth = MWidth end
	
	FadingIn = true
	Waiting = Wait
	WaitMessage = Message
	
	if (Timer) then timer.Simple(1.5, function() if (Waiting) then return end FadingOut = true end) end
	
	GR.ChatMessage(Message)
	surface.PlaySound("buttons/button14.wav")
end
usermessage.Hook("GRate.Message", function(Data) GR.Message(Data:ReadString(), false, true) end)
usermessage.Hook("GRate.Waiting", function(Data) GR.Message(Data:ReadString(), true, false) end)
usermessage.Hook("GRate.Rating", function(Data) GR.Message("Casting vote. Please wait...", true, false) end)

function GR.CastVote(Data)
	local Ticket = Data:ReadString()
	
	FadingIn = true
	Waiting = true
	WaitMessage = "Casting vote. Please wait..."
	
	GR.RequestPage("http://grate.pngskin.com/votelib/vote_cl.php?ticket=" .. Ticket .. "&serverticket=" .. GR.Info.ServerTicket, function(Text)
		GR.Message(Text, false, true)
	end)
end
usermessage.Hook("GRate.CastVote", GR.CastVote)

function GR.IsOnServer()
	First = true
	FadingIn = true
end
usermessage.Hook("GRate.IsOnServer", GR.IsOnServer)

function GR.GeneratePath(PositionX, PositionY, TextWidth)
	PositionX = math.floor(PositionX + (TextWidth / 2))
	PositionY = PositionY + 5
	
	GR.WaitingPath = {}
	
	GR.WaitingPath[0] = {PositionX, PositionY}
	
	for i = 1, 39 do
		if (i <= 20) then
			PositionY = PositionY + 1
		else
			PositionY = PositionY - 1
		end
		
		if (i <= 10) then
			PositionX = PositionX + 1
		elseif (i <= 30) then
			PositionX = PositionX - 1
		elseif (i > 30) then
			PositionX = PositionX + 1
		end
		GR.WaitingPath[i] = {PositionX, PositionY}
	end
end

function GR.DrawTitle()
	local GRateWidth = surface.GetTextSize("GRate | ")
	local NameWidth = surface.GetTextSize(GR.Info.ServerName)
	local TextWidth = GRateWidth + NameWidth + 8
	
	local DrawWidth = math.Clamp(TextWidth, GR.Info.MinimumWidth or 200, math.huge)
	
	local MinusFactor = math.floor(DrawWidth / 2)
	
	local PositionX = math.floor((ScrW() / 2) - MinusFactor)
	local PositionY = math.floor(.2 * ScrH())
	
	local TextX = math.floor(PositionX + (DrawWidth / 2) - (TextWidth / 2)) + 4
	
	surface.SetDrawColor(GR.Info.ServerBGColor)
		surface.DrawRect(PositionX, PositionY, DrawWidth, 20)
	surface.SetDrawColor(GR.Info.ServerBorderColor)
		surface.DrawRect(PositionX, PositionY, DrawWidth, 1)
		surface.DrawRect(PositionX, PositionY, 1, 20)
		surface.DrawRect(PositionX + DrawWidth, PositionY, 1, 20)
	surface.SetTextColor(Color(0, 0, 255, GR.Info.ServerTextColor.a))
		surface.SetTextPos(TextX, PositionY)
		surface.DrawText("GRate | ")
	surface.SetTextColor(GR.Info.ServerTextColor)
		surface.SetTextPos(TextX + GRateWidth, PositionY)
		surface.DrawText(GR.Info.ServerName)
	
	return PositionX, PositionY + 20, PositionX + DrawWidth, DrawWidth
end

function GR.DrawBody(PositionX, PositionY, TitleWidth, MidPoint)
	surface.SetTextColor(GR.Info.ServerTextColor)

	surface.SetDrawColor(GR.Info.ServerBGColor)
		surface.DrawRect(PositionX, PositionY, TitleWidth, 45)
	surface.SetDrawColor(GR.Info.ServerBorderColor)
		surface.DrawRect(PositionX + TitleWidth, PositionY, 1, 45)
		surface.DrawRect(PositionX, PositionY, 1, 45)
		surface.DrawRect(PositionX, PositionY + 45, TitleWidth + 1, 1)
		
		
	surface.SetDrawColor(GR.Info.ServerTextColor)
	if (Waiting) then
		local WaitPos = GR.WaitingPath[CurrentWaitingPosition]
			surface.DrawRect(WaitPos[1] - 1, WaitPos[2] - 1, 2, 2)
		WaitPos = GR.WaitingPath[CurrentWaitingPosition2]
			surface.DrawRect(WaitPos[1] - 1, WaitPos[2] - 1, 2, 2)
		WaitPos = GR.WaitingPath[CurrentWaitingPosition3]
			surface.DrawRect(WaitPos[1] - 1, WaitPos[2] - 1, 2, 2)
		WaitPos = GR.WaitingPath[CurrentWaitingPosition4]
			surface.DrawRect(WaitPos[1] - 1, WaitPos[2] - 1, 2, 2)
	else
		surface.DrawRect(PositionX + 4, PositionY + 15, TitleWidth-8, 2)
	end
	
	local Width = surface.GetTextSize(WaitMessage)
	PositionX = math.floor((ScrW() / 2) - (Width / 2))
			
	surface.SetTextPos(PositionX, PositionY + 25)
		surface.DrawText(WaitMessage)
end

function GR.Draw()
	if (!Drawing) then return end
	
	surface.SetFont(GR.Info.ServerFont)
	local PositionX, PositionY, EndPositionX, TitleWidth = GR.DrawTitle()
	local MidPoint = math.floor(PositionX + (TitleWidth / 2))
	
	if (!GR.WaitPath) then GR.GeneratePath(PositionX, PositionY, TitleWidth) end
	
	GR.DrawBody(PositionX, PositionY, TitleWidth, MidPoint)
end

function GR.Think()
	if (First) then
		First = false
		GR.ForceServerLoad()
	end

	if (FadingOut) and (FadingIn) then FadingIn = false end

	if (FadingOut) then	
		GR.Info.ServerBorderColor.a = math.Clamp(GR.Info.ServerBorderColor.a - 1, 0, 255)
		GR.Info.ServerTextColor.a = GR.Info.ServerBorderColor.a
		GR.Info.ServerBGColor.a = 150 * (GR.Info.ServerBorderColor.a/255)
		
		if (GR.Info.ServerBorderColor.a == 0) then
			FadingOut = false
			Drawing = false
		end
	elseif (FadingIn) then
		Drawing = true
		
		GR.Info.ServerBorderColor.a = math.Clamp(GR.Info.ServerBorderColor.a + 1, 0, 255)
		GR.Info.ServerTextColor.a = GR.Info.ServerBorderColor.a
		GR.Info.ServerBGColor.a = 150 * (GR.Info.ServerBorderColor.a/255)
		
		if (GR.Info.ServerBorderColor.a == 255) then
			FadingIn = false
		end
	end
end

function GR.Animate()
	if (Waiting) then
		CurrentWaitingPosition = CurrentWaitingPosition + 1
		if (CurrentWaitingPosition == 40) then
			CurrentWaitingPosition = 0
		end
		CurrentWaitingPosition2 = CurrentWaitingPosition2 + 1
		if (CurrentWaitingPosition2 == 40) then
			CurrentWaitingPosition2 = 0
		end
		CurrentWaitingPosition3 = CurrentWaitingPosition3 + 1
		if (CurrentWaitingPosition3 == 40) then
			CurrentWaitingPosition3 = 0
		end
		CurrentWaitingPosition4 = CurrentWaitingPosition4 + 1
		if (CurrentWaitingPosition4 == 40) then
			CurrentWaitingPosition4 = 0
		end
	end
end
timer.Create("GRates.Animation", 0.03,  0, GR.Animate)

function GR.ForceServerLoad()
	if (!GR.Info.ServerTicket) then
		if (LocalPlayer():IsValid()) and (LocalPlayer().ConCommand) then
			LocalPlayer():ConCommand("GRate.LoadInfo")
		end
	else
		timer.Destroy("GRates.ForceServerLoad")
	end
end
timer.Create("GRates.ForceServerLoad", 2, 0, GR.ForceServerLoad)

hook.Add("HUDPaint", "GRates.HUDPaint", GR.Draw)
hook.Add("Think", "GRates.Think", GR.Think)