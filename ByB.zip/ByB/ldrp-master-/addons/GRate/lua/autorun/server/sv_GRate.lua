AddCSLuaFile("autorun/client/cl_GRate.lua")
AddCSLuaFile("sh_GRate.lua")

GR = {}

include("sh_GRate.lua")
include("sv_Config.lua")

GR.Config.ChatRateCommand = GR.Config.ChatRateCommand:lower()
GR.Config.ChatVerifyCommand = GR.Config.ChatVerifyCommand:lower()

function GR.LoadInfo(p)
	if (p.GRateLoadLimit) and (p.GRateLoadLimit > CurTime()) then return end
	
	p.GRateLoadLimit = CurTime() + 2

	umsg.Start("GRate.Info", p)
		umsg.String(GR.Config.ServerTicket)
		umsg.String(GR.Config.ServerName)
		umsg.String(GR.Config.ServerFont)
		umsg.String(GR.Config.ServerBorderColor)
		umsg.String(GR.Config.ServerBGColor)
		umsg.String(GR.Config.ServerTextColor)
	umsg.End()
end
concommand.Add("GRate.LoadInfo", GR.LoadInfo)

function GR.CastVote(p)
	if (!p:IsPlayer()) then return end

	local SteamID = p:SteamID()
	local IP = p:IPAddress()
	
	local Colon = string.find(IP, ":")
	if (Colon) then IP = string.sub(IP, 1, Colon-1) end
	
	umsg.Start("GRate.Rating", p) umsg.End()
	
	GR.RequestPage("http://grate.pngskin.com/votelib/vote_sv.php?ticket=" .. GR.Config.ServerTicket .. "&clientip=" .. IP .. "&steamid=" .. p:SteamID(), function(Text) timer.Simple(.5, function()
		if (string.len(Text) != 40) then
			umsg.Start("GRate.Message", p)
				umsg.String(Text)
			umsg.End()
		else
			umsg.Start("GRate.CastVote", p)
				umsg.String(Text)
			umsg.End()
		end
	end) end)
end
concommand.Add("GRate.CastVote", GR.CastVote)

function GR.Verify(p)
	if (p:IsPlayer()) then
		umsg.Start("GRate.Waiting", p)
			umsg.String("Verifying server with GRate...")
		umsg.End()

		if (!p:IsSuperAdmin()) then timer.Simple(1.5, function()
			umsg.Start("GRate.Message", p)
				umsg.String("You're not a superadmin!")
			umsg.End()
			end) return
		end
	end
	
	GR.RequestPage("http://grate.pngskin.com/votelib/verify.php?ticket=" .. GR.Config.ServerTicket, function(Text) timer.Simple(1.5, function()
		if (Text == "Verification Succeeded") then
			local rl = RecipientFilter()
			rl:AddAllPlayers()
			if (p:IsPlayer()) then rl:RemovePlayer(p) end
			GR.ChatMessage("Server is now verified.", rl, true)
		end
		
		if (p:IsPlayer()) then
			umsg.Start("GRate.Message", p)
				umsg.String(Text)
			umsg.End()
		end
	end) end)
end
concommand.Add("GRate.Verify", GR.Verify)

function GR.PlayerSay(p, Text)
	Text = string.Explode(" ", Text)[1]:lower()
	if (Text:lower() == GR.Config.ChatRateCommand) then
		GR.CastVote(p)
		return ""
	elseif (Text == GR.Config.ChatVerifyCommand) then
		GR.Verify(p)
		return ""
	end
end
hook.Add("PlayerSay", "GRate.PlayerSay", GR.PlayerSay)

function GR.Advert()
	GR.ChatMessage("Like this server? Type " .. GR.Config.ChatRateCommand .. " to vote it up! Want to add your own server? Visit grate.pngskin.com!")
end
timer.Create("GRates.Advert", 300, 0, GR.Advert)

function GR.PlayerInitialSpawn(p)
	umsg.Start("GRate.IsOnServer", p) umsg.End()
end
hook.Add("PlayerInitialSpawn", "GRate.PlayerInitialSpawn", GR.PlayerInitialSpawn)