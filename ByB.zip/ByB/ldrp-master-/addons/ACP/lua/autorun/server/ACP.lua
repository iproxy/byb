-- ColdFusion Anti-Cheat

-- Enums
ACP_CONVAR_REPLICATED = 1
ACP_CONVAR_STATIC = 2
ACP_CONCOMMAND_EXIST = 3
ACP_CONVAR_EXIST = 3

ACP_LOG = 1
ACP_KICK = 2
ACP_BAN = 3

include("sn3_base_querycvar.lua")

CreateConVar("ACP_Enabled", "1")
CreateConVar("ACP_IgnoreAdmins", "0")
CreateConVar("ACP_IgnoreSuperAdmins", "0")
CreateConVar("ACP_bantime", "0")
CreateConVar("ACP_PrintToAdmins", "1")
CreateConVar("ACP_AlwaysLog", "1")
CreateConVar("ACP_AlwaysBan", "0")

local ACP_Convars = {}

function ACP_AddConvar( Name, flType, flResults, iDefault)
	local a = {}
	a.name = Name
	a.type = flType
	a.action = flResults
	if iDefault and flType == ACP_CONVAR_STATIC then
		a.default = iDefault
	end
	table.insert(ACP_Convars, a)
end

include("ACP_Convars.lua")

function FindPlayerByNetChannel( netchan )
	local adr = netchan:GetAddress():ToString()

	for k, v in pairs( player.GetAll() ) do
		if ( adr == v:IPAddress() ) then
			return v
		end
	end
end

local cvcheck_nr = 1
timer.Create("ACP.CvarCheck", 0.5, 0, function()
	if !tobool(GetConVarString("ACP_Enabled")) then return end
	
	if !player.GetAll()[cvcheck_nr] then 
		cvcheck_nr = 1 
		return 
	end
	
	ply = player.GetAll()[cvcheck_nr]
	
	if tobool(GetConVarString("ACP_IgnoreSuperAdmins")) and ply:IsSuperAdmin() then cvcheck_nr = cvcheck_nr + 1 return end
	if tobool(GetConVarString("ACP_IgnoreAdmins")) and ply:IsAdmin() then cvcheck_nr = cvcheck_nr + 1 return end
	if ply:IsBot() then cvcheck_nr = cvcheck_nr + 1 return end
	
	for k, cvcheck in pairs ( ACP_Convars ) do
		ply["ACP_COOKIE_" .. cvcheck.name] = ply:QueryConVarValue( cvcheck.name );
	end
	cvcheck_nr = cvcheck_nr + 1
end)

local function HandleFail(ply, cvcheck, val)
	if tobool(GetConVarString("ACP_IgnoreSuperAdmins")) and ply:IsSuperAdmin() then return end
	if tobool(GetConVarString("ACP_IgnoreAdmins")) and ply:IsAdmin() then return end
	
	local text = ""
	if (cvcheck.type == ACP_CONVAR_REPLICATED) or (cvcheck.type == ACP_CONVAR_STATIC) then
		text = "had " .. cvcheck.name .. " with value: " .. tostring(val)
	else
		text = "had concommand/convar " .. cvcheck.name .. "(status = " .. tostring(val) .. ")"
	end
	if (cvcheck.action == ACP_LOG) or tobool(GetConVarString("ACP_AlwaysLog")) then
		filex.Append("ACP/" .. string.gsub(ply:SteamID(), ":", "_") .. ".txt", ply:Name() .. " - [" .. ply:SteamID() .. "][" .. ply:IPAddress() .. "] " .. text .. ". On Gamemode: " .. GAMEMODE.Name .. " At: " .. os.date() .. "\n")
	end
	
	if tobool(GetConVarString("ACP_PrintToAdmins")) then
		for i, v in pairs(player.GetAll()) do
			if v:IsAdmin() then
				v:PrintMessage(HUD_PRINTTALK, "ACP: " .. ply:Name() .. " " .. text)
			end
		end
	end
	
	if (cvcheck.action == ACP_LOG) then return end
	if (cvcheck.action == ACP_KICK) then
		ply:Kick(text)
		return
	end
	if (cvcheck.action == ACP_BAN) or tobool(GetConVarString("ACP_AlwaysBan")) then
		if ULib and ULib.kickban then
			ULib:kickban( ply, tonumber(GetConVarString("ACP_bantime")), "ACP: " .. ply:Name() .. " " .. text, "Dicks" )
		elseif evolve and evolve.Ban then
			evolve:Ban( ply:UniqueID(), tonumber(GetConVarString("ACP_bantime")), "ACP: " .. ply:Name() .. " " .. text, 0 )
		else
			RunConsoleCommand("banid", GetConVarString("ACP_bantime"), ply:SteamID())
			ply:Kick("ACP: " .. ply:Name() .. " " .. text)
		end
	end
end

hook.Add( "RespondCvarValue", "ACP.CvarCheck", function( netchan, cookie, status, cvarname, cvarvalue )
	for k, cvcheck in pairs ( ACP_Convars ) do
		if string.lower(cvarname) == string.lower(cvcheck.name) then
			if cvcheck.type == ACP_CONVAR_REPLICATED then
				if tostring(cvarvalue) != GetConVarString( cvcheck.name ) then 
					local ply = FindPlayerByNetChannel( netchan )
					if ( ValidEntity( ply ) and cookie == ply["ACP_COOKIE_" .. cvcheck.name] ) then
						HandleFail(ply, cvcheck, cvarvalue)
					end
				end
				return
			end
			if cvcheck.type == ACP_CONVAR_STATIC then
				if tostring(cvarvalue) != tostring(cvcheck.default) then 
					local ply = FindPlayerByNetChannel( netchan )
					if ( ValidEntity( ply ) and cookie == ply["ACP_COOKIE_" .. cvcheck.name] ) then
						HandleFail(ply, cvcheck, cvarvalue)
					end
				end
				return
			end
			if cvcheck.type == ACP_CONCOMMAND_EXIST then
				if status != 1 then 
					local ply = FindPlayerByNetChannel( netchan )
					if ( ValidEntity( ply ) and cookie == ply["ACP_COOKIE_" .. cvcheck.name] ) then
						HandleFail(ply, cvcheck, status)
					end
				end
				return
			end
		end
	end
end)
print("ACP Loaded.")
