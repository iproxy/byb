/*---------------------------------------------------------
------mmmm---mmmm-aaaaaaaa----ddddddddd---------------------------------------->
     mmmmmmmmmmmm aaaaaaaaa   dddddddddd	  Name: Mad Cows Weapons
     mmm mmmm mmm aaa    aaa  ddd     ddd	  Author: Worshipper
    mmm  mmm  mmm aaaaaaaaaaa ddd     ddd	  Project Start: October 23th, 2009
    mmm       mmm aaa     aaa dddddddddd	  File: mad_npcs.lua
---mmm--------mmm-aaa-----aaa-ddddddddd---------------------------------------->
---------------------------------------------------------*/

/*
list.Set("NPCWeapons", "weapon_mad_57", "MAD COWS : FN FIVE-SEVEN")
list.Set("NPCWeapons", "weapon_mad_ak47", "MAD COWS : AK-47")
list.Set("NPCWeapons", "weapon_mad_alyxgun", "MAD COWS : ALYX GUN")
list.Set("NPCWeapons", "weapon_mad_ar2", "MAD COWS : AR-2")
list.Set("NPCWeapons", "weapon_mad_aug", "MAD COWS : STEYR AUG A1")
list.Set("NPCWeapons", "weapon_mad_awp", "MAD COWS : AI AWP")
list.Set("NPCWeapons", "weapon_mad_crossbow", "MAD COWS : HUNTING CROSSBOW")
list.Set("NPCWeapons", "weapon_mad_deagle", "MAD COWS : DESERT EAGLE")
list.Set("NPCWeapons", "weapon_mad_dual", "MAD COWS : DUAL PISTOLS")
list.Set("NPCWeapons", "weapon_mad_famas", "MAD COWS : FAMAS F1")
list.Set("NPCWeapons", "weapon_mad_flare", "MAD COWS : FLARE GUN")
list.Set("NPCWeapons", "weapon_mad_galil", "MAD COWS : GALIL SAR")
list.Set("NPCWeapons", "weapon_mad_g3", "MAD COWS : HK G3SG1 SNIPER")
list.Set("NPCWeapons", "weapon_mad_glock", "MAD COWS : GLOCK 18")
list.Set("NPCWeapons", "weapon_mad_grenadelauncher", "MAD COWS : GRENADE LAUNCHER")
list.Set("NPCWeapons", "weapon_mad_m3", "MAD COWS : BENELLI M3 SUPER 90")
list.Set("NPCWeapons", "weapon_mad_m4", "MAD COWS : M4A1")
list.Set("NPCWeapons", "weapon_mad_m249", "MAD COWS : M249 SAW")
list.Set("NPCWeapons", "weapon_mad_mac10", "MAD COWS : INGRAM MAC M10")
list.Set("NPCWeapons", "weapon_mad_mp5", "MAD COWS : HK MP-5A5")
list.Set("NPCWeapons", "weapon_mad_mp7", "MAD COWS : HK MP7A1")
list.Set("NPCWeapons", "weapon_mad_p90", "MAD COWS : FN P90")
list.Set("NPCWeapons", "weapon_mad_p228", "MAD COWS : SIG-SAUER P228")
list.Set("NPCWeapons", "weapon_mad_rpg", "MAD COWS : ROCKET LAUNCHER")
list.Set("NPCWeapons", "weapon_mad_scout", "MAD COWS : STEYR SCOUT SNIPER")
list.Set("NPCWeapons", "weapon_mad_sg550", "MAD COWS : SIG SG-550 SNIPER")
list.Set("NPCWeapons", "weapon_mad_sg552", "MAD COWS : SIG SG-552")
list.Set("NPCWeapons", "weapon_mad_spas", "MAD COWS : FRANCHI SPAS-12")
list.Set("NPCWeapons", "weapon_mad_tmp", "MAD COWS : STEYR TMP")
list.Set("NPCWeapons", "weapon_mad_ump", "MAD COWS : HK UMP-45")
list.Set("NPCWeapons", "weapon_mad_usp", "MAD COWS : HK USP")
list.Set("NPCWeapons", "weapon_mad_usp_match", "MAD COWS : HK USP MATCH")
list.Set("NPCWeapons", "weapon_mad_xm1014", "MAD COWS : BENELLI M4 SUPER 90")
*/
