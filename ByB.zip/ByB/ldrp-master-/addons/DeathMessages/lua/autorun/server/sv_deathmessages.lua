---------------------------------
---------------------------------
---- Made By Greyfox -----
---------------------------------
---------------------------------

AddCSLuaFile( "autorun/client/cl_deathmessages.lua" ) -- the clientside lua file 
  
--Serverside below add this to some serverside script like your gamemodes init.lua 
  
function SendDeathPanel(pl,cmd,args) 
pl:ConCommand("DrawDeathMsg") -- or RunConsoleCommand("DrawDeathMsg") 
end 
hook.Add("PlayerDeath", "DeathPanel", SendDeathPanel) 
  
-- more serverside stuff, this lets the player spawn! 
function DeathMessageSpawn(pl,cmd,args) 
if( !pl:Alive() ) then 
    pl:Spawn() 
end 
end 
concommand.Add("dmspawn",DeathMessageSpawn)
 
------------------------------------------------ 
